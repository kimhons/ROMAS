# Section 3.3: Cardiovascular System Physiology

## Learning Objectives

Upon completion of this section, the learner should be able to:

*   Describe the structure and function of the heart chambers, valves, and major blood vessels (aorta, vena cavae, pulmonary artery, pulmonary veins).
*   Outline the pathway of blood flow through the pulmonary and systemic circuits.
*   Explain the electrical conduction system of the heart (SA node, AV node, Bundle of His, Purkinje fibers) and its relation to the electrocardiogram (ECG).
*   Describe the phases of the cardiac cycle (atrial systole, ventricular systole, diastole) and relate them to pressure and volume changes in the heart chambers and valve function.
*   Define cardiac output, stroke volume, and heart rate, and explain the factors that regulate them (preload, afterload, contractility, autonomic nervous system).
*   Explain the principles of hemodynamics, including blood pressure, blood flow, resistance, and their relationships (e.g., Poiseuille's Law).
*   Describe the mechanisms involved in the regulation of blood pressure, including neural (baroreceptor reflex) and hormonal (RAAS, ADH) controls.
*   Differentiate between arteries, arterioles, capillaries, venules, and veins based on structure and function.
*   Relate the physiology of the cardiovascular system to medical physics applications, such as cardiac imaging (ECG-gated CT/MRI, SPECT/PET, ultrasound), hemodynamic monitoring, and considerations in radiation therapy (cardiac toxicity).

## Introduction

The cardiovascular system, comprising the heart, blood vessels, and blood, is responsible for transporting oxygen, nutrients, hormones, and immune cells throughout the body, while also removing metabolic waste products like carbon dioxide. Its continuous and efficient operation is vital for maintaining homeostasis and supporting the function of all other organ systems. For medical physicists, a solid understanding of cardiovascular physiology is essential for interpreting various imaging modalities that visualize the heart and blood vessels (e.g., echocardiography, cardiac MRI, CT angiography, nuclear cardiology studies), understanding physiological motion artifacts, implementing techniques like ECG gating, and appreciating the potential impact of radiation therapy on cardiac structures. This section covers the fundamental principles of heart function, the cardiac cycle, hemodynamics, and blood pressure regulation, aligning with foundational knowledge expectations (CAMPEP/ABR).

## The Heart: Structure and Function

The heart is a four-chambered muscular pump located in the thoracic cavity.

### Chambers and Valves
*   **Atria (Right and Left):** Receiving chambers. The right atrium receives deoxygenated blood from the body (via superior and inferior vena cavae), and the left atrium receives oxygenated blood from the lungs (via pulmonary veins).
*   **Ventricles (Right and Left):** Pumping chambers. The right ventricle pumps deoxygenated blood to the lungs (via pulmonary artery), and the left ventricle pumps oxygenated blood to the rest of the body (via aorta). The left ventricular wall is significantly thicker due to the higher pressure required for systemic circulation.
*   **Valves:** Ensure unidirectional blood flow:
    *   **Atrioventricular (AV) Valves:** Between atria and ventricles (Tricuspid valve on the right, Mitral/Bicuspid valve on the left). Prevent backflow into atria during ventricular contraction.
    *   **Semilunar Valves:** Between ventricles and major arteries (Pulmonary valve between right ventricle and pulmonary artery, Aortic valve between left ventricle and aorta). Prevent backflow into ventricles during ventricular relaxation.

`[IMAGE PLACEHOLDER: Diagram of heart anatomy showing the four chambers, valves, and major vessels like aorta, vena cavae, pulmonary artery, and pulmonary veins.]`

### Blood Flow Circuits
1.  **Pulmonary Circuit:** Right side of the heart pumps deoxygenated blood to the lungs for gas exchange (CO2 unloaded, O2 loaded), and oxygenated blood returns to the left side of the heart.
2.  **Systemic Circuit:** Left side of the heart pumps oxygenated blood to all body tissues, and deoxygenated blood returns to the right side of the heart.

`[IMAGE PLACEHOLDER: Diagram illustrating both the pulmonary and systemic circulation pathways, showing the flow of oxygenated and deoxygenated blood through the heart, lungs, and body.]`

### Cardiac Conduction System
The heart possesses an intrinsic electrical conduction system that coordinates its rhythmic contractions:
1.  **Sinoatrial (SA) Node:** Located in the right atrium; the heart's natural pacemaker, initiating electrical impulses at a rate of ~60-100 bpm.
2.  **Atrioventricular (AV) Node:** Located at the junction of atria and ventricles; delays the impulse slightly, allowing atria to contract fully before ventricles.
3.  **Bundle of His (AV Bundle):** Conducts the impulse from the AV node into the interventricular septum.
4.  **Right and Left Bundle Branches:** Carry the impulse down the septum towards the apex.
5.  **Purkinje Fibers:** Spread the impulse rapidly throughout the ventricular myocardium, causing coordinated ventricular contraction.

`[IMAGE PLACEHOLDER: Diagram showing the cardiac conduction system pathway, including the SA node, AV node, Bundle of His, bundle branches, and Purkinje fibers within the heart structure.]`

*Electrocardiogram (ECG/EKG):* A recording of the heart's electrical activity detected on the body surface. Key components include:
*   **P wave:** Atrial depolarization.
*   **QRS complex:** Ventricular depolarization (masks atrial repolarization).
*   **T wave:** Ventricular repolarization.

`[IMAGE PLACEHOLDER: Diagram of a standard ECG waveform, labeling the P wave, QRS complex, and T wave, and indicating the corresponding electrical events (atrial depolarization, ventricular depolarization, ventricular repolarization).]`

*Practical Example:* ECG gating is crucial in cardiac imaging (CT, MRI, SPECT) to acquire images during specific phases of the cardiac cycle, minimizing motion artifacts and allowing functional assessment (e.g., ejection fraction calculation).

## The Cardiac Cycle

This refers to the sequence of events occurring during one heartbeat (~0.8 seconds at 75 bpm).

1.  **Ventricular Filling (Mid-to-Late Diastole):** AV valves are open, semilunar valves are closed. Blood flows passively from atria into ventricles. Atrial systole (contraction) then occurs, pushing the final volume of blood into the ventricles (atrial kick).
2.  **Ventricular Systole:**
    *   **Isovolumetric Contraction:** Ventricles begin to contract, increasing pressure. AV valves close (producing the first heart sound, S1). Ventricular pressure rises rapidly, but volume remains constant as semilunar valves are still closed.
    *   **Ventricular Ejection:** Ventricular pressure exceeds pressure in the aorta/pulmonary artery, forcing semilunar valves open. Blood is ejected from ventricles into the major arteries. Ventricular volume decreases.
3.  **Isovolumetric Relaxation (Early Diastole):** Ventricles relax, pressure falls. Semilunar valves close (producing the second heart sound, S2) when ventricular pressure drops below aortic/pulmonary artery pressure. Both AV and semilunar valves are closed; ventricular volume remains constant.
4.  **Ventricular Filling (Early Diastole):** Ventricular pressure drops below atrial pressure, AV valves open, and passive ventricular filling begins again.

Pressure and volume changes throughout the cycle can be visualized using Wiggers diagrams or pressure-volume loops.

`[IMAGE PLACEHOLDER: Wiggers diagram illustrating the relationship between ECG, atrial pressure, ventricular pressure, aortic pressure, ventricular volume, and heart sounds throughout the cardiac cycle.]`

## Cardiac Output and Regulation

**Cardiac Output (CO):** The volume of blood pumped by each ventricle per minute.
CO = Heart Rate (HR) × Stroke Volume (SV)
(Typical resting CO ≈ 5 L/min)

**Heart Rate (HR):** Number of beats per minute. Primarily regulated by the autonomic nervous system:
*   **Sympathetic:** Increases HR (positive chronotropy).
*   **Parasympathetic (Vagus nerve):** Decreases HR (negative chronotropy).

**Stroke Volume (SV):** The volume of blood ejected by each ventricle per beat.
SV = End-Diastolic Volume (EDV) - End-Systolic Volume (ESV)
(Typical resting SV ≈ 70 mL)

SV is influenced by:
*   **Preload:** The degree of stretch of ventricular muscle fibers at the end of diastole (related to EDV). Increased preload generally increases SV (Frank-Starling mechanism).
*   **Afterload:** The pressure the ventricle must overcome to eject blood (related to aortic/pulmonary artery pressure). Increased afterload decreases SV.
*   **Contractility (Inotropy):** The intrinsic strength of cardiac muscle contraction, independent of preload. Sympathetic stimulation increases contractility (positive inotropy); certain drugs or conditions can decrease it (negative inotropy).

## Hemodynamics: Blood Vessels, Flow, Pressure, and Resistance

Hemodynamics describes the physical principles governing blood flow.

### Blood Vessel Structure and Function
*   **Arteries:** Carry blood away from the heart; thick, elastic walls to withstand high pressure.
*   **Arterioles:** Smaller arteries; major site of vascular resistance, regulating blood flow into capillary beds via smooth muscle contraction/relaxation.
*   **Capillaries:** Microscopic vessels; thin walls (single endothelial layer) optimized for exchange of gases, nutrients, and wastes between blood and tissues.
*   **Venules:** Small veins; collect blood from capillaries.
*   **Veins:** Carry blood towards the heart; thinner walls, lower pressure than arteries; contain valves to prevent backflow, especially in limbs. Act as a blood reservoir.

### Blood Flow, Pressure, and Resistance
*   **Blood Flow (Q):** Volume of blood moving past a point per unit time (analogous to current).
*   **Blood Pressure (BP):** Force exerted by blood against the vessel wall (analogous to voltage). Typically measured as systolic/diastolic pressure in large arteries (e.g., 120/80 mmHg).
*   **Resistance (R):** Opposition to blood flow (analogous to electrical resistance).

Relationship: Q = ΔP / R (Ohm's Law applied to fluid dynamics)
Where ΔP is the pressure difference driving flow.

Resistance is determined primarily by:
*   **Vessel Radius:** Most important factor. Resistance is inversely proportional to the radius to the fourth power (R ∝ 1/r⁴) - **Poiseuille's Law**. Small changes in arteriole radius cause large changes in resistance and flow.
*   **Vessel Length:** Resistance is directly proportional to length.
*   **Blood Viscosity:** Resistance is directly proportional to viscosity (influenced by hematocrit).

### Blood Pressure Regulation
Maintaining adequate blood pressure is crucial for tissue perfusion.
*   **Short-Term Regulation (Neural):**
    *   **Baroreceptor Reflex:** Stretch receptors in the aorta and carotid arteries detect changes in BP. Signals sent to the brainstem cardiovascular center trigger autonomic adjustments to HR, contractility, and vascular resistance to restore normal BP.

`[IMAGE PLACEHOLDER: Diagram illustrating the baroreceptor reflex arc, showing receptors in the aorta/carotid arteries, afferent pathways to the brainstem, efferent sympathetic/parasympathetic pathways, and effects on heart rate, contractility, and vessel diameter.]`

*   **Long-Term Regulation (Hormonal/Renal):**
    *   **Renin-Angiotensin-Aldosterone System (RAAS):** Activated by low BP. Leads to vasoconstriction (Angiotensin II) and increased sodium/water retention by kidneys (Aldosterone), increasing blood volume and BP.
    *   **Antidiuretic Hormone (ADH):** Released in response to low BP or high blood osmolarity; promotes water reabsorption by kidneys, increasing blood volume and BP.
    *   **Atrial Natriuretic Peptide (ANP):** Released by atria in response to high BP; promotes sodium/water excretion, vasodilation, lowering blood volume and BP.

*Practical Example:* Understanding hemodynamics is vital for interpreting Doppler ultrasound measurements of blood flow velocity and direction, used to detect stenosis (narrowing) or occlusion in arteries (e.g., carotid artery ultrasound).

*Practical Example:* Radiation therapy to the chest can cause late cardiac effects, including pericarditis, coronary artery disease, valvular dysfunction, and cardiomyopathy. Dose constraints to the heart and its substructures (e.g., left ventricle, coronary arteries) are critical in treatment planning, particularly for left-sided breast cancer or mediastinal lymphoma.

> ## **Key Points**
> 
> *   The heart pumps blood through **pulmonary** (lungs) and **systemic** (body) circuits, with valves ensuring unidirectional flow.
> *   The **cardiac conduction system** (SA node, AV node, etc.) coordinates heartbeats, reflected in the ECG.
> *   The **cardiac cycle** involves phases of filling and ejection driven by pressure changes and valve movements.
> *   **Cardiac output** (CO = HR × SV) is regulated by autonomic control of heart rate and factors affecting stroke volume (preload, afterload, contractility).
> *   **Hemodynamics** relates blood flow, pressure, and resistance (Q = ΔP / R), with vessel radius being the primary determinant of resistance (Poiseuille's Law).
> *   **Blood pressure** is regulated short-term by the baroreceptor reflex and long-term by hormonal systems (RAAS, ADH, ANP) acting on blood volume and vascular tone.
> *   Knowledge of cardiovascular physiology is essential for **cardiac imaging**, ECG gating, and understanding **radiation-induced cardiac toxicity**.

## Assessment Questions

1.  **Which valve prevents backflow of blood from the left ventricle into the left atrium during ventricular systole?**
    (A) Aortic valve
    (B) Pulmonary valve
    (C) Tricuspid valve
    (D) Mitral (Bicuspid) valve

2.  **In a standard ECG, what does the QRS complex represent?**
    (A) Atrial depolarization
    (B) Ventricular depolarization
    (C) Atrial repolarization
    (D) Ventricular repolarization

3.  **According to the Frank-Starling mechanism, an increase in end-diastolic volume (preload) leads to:**
    (A) A decrease in stroke volume
    (B) An increase in stroke volume
    (C) A decrease in heart rate
    (D) An increase in afterload

4.  **If the radius of an arteriole is halved, how does the resistance to blood flow through that arteriole change (assuming other factors remain constant)?**
    (A) It is halved
    (B) It is doubled
    (C) It increases by a factor of 4
    (D) It increases by a factor of 16

5.  **Describe the role of the baroreceptor reflex in the short-term regulation of blood pressure.**

### Solutions

1.  **(D) Mitral (Bicuspid) valve.** The mitral valve is the AV valve between the left atrium and left ventricle.
2.  **(B) Ventricular depolarization.** This large electrical event corresponds to the contraction impulse spreading through the ventricles.
3.  **(B) An increase in stroke volume.** The Frank-Starling law states that the heart pumps out the volume it receives; increased stretch (preload) leads to a more forceful contraction and higher SV, up to a physiological limit.
4.  **(D) It increases by a factor of 16.** Resistance is inversely proportional to the radius to the fourth power (R ∝ 1/r⁴). If r is halved (1/2), R increases by 1 / (1/2)⁴ = 1 / (1/16) = 16.
5.  **Answer:** Baroreceptors (stretch receptors in the aorta and carotid arteries) detect changes in blood pressure. If BP increases, they increase their firing rate, signaling the brainstem cardiovascular center to increase parasympathetic activity (decreasing HR) and decrease sympathetic activity (decreasing HR, contractility, and causing vasodilation), thus lowering BP. If BP decreases, the opposite occurs: decreased baroreceptor firing leads to increased sympathetic and decreased parasympathetic output, raising BP back towards normal.

## Conclusion

The cardiovascular system's intricate physiology ensures the constant delivery of oxygen and nutrients vital for life. From the coordinated electrical and mechanical events of the cardiac cycle to the complex regulation of blood pressure and flow through a vast network of vessels, this system demonstrates remarkable adaptability. Understanding these principles is indispensable for medical physicists involved in cardiovascular imaging, motion management techniques like ECG gating, and the safe delivery of radiation therapy near the heart and major vessels. This knowledge underpins the ability to interpret physiological data, optimize imaging protocols, and contribute to minimizing treatment-related cardiac complications.

## References

*   Hall, J. E., & Hall, M. E. (2020). *Guyton and Hall Textbook of Medical Physiology* (14th ed.). Elsevier.
*   Mohrman, D. E., & Heller, L. J. (2018). *Cardiovascular Physiology* (9th ed.). McGraw-Hill Education.
*   Relevant CAMPEP Graduate Program Standards for Medical Physics.

