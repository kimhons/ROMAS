# Comprehensive Curriculum: Medical Physics Part 1

## General Content

### Section 1: Atomic / Nuclear Physics, Sources of Radiation, Interaction of Radiation with Matter

#### Subsection 1.1: Basic Atomic and Nuclear Physics

**Overview:**
This subsection provides a comprehensive foundation in atomic and nuclear physics essential for understanding radiation interactions, detection, and applications in medical physics. It covers atomic structure, nuclear properties, binding energy, and the fundamental forces governing nuclear stability and interactions.

**Learning Objectives:**
After completing this subsection, you will be able to:
- Describe the structure of atoms and nuclei, including subatomic particles and their properties
- Explain nuclear binding energy, mass defect, and their relationship to nuclear stability
- Calculate nuclear binding energy and interpret binding energy per nucleon curves
- Identify factors affecting nuclear stability and predict likely decay modes
- Apply quantum mechanical principles to explain atomic and nuclear energy levels
- Relate atomic and nuclear structure to radiation emission and interaction processes
- Discuss the clinical relevance of atomic and nuclear physics in medical applications

**Estimated Completion Time:** 120 minutes

**Key Points for Understanding:**
- Atoms consist of a nucleus (containing protons and neutrons) surrounded by electrons
- Nuclear forces overcome electrostatic repulsion to maintain nuclear stability
- The binding energy curve explains nuclear stability and energy release in nuclear reactions
- Quantum mechanics governs atomic and nuclear energy states and transitions
- Nuclear properties directly influence radioactive decay modes and radiation characteristics
- Understanding atomic and nuclear physics is fundamental to all aspects of medical physics

#### Content Section 1: Atomic Structure

##### Subsection 1.1.1: Fundamental Particles and Atomic Components

The atom consists of three primary subatomic particles:

**Electrons:**
- Charge: -1.602 × 10^-19 C (negative elementary charge)
- Rest mass: 9.109 × 10^-31 kg (0.511 MeV/c²)
- Spin: 1/2 (fermion)
- Arranged in shells and subshells around the nucleus
- Determine chemical properties and electron-based interactions

**Protons:**
- Charge: +1.602 × 10^-19 C (positive elementary charge)
- Rest mass: 1.673 × 10^-27 kg (938.27 MeV/c²)
- Spin: 1/2 (fermion)
- Located in the nucleus
- Number determines the element (atomic number Z)

**Neutrons:**
- Charge: 0 (neutral)
- Rest mass: 1.675 × 10^-27 kg (939.57 MeV/c²)
- Spin: 1/2 (fermion)
- Located in the nucleus
- Contribute to isotope determination and nuclear stability

**Atomic Structure Parameters:**
- **Atomic Number (Z)**: Number of protons in the nucleus
- **Mass Number (A)**: Total number of nucleons (protons + neutrons)
- **Neutron Number (N)**: Number of neutrons (N = A - Z)
- **Nuclide Notation**: ₂₄He (or sometimes ₂He⁴)

**Isotopes, Isobars, and Isotones:**
- **Isotopes**: Same Z, different N (e.g., ¹H, ²H, ³H)
- **Isobars**: Same A, different Z (e.g., ¹⁴C, ¹⁴N)
- **Isotones**: Same N, different Z (e.g., ¹³C, ¹⁴N)

**Clinical Relevance:**
Understanding isotopes is crucial in nuclear medicine and radiation therapy. For example:
- ¹²C vs. ¹³C vs. ¹⁴C: While ¹²C and ¹³C are stable, ¹⁴C is radioactive (β⁻ emitter, T₁/₂ = 5730 years)
- ¹⁶O vs. ¹⁸O: ¹⁸O is used to produce ¹⁸F for PET imaging via the ¹⁸O(p,n)¹⁸F reaction
- ⁹⁹Mo vs. ⁹⁹ᵐTc: The parent-daughter relationship enables technetium generators for nuclear medicine

##### Subsection 1.1.2: Quantum Mechanical Model of the Atom

The quantum mechanical model describes electrons as wave functions with probabilistic distributions around the nucleus:

**Quantum Numbers:**
- **Principal Quantum Number (n)**: Determines the energy level or shell (n = 1, 2, 3, ...)
- **Angular Momentum Quantum Number (l)**: Determines the subshell shape (l = 0, 1, ..., n-1)
  - l = 0: s-orbital (spherical)
  - l = 1: p-orbital (dumbbell-shaped)
  - l = 2: d-orbital (complex shapes)
  - l = 3: f-orbital (more complex shapes)
- **Magnetic Quantum Number (m₁)**: Determines the orbital orientation (m₁ = -l, ..., 0, ..., +l)
- **Spin Quantum Number (m_s)**: Describes electron spin (m_s = +1/2 or -1/2)

**Pauli Exclusion Principle:**
No two electrons in an atom can have identical sets of quantum numbers. This limits the number of electrons in each shell and subshell.

**Electron Configuration:**
Electrons fill orbitals according to the Aufbau principle, Pauli exclusion principle, and Hund's rule. The electron configuration affects:
- Chemical properties and bonding
- X-ray emission spectra
- Atomic energy levels and transitions

**Energy Levels and Transitions:**
- Electrons occupy discrete energy levels
- Transitions between levels result in emission or absorption of photons
- Energy of emitted/absorbed photon: E = hν = E₂ - E₁
- Characteristic X-rays result from electron transitions between atomic shells

**Clinical Application: X-ray Production in Radiography**
In diagnostic X-ray tubes, electrons accelerated by a potential difference (kVp) strike a target anode. Two types of X-rays are produced:
1. **Bremsstrahlung (braking radiation)**: Continuous spectrum produced when electrons decelerate in the electric field of target nuclei
2. **Characteristic X-rays**: Discrete energy peaks produced when outer-shell electrons fill inner-shell vacancies

The knowledge of atomic structure allows optimization of:
- kVp selection for appropriate tissue penetration
- Filtration to remove low-energy photons
- Target material selection (e.g., tungsten, molybdenum, rhodium)

#### Content Section 2: Nuclear Structure and Properties

##### Subsection 1.1.3: Nuclear Size, Density, and Shape

**Nuclear Radius:**
The nuclear radius can be approximated by:
R = r₀A^(1/3)

Where:
- R is the nuclear radius
- r₀ is approximately 1.2-1.5 × 10^-15 m (1.2-1.5 fm)
- A is the mass number

This relationship indicates that nuclear volume is proportional to A, meaning nuclear density is approximately constant across all nuclei.

**Nuclear Density:**
Nuclear density is extremely high, approximately 2.3 × 10^17 kg/m³. This density is relevant in:
- Radiation interaction probabilities
- Nuclear medicine tracer design
- Understanding neutron stars and other astrophysical phenomena

**Nuclear Shape:**
While often approximated as spherical, nuclei can have:
- Spherical shape (magic numbers of protons/neutrons)
- Deformed shapes (ellipsoidal)
- Dynamic shape changes during excitation

**Clinical Relevance:**
Nuclear size affects:
- Cross-sections for nuclear reactions used in radionuclide production
- Probability of interaction for radiation therapy beams
- Design of targeted radionuclide therapies

##### Subsection 1.1.4: Nuclear Forces and Stability

**Fundamental Forces in the Nucleus:**
Four fundamental forces govern nuclear behavior:
1. **Strong Nuclear Force**: Attractive force between nucleons, extremely strong but short-range (~1 fm)
2. **Electromagnetic Force**: Repulsive force between protons, long-range
3. **Weak Nuclear Force**: Governs beta decay, very short-range
4. **Gravitational Force**: Negligible at nuclear scale

**Nuclear Stability Factors:**
Several factors determine nuclear stability:
- **Neutron-to-Proton Ratio (N/Z)**: Stable light nuclei have N ≈ Z; heavier stable nuclei have N > Z
- **Pairing Effects**: Even-even nuclei (even Z, even N) are more stable than odd-odd nuclei
- **Magic Numbers**: Nuclei with "magic numbers" of protons or neutrons (2, 8, 20, 28, 50, 82, 126) have enhanced stability
- **Nuclear Shell Structure**: Similar to electron shells, nucleons arrange in energy levels

**The Valley of Stability:**
When plotting N vs. Z, stable nuclei form a "valley of stability":
- Light nuclei (Z < 20): Stable nuclei have N ≈ Z
- Medium to heavy nuclei: Stable nuclei have N > Z (due to increasing Coulomb repulsion)
- No stable nuclei exist beyond Z = 83 (bismuth)

**Predicting Decay Modes:**
The position relative to the valley of stability helps predict likely decay modes:
- Nuclei with excess neutrons (right of stability): β⁻ decay
- Nuclei with excess protons (left of stability): β⁺ decay or electron capture
- Very heavy nuclei (Z > 83): α decay
- Nuclei far from stability: Neutron or proton emission

**Clinical Application: Radionuclide Selection in Nuclear Medicine**
Understanding nuclear stability helps in selecting appropriate radionuclides:
- ⁹⁹ᵐTc is metastable with ideal properties for SPECT imaging (140 keV γ, 6-hour half-life)
- ¹⁸F has suitable decay characteristics for PET (β⁺ decay, 110-minute half-life)
- ¹³¹I has mixed emissions (β⁻ and γ) useful for both therapy and imaging
- ²²³Ra mimics calcium for bone metastasis treatment (α emitter)

##### Subsection 1.1.5: Nuclear Binding Energy

**Mass Defect:**
The mass of a nucleus is less than the sum of its constituent nucleons' masses. This mass difference (Δm) is converted to binding energy according to Einstein's E = mc².

Mass defect: Δm = [Z·m_p + (A-Z)·m_n] - m_nucleus

Where:
- m_p is the proton mass
- m_n is the neutron mass
- m_nucleus is the actual nuclear mass

**Binding Energy:**
The binding energy (BE) is the energy required to completely separate a nucleus into its constituent nucleons:

BE = Δm · c² = [Z·m_p + (A-Z)·m_n - m_nucleus] · c²

Often expressed in MeV using the conversion 1 u = 931.494 MeV/c².

**Binding Energy per Nucleon:**
The binding energy per nucleon (BE/A) indicates the average energy binding each nucleon:

BE/A = BE / A

**Binding Energy Curve:**
The plot of BE/A versus A shows:
- Low BE/A for very light nuclei
- Increasing BE/A up to A ≈ 56 (iron)
- Gradual decrease for heavier nuclei
- Maximum at iron (Fe) and nickel (Ni) isotopes (~8.8 MeV/nucleon)

This curve explains why:
- Fusion of light nuclei releases energy (increasing BE/A)
- Fission of heavy nuclei releases energy (increasing BE/A)
- Iron-group elements are the most stable (maximum BE/A)

**Worked Example: Calculating Binding Energy**
Calculate the binding energy and binding energy per nucleon for ¹⁶O.

Given:
- Mass of ¹⁶O nucleus = 15.994915 u
- Proton mass = 1.007825 u
- Neutron mass = 1.008665 u

Solution:
1. Calculate mass defect:
   Δm = [8 × 1.007825 u + 8 × 1.008665 u] - 15.994915 u
   Δm = [8.06260 u + 8.06932 u] - 15.994915 u
   Δm = 16.13192 u - 15.994915 u
   Δm = 0.137005 u

2. Convert to energy (1 u = 931.494 MeV/c²):
   BE = 0.137005 u × 931.494 MeV/c²/u
   BE = 127.62 MeV

3. Calculate binding energy per nucleon:
   BE/A = 127.62 MeV / 16
   BE/A = 7.98 MeV/nucleon

This high BE/A indicates ¹⁶O is a very stable nucleus, consistent with its abundance in nature.

**Clinical Relevance:**
Understanding binding energy is crucial for:
- Predicting energy release in nuclear reactions
- Designing cyclotron targets for radionuclide production
- Calculating Q-values for decay processes
- Understanding the biological effects of different radiation types

#### Content Section 3: Nuclear Models

##### Subsection 1.1.6: Liquid Drop Model

The liquid drop model treats the nucleus as an incompressible fluid of nucleons, explaining:
- Nuclear binding energy trends
- Nuclear fission process
- Collective excitations

**Semi-Empirical Mass Formula (SEMF):**
The binding energy can be calculated using the SEMF:

BE = a_v·A - a_s·A^(2/3) - a_c·Z(Z-1)/A^(1/3) - a_a·(N-Z)²/A + δ

Where:
- a_v: Volume term (~15.5 MeV) - attractive strong force
- a_s: Surface term (~16.8 MeV) - correction for nucleons at surface
- a_c: Coulomb term (~0.72 MeV) - repulsive electrostatic force
- a_a: Asymmetry term (~23 MeV) - preference for N=Z
- δ: Pairing term - extra stability for even-even nuclei

**Clinical Application: Understanding Fission in Brachytherapy Sources**
The liquid drop model helps explain the fission process in ²⁵²Cf, used in some specialized brachytherapy applications:
- Spontaneous fission occurs when Coulomb repulsion overcomes nuclear attraction
- Fission fragments have excess neutrons, leading to subsequent neutron emission
- Understanding this process is crucial for radiation protection and dosimetry

##### Subsection 1.1.7: Nuclear Shell Model

The nuclear shell model is analogous to the atomic shell model, treating nucleons as moving in a potential well with discrete energy levels:
- Explains "magic numbers" of enhanced stability (2, 8, 20, 28, 50, 82, 126)
- Predicts nuclear spin and magnetic moments
- Explains isomeric states important in nuclear medicine

**Clinical Relevance:**
The shell model explains why certain nuclei are particularly suitable for medical applications:
- ⁹⁹ᵐTc's metastable state (isomeric transition) results from nuclear shell structure
- Magic number nuclei often have favorable half-lives for medical applications
- Nuclear spin influences MRI properties of certain nuclei (e.g., ¹H, ¹³C, ¹⁹F)

#### Content Section 4: Clinical Applications and Relevance

##### Subsection 1.1.8: Applications in Medical Physics

**Diagnostic Radiology:**
- X-ray production depends on atomic structure and electron transitions
- Attenuation coefficients relate to electron density and atomic number
- Contrast agents exploit K-edge absorption based on atomic structure

**Nuclear Medicine:**
- Radionuclide selection based on nuclear stability and decay properties
- PET relies on positron emission from proton-rich nuclei
- SPECT utilizes gamma emission from metastable states
- Radiopharmaceutical design considers nuclear properties

**Radiation Therapy:**
- Linear energy transfer (LET) depends on particle type and energy
- Relative biological effectiveness (RBE) relates to energy deposition patterns
- Brachytherapy source selection based on decay properties
- Proton and heavy ion therapy exploit Bragg peak related to nuclear interactions

**Radiation Protection:**
- Shielding design based on radiation interaction mechanisms
- Radiation weighting factors account for different biological effects
- Decay chains must be considered for some radionuclides

**Case Study: Technetium-99m in Nuclear Medicine**
⁹⁹ᵐTc is the most widely used radionuclide in nuclear medicine, accounting for approximately 80% of all procedures. Its ideal properties stem directly from its nuclear structure:

1. **Metastable State**: The "m" indicates a metastable excited nuclear state with 142.7 keV above ground state
2. **Decay Mode**: Isomeric transition (IT) with emission of 140 keV gamma photons (89%)
3. **Half-Life**: 6.01 hours - long enough for procedures but short enough to minimize patient dose
4. **Chemistry**: Forms complexes with various ligands for different organ targeting
5. **Production**: Generated from ⁹⁹Mo (T₁/₂ = 66 hours) in a generator system

The nuclear properties of ⁹⁹ᵐTc make it ideal for SPECT imaging:
- Gamma energy (140 keV) is high enough to escape the body but low enough for efficient detection
- No particulate radiation minimizes patient dose
- Half-life allows for preparation, quality control, and imaging within a clinical workday
- Generator production provides on-site availability without a cyclotron

#### Assessment Questions:

1. **Multiple Choice**: Which of the following statements about nuclear binding energy is correct?
   a) The binding energy per nucleon is highest for uranium
   b) Fusion of heavy elements releases energy
   c) The binding energy curve explains why both fusion and fission can release energy
   d) The binding energy is directly proportional to the mass number for all nuclei
   e) Nuclei with magic numbers have lower binding energy per nucleon
   *(Answer: c)*

2. **Calculation**: Calculate the binding energy per nucleon for ⁴He (alpha particle) given the following masses: ⁴He nucleus = 4.0026 u, proton = 1.0078 u, neutron = 1.0087 u. (1 u = 931.494 MeV/c²)
   *(Answer: BE = [(2×1.0078 + 2×1.0087) - 4.0026] × 931.494 = 28.3 MeV; BE/A = 28.3/4 = 7.07 MeV/nucleon)*

3. **Short Answer**: Explain why stable heavy nuclei have more neutrons than protons, while light stable nuclei have approximately equal numbers.
   *(Answer: As the number of protons increases, the Coulomb repulsion between protons increases. Additional neutrons provide strong nuclear force without adding to Coulomb repulsion, helping stabilize the nucleus. Light nuclei have less Coulomb repulsion, so N≈Z is sufficient for stability.)*

4. **Clinical Application**: A nuclear medicine department uses a ⁹⁹Mo/⁹⁹ᵐTc generator. Explain how the nuclear properties of these isotopes make this generator system practical for clinical use.
   *(Answer: ⁹⁹Mo has a suitable half-life (66 hours) allowing weekly generator delivery. ⁹⁹ᵐTc has ideal imaging properties (140 keV gamma, 6-hour half-life). The significant half-life difference allows transient equilibrium to establish, permitting daily "milking" of the generator. The chemical difference between molybdate and pertechnetate ions enables simple separation by elution.)*

5. **Concept Question**: How does understanding nuclear binding energy help explain the biological effectiveness of different radiation types?
   *(Answer: Nuclear binding energy concepts help explain why different radiation types deposit energy differently. Alpha particles and neutrons can cause nuclear recoil and displacement, leading to dense ionization tracks and higher biological effectiveness compared to photons. The energy required to displace atoms in biological molecules relates to binding energies, affecting the types of damage produced.)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection addresses core concepts outlined in the ABR Medical Physics Part 1 exam blueprint under "General Content: Section 1 - Atomic/Nuclear Physics, Sources of Radiation, Interaction of Radiation with Matter." The material covers fundamental atomic and nuclear physics with direct applications to medical physics practice, meeting CAMPEP curriculum requirements for graduate education in medical physics.

---

##### Subsection 1.2: Radioactivity

**Overview:**
Radioactivity is the spontaneous process by which unstable atomic nuclei lose energy by emitting radiation in the form of particles or electromagnetic waves. Understanding the principles of radioactivity, including decay modes, kinetics, and equilibrium, is fundamental to medical physics, underpinning applications in nuclear medicine imaging, radionuclide therapy, brachytherapy, and radiation safety. This subsection delves into the quantitative aspects of radioactive decay and its clinical significance.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Define radioactivity and identify common modes of radioactive decay.
- Explain the concepts of activity, decay constant, half-life, and mean life.
- Apply the radioactive decay law to calculate remaining activity and perform decay corrections.
- Differentiate between secular and transient equilibrium and explain their clinical relevance (e.g., radionuclide generators).
- Describe the production of radionuclides.
- Discuss the clinical applications and safety considerations related to radioactive decay.

**Estimated Completion Time:** 90 minutes

**Key Points for Understanding:**
- Radioactivity originates from nuclear instability.
- Decay modes (alpha, beta-minus, beta-plus, electron capture, isomeric transition) result in different types of emissions and daughter products.
- Radioactive decay is a random, first-order process described by exponential decay laws.
- Activity (Bq, Ci) quantifies the rate of decay.
- Half-life (T₁/₂) is the time for activity to decrease by half.
- Mean life (τ) is the average lifetime of a radioactive nucleus.
- Radioactive equilibrium (secular, transient) occurs when a parent radionuclide decays to a radioactive daughter.
- Radionuclide generators (e.g., ⁹⁹Mo/⁹⁹ᵐTc) exploit equilibrium principles for clinical isotope supply.

**1.2.1 Nuclear Stability and Decay Modes:**

Nuclei strive for stability, typically characterized by an optimal neutron-to-proton ratio. Unstable nuclei undergo spontaneous transformations (decays) to reach a more stable configuration, emitting radiation in the process. The primary modes of decay relevant to medical physics are:

*   **Alpha (α) Decay:** Emission of an alpha particle (²⁴He nucleus: 2 protons, 2 neutrons). Occurs primarily in heavy nuclei (Z > 82).
    *   Equation:  ᴬ<0xE1><0xB5><0xA1>X → ᴬ⁻⁴<0xE1><0xB5><0xA1>⁻²Y + ⁴₂He + Q
    *   Characteristics: Monoenergetic alpha particles, high LET, short range in tissue.
    *   Clinical Relevance: Used in targeted alpha therapy (TAT) (e.g., ²²³Ra for bone metastases). Significant internal hazard if ingested/inhaled.

*   **Beta-Minus (β⁻) Decay:** Conversion of a neutron into a proton within the nucleus, emitting a beta-minus particle (electron, e⁻) and an antineutrino (ν̅ₑ). Occurs in neutron-rich nuclei.
    *   Equation: n → p + e⁻ + ν̅ₑ ;  ᴬ<0xE1><0xB5><0xA1>X → ᴬ<0xE1><0xB5><0xA1>₊₁Y + e⁻ + ν̅ₑ + Q
    *   Characteristics: Continuous energy spectrum for electrons (up to E_max), lower LET than alpha, longer range.
    *   Clinical Relevance: Used in radionuclide therapy (e.g., ¹³¹I for thyroid cancer, ⁹⁰Y for liver tumors), source of electrons in some brachytherapy sources.

*   **Beta-Plus (β⁺) Decay (Positron Emission):** Conversion of a proton into a neutron within the nucleus, emitting a beta-plus particle (positron, e⁺) and a neutrino (νₑ). Occurs in proton-rich nuclei. Requires decay energy > 1.022 MeV.
    *   Equation: p → n + e⁺ + νₑ ;  ᴬ<0xE1><0xB5><0xA1>X → ᴬ<0xE1><0xB5><0xA1>₋₁Y + e⁺ + νₑ + Q
    *   Characteristics: Continuous energy spectrum for positrons. Positrons quickly annihilate with electrons, producing two 511 keV photons traveling in opposite directions.
    *   Clinical Relevance: Basis of Positron Emission Tomography (PET) imaging (e.g., ¹⁸F-FDG, ¹¹C, ¹³N, ¹⁵O).

*   **Electron Capture (EC):** Capture of an orbital electron (usually K-shell) by the nucleus, converting a proton into a neutron and emitting a neutrino (νₑ). Occurs in proton-rich nuclei, competes with β⁺ decay.
    *   Equation: p + e⁻ → n + νₑ ;  ᴬ<0xE1><0xB5><0xA1>X + e⁻ → ᴬ<0xE1><0xB5><0xA1>₋₁Y + νₑ + Q
    *   Characteristics: Results in characteristic X-rays or Auger electrons as the electron shell vacancy is filled. No charged particle emission from the nucleus itself.
    *   Clinical Relevance: Used in nuclear medicine imaging (e.g., ⁶⁷Ga, ¹¹¹In, ¹²³I, ²⁰¹Tl). Auger electrons can contribute significantly to dose at the cellular level.

*   **Isomeric Transition (IT):** Decay of a nucleus from a metastable excited state (isomer) to a lower energy state by emitting a gamma ray (γ) or via internal conversion (IC). The atomic number (Z) and mass number (A) remain unchanged.
    *   Equation: ᴬᵐ<0xE1><0xB5><0xA1>X → ᴬ<0xE1><0xB5><0xA1>X + γ  or  ᴬᵐ<0xE1><0xB5><0xA1>X → ᴬ<0xE1><0xB5><0xA1>X + e⁻ (IC electron)
    *   Characteristics: Gamma rays are monoenergetic photons originating from the nucleus. Internal conversion ejects an orbital electron, followed by characteristic X-rays/Auger electrons.
    *   Clinical Relevance: Basis for many diagnostic radionuclides (e.g., ⁹⁹ᵐTc → ⁹⁹Tc + γ (140 keV)). Gamma emission is key for SPECT imaging.

[ILLUSTRATION: Simplified decay scheme diagrams for common decay modes (e.g., β⁻ decay of ¹³¹I, β⁺ decay of ¹⁸F, EC of ¹²³I, IT of ⁹⁹ᵐTc)]

**1.2.2 Radioactive Decay Law:**

Radioactive decay is a random process. For a large number of radioactive atoms (N), the rate of decay (dN/dt) is proportional to the number of atoms present:

$$ \frac{dN}{dt} = -\lambda N $$

Where:
- N is the number of radioactive atoms at time t.
- λ is the **decay constant** (units: s⁻¹, min⁻¹, hr⁻¹, etc.), representing the probability per unit time that a nucleus will decay. It is specific to each radionuclide.

Integrating this differential equation gives the **radioactive decay law**:

$$ N(t) = N_0 e^{-\lambda t} $$

Where:
- N(t) is the number of radioactive atoms remaining at time t.
- N₀ is the initial number of radioactive atoms at t=0.

**1.2.3 Activity:**

**Activity (A)** is defined as the rate of decay (number of disintegrations per unit time). It is directly proportional to the number of radioactive atoms:

$$ A(t) = \left| \frac{dN}{dt} \right| = \lambda N(t) $$

Substituting N(t) from the decay law:

$$ A(t) = \lambda N_0 e^{-\lambda t} $$

Since A₀ = λN₀ (initial activity):

$$ A(t) = A_0 e^{-\lambda t} $$

**Units of Activity:**
- **Becquerel (Bq):** The SI unit. 1 Bq = 1 disintegration per second (dps).
- **Curie (Ci):** The traditional unit. 1 Ci = 3.7 x 10¹⁰ Bq (originally based on the activity of 1 gram of ²²⁶Ra).
    - Common subunits: millicurie (mCi), microcurie (μCi).

**Clinical Example: Decay Correction for Patient Dose**
A patient is prescribed 15 mCi of ¹³¹I for thyroid therapy. The dose is drawn up at 8:00 AM but administered at 11:00 AM. What activity is administered? (T₁/₂ for ¹³¹I = 8.02 days).

1.  Calculate the decay constant (λ):
    λ = ln(2) / T₁/₂ = 0.693 / (8.02 days * 24 hr/day) ≈ 0.0036 hr⁻¹
2.  Calculate the decay time (t): t = 11:00 AM - 8:00 AM = 3 hours.
3.  Apply the activity decay formula:
    A(t) = A₀ * e^(-λt) = 15 mCi * e^(-0.0036 hr⁻¹ * 3 hr)
    A(t) = 15 mCi * e^(-0.0108) ≈ 15 mCi * 0.9893 ≈ 14.84 mCi

The patient receives approximately 14.84 mCi. Accurate decay correction is crucial for delivering the prescribed therapeutic dose or ensuring accurate quantification in imaging.

**1.2.4 Half-Life and Mean Life:**

**Half-Life (T₁/₂):** The time required for the number of radioactive atoms (or the activity) to decrease by half.
Setting N(t) = N₀/2 in the decay law:
N₀/2 = N₀ * e^(-λT₁/₂)
1/2 = e^(-λT₁/₂)
ln(1/2) = -λT₁/₂
-ln(2) = -λT₁/₂

$$ T_{1/2} = \frac{\ln(2)}{\lambda} \approx \frac{0.693}{\lambda} $$

Half-life is a characteristic constant for each radionuclide.

[ILLUSTRATION: Exponential decay curve showing activity vs. time, highlighting T₁/₂, 2T₁/₂, 3T₁/₂, etc.]

**Mean Life (τ):** The average lifetime of a radioactive atom before it decays.
It can be shown that:

$$ \tau = \frac{1}{\lambda} $$

Relationship between T₁/₂ and τ:

$$ \tau = \frac{T_{1/2}}{\ln(2)} \approx 1.44 \times T_{1/2} $$

Mean life is useful for calculating the total number of disintegrations over time or the cumulative dose delivered by a radionuclide. The total number of disintegrations (N_total) from an initial activity A₀ is:
N_total = A₀ / λ = A₀ * τ

**Clinical Example: Cumulative Dose in Brachytherapy**
A permanent ¹²⁵I brachytherapy seed implant has an initial activity A₀. Calculate the total dose delivered, assuming dose rate is proportional to activity. (T₁/₂ for ¹²⁵I = 59.4 days).

1.  Calculate mean life (τ):
    τ = T₁/₂ / ln(2) = 59.4 days / 0.693 ≈ 85.7 days
2.  The initial dose rate (DR₀) is proportional to A₀: DR₀ = k * A₀
3.  The dose rate at time t is DR(t) = DR₀ * e^(-λt)
4.  The total dose (D_total) is the integral of the dose rate over infinite time:
    D_total = ∫[0, ∞] DR(t) dt = ∫[0, ∞] DR₀ * e^(-λt) dt
    D_total = DR₀ * [-1/λ * e^(-λt)] evaluated from 0 to ∞
    D_total = DR₀ * (0 - (-1/λ * 1)) = DR₀ / λ = DR₀ * τ
    D_total = DR₀ * 1.44 * T₁/₂

The total dose delivered is proportional to the initial dose rate and the mean life (or 1.44 times the half-life). This is crucial for planning permanent implants.

**1.2.5 Specific Activity:**

Specific Activity (SA) is the activity per unit mass of a radionuclide.
Units: Bq/g or Ci/g.

$$ SA = \frac{A}{m} = \frac{\lambda N}{m} $$

Since N = (m / M) * N_A (where m=mass, M=molar mass, N_A=Avogadro's number):

$$ SA = \frac{\lambda N_A}{M} $$

High specific activity is often desirable in nuclear medicine, especially for receptor-based imaging or therapy, to minimize the mass of the administered substance and avoid saturating biological targets. "Carrier-free" sources have the highest possible specific activity.

**1.2.6 Radionuclide Production:**

Radionuclides are produced through nuclear reactions:

*   **Nuclear Reactors:** Neutron bombardment of stable target nuclei (neutron activation).
    *   Example: ⁹⁸Mo(n,γ)⁹⁹Mo (produces ⁹⁹Mo for Tc generators)
    *   Example: ⁵⁹Co(n,γ)⁶⁰Co (produces ⁶⁰Co for teletherapy/brachytherapy)
    *   Often produces neutron-rich isotopes decaying by β⁻.
    *   Can also produce isotopes via fission of heavy elements (e.g., ²³⁵U fission yields ¹³¹I, ⁹⁰Sr, ¹³⁷Cs).

*   **Particle Accelerators (Cyclotrons):** Bombardment of target materials with charged particles (protons, deuterons, alpha particles).
    *   Example: ¹⁸O(p,n)¹⁸F (produces ¹⁸F for PET)
    *   Example: ⁶⁸Zn(p,2n)⁶⁷Ga (produces ⁶⁷Ga for SPECT)
    *   Often produces proton-rich isotopes decaying by β⁺ or EC.
    *   Can achieve higher specific activity than neutron activation.

*   **Radionuclide Generators:** A system containing a long-lived parent radionuclide that decays to a shorter-lived daughter radionuclide, which can be chemically separated ("eluted").
    *   Example: ⁹⁹Mo (T₁/₂=66 hr) → ⁹⁹ᵐTc (T₁/₂=6 hr) + β⁻ + ν̅ₑ
    *   Example: ⁸²Sr (T₁/₂=25 days) → ⁸²Rb (T₁/₂=75 sec) + EC/β⁺
    *   Relies on principles of radioactive equilibrium.

**1.2.7 Radioactive Equilibrium:**

When a parent radionuclide (P) decays to a radioactive daughter (D), the activity of the daughter depends on the activities and half-lives of both.
Parent decay: dN_P/dt = -λ_P N_P
Daughter decay/production: dN_D/dt = (Rate of formation) - (Rate of decay) = λ_P N_P - λ_D N_D

The activity of the daughter A_D(t) at time t, assuming A_D(0)=0, is given by the **Bateman equation** for a simple parent-daughter chain:

$$ A_D(t) = A_P(0) \frac{\lambda_D}{\lambda_D - \lambda_P} (e^{-\lambda_P t} - e^{-\lambda_D t}) $$

Or in terms of activities:

$$ A_D(t) = A_P(t) \frac{\lambda_D}{\lambda_D - \lambda_P} (1 - e^{-(\lambda_D - \lambda_P) t}) $$

Two important special cases arise:

*   **Secular Equilibrium:** Occurs when the parent half-life is much longer than the daughter half-life (T₁/₂(P) >> T₁/₂(D), or λ_P << λ_D).
    *   After several daughter half-lives, e^(-λ_D t) ≈ 0 and λ_D - λ_P ≈ λ_D.
    *   The equation simplifies to: A_D(t) ≈ A_P(0) * e^(-λ_P t) ≈ A_P(t)
    *   **Condition:** The daughter activity becomes equal to the parent activity and decays with the apparent half-life of the parent.
    *   Clinical Relevance: ²²⁶Ra (T₁/₂=1600 y) and its short-lived daughters; ⁹⁰Sr (T₁/₂=29 y) / ⁹⁰Y (T₁/₂=64 hr) generator (approximates secular).

*   **Transient Equilibrium:** Occurs when the parent half-life is longer than the daughter half-life, but not infinitely longer (T₁/₂(P) > T₁/₂(D), or λ_P < λ_D).
    *   After some time, e^(-λ_D t) becomes negligible compared to e^(-λ_P t).
    *   The equation simplifies to: A_D(t) ≈ A_P(0) * [λ_D / (λ_D - λ_P)] * e^(-λ_P t)
    *   Or: A_D(t) ≈ A_P(t) * [λ_D / (λ_D - λ_P)] = A_P(t) * [T₁/₂(P) / (T₁/₂(P) - T₁/₂(D))]
    *   **Condition:** The daughter activity exceeds the parent activity, and the ratio A_D/A_P becomes constant. Both decay with the apparent half-life of the parent. Maximum daughter activity occurs at t_max = ln(λ_D/λ_P) / (λ_D - λ_P).
    *   Clinical Relevance: ⁹⁹Mo (T₁/₂=66 hr) / ⁹⁹ᵐTc (T₁/₂=6 hr) generator is the classic example. Allows regular elution ("milking") of ⁹⁹ᵐTc for clinical use.

[ILLUSTRATION: Graphs showing parent and daughter activities vs. time for Secular Equilibrium and Transient Equilibrium, highlighting key features like A_D=A_P or A_D>A_P and maximum daughter activity.]

**Clinical Application: The ⁹⁹Mo/⁹⁹ᵐTc Generator**
The "Moly cow" is essential for nuclear medicine departments.
1.  ⁹⁹Mo (produced in reactor) is adsorbed onto an alumina (Al₂O₃) column.
2.  ⁹⁹Mo decays to ⁹⁹ᵐTc via β⁻ decay.
3.  Transient equilibrium is established. Maximum ⁹⁹ᵐTc activity is reached after about 23 hours.
4.  Saline solution (0.9% NaCl) is passed through the column.
5.  The pertechnetate ion (⁹⁹ᵐTcO₄⁻) is soluble and washes off ("elutes"), while the molybdate ion (⁹⁹MoO₄²⁻) remains bound to the alumina.
6.  The eluted ⁹⁹ᵐTc can be used to prepare various radiopharmaceuticals.
7.  The ⁹⁹ᵐTc activity regrows on the column, allowing for daily elution for about a week.
Quality control checks (e.g., for ⁹⁹Mo breakthrough, aluminum ion concentration) are crucial before clinical use.

**Assessment Questions:**

1.  **Multiple Choice:** Which decay mode is the basis for PET imaging?
    a) Alpha decay
    b) Beta-minus decay
    c) Beta-plus decay
    d) Electron capture
    e) Isomeric transition
    *(Answer: c)*

2.  **Calculation:** A sample of ¹³¹I has an activity of 100 mCi. What will its activity be after 16.04 days? (T₁/₂ = 8.02 days)
    *(Answer: 16.04 days is exactly 2 half-lives. Activity = 100 mCi / 2² = 100 / 4 = 25 mCi)*

3.  **Short Answer:** Explain the difference between secular and transient equilibrium, providing a clinical example for each.
    *(Answer: See text above)*

4.  **Clinical Scenario:** A technologist needs 20 mCi of ⁹⁹ᵐTc for a scan at 1:00 PM. The generator was last eluted at 8:00 AM yesterday. The calibration sheet indicates the generator contained 1 Ci of ⁹⁹Mo at 8:00 AM yesterday. Assuming 85% elution efficiency and transient equilibrium kinetics, estimate if sufficient ⁹⁹ᵐTc activity can be eluted at 12:30 PM today. (Requires Bateman equation or equilibrium approximation; T₁/₂(Mo)=66h, T₁/₂(Tc)=6h).
    *(Answer: This requires calculation using the transient equilibrium formula or Bateman equation, considering decay of Mo and buildup/decay of Tc over ~28.5 hours, then applying elution efficiency. A detailed calculation would show whether 20 mCi / 0.85 ≈ 23.5 mCi of Tc is available.)*

5.  **Concept Question:** Why is high specific activity important for receptor-targeted radionuclide therapy?
    *(Answer: To deliver a therapeutic amount of radioactivity using a small mass of the radionuclide, avoiding saturation of the limited number of biological receptors and minimizing potential chemical toxicity.)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection covers core concepts outlined in the ABR General Content outline under Section 1 (Atomic/Nuclear Physics, Sources of Radiation) and Section 4 (Nuclear Medical Physics), including radioactivity, decay modes, kinetics, equilibrium, and radionuclide production. It also touches upon clinical applications relevant to diagnostic and therapeutic medical physics (Sections 3, 4, 5) and radiation safety (Section 6). The level of detail aligns with CAMPEP graduate program expectations.

##### Subsection 1.3: Sources of Radioactive Material (Enhanced Detail)

**Overview:**
Radioactive materials, both naturally occurring and artificially produced, are integral to the environment and modern technology. A profound understanding of their origins, characteristics, distribution, and quantification is paramount for medical physicists. This knowledge underpins effective radiation protection strategies, accurate environmental monitoring, safe handling practices in nuclear medicine and radiation therapy, and compliance with regulatory frameworks. This subsection provides an in-depth exploration of natural radioactivity (primordial, cosmogenic), technologically enhanced materials (TENORM), and the diverse array of artificial radionuclides generated through human ingenuity and industrial processes, emphasizing quantitative aspects and clinical relevance.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Quantitatively describe the components and variability of natural background radiation (cosmic and terrestrial).
- Analyze the decay chains of major primordial radionuclides (²³⁸U, ²³²Th, ²³⁵U) and calculate progeny activities under equilibrium conditions.
- Evaluate the significance and dosimetry of key internal emitters (⁴⁰K, ²²²Rn and progeny, ¹⁴C).
- Explain the mechanisms of cosmogenic radionuclide production (e.g., ¹⁴C, ³H, ⁷Be) and their applications.
- Identify specific industrial processes leading to TENORM, quantify typical activity concentrations, and discuss associated regulatory concerns.
- Detail the production methods (reactor activation, fission, accelerator bombardment) for key artificial radionuclides used in medicine and industry.
- Critically assess the impact of different radioactive sources on clinical practice, including background interference, shielding requirements, waste disposal, and patient/staff dosimetry.

**Estimated Completion Time:** 90-120 minutes

**Key Points for Understanding:**
- Natural background radiation dose varies significantly based on geographic location, altitude, and lifestyle (average US dose ~3.1 mSv/year from natural sources).
- Primordial decay chains (Uranium, Thorium) are complex, involving multiple alpha/beta decays and gaseous intermediates (Radon, Thoron), leading to potential disequilibrium.
- Radon (²²²Rn) and its short-lived progeny are the largest contributors to natural background dose, primarily through inhalation.
- ⁴⁰K is the dominant internal natural radionuclide due to its presence in body tissues.
- TENORM represents a significant regulatory and safety challenge in specific industries (e.g., oil/gas, mining, water treatment).
- Artificial radionuclide production requires careful selection of target materials, irradiation conditions (neutron flux, particle energy), and post-processing chemistry.
- Accurate source characterization is fundamental for dosimetry, safety, and regulatory compliance in all medical physics domains.

**1.3.1 Natural Background Radiation (Detailed):**

Natural background radiation provides a continuous, low-level exposure to all living organisms. The average annual effective dose to a member of the US population from natural sources is estimated by NCRP Report No. 160 to be approximately 3.1 mSv. This is composed of:

*   **Cosmic Radiation (~0.33 mSv/year average):**
    *   **Primary Cosmic Rays:** Extremely high-energy particles (87% protons, 12% alpha particles, 1% heavier nuclei) originating from galactic sources and solar events.
    *   **Secondary Cosmic Rays:** Produced by interactions in the atmosphere (spallation). Components at sea level include muons, neutrons, electrons, photons, and pions.
    *   **Altitude Dependence:** Dose rate increases significantly with altitude. For example, the dose rate in Denver (altitude ~1600 m) is roughly double that at sea level. At typical commercial flight altitudes (10,000-12,000 m), dose rates can be 3-9 μSv/hour, leading to significant occupational doses for aircrew (potentially 2-5 mSv/year).
    *   **Latitude Dependence:** The Earth's magnetic field provides more shielding near the equator. Dose rates can be 10-20% higher at high latitudes compared to equatorial regions.
    *   **Solar Cycle:** Varies by ~10-20% over the 11-year solar cycle (higher during solar minimum due to reduced solar magnetic field shielding against galactic cosmic rays).
    *   **Neutron Component:** Contributes significantly to the effective dose at high altitudes, requiring specific consideration in dosimetry for aircrew.

*   **Terrestrial Radiation (~0.21 mSv/year external average):**
    *   **Source:** Gamma rays emitted from primordial radionuclides (⁴⁰K, ²³⁸U series, ²³²Th series) in soil, rocks, and building materials.
    *   **Geological Variation:** Dose rates vary widely. Areas with igneous rocks (granite) typically have higher concentrations of U and Th than sedimentary rocks. Average outdoor absorbed dose rate in air in the US is ~50 nGy/hr, but can range from 10 to >1000 nGy/hr globally.
    *   **Building Materials:** Concrete, brick, and natural stone contribute to indoor exposure. Indoor dose rates are often ~1.5 times higher than outdoor rates due to source geometry and reduced ventilation.
    *   **Dosimetry:** Requires converting absorbed dose rate in air (nGy/hr) to effective dose (mSv/year) using conversion factors and occupancy factors (e.g., 0.7 Sv/Gy for adults, 0.8 indoor occupancy).

*   **Internal Emitters (~2.56 mSv/year average):**
    *   **Inhalation (~2.28 mSv/year):** Dominated by Radon (²²²Rn) and Thoron (²²⁰Rn) and their short-lived decay products. Radon gas diffuses from soil into buildings, where progeny attach to aerosols and are inhaled. Alpha emissions from deposited progeny (esp. ²¹⁸Po, ²¹⁴Po) deliver high LET dose to bronchial epithelium. Indoor radon levels vary drastically depending on geology, building construction, and ventilation (EPA action level: 4 pCi/L or 148 Bq/m³).
    *   **Ingestion (~0.28 mSv/year):** Primarily from ⁴⁰K, which is naturally present in foods (bananas, potatoes, etc.) and maintains a relatively constant concentration in the body due to homeostasis (~4000 Bq in a 70 kg adult). Smaller contributions from U and Th series radionuclides in food and water.

**1.3.2 Primordial Radionuclides (Detailed Chains):**

These long-lived radionuclides provide a continuous source of decay products.

*   **Uranium Series (⁴n+2):**
    *   ²³⁸U (α, 4.47×10⁹ y) → ²³⁴Th (β⁻, 24.1 d) → ²³⁴Pa (β⁻, 1.17 min) → ²³⁴U (α, 2.45×10⁵ y) → ²³⁰Th (α, 7.54×10⁴ y) → ²²⁶Ra (α, 1600 y) → **²²²Rn** (α, 3.82 d) → ²¹⁸Po (α, 3.1 min) → ²¹⁴Pb (β⁻, 26.8 min) → ²¹⁴Bi (β⁻/α, 19.9 min) → ²¹⁴Po (α, 164 μs) / ²¹⁰Tl (β⁻, 1.3 min) → ²¹⁰Pb (β⁻, 22.3 y) → ²¹⁰Bi (β⁻/α, 5.01 d) → ²¹⁰Po (α, 138 d) / ²⁰⁶Hg (β⁻, 8.3 min) → ²⁰⁶Pb (Stable).
    *   **Key Features:** Long-lived ²³⁴U and ²³⁰Th can lead to disequilibrium in geological settings. ²²⁶Ra is relatively mobile in water. Gaseous ²²²Rn allows dispersal. Short-lived progeny ²¹⁸Po, ²¹⁴Pb, ²¹⁴Bi, ²¹⁴Po are responsible for most of the radon inhalation dose.

*   **Thorium Series (⁴n):**
    *   ²³²Th (α, 1.41×10¹⁰ y) → ²²⁸Ra (β⁻, 5.75 y) → ²²⁸Ac (β⁻, 6.15 h) → ²²⁸Th (α, 1.91 y) → ²²⁴Ra (α, 3.66 d) → **²²⁰Rn** (Thoron) (α, 55.6 s) → ²¹⁶Po (α, 0.15 s) → ²¹²Pb (β⁻, 10.6 h) → ²¹²Bi (β⁻/α, 60.6 min) → ²¹²Po (α, 0.3 μs) / ²⁰⁸Tl (β⁻, 3.05 min) → ²⁰⁸Pb (Stable).
    *   **Key Features:** Includes relatively long-lived ²²⁸Ra and ²²⁸Th. Thoron (²²⁰Rn) has a very short half-life, limiting its migration distance compared to Radon.

*   **Actinium Series (⁴n+3):**
    *   ²³⁵U (α, 7.04×10⁸ y) → ²³¹Th (β⁻, 25.5 h) → ²³¹Pa (α, 3.28×10⁴ y) → ²²⁷Ac (β⁻/α, 21.8 y) → ... → **²¹⁹Rn** (Actinon) (α, 4.0 s) → ... → ²⁰⁷Pb (Stable).
    *   **Key Features:** Contributes less to background dose due to lower abundance of ²³⁵U (0.72%). Actinon (²¹⁹Rn) is very short-lived.

*   **Potassium-40 (⁴⁰K):**
    *   Not part of a chain. Decays directly: 89.3% via β⁻ to stable ⁴⁰Ca; 10.7% via EC/β⁺ (mostly EC) to stable ⁴⁰Ar, emitting a characteristic 1.46 MeV gamma ray in ~10% of decays.
    *   **Significance:** Ubiquitous in minerals and biological tissues. The 1.46 MeV gamma is a significant component of the terrestrial gamma background. Internal ⁴⁰K dose is relatively constant due to homeostasis.

**Clinical Application: Disequilibrium in Radium Sources**
Historically, ²²⁶Ra needles/tubes were used for brachytherapy. These sources relied on secular equilibrium being established between ²²⁶Ra and its progeny down to ²¹⁰Pb. However, leakage of gaseous ²²²Rn could disrupt this equilibrium, altering the dose rate and posing a significant contamination hazard. Modern sources (e.g., ¹⁹²Ir, ¹²⁵I) do not have gaseous progeny, simplifying handling and dosimetry.

**1.3.3 Cosmogenic Radionuclides (Detailed Production):**

Cosmic ray interactions (primarily neutrons from spallation) with atmospheric nuclei (¹⁴N, ¹⁶O, ⁴⁰Ar) produce these isotopes.

*   **Carbon-14 (¹⁴C):**
    *   Reaction: ¹⁴N + n → ¹⁴C + p (dominant reaction, thermal neutrons)
    *   Global Inventory: ~70-100 tons, relatively constant due to balance between production and decay.
    *   Specific Activity: ~0.23 Bq/g of carbon in living organisms.

*   **Tritium (³H):**
    *   Reactions: ¹⁴N(n, ³H)¹²C, ¹⁶O(n, ³H)¹⁴N, etc. (high-energy neutrons)
    *   Inventory: Significantly increased by atmospheric nuclear weapons testing in the mid-20th century, now decreasing.

*   **Beryllium-7 (⁷Be):**
    *   Reactions: Spallation of N and O by high-energy protons/neutrons.
    *   Significance: Short half-life, attaches to aerosols, used to study atmospheric transport.

**1.3.4 Technologically Enhanced Naturally Occurring Radioactive Materials (TENORM) (Detailed Examples):**

Human activities redistribute and concentrate NORM.

*   **Oil and Gas:** Formation water contains dissolved ²²⁶Ra and ²²⁸Ra. Changes in temperature/pressure cause co-precipitation with Ba/Sr sulfates, forming highly radioactive scale (up to thousands of Bq/g) inside pipes, tanks, and valves. ²²²Rn concentrates in natural gas (can exceed 1000 Bq/m³).
    *   **Regulatory Concern:** Worker exposure during maintenance, equipment decontamination, disposal of contaminated scale/sludge (often classified as low-level radioactive waste).

*   **Mining:** Uranium mining tailings contain residual U, Th, and all progeny (esp. ²²⁶Ra, ²¹⁰Pb, ²¹⁰Po). Phosphate rock mining concentrates U and progeny in phosphogypsum waste (²²⁶Ra ~1000 Bq/kg). Coal mining brings NORM to the surface; coal ash concentrates ⁴⁰K, U, Th (typically 100-500 Bq/kg).
    *   **Regulatory Concern:** Long-term stabilization of tailings piles, radon emanation, leaching into groundwater, use of contaminated materials (e.g., phosphogypsum in construction).

*   **Water Treatment:** Removal of contaminants can concentrate ²²⁶Ra, ²²⁸Ra, U in filter media (ion exchange resins, activated carbon) and sludges.
    *   **Regulatory Concern:** Disposal of spent media/sludge, worker exposure during handling.

*   **Metal Processing:** Smelting ores can concentrate radionuclides like ²¹⁰Pb/²¹⁰Po in slags, dusts, and residues.

**1.3.5 Artificial Radionuclides (Detailed Production & Use):**

*   **Fission Products:** Produced with characteristic yield distribution from fission of ²³⁵U or ²³⁹Pu. Double-humped mass yield curve peaks around A≈90-100 and A≈130-140.
    *   **¹³⁷Cs:** High fission yield, T₁/₂=30.17 y, emits 662 keV gamma (from daughter ¹³⁷ᵐBa). Used in LDR brachytherapy (historical), blood irradiators, industrial gauges. Major environmental contaminant from Chernobyl and weapons fallout.
    *   **⁹⁰Sr:** High fission yield, T₁/₂=28.8 y, pure β⁻ emitter. Decays to ⁹⁰Y (T₁/₂=64 h, high-energy β⁻ emitter). Used in radioisotope thermoelectric generators (RTGs), historical ophthalmic applicators, bone-seeking therapy (⁸⁹Sr).
    *   **¹³¹I:** High fission yield, T₁/₂=8.02 d, β⁻/γ emitter (main γ=364 keV). Used extensively for thyroid diagnostics and therapy.
    *   **⁹⁹Mo:** Fission product (yield ~6%), T₁/₂=66 h. Parent for ⁹⁹ᵐTc generators.

*   **Activation Products:**
    *   **Reactor (Neutron Activation):**
        *   ⁶⁰Co: ⁵⁹Co(n,γ)⁶⁰Co. Requires high thermal neutron flux. High specific activity needed for teletherapy sources.
        *   ¹⁹²Ir: ¹⁹¹Ir(n,γ)¹⁹²Ir. Natural iridium (37% ¹⁹¹Ir, 63% ¹⁹³Ir) activated. High specific activity crucial for small HDR sources.
        *   ³²P: ³²S(n,p)³²P (fast neutrons) or ³¹P(n,γ)³²P (thermal neutrons).
        *   ¹²⁵I: ¹²⁴Xe(n,γ)¹²⁵Xe (EC, 17h) → ¹²⁵I. Requires enriched ¹²⁴Xe target.
    *   **Accelerator (Charged Particle Activation):**
        *   ¹⁸F: ¹⁸O(p,n)¹⁸F. Requires proton beam (10-20 MeV) on enriched ¹⁸O water target. Most common PET isotope.
        *   ¹¹C: ¹⁴N(p,α)¹¹C. Proton beam on nitrogen gas target. T₁/₂=20 min.
        *   ⁶⁷Ga: ⁶⁸Zn(p,2n)⁶⁷Ga or ⁶⁷Zn(p,n)⁶⁷Ga. Proton beam on enriched zinc target.
        *   ²⁰¹Tl: ²⁰³Tl(p,3n)²⁰¹Pb (EC, 9h) → ²⁰¹Tl. Requires higher energy protons (>25 MeV).
        *   ¹²³I: ¹²⁴Te(p,2n)¹²³I or ¹²⁷I(p,5n)¹²³Xe → ¹²³I. Choice depends on proton energy and desired purity.

*   **Transuranics:** Produced by successive neutron captures and decays starting from U.
    *   ²³⁹Pu: ²³⁸U(n,γ) → ²³⁹U (β⁻, 23m) → ²³⁹Np (β⁻, 2.4d) → ²³⁹Pu.
    *   ²⁴¹Am: From beta decay of ²⁴¹Pu (fission/activation product).
    *   ²⁵²Cf: Requires very high neutron flux reactors for multiple neutron captures starting from Pu or Am isotopes.

**Clinical Application: HDR ¹⁹²Ir Source Exchange**
High-dose-rate (HDR) brachytherapy units use ¹⁹²Ir sources (~10 Ci). Due to its 74-day half-life, the source activity decreases significantly over time (~1% per day). Sources are typically replaced every 3-4 months to maintain reasonable treatment times.
- **Physics Role:** Verifying new source activity calibration (using well chamber traceable to NIST), ensuring correct decay calculations in the treatment planning system, performing safety checks during source exchange, managing transport and disposal of the old source according to regulations.

**Revised Assessment Questions (ABR Style):**

1.  **Scenario:** A medical physicist is evaluating background radiation levels in a newly constructed PET/CT facility located at an altitude of 2000 meters. The building incorporates significant amounts of granite. Which of the following combinations represents the MOST likely primary contributors to elevated background readings on a sensitive survey meter (e.g., pressurized ion chamber) inside the facility compared to a sea-level location with standard concrete construction?
    a) Cosmic-ray induced neutrons and ⁴⁰K from concrete
    b) Secondary cosmic-ray muons and ²²²Rn from granite
    c) Primary cosmic-ray protons and ²³²Th series gammas from granite
    d) Secondary cosmic-ray muons/electrons and gammas from ⁴⁰K, ²³⁸U series, and ²³²Th series in granite
    e) Solar flare protons and ²³⁵U series gammas from granite
    *(Answer: d - Altitude increases cosmic secondaries (muons, electrons, photons); granite increases terrestrial gammas from all three major natural series.)*

2.  **Calculation:** A sealed container holds 1 gram of pure ²²⁶Ra (T₁/₂ = 1600 y). Assuming secular equilibrium has been established with its progeny down to ²¹⁰Pb (T₁/₂ = 22.3 y), estimate the activity of ²²²Rn (T₁/₂ = 3.82 d) within the container. (Avogadro's number ≈ 6.022×10²³ mol⁻¹; Atomic mass of ²²⁶Ra ≈ 226 g/mol).
    a) ~1 Bq
    b) ~1 kBq
    c) ~1 MBq
    d) ~1 GBq
    e) ~37 GBq
    *(Answer: e - Activity of ²²⁶Ra = λN = (ln2/T₁/₂) * (mass/molar_mass) * N_A. A = (0.693 / (1600 y * 3.15e7 s/y)) * (1g / 226 g/mol) * 6.022e23 ≈ 3.66×10¹⁰ Bq ≈ 1 Ci. In secular equilibrium, progeny activity equals parent activity. 37 GBq = 1 Ci.)*

3.  **Concept Application:** A nuclear medicine department receives a ⁹⁹Mo/⁹⁹ᵐTc generator calibrated to contain 50 GBq of ⁹⁹Mo at 6:00 AM Monday. The generator is eluted daily at 7:00 AM. Which statement BEST describes the expected ⁹⁹ᵐTc activity available for elution on Wednesday morning at 7:00 AM?
    a) Approximately 50 GBq, due to secular equilibrium.
    b) Significantly less than 50 GBq, as the ⁹⁹Mo has decayed for two days.
    c) Close to the activity of the remaining ⁹⁹Mo, potentially slightly higher due to transient equilibrium.
    d) Approximately zero, as all ⁹⁹ᵐTc decayed since the last elution.
    e) Roughly double the activity of the remaining ⁹⁹Mo due to the Bateman equation peak.
    *(Answer: c - Transient equilibrium is established. ⁹⁹Mo decays (T₁/₂=66h), so parent activity is lower. Daughter activity regrows between elutions and will be related to the parent activity by the transient equilibrium ratio A_D/A_P = T_P / (T_P - T_D) ≈ 66/(66-6) ≈ 1.1. So, it will be close to, but slightly higher than, the remaining Mo activity.)*

4.  **Clinical Relevance:** During maintenance of equipment in an oil field, scale buildup inside a pipe is found to have a contact gamma dose rate significantly above background. Which radionuclide is MOST likely responsible for the elevated gamma dose rate?
    a) ⁴⁰K
    b) ²³⁸U
    c) ²²⁶Ra and progeny (esp. ²¹⁴Pb, ²¹⁴Bi)
    d) ⁹⁰Sr/⁹⁰Y
    e) ³H
    *(Answer: c - Radium isotopes co-precipitate with scale. While ²²⁶Ra itself is primarily an alpha emitter, its short-lived decay products ²¹⁴Pb and ²¹⁴Bi are strong gamma emitters, leading to the elevated external dose rate from TENORM scale.)*

5.  **Production Methods:** To produce ¹⁸F for PET imaging using the ¹⁸O(p,n)¹⁸F reaction, which combination of accelerator and target is typically employed?
    a) Linear accelerator; high-energy electron beam on ¹⁸O gas target.
    b) Nuclear reactor; thermal neutron flux on ¹⁷O water target.
    c) Cyclotron; 10-20 MeV proton beam on enriched ¹⁸O water target.
    d) Cyclotron; high-energy alpha particle beam on ¹⁴N gas target.
    e) Synchrotron; high-energy photon beam on ¹⁹F target.
    *(Answer: c - This is the standard production method for ¹⁸F, requiring a moderate energy proton beam from a cyclotron impacting water enriched in ¹⁸O.)*

**Alignment with CAMPEP/ABR Requirements:**
This enhanced subsection provides graduate-level detail on Sources of Radiation (ABR General Content Section 1) and aspects of Radiation Protection (Section 6). It covers natural background variations, decay chain dynamics, TENORM issues, and artificial production methods with quantitative depth and clinical context, meeting CAMPEP curriculum standards and preparing candidates for ABR-style examination questions.

### Radiation Detection and Measurement for Protection

#### Overview
This lesson covers the principles and practices of radiation detection and measurement essential for radiation protection in radiation oncology. It examines the fundamental principles of radiation detection, the various types of survey instruments and their applications, personal dosimetry methods, environmental monitoring techniques, quality control of radiation detection equipment, and the interpretation of measurement results. Understanding these concepts is crucial for implementing effective radiation monitoring programs and ensuring the safety of patients, staff, and the public.

#### Learning Objectives
After completing this lesson, you will be able to:
- Explain the fundamental principles of radiation detection and measurement
- Select appropriate survey instruments for different radiation protection scenarios
- Implement effective personal dosimetry programs for occupational monitoring
- Design and conduct environmental monitoring for radiation oncology facilities
- Perform quality control procedures for radiation detection equipment
- Interpret radiation measurement results and apply them to protection decisions

#### Estimated Completion Time
60 minutes

#### Content Section 1: Principles of Radiation Detection

##### Subsection 1.1: Interaction Mechanisms
Radiation detection is based on the interactions between ionizing radiation and detector materials. Different detection methods exploit various interaction mechanisms:

**Ionization in Gases:**
When ionizing radiation passes through a gas, it creates ion pairs by removing electrons from gas atoms. The number of ion pairs is proportional to the energy deposited. In an electric field, these ions can be collected to produce a measurable signal. This principle is used in:
- Ionization chambers
- Proportional counters
- Geiger-Müller counters

The relationship between applied voltage and collected charge follows distinct regions:

[IMAGE: Graph showing the relationship between applied voltage and collected charge in gas-filled detectors, with regions labeled: recombination, ionization chamber, proportional, Geiger-Müller, and continuous discharge]

**Excitation in Scintillators:**
Radiation can excite atoms or molecules in certain materials, causing them to emit light (scintillation) when they return to ground state. This light can be detected and converted to an electrical signal. This principle is used in:
- Inorganic scintillators (NaI(Tl), CsI(Tl), LaBr₃)
- Organic scintillators (plastic, liquid)

The scintillation process can be described by:

$$N_{ph} = E \times S \times Q$$

Where:
- $N_{ph}$ is the number of photons produced
- $E$ is the energy deposited
- $S$ is the scintillation efficiency
- $Q$ is the quantum yield

**Charge Generation in Semiconductors:**
Radiation creates electron-hole pairs in semiconductor materials. In an electric field, these charge carriers can be collected to produce a signal. This principle is used in:
- Silicon detectors

##### Subsection 1.4: Radioactive Material Uses and Safety

**Overview:**
Radioactive materials have diverse applications across medicine, industry, research, and energy production. Their unique properties enable critical diagnostic and therapeutic procedures, industrial measurements, scientific investigations, and power generation. However, these same properties necessitate comprehensive safety protocols to protect workers, the public, and the environment. This subsection explores the major applications of radioactive materials and the safety principles, regulatory frameworks, and practical measures essential for their safe use.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Identify and explain the major medical, industrial, research, and energy applications of radioactive materials
- Describe the fundamental principles of radiation safety (justification, optimization, dose limitation)
- Analyze the regulatory framework governing radioactive material use in the United States
- Evaluate radiation safety program components for different applications
- Design appropriate safety measures for specific radioactive material uses
- Apply ALARA principles through time, distance, and shielding calculations
- Assess the effectiveness of contamination control and waste management strategies

**Estimated Completion Time:** 120 minutes

**Key Points for Understanding:**
- Radioactive materials serve essential functions in medicine, industry, research, and energy production
- Safety principles include justification, optimization (ALARA), and dose limitation
- Regulatory oversight in the US is divided between NRC/Agreement States and other agencies
- Effective radiation safety programs include multiple elements from training to emergency planning
- Time, distance, and shielding are the primary means of external exposure control
- Contamination control prevents internal exposure and environmental release
- Waste management requires consideration of half-life, activity, and disposal pathways

**1.4.1 Medical Applications of Radioactive Materials:**

Radioactive materials are integral to modern medicine, enabling both diagnostic imaging and therapeutic procedures.

*   **Nuclear Medicine Diagnostics:**
    *   **SPECT Imaging:** Uses gamma-emitting radionuclides (primarily ⁹⁹ᵐTc-labeled compounds) to visualize physiological function and biochemical processes.
        *   **Common Radiopharmaceuticals:**
            *   ⁹⁹ᵐTc-MDP: Bone scans (metastases, fractures, infection)
            *   ⁹⁹ᵐTc-MAA: Lung perfusion studies (pulmonary embolism)
            *   ⁹⁹ᵐTc-DTPA: Renal function studies
            *   ⁹⁹ᵐTc-Sestamibi: Myocardial perfusion imaging
            *   ¹²³I-MIBG: Neuroendocrine tumor imaging
            *   ¹²³I-NaI: Thyroid imaging
            *   ⁶⁷Ga-citrate: Infection and inflammation imaging
            *   ¹¹¹In-octreotide: Neuroendocrine tumor imaging
        *   **Typical Activities:** 185-1110 MBq (5-30 mCi) per administration
        *   **Safety Considerations:** Preparation in radiopharmacy (shielding, laminar flow), patient-specific dose calibration, administration protocols, post-procedure precautions

    *   **PET Imaging:** Uses positron-emitting radionuclides to visualize metabolic activity, receptor density, and other molecular processes with higher sensitivity than SPECT.
        *   **Common Radiopharmaceuticals:**
            *   ¹⁸F-FDG: Glucose metabolism (oncology, neurology, cardiology)
            *   ¹⁸F-Fluciclovine: Prostate cancer imaging
            *   ¹⁸F-PSMA: Prostate cancer imaging
            *   ¹⁸F-NaF: Bone imaging
            *   ¹¹C-Choline: Prostate cancer imaging
            *   ¹³N-Ammonia: Myocardial perfusion
            *   ⁶⁸Ga-DOTATATE: Neuroendocrine tumor imaging
            *   ⁶⁸Ga-PSMA: Prostate cancer imaging
        *   **Typical Activities:** 185-740 MBq (5-20 mCi) per administration
        *   **Safety Considerations:** Cyclotron or generator production, automated synthesis modules, higher energy photons (511 keV), increased shielding requirements

*   **Therapeutic Nuclear Medicine:**
    *   **Radiopharmaceutical Therapy (RPT):** Delivers targeted radiation to specific tissues or tumors using various mechanisms.
        *   **Common Therapies:**
            *   ¹³¹I-NaI: Thyroid cancer and hyperthyroidism (beta/gamma emitter)
            *   ¹⁷⁷Lu-DOTATATE: Neuroendocrine tumors (beta emitter)
            *   ¹⁷⁷Lu-PSMA: Metastatic prostate cancer (beta emitter)
            *   ⁸⁹Sr-chloride: Bone pain palliation (beta emitter)
            *   ²²³Ra-dichloride: Bone metastases from prostate cancer (alpha emitter)
            *   ⁹⁰Y-microspheres: Liver tumors (beta emitter)
            *   ¹⁷⁷Lu-PSMA: Metastatic prostate cancer (beta emitter)
        *   **Typical Activities:** 1.85-7.4 GBq (50-200 mCi) for ¹³¹I; 5.55-7.4 GBq (150-200 mCi) for ¹⁷⁷Lu
        *   **Safety Considerations:** Higher activities than diagnostics, potential for significant external exposure and contamination, patient isolation requirements, release criteria, radioactive waste management, potential for internal contamination

*   **Brachytherapy:**
    *   **Low Dose Rate (LDR):** Permanent implantation or temporary placement of sealed radioactive sources.
        *   **Common Sources:**
            *   ¹²⁵I seeds (T₁/₂=59.4d, 27-35 keV photons): Prostate, eye plaques
            *   ¹⁰³Pd seeds (T₁/₂=17d, 20-23 keV photons): Prostate
            *   ¹³¹Cs seeds (T₁/₂=9.7d, 30-34 keV photons): Prostate, gynecological
        *   **Typical Activities:** 0.3-1.0 mCi per seed; 40-120 seeds per prostate implant
        *   **Safety Considerations:** Seed inventory control, implantation techniques, potential for dislodged seeds, patient release instructions

    *   **High Dose Rate (HDR):** Temporary placement of high-activity sealed sources using remote afterloading.
        *   **Common Sources:**
            *   ¹⁹²Ir (T₁/₂=74d, average 380 keV photons): Most common HDR source
            *   ⁶⁰Co (T₁/₂=5.27y, 1.17 and 1.33 MeV photons): Emerging alternative
        *   **Typical Activities:** 370-444 GBq (10-12 Ci) for ¹⁹²Ir sources
        *   **Safety Considerations:** Shielded treatment rooms, interlocks, emergency procedures, source exchange protocols, transport regulations, leak testing

*   **Calibration and Quality Assurance Sources:**
    *   **Sealed Check Sources:** Used for instrument QC, constancy checks, and calibrations.
        *   **Common Sources:**
            *   ⁵⁷Co (T₁/₂=272d, 122 keV): Dose calibrator/gamma camera QC
            *   ¹³⁷Cs (T₁/₂=30.17y, 662 keV): Survey meter calibration
            *   ⁶⁸Ge/⁶⁸Ga (T₁/₂=271d, 511 keV): PET scanner QC
            *   ²²Na (T₁/₂=2.6y, 511 keV, 1275 keV): PET scanner QC
        *   **Typical Activities:** 3.7-37 MBq (0.1-1.0 mCi)
        *   **Safety Considerations:** Inventory control, leak testing, proper storage, handling procedures

**Clinical Application: Radiation Safety in ¹³¹I Therapy**
Iodine-131 therapy for thyroid cancer presents unique radiation safety challenges due to its beta/gamma emissions and volatility:

1. **Patient Preparation and Administration:**
   - Activity verification in dose calibrator with appropriate setting
   - Administration behind L-block shield using long-handled tools
   - Use of absorbent pads to catch potential spills
   - Wearing of double gloves, lab coat, and thyroid shield by staff

2. **Patient Hospitalization (for activities >33 mCi in most jurisdictions):**
   - Room preparation: Covering surfaces with plastic, removing unnecessary items
   - Radiation surveys of patient and room (typically at 1 meter from patient)
   - Exposure rate limits for release: typically <7 mR/hr at 1 meter
   - Instruction on maintaining distance from others, especially children and pregnant women
   - Management of bodily fluids (urine, saliva, sweat) which contain radioiodine

3. **Waste Management:**
   - Collection of contaminated items in dedicated radioactive waste containers
   - Holding of patient urine in decay tanks in some facilities
   - Survey of room before release for other patients
   - Decontamination procedures for any areas exceeding release limits

4. **Medical Physics Role:**
   - Developing institutional protocols for safe handling
   - Training staff on radiation safety procedures
   - Performing radiation surveys and contamination monitoring
   - Calculating patient-specific release instructions
   - Investigating any unusual exposures or contamination events

**1.4.2 Industrial Applications of Radioactive Materials:**

Radioactive materials are widely used in industry for process control, quality assurance, and analytical techniques.

*   **Industrial Radiography:**
    *   **Applications:** Non-destructive testing of welds, castings, and structural components
    *   **Common Sources:**
        *   ¹⁹²Ir (T₁/₂=74d): Steel up to 2.5 inches
        *   ⁶⁰Co (T₁/₂=5.27y): Steel up to 9 inches
        *   ⁷⁵Se (T₁/₂=120d): Aluminum, thin steel
    *   **Typical Activities:** 0.1-5 TBq (3-150 Ci)
    *   **Safety Considerations:** High-activity sources, potential for significant exposure, remote handling, collimation, boundary control, emergency procedures for stuck sources

*   **Industrial Gauging:**
    *   **Level Gauges:** Measure material levels in tanks, vessels
        *   **Common Sources:** ¹³⁷Cs, ⁶⁰Co
        *   **Typical Activities:** 0.1-40 GBq (3-1000 mCi)
    *   **Thickness/Density Gauges:** Monitor product thickness, density, or composition
        *   **Common Sources:** ²⁴¹Am, ⁸⁵Kr, ¹⁴⁷Pm, ²⁴¹Am/Be
        *   **Typical Activities:** 0.1-40 GBq (3-1000 mCi)
    *   **Moisture Gauges:** Measure soil or material moisture content
        *   **Common Sources:** ²⁴¹Am/Be (neutron), ¹³⁷Cs (gamma)
        *   **Typical Activities:** 0.3-2 GBq (10-50 mCi)
    *   **Safety Considerations:** Fixed installation shielding, lock-out procedures during maintenance, transportation regulations, security requirements

*   **Well Logging:**
    *   **Applications:** Characterization of geological formations in oil and gas exploration
    *   **Common Sources:**
        *   ²⁴¹Am/Be (neutron): Porosity measurement
        *   ¹³⁷Cs (gamma): Density measurement
    *   **Typical Activities:** 50-800 GBq (1.5-20 Ci) for neutron sources
    *   **Safety Considerations:** Remote locations, transportation challenges, potential for lost sources, emergency procedures

*   **Irradiators:**
    *   **Applications:** Sterilization of medical products, food preservation, material modification
    *   **Common Sources:**
        *   ⁶⁰Co: Large-scale commercial irradiators
        *   ¹³⁷Cs: Blood irradiators (being phased out for security concerns)
    *   **Typical Activities:** 0.1-400 PBq (3,000-10,000,000 Ci) for commercial irradiators
    *   **Safety Considerations:** Extremely high activities, engineered safety systems, interlocks, water shielding, security measures, emergency procedures

*   **Analytical Techniques:**
    *   **X-Ray Fluorescence (XRF):** Elemental analysis of materials
        *   **Common Sources:** ⁵⁵Fe, ¹⁰⁹Cd, ²⁴¹Am
        *   **Typical Activities:** 0.1-4 GBq (3-100 mCi)
    *   **Electron Capture Detectors:** Used in gas chromatography
        *   **Common Sources:** ⁶³Ni, ³H
        *   **Typical Activities:** 0.1-1 GBq (3-30 mCi)
    *   **Safety Considerations:** Proper handling procedures, leak testing, inventory control

**1.4.3 Research Applications of Radioactive Materials:**

Radioactive materials are essential tools in scientific research across multiple disciplines.

*   **Life Sciences Research:**
    *   **Radiotracers:** Labeling of biomolecules to study metabolic pathways, protein interactions, and cellular processes
        *   **Common Isotopes:** ³H, ¹⁴C, ³²P, ³⁵S, ¹²⁵I
        *   **Typical Activities:** 0.1-100 MBq (3-3000 μCi)
    *   **Autoradiography:** Visualization of radioactively labeled molecules in tissues or cells
    *   **Cell Proliferation Studies:** Using ³H-thymidine incorporation
    *   **Safety Considerations:** Contamination control, waste segregation, monitoring, training

*   **Physical Sciences Research:**
    *   **Neutron Activation Analysis:** Elemental composition determination
    *   **Radiometric Dating:** Age determination using ¹⁴C, ⁴⁰K, uranium series
    *   **Tracer Studies:** Environmental transport, hydrology
    *   **Safety Considerations:** Application-specific protocols, waste management

*   **Particle Physics and Nuclear Research:**
    *   **Calibration Sources:** Energy calibration of detectors
    *   **Target Materials:** Production of secondary particles
    *   **Safety Considerations:** High-energy radiation fields, activation products, specialized monitoring

**1.4.4 Energy Production Applications:**

Nuclear energy utilizes radioactive materials for power generation and involves significant safety considerations.

*   **Nuclear Power Plants:**
    *   **Fuel:** Enriched uranium (3-5% ²³⁵U) in fuel assemblies
    *   **Byproducts:** Fission products, activation products, spent fuel
    *   **Safety Considerations:** Multiple engineered safety systems, containment, emergency planning, waste management

*   **Radioisotope Thermoelectric Generators (RTGs):**
    *   **Applications:** Power for remote locations, space missions
    *   **Common Sources:** ²³⁸Pu, ⁹⁰Sr
    *   **Safety Considerations:** Robust containment, security, long-term integrity

**1.4.5 Fundamental Principles of Radiation Safety:**

Three core principles form the foundation of radiation protection for all radioactive material applications:

*   **Justification:** Any practice involving radiation exposure must yield sufficient benefit to offset the radiation risk.
    *   **Implementation:** Cost-benefit analysis, risk assessment, consideration of alternatives
    *   **Example:** For medical exposures, the diagnostic or therapeutic benefit must outweigh the radiation risk

*   **Optimization (ALARA):** All exposures must be kept As Low As Reasonably Achievable, economic and social factors being taken into account.
    *   **Implementation:** Engineering controls, administrative procedures, PPE, continuous improvement
    *   **Example:** Designing a nuclear medicine hot lab with appropriate shielding, workflow, and monitoring

*   **Dose Limitation:** Individual doses must not exceed specified limits for workers and the public.
    *   **Implementation:** Regulatory limits, monitoring programs, investigation levels
    *   **Example:** Ensuring no radiation worker exceeds 50 mSv (5 rem) annual effective dose

**1.4.6 Regulatory Framework for Radioactive Material Safety:**

In the United States, multiple agencies regulate different aspects of radioactive material use:

*   **Nuclear Regulatory Commission (NRC):**
    *   **Jurisdiction:** Byproduct material, source material, special nuclear material
    *   **Regulatory Basis:** Atomic Energy Act, 10 CFR Parts 19-37, 39, 40, 70, 71
    *   **Agreement States:** 39 states have agreements with NRC to regulate certain materials within their borders
    *   **Licensing:** Specific licenses based on intended use, quantities, training, facilities
    *   **General Licenses:** Limited uses of certain devices without specific application

*   **Department of Energy (DOE):**
    *   **Jurisdiction:** DOE facilities, contractors
    *   **Regulatory Basis:** 10 CFR Part 835, DOE Orders

*   **Food and Drug Administration (FDA):**
    *   **Jurisdiction:** Radiopharmaceuticals, radiation-emitting medical devices
    *   **Regulatory Basis:** Federal Food, Drug, and Cosmetic Act

*   **Environmental Protection Agency (EPA):**
    *   **Jurisdiction:** Environmental standards, air emissions, drinking water
    *   **Regulatory Basis:** Clean Air Act, Safe Drinking Water Act, other environmental laws

*   **Department of Transportation (DOT):**
    *   **Jurisdiction:** Transport of radioactive materials
    *   **Regulatory Basis:** 49 CFR Parts 171-178

**1.4.7 Radiation Safety Program Components:**

Effective radiation safety programs for radioactive material use include multiple elements:

*   **Radiation Safety Committee (RSC):**
    *   **Function:** Oversight of radiation safety program, policy development, review of uses
    *   **Composition:** Management, Radiation Safety Officer, representative users, medical personnel (for medical uses)
    *   **Responsibilities:** Program review, authorization of users, incident review, ALARA program

*   **Radiation Safety Officer (RSO):**
    *   **Qualifications:** Specified by license, typically advanced degree plus experience
    *   **Responsibilities:** Day-to-day program management, training, monitoring, inspections, regulatory compliance

*   **Training and Education:**
    *   **Initial Training:** Radiation basics, safety procedures, regulatory requirements
    *   **Refresher Training:** Typically annual, updates on procedures and regulations
    *   **Task-Specific Training:** Detailed procedures for specific operations

*   **Facilities and Equipment:**
    *   **Design Features:** Shielding, ventilation, containment, waste storage
    *   **Safety Equipment:** Survey instruments, personal dosimeters, PPE
    *   **Signage and Labeling:** Radiation symbols, warning signs, labels on containers

*   **Operating and Emergency Procedures:**
    *   **Standard Operating Procedures (SOPs):** Step-by-step instructions for routine operations
    *   **Emergency Procedures:** Response to spills, contamination, lost sources, medical emergencies
    *   **Security Procedures:** Access control, inventory management, source tracking

*   **Monitoring and Surveillance:**
    *   **Personnel Monitoring:** Dosimeters (film, TLD, OSL), bioassay when appropriate
    *   **Area Monitoring:** Surveys, wipe tests, continuous monitors
    *   **Environmental Monitoring:** Air sampling, effluent monitoring, boundary surveys

*   **Records and Reports:**
    *   **Required Records:** Surveys, dosimetry, inventory, waste disposal, training
    *   **Retention Periods:** Vary by record type (typically 3 years to lifetime)
    *   **Regulatory Reports:** Incidents, overexposures, lost sources, annual reports

*   **Waste Management:**
    *   **Waste Classification:** Based on half-life, activity, physical/chemical form
    *   **Disposal Options:** Decay-in-storage, transfer to authorized recipient, licensed disposal facility
    *   **Documentation:** Waste manifests, disposal records

**1.4.8 Practical Radiation Safety Measures:**

*   **Time, Distance, and Shielding:**
    *   **Time:** Minimize duration of exposure
        *   **Calculation:** Dose = Dose rate × Time
        *   **Implementation:** Pre-planning, practice runs, efficient procedures
    *   **Distance:** Maximize distance from source
        *   **Calculation:** Dose rate ∝ 1/d² (inverse square law)
        *   **Implementation:** Remote handling tools, appropriate room layout
    *   **Shielding:** Place appropriate material between source and person
        *   **Calculation:** I = I₀e^(-μx) (exponential attenuation)
        *   **Implementation:** Fixed barriers, mobile shields, containers

*   **Contamination Control:**
    *   **Prevention:**
        *   Containment (fume hoods, glove boxes)
        *   Work surfaces (absorbent coverings, trays)
        *   Personal protective equipment (gloves, lab coats, shoe covers)
    *   **Detection:**
        *   Survey instruments (appropriate for radiation type)
        *   Wipe tests (removable contamination)
        *   Portal monitors (personnel contamination)
    *   **Decontamination:**
        *   Personnel decontamination procedures
        *   Surface decontamination methods
        *   Documentation and follow-up

*   **Practical Shielding Calculations:**
    *   **Half-Value Layer (HVL):** Thickness that reduces intensity by 50%
        *   **Calculation:** I = I₀ × 0.5^(x/HVL)
        *   **Example HVLs for 140 keV (⁹⁹ᵐTc):**
            *   Lead: 0.12 cm
            *   Concrete: 2.3 cm
            *   Water: 4.6 cm
    *   **Tenth-Value Layer (TVL):** Thickness that reduces intensity by 90%
        *   **Calculation:** I = I₀ × 0.1^(x/TVL)
        *   **Relationship:** TVL ≈ 3.3 × HVL

**Worked Example: Shielding Calculation for a Nuclear Medicine Hot Lab**
A nuclear medicine department regularly handles up to 100 mCi (3.7 GBq) of ⁹⁹ᵐTc. Calculate the lead thickness needed for an L-block shield to reduce the exposure rate at the operator position to less than 2 mR/hr.

Given:
- Unshielded exposure rate constant for ⁹⁹ᵐTc: 0.6 R·cm²/mCi·hr
- Distance from source to operator: 30 cm
- HVL of lead for 140 keV photons: 0.12 cm

Solution:
1. Calculate unshielded exposure rate:
   Ẋ = (0.6 R·cm²/mCi·hr × 100 mCi) / (30 cm)² = 0.67 R/hr = 670 mR/hr

2. Determine required attenuation factor:
   Attenuation factor = 2 mR/hr ÷ 670 mR/hr = 0.003

3. Calculate required lead thickness:
   Using I = I₀ × 0.5^(x/HVL)
   0.003 = 0.5^(x/0.12)
   Taking log base 0.5 of both sides:
   log₀.₅(0.003) = x/0.12
   x = 0.12 × log₀.₅(0.003)
   x = 0.12 × (-8.38) = 1.01 cm

4. Add safety margin (typically 10%):
   Final thickness = 1.01 cm × 1.1 = 1.11 cm

Therefore, a lead shield of approximately 1.1 cm thickness is required. In practice, this would be rounded up to the next available standard thickness (e.g., 1.2 cm or 1/2 inch).

**Assessment Questions (ABR Style):**

1. The mass attenuation coefficient of lead is 5.55 cm²/g for 140-keV gamma rays. The density of lead is 11.3 g/cm³. What thickness of lead is required to reduce the intensity of a narrow beam of 140-keV gamma rays to 1% of its initial value?
   A. 0.36 cm
   B. 0.83 cm
   C. 1.2 cm
   D. 3.6 cm
   E. 8.3 cm

2. A nuclear medicine technologist administers 25 mCi of ⁹⁹ᵐTc-MDP to a patient. The exposure rate constant for ⁹⁹ᵐTc is 0.6 R·cm²/mCi·hr. What is the exposure rate at 1 meter from the patient immediately after administration?
   A. 0.15 mR/hr
   B. 1.5 mR/hr
   C. 15 mR/hr
   D. 150 mR/hr
   E. 1500 mR/hr

3. A radiation worker receives an occupational dose of 2.4 rem (24 mSv) in a single year. According to NRC regulations, which of the following statements is correct?
   A. This exceeds the annual occupational dose limit and must be reported to the NRC.
   B. This exceeds the ALARA Level I investigation level but is below the annual limit.
   C. This is below all regulatory limits and requires no action.
   D. This exceeds the public dose limit but is below the occupational limit.
   E. This exceeds the embryo/fetus limit but is below the occupational limit.

4. A sealed source containing 5 Ci (185 GBq) of ¹³⁷Cs is used for industrial radiography. The HVL for ¹³⁷Cs (662 keV) in concrete is 4.8 cm. What thickness of concrete is needed to reduce the exposure rate to 2 mR/hr at a location where the unshielded exposure rate would be 2 R/hr?
   A. 14.4 cm
   B. 24 cm
   C. 33.6 cm
   D. 48 cm
   E. 67.2 cm

5. A nuclear medicine department receives a ⁹⁹Mo/⁹⁹ᵐTc generator calibrated for 2.0 Ci (74 GBq) of ⁹⁹Mo at noon on Monday. If the generator is eluted at 8:00 AM on Tuesday, what is the approximate activity of ⁹⁹ᵐTc that can be obtained, assuming 90% elution efficiency and that the generator has not been previously eluted? (T₁/₂ of ⁹⁹Mo = 66 hr, T₁/₂ of ⁹⁹ᵐTc = 6 hr)
   A. 0.5 Ci
   B. 0.9 Ci
   C. 1.4 Ci
   D. 1.8 Ci
   E. 2.0 Ci

**Alignment with CAMPEP/ABR Requirements:**
This subsection addresses core concepts outlined in the ABR Medical Physics Part 1 exam blueprint under "General Content: Section 6 - Radiation Protection, Safety, Professionalism and Ethics." It covers the applications of radioactive materials and the fundamental safety principles, regulatory frameworks, and practical measures essential for their safe use. The material aligns with CAMPEP curriculum requirements for graduate education in medical physics, particularly in radiation safety and protection.

---

##### Subsection 1.4: Radioactive Material Uses and Safety (Revised)

**Overview:**
Radioactive materials, both naturally occurring and artificially produced, are integral to the environment and modern technology. Their unique properties enable critical diagnostic and therapeutic procedures, industrial measurements, scientific investigations, and power generation. However, these same properties necessitate comprehensive safety protocols to protect workers, the public, and the environment. A profound understanding of their origins, characteristics, applications, and associated risks is paramount for medical physicists. This subsection provides an in-depth exploration of the major applications of radioactive materials, the fundamental principles of radiation safety, the complex regulatory frameworks governing their use (with emphasis on US regulations like 10 CFR 20 and 10 CFR 35), and the practical measures essential for ensuring safety in clinical, industrial, and research settings. It emphasizes quantitative aspects, clinical decision-making, and alignment with professional standards.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Identify and explain the major medical (diagnostic, therapeutic, brachytherapy), industrial, research, and energy applications of radioactive materials, including specific radionuclides and typical activities.
- Describe the fundamental principles of radiation safety (justification, optimization/ALARA, dose limitation) and apply them to practical scenarios.
- Analyze the regulatory framework governing radioactive material use in the United States (NRC, Agreement States, DOT, FDA, EPA), specifically interpreting key requirements from 10 CFR 20 (Standards for Protection Against Radiation) and 10 CFR 35 (Medical Use of Byproduct Material).
- Evaluate the essential components of a comprehensive radiation safety program (RSC, RSO, training, facilities, procedures, monitoring, records, waste management) as required by regulations.
- Design and justify appropriate safety measures (time, distance, shielding, contamination control) for specific radioactive material uses, including quantitative shielding calculations using HVL/TVL concepts.
- Apply ALARA principles through practical time, distance, and shielding calculations for external exposure control.
- Assess the effectiveness of contamination control strategies (prevention, detection, decontamination) and radioactive waste management protocols according to regulatory guidelines.
- Evaluate radiation safety considerations specific to vulnerable populations (e.g., pediatric patients, pregnant workers/patients).
- Analyze emergency response procedures for incidents involving radioactive materials (e.g., spills, lost sources).

**Estimated Completion Time:** 150-180 minutes

**Key Points for Understanding:**
- Diverse applications of radioactivity necessitate tailored safety protocols.
- Radiation safety is built upon justification, optimization (ALARA), and dose limitation.
- US regulations (NRC, Agreement States, 10 CFR 20, 10 CFR 35) establish strict requirements for licensing, personnel dosimetry, exposure limits, safety programs, and waste disposal.
- Effective radiation safety programs are multi-faceted, requiring institutional commitment, qualified personnel (RSO), comprehensive training, appropriate facilities, robust procedures, and diligent record-keeping.
- External exposure control relies fundamentally on minimizing Time, maximizing Distance (Inverse Square Law), and utilizing appropriate Shielding (HVL/TVL calculations).
- Internal exposure control focuses on preventing and detecting Contamination through containment, PPE, surveys, and decontamination.
- Radioactive waste must be managed according to its physical form, activity, and half-life, following strict regulatory pathways (decay-in-storage, transfer, licensed disposal).
- Specific safety considerations apply to medical procedures (e.g., ¹³¹I therapy, HDR brachytherapy), industrial applications (e.g., radiography, irradiators), and research settings.

**1.4.1 Medical Applications of Radioactive Materials:**

Radioactive materials are indispensable in modern medicine, enabling sophisticated diagnostic imaging and targeted therapeutic interventions.

*   **Nuclear Medicine Diagnostics (10 CFR 35 Subparts D & E):**
    *   **SPECT Imaging:** Utilizes gamma-emitting radionuclides, primarily ⁹⁹ᵐTc chemically linked to various pharmaceuticals, to visualize physiological function.
        *   **Common Radiopharmaceuticals & Typical Activities (Adult):**
            *   ⁹⁹ᵐTc-MDP (Bone): 740-1110 MBq (20-30 mCi)
            *   ⁹⁹ᵐTc-MAA (Lung Perfusion): 150-300 MBq (4-8 mCi)
            *   ⁹⁹ᵐTc-DTPA (Renal): 370-740 MBq (10-20 mCi)
            *   ⁹⁹ᵐTc-Sestamibi/Tetrofosmin (Myocardial Perfusion): 370-1110 MBq (10-30 mCi) per injection (stress/rest)
            *   ¹²³I-Ioflupane (DaTscan): 111-185 MBq (3-5 mCi)
            *   ¹²³I-NaI (Thyroid Uptake/Scan): 7.4-14.8 MBq (200-400 μCi)
            *   ⁶⁷Ga-citrate (Inflammation/Tumor): 185-370 MBq (5-10 mCi)
            *   ¹¹¹In-pentetreotide (OctreoScan): 111-222 MBq (3-6 mCi)
        *   **Safety Considerations (Ref: 10 CFR 35.60-65, 35.75, 35.315):** Radiopharmacy preparation (shielded vials, syringe shields, L-blocks, fume hoods for volatile materials like ¹³³Xe), dose calibrator accuracy checks (10 CFR 35.60), patient identification (10 CFR 35.315), administration techniques (minimize time/distance), post-procedure patient instructions (ALARA for family/public).

    *   **PET Imaging:** Employs positron-emitting radionuclides, offering higher sensitivity and resolution for metabolic and molecular imaging.
        *   **Common Radiopharmaceuticals & Typical Activities (Adult):**
            *   ¹⁸F-FDG (Oncology/Neurology/Cardiology): 185-740 MBq (5-20 mCi)
            *   ¹⁸F-Fluciclovine/¹⁸F-Choline/¹⁸F-PSMA (Prostate Cancer): 185-370 MBq (5-10 mCi)
            *   ¹⁸F-NaF (Bone): 185-370 MBq (5-10 mCi)
            *   ¹³N-Ammonia/⁸²Rb-Chloride (Myocardial Perfusion): 370-740 MBq (10-20 mCi) for ¹³N; 1110-2220 MBq (30-60 mCi) for ⁸²Rb generator elution.
            *   ⁶⁸Ga-DOTATATE/DOTATOC (Neuroendocrine Tumors): 111-185 MBq (3-5 mCi)
            *   ⁶⁸Ga-PSMA (Prostate Cancer): 111-259 MBq (3-7 mCi)
        *   **Safety Considerations:** Higher energy annihilation photons (511 keV) require thicker shielding (lead, tungsten) compared to SPECT isotopes. Automated synthesis units in shielded hot cells are common. Increased potential for staff extremity doses during preparation and injection. Patient uptake rooms require careful design to minimize staff/public exposure.

*   **Therapeutic Nuclear Medicine (Radiopharmaceutical Therapy - RPT) (10 CFR 35 Subpart E):** Delivers targeted radiation dose using unsealed radionuclides.
    *   **Common Therapies & Typical Activities:**
        *   ¹³¹I-NaI (Thyroid Cancer/Hyperthyroidism): 185 MBq - 7.4+ GBq (5 mCi - 200+ mCi)
        *   ¹⁷⁷Lu-DOTATATE (Neuroendocrine Tumors): 7.4 GBq (200 mCi) per cycle
        *   ¹⁷⁷Lu-PSMA-617 (Metastatic Prostate Cancer): 7.4 GBq (200 mCi) per cycle
        *   ²²³Ra-dichloride (Xofigo® - Bone Mets): 55 kBq/kg (1.49 μCi/kg) per injection
        *   ⁹⁰Y-microspheres (TheraSphere®/SIR-Spheres® - Liver Tumors): Activity calculated based on dosimetry, often 1-3 GBq (30-80 mCi)
        *   ¹⁵³Sm-EDTMP (Quadramet® - Bone Pain): 37 MBq/kg (1 mCi/kg)
        *   ¹³¹I-MIBG (Neuroblastoma/Pheochromocytoma): 3.7-18.5 GBq (100-500 mCi)
    *   **Safety Considerations (Ref: 10 CFR 35.75, 35.315):** Significantly higher activities require robust safety protocols. Patient isolation often required (threshold typically >1220 MBq or 33 mCi of ¹³¹I, or dose rate >0.05 mSv/hr or 5 mrem/hr at 1 meter - 10 CFR 35.75). Shielded administration, dedicated patient rooms with specific plumbing/ventilation, extensive contamination control, detailed patient release instructions (written directive required - 10 CFR 35.40), careful waste management (urine, linens, etc.), staff dosimetry (whole body, extremity, thyroid bioassay for ¹³¹I handling).

*   **Brachytherapy (10 CFR 35 Subparts F & H):** Uses sealed radioactive sources placed directly into or near the target volume.
    *   **Low Dose Rate (LDR) - Manual or Remote Afterloading:**
        *   **Common Sources:** ¹²⁵I seeds (Prostate, Eye Plaques), ¹⁰³Pd seeds (Prostate), ¹³⁷Cs tubes/needles (Gynecological - largely historical in US), ¹³¹Cs seeds (Prostate).
        *   **Typical Activities:** Seeds: 11-37 MBq (0.3-1.0 mCi) per seed. ¹³⁷Cs: 370-740 MBq (10-20 mCi) per source.
        *   **Safety Considerations (Ref: 10 CFR 35.400 series):** Source inventory control, leak testing, calibration (traceable to NIST), manual handling procedures (forceps, shielding), patient surveys post-implant, lost source procedures, patient release instructions for permanent implants.

    *   **High Dose Rate (HDR) - Remote Afterloading:**
        *   **Common Sources:** ¹⁹²Ir (Most common), ⁶⁰Co (Emerging).
        *   **Typical Activities:** 185-444 GBq (5-12 Ci) for ¹⁹²Ir.
        *   **Safety Considerations (Ref: 10 CFR 35.600 series):** Shielded treatment rooms (vaults), remote afterloader device with interlocks, console operation outside the room, emergency source retraction mechanisms, emergency procedures (source retrieval), source exchange protocols, daily/monthly QA checks (timer accuracy, source positioning, interlocks - 10 CFR 35.615, 35.642, 35.643), security of high-activity sources.

    *   **Electronic Brachytherapy (eBx):** Uses miniature X-ray tubes, not radioactive sources, but often managed under similar safety paradigms.

*   **Calibration and Quality Assurance Sources (10 CFR 35.59, 35.60, 35.67):**
    *   **Sealed Check Sources:** Used for instrument QC (dose calibrators, survey meters, well counters, uptake probes, gamma cameras).
        *   **Common Sources:** ⁵⁷Co, ¹³³Ba, ¹³⁷Cs, ⁶⁸Ge/⁶⁸Ga, ²²Na.
        *   **Typical Activities:** 0.1-37 MBq (3 μCi - 1 mCi).
        *   **Safety Considerations:** Inventory control, leak testing (10 CFR 35.67), proper storage (shielded containers), handling procedures to minimize exposure.

[ILLUSTRATION: Table summarizing common medical radionuclides, their half-lives, decay modes, primary emissions, typical activities, and primary safety concerns.]

**Clinical Application Deep Dive: Radiation Safety in ¹³¹I Therapy (>33 mCi)**
(Ref: 10 CFR 35.75, NUREG-1556 Vol. 9)
Iodine-131 therapy for thyroid cancer exemplifies rigorous radiation safety management:

1.  **Pre-Administration (10 CFR 35.40, 35.41):**
    *   Written Directive: Patient identity, radionuclide, prescribed dose, route.
    *   Dose Verification: Assay dose within 10% of prescription (10 CFR 35.63). Dose calibrator QC essential (Constancy, Linearity, Accuracy, Geometry - 10 CFR 35.60).
    *   Patient Preparation: Low-iodine diet, pregnancy test, instructions.

2.  **Administration (ALARA):**
    *   Administer in designated area with appropriate shielding (L-block, vial shield, syringe shield).
    *   Use absorbent materials to contain potential spills.
    *   Staff PPE: Double gloves, lab coat, +/- thyroid shield (effectiveness debated for external exposure).
    *   Minimize time, maximize distance.

3.  **Patient Hospitalization (10 CFR 35.75):**
    *   Required if dose to other individuals likely to exceed 5 mSv (0.5 rem).
    *   Designated room: Shielding considerations, private toilet, signage ("Radioactive Materials").
    *   Room Preparation: Cover surfaces, limit items, provide dedicated waste bins.
    *   Staff Entry/Exit: Logbook, dosimetry, surveys, PPE.
    *   Patient Care: Minimize staff time in room, maintain distance, provide clear instructions to patient (hygiene, flushing toilet multiple times).
    *   Waste Management: Collect contaminated linens, utensils, trash separately for decay-in-storage or disposal.

4.  **Patient Release (10 CFR 35.75):**
    *   Criteria: Dose to other individuals unlikely to exceed 5 mSv (0.5 rem).
    *   Methods: Measured dose rate (<0.05-0.07 mSv/hr or 5-7 mrem/hr at 1 meter, depending on interpretation/guidance) OR calculated remaining activity (often <1220 MBq or 33 mCi, but dose-based limit is primary).
    *   Written Instructions: Required for anyone receiving >1 mSv (100 mrem). Include duration of precautions, minimizing contact (esp. children/pregnant women), sleeping arrangements, hygiene, work restrictions.

5.  **Post-Release & Decontamination:**
    *   Room Survey: Survey room for contamination and exposure rates before release for general use (removable contamination limits often <200 dpm/100 cm² or <1000 dpm/100 cm² depending on area; exposure rate <0.02 mSv/hr or 2 mrem/hr).
    *   Decontamination: Use appropriate cleaning agents (e.g., Radiacwash) if limits exceeded.

6.  **Medical Physics Role:** Protocol development, staff training, dose calculations (patient release, fetal dose estimates), room design/shielding verification, survey meter calibration, incident investigation, regulatory compliance.

[ILLUSTRATION: Flowchart summarizing the key steps and decision points in managing a high-dose ¹³¹I therapy patient.]

**1.4.2 Industrial Applications of Radioactive Materials:**

Radioactive materials provide unique capabilities for industrial processes, but often involve high activities requiring stringent safety controls.

*   **Industrial Radiography (10 CFR Part 34):**
    *   **Applications:** Non-destructive testing (NDT) of welds, castings, pipelines.
    *   **Common Sources:** ¹⁹²Ir (most common), ⁶⁰Co, ⁷⁵Se.
    *   **Typical Activities:** 0.4-4 TBq (10-100+ Ci).
    *   **Safety Considerations:** High dose rates necessitate remote handling devices ("cameras" or "projectors"), shielded enclosures or controlled high-radiation areas, boundary surveys, audible/visible alarms, extensive training, emergency procedures for source disconnects or retrieval, transport regulations (Type A/B packaging).

*   **Industrial Gauging (Fixed & Portable):**
    *   **Applications:** Level, thickness, density, moisture measurement.
    *   **Common Sources:** ¹³⁷Cs, ⁶⁰Co (level/density); ²⁴¹Am, ⁸⁵Kr (thickness); ²⁴¹Am/Be (neutron - moisture).
    *   **Typical Activities:** 0.1-40 GBq (few mCi to ~1 Ci).
    *   **Safety Considerations:** Often involves fixed shielding integrated into the device. Lock-out/tag-out procedures during maintenance. Leak testing of sealed sources. Security of portable gauges. Training for operators.

*   **Well Logging:**
    *   **Applications:** Characterizing geological formations in oil/gas exploration.
    *   **Common Sources:** ²⁴¹Am/Be (neutron porosity), ¹³⁷Cs (gamma density).
    *   **Typical Activities:** 10-800 GBq (0.3-20 Ci).
    *   **Safety Considerations:** Rugged source encapsulation, transport regulations, potential for source abandonment downhole (requires specific NRC notification/procedures), emergency retrieval plans.

*   **Irradiators (10 CFR Part 36):**
    *   **Applications:** Sterilization (medical devices, food), material modification.
    *   **Common Sources:** ⁶⁰Co (large scale), ¹³⁷Cs (smaller scale, e.g., blood irradiators - being phased out due to security concerns).
    *   **Typical Activities:** 10 PBq+ (MegaCuries) for large facilities; ~1-100 TBq (kiloCuries) for smaller units.
    *   **Safety Considerations:** Extremely high dose rates require robust engineered safety features (shielding pools, mazes, interlocks), access control, security (IAEA Category 1 sources), dosimetry, emergency procedures.

*   **Other Industrial Uses:** Static eliminators (²¹⁰Po), X-Ray Fluorescence (XRF) analyzers (⁵⁵Fe, ¹⁰⁹Cd, ²⁴¹Am), Electron Capture Detectors (⁶³Ni).

**1.4.3 Research Applications of Radioactive Materials (10 CFR Part 33):**

Radioactive materials are vital tools in biological, chemical, and physical research.

*   **Life Sciences:**
    *   **Radiotracers:** ³H, ¹⁴C, ³²P, ³⁵S, ¹²⁵I used to label molecules and study metabolic pathways, drug kinetics, etc.
    *   **Typical Activities:** Microcurie to millicurie range.
    *   **Safety Considerations:** Primarily contamination control (fume hoods, glove boxes, surveys, waste segregation), accurate record-keeping, personnel training.

*   **Physical Sciences:** Neutron activation analysis, radiometric dating, environmental tracing.

**1.4.4 Energy Production Applications:**

*   **Nuclear Power Plants:** Utilize ²³⁵U fission. Involve massive inventories of fission and activation products. Safety relies on complex engineered systems, containment, and strict operational protocols (regulated primarily under 10 CFR Part 50).
*   **Radioisotope Thermoelectric Generators (RTGs):** Use heat from decay (e.g., ²³⁸Pu) to generate electricity for space probes and remote applications. Safety focuses on robust containment and security.

**1.4.5 Fundamental Principles of Radiation Safety (ICRP Framework):**

The modern system of radiological protection, largely based on recommendations from the International Commission on Radiological Protection (ICRP), rests on three fundamental principles:

*   **Justification:** Any decision that alters the radiation exposure situation should do more good than harm. The introduction or continuation of any practice involving radiation exposure must yield a sufficient net benefit to the exposed individuals or society to offset the radiation detriment it causes.
    *   **Implementation:** Evaluating benefits vs. risks, considering alternatives (e.g., non-radioactive imaging modalities).
    *   **Clinical Example:** Justifying a CT scan based on diagnostic need vs. the associated radiation dose.

*   **Optimization (ALARA - As Low As Reasonably Achievable):** The likelihood of incurring exposures, the number of people exposed, and the magnitude of their individual doses should all be kept As Low As Reasonably Achievable, economic and social factors being taken into account. For medical exposures, this involves keeping doses to patients at the minimum necessary to achieve the required diagnostic or therapeutic objective.
    *   **Implementation:** Use of engineering controls (shielding, ventilation), administrative controls (procedures, time limits), personal protective equipment (PPE), dose constraints, diagnostic reference levels (DRLs), continuous quality improvement.
    *   **Clinical Example:** Using syringe shields, optimizing imaging protocols, employing pediatric-specific techniques, designing shielded facilities.

*   **Dose Limitation:** The total dose to any individual from regulated sources in planned exposure situations (excluding medical exposure of patients) should not exceed the appropriate limits recommended by the ICRP and codified in regulations.
    *   **Implementation:** Establishing annual dose limits for occupational exposure (workers) and public exposure. Requires personnel dosimetry programs and environmental monitoring.
    *   **Key US Limits (10 CFR 20.1201, 20.1301):**
        *   Occupational (Adult): 50 mSv (5 rem) Total Effective Dose Equivalent (TEDE) per year.
        *   Lens of Eye: 150 mSv (15 rem) per year.
        *   Skin/Extremities: 500 mSv (50 rem) per year.
        *   Declared Pregnant Worker: 5 mSv (0.5 rem) to embryo/fetus over gestation period.
        *   Minor (Occupational): 10% of adult limits.
        *   Public: 1 mSv (0.1 rem) TEDE per year from licensed operations.
        *   Constraint for air emissions: 0.1 mSv (10 mrem) per year.

[ILLUSTRATION: Diagram illustrating the relationship between Justification, Optimization (ALARA), and Dose Limitation.]

**1.4.6 Regulatory Framework for Radioactive Material Safety (USA Focus):**

A complex web of agencies governs radioactive material use in the US:

*   **Nuclear Regulatory Commission (NRC):**
    *   **Jurisdiction:** Regulates byproduct material (reactor-produced, accelerator-produced since 2005 Energy Policy Act), source material (U, Th), and special nuclear material (fissile materials like enriched U, Pu).
    *   **Regulations:** Title 10, Code of Federal Regulations (10 CFR).
        *   **Part 19:** Notices, Instructions, and Reports to Workers; Inspections.
        *   **Part 20:** Standards for Protection Against Radiation (Dose limits, monitoring, waste, ALARA).
        *   **Part 30:** Rules of General Applicability to Domestic Licensing of Byproduct Material.
        *   **Part 33:** Specific Domestic Licenses of Broad Scope for Byproduct Material.
        *   **Part 34:** Licenses for Industrial Radiography.
        *   **Part 35:** Medical Use of Byproduct Material (Detailed requirements for diagnostic/therapeutic uses, RSO/AU qualifications, QA, patient safety).
        *   **Part 36:** Licenses for Industrial Irradiators.
        *   **Part 37:** Physical Protection of Category 1 and Category 2 Quantities of Radioactive Material.
        *   **Part 61:** Licensing Requirements for Land Disposal of Radioactive Waste.
        *   **Part 71:** Packaging and Transportation of Radioactive Material.
    *   **Agreement States:** ~39 states have agreements with the NRC allowing them to regulate most byproduct, source, and small quantities of special nuclear material within their borders. State regulations must be at least as stringent as NRC regulations. Medical physicists must be aware of specific state requirements.
    *   **Licensing:** Institutions require specific licenses detailing authorized materials, quantities, uses, locations, personnel (RSO, Authorized Users - AUs), facilities, equipment, and the radiation safety program.

*   **Department of Transportation (DOT):**
    *   **Jurisdiction:** Regulates the packaging, labeling, and transport of hazardous materials, including radioactive materials.
    *   **Regulations:** 49 CFR Parts 171-180. Harmonized with IAEA transport regulations (SSR-6).
    *   **Key Concepts:** Activity limits (A1, A2 values), package types (Excepted, Industrial, Type A, Type B), labeling (White-I, Yellow-II, Yellow-III based on surface dose rate and Transport Index - TI), shipping papers.

*   **Food and Drug Administration (FDA):**
    *   **Jurisdiction:** Regulates the safety and efficacy of drugs and medical devices, including radiopharmaceuticals and radiation-emitting devices (e.g., X-ray machines, accelerators, HDR units).
    *   **Regulations:** 21 CFR.

*   **Environmental Protection Agency (EPA):**
    *   **Jurisdiction:** Sets environmental radiation standards (air, water), regulates hazardous waste disposal (including mixed waste).
    *   **Regulations:** 40 CFR.

*   **Occupational Safety and Health Administration (OSHA):**
    *   **Jurisdiction:** Regulates general workplace safety, including potential exposure to hazardous materials.

[ILLUSTRATION: Venn diagram showing the overlapping jurisdictions of NRC, Agreement States, DOT, FDA, and EPA regarding radioactive materials.]

**1.4.7 Radiation Safety Program Components (Ref: 10 CFR 20.1101, 10 CFR 35.24):**

An effective radiation safety program, mandated by license conditions, includes:

*   **Radiation Safety Committee (RSC) (Required for Broad Scope / Type A licenses, often used by Type B/C):**
    *   **Function:** Provides oversight, reviews/approves uses, ensures ALARA implementation, reviews incidents.
    *   **Composition:** Typically includes RSO, management representative, authorized users, nursing representative, worker representative.

*   **Radiation Safety Officer (RSO):**
    *   **Qualifications:** Defined by regulation based on license type (e.g., 10 CFR 35.50 for medical RSO - board certification or specific training/experience).
    *   **Responsibilities:** Day-to-day program management, developing/implementing procedures, ensuring regulatory compliance, training, dosimetry review, audits, incident investigation, liaison with regulators.

*   **Training (10 CFR 19.12, 10 CFR 35.310):**
    *   **Initial & Annual Refresher:** For all radiation workers. Covers radiation risks, safety procedures, regulations, worker rights.
    *   **Task-Specific Training:** For specific procedures (e.g., HDR console operation, radiopharmaceutical administration).
    *   **Documentation:** Training records are essential.

*   **Facilities and Equipment:**
    *   **Design:** Shielding, ventilation (fume hoods), restricted access areas, waste storage areas.
    *   **Safety Equipment:** Survey meters (calibrated annually - 10 CFR 35.61), personal dosimeters, contamination monitoring equipment (wipe test counters, well counters), PPE (gloves, lab coats, eye protection, lead aprons, syringe shields).
    *   **Signage & Labeling (10 CFR 20.1901-1905):** "Caution, Radioactive Material" signs, labels on containers indicating radionuclide, activity, date. Posting requirements for Radiation Areas, High Radiation Areas, Very High Radiation Areas.

*   **Operating and Emergency Procedures:**
    *   **Standard Operating Procedures (SOPs):** Detailed instructions for safe handling, use, storage, and disposal.
    *   **Emergency Procedures:** Spills (minor/major), contamination events, lost/stolen sources, fires, medical emergencies involving radioactive patients.
    *   **Security Procedures (10 CFR Part 37):** For high-activity sources (Category 1 & 2), includes access control, background checks, source tracking, transport security.

*   **Monitoring and Surveillance (10 CFR Part 20 Subparts F & L):**
    *   **Personnel Monitoring:** Required if likely to receive >10% of occupational dose limits. Dosimeters (OSL, TLD), extremity dosimeters, bioassay (e.g., thyroid counts for ¹³¹I, urinalysis for ³H).
    *   **Area Monitoring:** Radiation surveys (exposure rate) using calibrated survey meters (e.g., ion chambers, GM detectors). Contamination surveys (wipe tests) for removable contamination.
    *   **Leak Testing:** Sealed sources must be leak tested (typically every 6 months) to check for removable contamination > 0.005 μCi (185 Bq) (10 CFR 35.67).

*   **Records and Reports (10 CFR Part 20 Subpart L, Part 35 Subpart L):**
    *   **Required Records:** Dosimetry results, surveys, instrument calibrations, leak tests, inventory, waste disposal, training, RSC minutes, audits, incident reports.
    *   **Retention Periods:** Vary (e.g., 3 years for surveys, lifetime for personnel dosimetry).
    *   **Regulatory Reports:** Overexposures, lost/stolen material, leaking sources, medical events (10 CFR 35.3045 - wrong patient/drug/route/dose >20% or organ dose >50 rem).

*   **Waste Management (10 CFR 20 Subpart K):**
    *   **Options:**
        *   Decay-in-Storage (DIS): For short-lived waste (T₁/₂ < 120 days). Hold for 10 half-lives, survey to ensure background levels before disposal as normal trash (must obliterate radiation symbols).
        *   Transfer to Authorized Recipient: Return to manufacturer, transfer to another licensee, or transfer to licensed waste broker/processor.
        *   Licensed Disposal Facility: For long-lived or high-activity waste.
        *   Sewer Disposal (10 CFR 20.2003): Strict limits on concentration and total annual activity.
    *   **Documentation:** Manifests for transfers, DIS records.

**1.4.8 Practical Radiation Safety Measures (ALARA Implementation):**

*   **Time:** Minimize time spent near radiation sources.
    *   **Implementation:** Pre-planning tasks, using efficient procedures, dry runs for complex operations.
    *   **Calculation:** Dose = Dose Rate × Time

*   **Distance:** Maximize distance from radiation sources.
    *   **Implementation:** Use remote handling tools (forceps, tongs), stand back during exposures, design workflows to increase distance.
    *   **Calculation:** Dose Rate ∝ 1/d² (Inverse Square Law for point sources). For line/area sources, the fall-off is less rapid.

*   **Shielding:** Use appropriate materials to attenuate radiation.
    *   **Implementation:** Fixed barriers (lead, concrete walls), mobile shields (L-blocks, bed shields), syringe shields, vial shields, source containers.
    *   **Material Choice:** Depends on radiation type and energy. Lead/tungsten for photons; plastics/water/concrete for neutrons; thin plastic/paper for high-energy betas.
    *   **Calculation:**
        *   Exponential Attenuation: I = I₀ * e^(-μx)
        *   Half-Value Layer (HVL): Thickness reducing intensity by 50%. I = I₀ * (0.5)^(x/HVL)
        *   Tenth-Value Layer (TVL): Thickness reducing intensity by 90%. I = I₀ * (0.1)^(x/TVL). TVL ≈ 3.32 * HVL.
        *   Build-up Factor (B): Accounts for scattered radiation in broad beams. I = I₀ * B * e^(-μx).

[ILLUSTRATION: Diagram clearly showing the concepts of Time, Distance, and Shielding with practical examples.]

**Worked Example: Shielding Calculation (Revised)**
A vial containing 500 mCi (18.5 GBq) of ¹⁸F-FDG is stored behind a lead shield. Calculate the lead thickness needed to reduce the exposure rate at 50 cm to less than 0.02 mSv/hr (2 mrem/hr). Assume point source geometry.

Given:
- Exposure rate constant (Γ) for ¹⁸F ≈ 0.6 R·cm²/mCi·hr at 1 cm (includes 511 keV photons)
- Target Dose Rate = 0.02 mSv/hr (Note: 1 R ≈ 1 rem = 10 mSv for photons)
- Distance (d) = 50 cm
- HVL of lead for 511 keV photons ≈ 0.4 cm

Solution:
1.  Calculate unshielded exposure rate (Ẋ₀) at 1 cm:
    Ẋ₀ = Γ × Activity = (0.6 R·cm²/mCi·hr) × 500 mCi = 300 R/hr at 1 cm
2.  Calculate unshielded exposure rate (Ẋ) at 50 cm using Inverse Square Law:
    Ẋ = Ẋ₀ × (1 cm / 50 cm)² = 300 R/hr × (1/2500) = 0.12 R/hr = 120 mR/hr ≈ 1.2 mSv/hr
3.  Determine required attenuation factor (Transmission, T):
    T = Target Dose Rate / Unshielded Dose Rate = (0.02 mSv/hr) / (1.2 mSv/hr) ≈ 0.0167
4.  Calculate required number of HVLs (n):
    T = (0.5)ⁿ
    n = log₀.₅(T) = log₀.₅(0.0167) = log(0.0167) / log(0.5) ≈ -1.78 / -0.301 ≈ 5.9 HVLs
5.  Calculate required lead thickness (x):
    x = n × HVL = 5.9 × 0.4 cm ≈ 2.36 cm

Therefore, approximately 2.4 cm of lead shielding is required. (Note: Build-up factor could increase this slightly in a broad beam scenario).

*   **Contamination Control:** Preventing and managing the spread of unsealed radioactive material.
    *   **Prevention:**
        *   Containment: Fume hoods (for volatile materials), glove boxes.
        *   Protective Barriers: Absorbent paper (e.g., Chux), trays.
        *   PPE: Lab coats, disposable gloves (double-gloving often recommended), shoe covers, safety glasses.
        *   Procedures: No eating/drinking/smoking in labs, proper pipetting techniques.
    *   **Detection:**
        *   Direct Survey: Using appropriate survey meter (e.g., pancake GM for beta/gamma) to detect contamination on surfaces, personnel.
        *   Indirect Survey (Wipe Test): Wiping a defined area (typically 100 cm²) with filter paper and counting it in a sensitive detector (e.g., well counter, liquid scintillation counter) to quantify removable contamination.
        *   Regulatory Limits (Example - NRC NUREG-1556): Often <1000 or <200 dpm/100 cm² for removable contamination depending on area type (restricted vs unrestricted).
    *   **Decontamination:**
        *   Personnel: Remove contaminated clothing, wash affected skin gently with mild soap and lukewarm water.
        *   Surfaces: Use appropriate cleaning agents (e.g., Radiacwash), work from outer edge inward, re-survey, document.

[ILLUSTRATION: Flowchart for responding to a radioactive spill (minor vs major based on activity/radionuclide/location).]

**1.4.9 Special Considerations:**

*   **Pediatric Patients:** Doses should be scaled appropriately (e.g., based on weight/age using EANM or SNMMI guidelines). ALARA is particularly critical.
*   **Pregnant Workers/Patients (10 CFR 20.1208):** Declared pregnant workers have a lower dose limit (5 mSv over gestation). Fetal dose estimates may be required for pregnant patients undergoing procedures. Justification principle is paramount.
*   **Emergency Response:** Procedures must be in place for spills, lost sources, fires, medical events. Drills should be conducted. Coordination with local emergency responders may be needed.

**Assessment Questions (Revised ABR Style):**

1.  (Calculation) The exposure rate constant for ¹⁹²Ir is 4.69 R·cm²/mCi·hr at 1 cm. An HDR brachytherapy source has an activity of 10 Ci. What is the approximate exposure rate in R/hr at 1 meter from the unshielded source?
    A. 0.469 R/hr
    B. 4.69 R/hr
    C. 46.9 R/hr
    D. 469 R/hr
    E. 4690 R/hr
    *(Answer: B. Ẋ = (4.69 R·cm²/mCi·hr) × (10 Ci × 1000 mCi/Ci) / (100 cm)² = 4.69 R/hr)*

2.  (Regulation) According to 10 CFR 35, a written directive is required before administering which of the following?
    A. 15 mCi of ⁹⁹ᵐTc-MDP for a bone scan.
    B. 5 mCi of ¹⁸F-FDG for a PET scan.
    C. 100 mCi of ¹³¹I-NaI for thyroid cancer therapy.
    D. 3 mCi of ¹¹¹In-pentetreotide for OctreoScan.
    E. A lung perfusion scan using ⁹⁹ᵐTc-MAA.
    *(Answer: C. 10 CFR 35.40 requires a written directive for any therapeutic dosage of unsealed byproduct material.)*

3.  (Concept/Calculation) A radioactive source has a half-life of 6 hours. If the initial dose rate at 1 meter is 10 mSv/hr, what is the approximate total dose delivered at 1 meter over a very long time (assuming continuous exposure)?
    A. 60 mSv
    B. 86 mSv
    C. 144 mSv
    D. 600 mSv
    E. Infinite
    *(Answer: B. Total Dose = Initial Dose Rate × Mean Life = DR₀ × (T₁/₂ / ln2) = 10 mSv/hr × (6 hr / 0.693) ≈ 10 × 8.66 ≈ 86.6 mSv)*

4.  (Regulation/Application) A hospital room housing a patient treated with 150 mCi of ¹³¹I must be surveyed before being released for unrestricted use. Which of the following survey results would typically allow the room to be released according to NRC guidance?
    A. Exposure rate of 1 mrem/hr at 1 meter from the bed.
    B. Removable surface contamination of 5000 dpm/100 cm² on the floor.
    C. Exposure rate of 0.1 mrem/hr anywhere in the room.
    D. Removable surface contamination of 500 dpm/100 cm² on the bedside table.
    E. Exposure rate of 3 mrem/hr at the doorway.
    *(Answer: D. Typical release limits are often <2 mrem/hr exposure and <1000 dpm/100 cm² removable contamination, though specific license conditions may vary. 0.1 mrem/hr is unnecessarily low, 1 and 3 mrem/hr are too high, 5000 dpm/100 cm² is too high.)*

5.  (Scenario/Calculation) A small spill (approx. 1 mCi) of ⁹⁹ᵐTc occurs in a hot lab. A survey meter with a pancake GM probe (efficiency ≈ 10% for ⁹⁹ᵐTc) reads 5000 counts per minute (cpm) over a 100 cm² area after initial cleanup. The background reading is 50 cpm. Does this area meet a typical removable contamination limit of 1000 dpm/100 cm² for restricted areas?
    A. Yes, the contamination is well below the limit.
    B. Yes, the contamination is slightly below the limit.
    C. No, the contamination is slightly above the limit.
    D. No, the contamination is significantly above the limit.
    E. Cannot be determined without wipe test results.
    *(Answer: D. Net cpm = 5000 - 50 = 4950 cpm. Activity (dpm) = cpm / efficiency = 4950 / 0.10 = 49500 dpm/100 cm². This is significantly above 1000 dpm/100 cm². Note: This assumes the GM reading represents removable contamination, which is why a wipe test (Option E) is the definitive method, but the question asks about meeting the limit based *on the reading*.)*

6.  (Shielding Calculation) How many half-value layers (HVLs) are required to reduce the intensity of a narrow photon beam to 5% of its original value?
    A. 2.0
    B. 3.0
    C. 3.3
    D. 4.3
    E. 5.0
    *(Answer: D. T = (0.5)ⁿ => 0.05 = (0.5)ⁿ => n = log₀.₅(0.05) = log(0.05)/log(0.5) ≈ -1.30 / -0.301 ≈ 4.32)*

**Alignment with CAMPEP/ABR Requirements:**
This revised subsection provides enhanced detail on regulatory aspects (10 CFR 20, 35), practical safety measures, and quantitative calculations, directly addressing core competencies outlined in the ABR Medical Physics Part 1 exam blueprint under "General Content: Section 6 - Radiation Protection, Safety, Professionalism and Ethics." It integrates knowledge from other sections (decay kinetics, interactions) and aligns with CAMPEP curriculum requirements for graduate education in medical physics, emphasizing radiation safety and regulatory compliance.

---

##### Subsection 1.5: Radiation Generating Equipment: Photons, Electrons, and Heavy Particles (Revised)

**Overview:**
Beyond radioactive materials, a significant portion of radiation used in medicine is produced by specialized electrical devices. These machines accelerate charged particles to high energies, which then interact to produce clinically useful radiation beams, primarily photons (X-rays) and electrons, but also heavier particles like protons. Understanding the design, operation, physics principles, and quality assurance (QA) of this equipment is fundamental for medical physicists in diagnostic imaging and radiation therapy. This subsection details the major types of radiation generating equipment, including X-ray tubes, linear accelerators (linacs), cyclotrons, and synchrotrons, focusing on their components, beam generation mechanisms, energy spectra, and clinical applications, incorporating enhanced quantitative details and clinical context.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the components and operating principles of diagnostic and therapeutic X-ray tubes.
- Explain the mechanisms of Bremsstrahlung and characteristic X-ray production and factors influencing the resulting photon spectrum (kVp, target material, filtration).
- Analyze the design and function of key components in a medical linear accelerator (electron gun, accelerating waveguide, bending magnet, target, flattening filter, scattering foil, collimation system), including typical operating parameters.
- Differentiate between photon mode and electron mode operation in a linac, explain how the respective beams are produced and shaped, and discuss clinical rationale for modality selection.
- Describe the principles of operation for cyclotrons and synchrotrons used for proton and heavy ion therapy, including typical magnetic field strengths.
- Compare and contrast the energy spectra and characteristics of beams produced by different types of radiation generating equipment.
- Discuss the clinical applications of X-rays, electron beams, and heavy particle beams in diagnosis and therapy.
- Identify key quality assurance parameters for radiation generating equipment.

**Estimated Completion Time:** 190-220 minutes

**Key Points for Understanding:**
- X-ray tubes generate photons via Bremsstrahlung and characteristic emission when high-energy electrons strike a target.
- The X-ray spectrum is characterized by a continuous Bremsstrahlung component and discrete characteristic peaks, influenced by kVp, target Z, and filtration.
- Medical linear accelerators (linacs) use microwave power to accelerate electrons to MeV energies for producing high-energy photon and electron beams for radiation therapy.
- Linac components include an electron source, accelerating structure (with high shunt impedance for efficiency), RF power source, beam transport system (including energy-defining bending magnets), and treatment head for beam shaping.
- Photon beams are produced by directing the electron beam onto a high-Z target (Bremsstrahlung), followed by flattening and collimation.
- Electron beams are produced by removing the target and flattening filter, using scattering foils to spread the beam, and applicators/cutouts for collimation; energy is selected via bending magnet current/accelerator settings.
- Cyclotrons (using ~1-2 Tesla magnetic fields) and synchrotrons (varying fields up to several Tesla) accelerate protons or heavier ions for particle therapy.
- Beam characteristics (energy spectrum, penetration, dose distribution) differ significantly between photons, electrons, and heavy particles, dictating their clinical utility.
- Rigorous quality assurance is essential for all radiation generating equipment to ensure accurate and safe operation.

**1.5.1 X-Ray Tubes:**

X-ray tubes are the workhorse for generating photons used in diagnostic radiology (radiography, fluoroscopy, CT) and superficial/orthovoltage radiation therapy.

*   **Components:**
    *   **Glass or Metal Envelope:** Evacuated enclosure maintaining a high vacuum (~10⁻⁵ Pa or lower) to prevent electron collisions with air molecules.
    *   **Cathode Assembly:**
        *   **Filament:** Tungsten wire heated by a low-voltage current (filament current, typically 3-6 A). Thermionic emission releases electrons.
        *   **Focusing Cup:** Negatively charged molybdenum or nickel cup surrounding the filament. Electrostatic focusing shapes the electron cloud and directs it towards the anode. Bias voltage can control focal spot size (biased tubes).
    *   **Anode Assembly:**
        *   **Target:** Material struck by accelerated electrons to produce X-rays. Tungsten (Z=74) is common due to its high atomic number (efficient Bremsstrahlung), high melting point (3422 °C), and good thermal conductivity. Molybdenum (Z=42) or Rhodium (Z=45) targets are used in mammography for specific characteristic X-ray energies.
        *   **Stationary Anode:** Used in low-power applications (e.g., dental units). Target is embedded in a copper block for heat dissipation.
        *   **Rotating Anode:** Used in high-power applications (radiography, CT). Tungsten-rhenium alloy disc rotates at high speed (3,000-10,000 RPM) driven by an induction motor (stator outside, rotor inside). Distributes heat over a larger area (focal track), allowing higher tube currents (mA) and shorter exposure times.
    *   **High Voltage Supply:** Provides the accelerating potential difference (kVp) between cathode and anode (typically 20-150 kVp for diagnostics, 50-300 kVp for orthovoltage therapy).
    *   **Cooling System:** Oil bath surrounding the tube insert, often with external heat exchangers (fans, water cooling) to dissipate the large amount of heat generated (~99% of electron energy becomes heat).

*   **Operating Principle:**
    1.  Filament is heated (thermionic emission), creating an electron cloud (space charge).
    2.  High voltage (kVp) is applied between cathode and anode.
    3.  Electrons are accelerated across the vacuum towards the anode target.
    4.  Electrons strike the target, rapidly decelerating and interacting with target atoms.
    5.  Kinetic energy is converted into heat (~99%) and X-ray photons (~1%).

*   **X-Ray Production Mechanisms:**
    *   **Bremsstrahlung ("Braking Radiation"):**
        *   Incident electron interacts with the Coulomb field of a target nucleus.
        *   Electron is deflected and decelerates, losing kinetic energy.
        *   Lost energy is emitted as an X-ray photon.
        *   Energy of the photon can range from near zero up to the maximum kinetic energy of the incident electron (E_max = e·kVp).
        *   Produces a continuous energy spectrum.
        *   Efficiency of Bremsstrahlung production is proportional to Z·(kVp)².
    *   **Characteristic Radiation:**
        *   Incident electron ejects an inner-shell electron (e.g., K-shell) from a target atom.
        *   Vacancy is filled by an electron from an outer shell (e.g., L or M shell).
        *   The difference in binding energy between the shells is released as a characteristic X-ray photon with a discrete energy specific to the target material and the shells involved (e.g., Kα, Kβ lines).
        *   Requires incident electron energy > binding energy of the inner shell (e.g., K-shell binding energy of Tungsten ≈ 69.5 keV).
        *   Produces sharp peaks superimposed on the Bremsstrahlung spectrum.

[ILLUSTRATION: Diagram of a rotating anode X-ray tube showing cathode (filament, focusing cup), anode (target disc, rotor, stator), glass envelope, and beam port.]
[ILLUSTRATION: Graph showing a typical X-ray spectrum, illustrating the continuous Bremsstrahlung component and discrete characteristic peaks (Kα, Kβ) for a Tungsten target.]

*   **Factors Influencing the X-Ray Spectrum:**
    *   **Tube Potential (kVp):**
        *   Increases the maximum photon energy (E_max = e·kVp).
        *   Increases the average photon energy (beam hardening).
        *   Increases the overall X-ray output (intensity) significantly (approximately proportional to kVp² or higher).
    *   **Tube Current (mA):**
        *   Controls the rate of electron flow from cathode to anode (number of electrons per second).
        *   Directly proportional to the X-ray output (intensity or quantity).
        *   Does not affect the maximum or average photon energy (beam quality).
        *   Exposure time (s) combined with mA gives mAs, which is proportional to total X-ray output.
    *   **Target Material (Z):**
        *   Higher Z increases the efficiency of Bremsstrahlung production.
        *   Higher Z results in higher energy characteristic X-rays.
    *   **Filtration:**
        *   Materials placed in the beam path to selectively remove low-energy photons.
        *   **Inherent Filtration:** Attenuation by components of the X-ray tube itself (glass envelope, oil, window). Typically 0.5-1.0 mm Al equivalent.
        *   **Added Filtration:** Sheets of metal (usually aluminum for diagnostics, copper for therapy) placed externally.
        *   **Total Filtration:** Inherent + Added. Regulations specify minimum total filtration (e.g., ≥2.5 mm Al equivalent for diagnostic tubes operating above 70 kVp).
        *   Effect: Increases the average energy (hardens the beam), reduces patient skin dose, slightly decreases overall intensity.
    *   **Voltage Waveform:** Ripple in the high voltage supply affects beam quality and quantity.

*   **Focal Spot:**
    *   Area on the target struck by electrons.
    *   **Actual Focal Spot:** Physical area on the anode.
    *   **Effective Focal Spot:** Projected size of the focal spot as seen from the image receptor, determined by the anode angle (Line Focus Principle).
        *   Effective Size = Actual Size × sin(Anode Angle)
        *   Smaller anode angles (e.g., 6°-17°) produce smaller effective focal spots for better spatial resolution, while maintaining a larger actual focal spot for heat capacity.
    *   **Focal Spot Bloom:** Increase in focal spot size at high mA due to space charge effects.
    *   **Heel Effect:** Variation in X-ray intensity across the beam, lower on the anode side due to self-attenuation within the target. More pronounced with smaller anode angles and larger field sizes.

*   **Clinical Applications:**
    *   **Diagnostic Radiology:** Radiography, fluoroscopy, mammography, computed tomography (CT).
    *   **Radiation Therapy:** Superficial therapy (50-150 kVp) for skin lesions; Orthovoltage therapy (150-300 kVp) for deeper lesions (less common now due to linacs).

**1.5.2 Medical Linear Accelerators (Linacs):**

Linacs are the primary devices used to generate high-energy photon and electron beams for external beam radiation therapy.

*   **Major Components & Function:**
    *   **Modulator:** Provides high-voltage DC pulses (e.g., >100 kV) to the electron gun and RF power source.
    *   **Electron Gun:** Diode or triode design, produces pulsed electron beam (few μs pulses).
    *   **Radiofrequency (RF) Power Source:**
        *   **Magnetron:** Oscillator, typically for ≤ 6 MV linacs, output power ~2-5 MW.
        *   **Klystron:** Amplifier, for > 6 MV linacs, requires RF driver, output power ~5-7 MW or higher.
    *   **Waveguide System:** Transports microwaves (S-band ~2.8-3.0 GHz; X-band ~9.3 GHz for smaller/specialized units).
    *   **Accelerating Waveguide (Accelerator Structure):**
        *   Copper structure with resonant cavities.
        *   **Traveling Wave:** Longer, requires RF load.
        *   **Standing Wave:** Shorter, more efficient, often side-coupled. High **shunt impedance** (measure of efficiency in converting RF power to accelerating gradient, typically 40-100 MΩ/m) is desired.
    *   **Beam Transport System:**
        *   **Bending Magnet:** Typically 270° achromatic design for high-energy linacs. Magnetic field strength is precisely controlled (often via current) to select the desired electron energy exiting the waveguide. Different currents correspond to different energies (e.g., 6 MeV, 9 MeV, 12 MeV, etc., for electron mode; specific energies for photon modes like 6 MV, 18 MV).
        *   **Steering/Focusing Coils:** Maintain beam shape and position.
    *   **Treatment Head:**
        *   **Target (Photon Mode):** Tungsten or Tungsten/Copper composite.
        *   **Primary Collimator:** Defines maximum circular field.
        *   **Carousel:** Holds target and scattering foils.
        *   **Flattening Filter (Photon Mode):** Lead, steel, tungsten, or aluminum cone. Design specific to energy.
        *   **Scattering Foils (Electron Mode):** Tantalum, lead, aluminum. Dual foil systems common.
        *   **Ionization Chambers:** Sealed parallel plate chambers, monitor dose, dose rate, flatness, symmetry.
        *   **Secondary Collimators (Jaws):** Tungsten blocks.
        *   **Multi-Leaf Collimator (MLC):** Tungsten leaves (e.g., 5 mm or 10 mm width at isocenter).
        *   **Accessory Mount:** For wedges, electron applicators.

[ILLUSTRATION: Schematic diagram of a high-energy medical linac showing key components: electron gun, RF source (klystron), accelerating waveguide, bending magnet (indicating energy selection role), target/foils, flattening filter/scattering foil, ion chambers, collimators (primary, jaws, MLC).]

*   **Photon Beam Production (Photon Mode):**
    1.  Electrons accelerated in waveguide.
    2.  Electron beam strikes the target (Bremsstrahlung production).
    3.  Resulting forward-peaked X-ray beam passes through the primary collimator.
    4.  Beam passes through the flattening filter to achieve uniform intensity.
    5.  Beam passes through monitoring ionization chambers.
    6.  Beam shaped by secondary collimators (jaws) and MLC.
    7.  Beam exits towards the patient.
    *   **Energy Spectrum:** Continuous Bremsstrahlung spectrum extending up to the energy of the incident electrons. Average energy is typically ~1/3 of the maximum energy. Described by nominal accelerating potential (e.g., 6 MV, 18 MV).

*   **Electron Beam Production (Electron Mode):**
    1.  Electrons accelerated in waveguide (often to specific energies lower than max photon energy).
    2.  Target and flattening filter are moved out of the beam path.
    3.  Electron beam passes through scattering foils to widen the beam.
    4.  Beam passes through monitoring ionization chambers.
    5.  Beam shaped by jaws and often an electron applicator (cone) with a final custom cutout placed close to the patient surface.
    *   **Energy Selection:** Primarily determined by the bending magnet current setting, which selects electrons of a specific momentum/energy range from the accelerator structure output. The accelerator RF power/timing may also be adjusted for different electron energies.
    *   **Energy Spectrum:** Relatively narrow peak, characterized by Ep₀, Ē₀, Rp.

*   **Clinical Example: Beam Modality Choice**
    *   **Scenario:** Treating a superficial lesion (e.g., skin cancer on the nose, depth < 2 cm) vs. a deep-seated tumor (e.g., prostate cancer, depth > 10 cm).
    *   **Superficial Lesion:** An electron beam (e.g., 6 MeV or 9 MeV) is often preferred. Electrons deposit their dose within a limited range (Rp ≈ E/2 cm), delivering a high dose to the superficial target while rapidly falling off to spare deeper tissues (e.g., brain, eyes).
    *   **Deep-Seated Tumor:** A high-energy photon beam (e.g., 6 MV or 10 MV) is necessary. Photons have greater penetration, allowing dose to be delivered to the deep target. Techniques like IMRT/VMAT using multiple photon beams are employed to conform the dose to the target and spare surrounding normal tissues.
    *   **Rationale:** Choice based on target depth, need for skin sparing (photons offer more), and sparing of distal tissues (electrons offer complete sparing beyond Rp).

*   **Quality Assurance (QA):** Extensive QA is required (e.g., TG-40, TG-142 reports from AAPM) covering dosimetry (output, profiles, depth dose), mechanical aspects (collimator rotation, gantry angles, couch movements, laser alignment), imaging systems (kV, MV), and safety interlocks. Performed daily, monthly, and annually.

**1.5.3 Cyclotrons:**

Cyclotrons accelerate charged particles (protons, deuterons, alphas) to moderate energies (typically 10-30 MeV for PET isotope production, up to 250 MeV for proton therapy).

*   **Components:**
    *   **Ion Source:** Produces charged particles (e.g., H⁻ ions for proton therapy).
    *   **"Dees":** Two hollow, D-shaped electrodes.
    *   **Magnet:** Large electromagnet providing a uniform, constant magnetic field perpendicular to the particle path.
    *   **Radiofrequency (RF) Oscillator:** Applies an alternating voltage between the Dees.
    *   **Extraction System:** Deflector plate or stripping foil to extract the beam.

*   **Operating Principle:**
    1.  Ions injected into the center between the Dees.
    2.  Magnetic field forces ions into a circular path.
    3.  Alternating voltage on Dees accelerates ions each time they cross the gap between Dees.
    4.  As energy increases, the radius of the circular path increases (r = mv/qB).
    5.  The frequency of revolution remains constant (non-relativistic approximation: f = qB/2πm) and matches the RF frequency.
    6.  Particles spiral outwards until they reach the desired energy at the periphery.
    7.  Beam is extracted (e.g., by stripping H⁻ to H⁺ using a thin foil, reversing curvature).
    *   **Magnetic Field:** Typically uniform field of **~1.5 - 2.0 Tesla**.
    *   **Relativistic Effects:** At higher energies, mass increases, causing particles to lag behind the RF field. Synchrocyclotrons vary the RF frequency, while isochronous cyclotrons increase the magnetic field with radius to compensate.

*   **Clinical Applications:**
    *   **PET Radionuclide Production:** Bombarding targets with protons or deuterons (e.g., ¹⁸O(p,n)¹⁸F, ¹⁴N(d,α)¹²C -> ¹⁴N(p,α)¹¹C, ¹⁶O(p,α)¹³N).
    *   **Proton Therapy:** Accelerating protons to therapeutic energies (70-250 MeV).

[ILLUSTRATION: Diagram of a cyclotron showing ion source, Dees, magnet poles, RF oscillator connection, spiral particle path, and extraction system.]

**1.5.4 Synchrotrons:**

Synchrotrons accelerate charged particles (protons, carbon ions) to very high energies (up to GeV range, though typically 70-250 MeV for proton therapy, up to ~430 MeV/u for carbon ions) using a fixed-radius ring.

*   **Components:**
    *   **Ion Source & Pre-accelerator:** (e.g., Linac or cyclotron) injects particles at moderate energy.
    *   **Ring of Magnets:** Dipole magnets bend the particles around the ring; quadrupole magnets focus the beam.
    *   **RF Cavities:** Provide acceleration at specific points in the ring.
    *   **Extraction System:** Kicker magnets and septa deflect the beam out of the ring towards the treatment room.

*   **Operating Principle:**
    1.  Particles injected into the ring.
    2.  As particles circulate, both the magnetic field strength (B) and the RF frequency (f) are increased synchronously to keep the particles on a constant radius path and accelerate them.
    3.  Particles gain energy with each revolution.
    4.  Once the desired energy is reached, the beam is extracted.
    *   **Magnetic Field:** Dipole field strength is ramped during acceleration, typically from **~0.1 T up to ~1.5 T or higher** depending on final energy and ring radius.
    *   **Advantages:** Can achieve very high energies, allows precise energy selection by extracting beam at different points in the acceleration cycle.
    *   **Disadvantages:** Complex, large footprint, pulsed beam delivery.

*   **Clinical Applications:**
    *   **Proton Therapy:** Accelerating protons.
    *   **Heavy Ion Therapy:** Accelerating heavier ions like Carbon.

**1.5.5 Comparison of Beams:**

*   **Photons (X-rays):** Exponential attenuation with depth, dose maximum near surface (d_max depends on energy), significant exit dose.
*   **Electrons:** Sharp dose fall-off beyond a practical range (Rp ≈ E[MeV]/2 in cm of water), useful for superficial targets.
*   **Protons/Heavy Ions:** Exhibit Bragg peak - low entrance dose, sharp peak of maximum dose deposition at the end of range, very little exit dose. Allows high dose conformity to target while sparing distal tissues.

[ILLUSTRATION: Graph comparing depth dose curves for photons (e.g., 6 MV), electrons (e.g., 12 MeV), and protons (e.g., 150 MeV) in water.]

**Assessment Questions (Revised ABR Style):**

1.  (Concept) In a medical linear accelerator operating in photon mode, the primary purpose of the flattening filter is to:
    A. Remove low-energy photons from the beam.
    B. Increase the average energy of the photon beam.
    C. Make the beam intensity uniform across the field at a specified depth.
    D. Scatter the electron beam before it hits the target.
    E. Define the maximum field size.
    *(Answer: C)*

2.  (Concept/Component) Which component is present in the linac treatment head during electron beam therapy but *absent* or *bypassed* during photon beam therapy?
    A. Target
    B. Scattering Foil
    C. Primary Collimator
    D. Ionization Chamber
    E. Secondary Collimator (Jaw)
    *(Answer: B. Target and Flattening Filter are bypassed/removed; Scattering Foil is inserted.)*

3.  (Concept) The energy spectrum of X-rays produced by an X-ray tube consists of:
    A. Only discrete characteristic peaks.
    B. Only a continuous Bremsstrahlung distribution.
    C. A continuous Bremsstrahlung distribution with superimposed characteristic peaks (if kVp > K-edge).
    D. A monoenergetic beam determined by the kVp.
    E. A polyenergetic beam with energy up to twice the applied kVp.
    *(Answer: C - added clarification)*

4.  (Calculation/Principle) According to the line focus principle, if a rotating anode has an angle of 12 degrees and the actual focal spot size along that dimension is 5 mm, what is the approximate effective focal spot size? How does this principle benefit tube design?
    A. 1.0 mm; allows higher tube current for the same effective resolution.
    B. 1.0 mm; reduces the heel effect.
    C. 4.9 mm; improves heat dissipation.
    D. 4.9 mm; increases spatial resolution.
    E. 2.5 mm; simplifies anode construction.
    *(Answer: A. Effective Size ≈ 1.04 mm. Allows larger actual area for heat load while maintaining small effective size for resolution.)*

5.  (Concept/Comparison) A key difference enabling synchrotrons to achieve higher particle energies than traditional cyclotrons is:
    A. Synchrotrons use stronger magnets throughout the acceleration process.
    B. Synchrotrons vary both the magnetic field and RF frequency, while cyclotrons keep them constant.
    C. Synchrotrons accelerate particles linearly, avoiding relativistic mass increase issues.
    D. Synchrotrons use superconducting magnets, while cyclotrons use electromagnets.
    E. Synchrotrons extract the beam more efficiently.
    *(Answer: B. This synchronous variation allows maintaining resonance and constant radius despite relativistic effects.)*

6.  (Application/Physics) A radiation therapist accidentally selects a 15 MeV electron beam instead of a 6 MV photon beam to treat a prostate tumor at a depth of 12 cm. The most likely consequence is:
    A. Significant underdose to the tumor and overdose to distal tissues.
    B. Significant overdose to the tumor and acceptable dose to surrounding tissues.
    C. Acceptable dose to the tumor but severe overdose to proximal tissues (skin).
    D. Significant underdose to the tumor and minimal dose beyond the practical range.
    E. Dose distribution similar to the intended 6 MV photon beam.
    *(Answer: D. The practical range of 15 MeV electrons (Rp ≈ 7.5 cm) is insufficient to reach the 12 cm deep tumor, resulting in underdosing the target and negligible dose beyond Rp.)*

**Alignment with CAMPEP/ABR Requirements:**
This revised subsection provides enhanced detail on the physics and technology of radiation generating equipment, a core topic in the ABR Medical Physics Part 1 exam blueprint (General Content: Section 1). It details the principles of X-ray tubes, linacs (including energy selection and efficiency concepts), cyclotrons, and synchrotrons, aligning with CAMPEP curriculum standards for radiation production and accelerator physics. The content emphasizes the physical principles, component functions, beam characteristics, clinical relevance (including modality choice rationale), and quantitative aspects required for graduate-level understanding.

##### Subsection 1.6: Interactions of Photon and Particle Radiation with Matter

**Overview:**
Understanding how radiation interacts with matter is fundamental to medical physics. These interactions govern dose deposition, image formation, radiation detection, and radiation protection. This subsection explores the primary mechanisms by which photons (X-rays and gamma rays) and charged particles (electrons, protons, heavy ions) transfer their energy to matter, focusing on the physical principles, dependencies on energy and material properties, and their relevance in clinical applications.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the principal interaction mechanisms for photons with matter: photoelectric effect, Compton scattering, pair production, and Rayleigh (coherent) scattering.
- Explain the dependence of each photon interaction mechanism on photon energy (E) and atomic number (Z) of the absorbing material.
- Define and differentiate between linear attenuation coefficient (μ), mass attenuation coefficient (μ/ρ), energy transfer coefficient (μ_tr), and energy absorption coefficient (μ_en).
- Calculate photon beam attenuation using the concepts of Half-Value Layer (HVL) and Tenth-Value Layer (TVL).
- Describe the primary energy loss mechanisms for charged particles: collisional (ionization and excitation) and radiative (Bremsstrahlung).
- Define and explain stopping power (collisional, radiative, total) and its dependence on particle energy, charge, and medium properties (Bethe-Bloch formula).
- Define and calculate the range of charged particles (CSDA range, practical range).
- Explain the concept of Linear Energy Transfer (LET) and its significance in radiobiology.
- Compare and contrast the interaction characteristics of photons, electrons, and heavy charged particles.

**Estimated Completion Time:** 210-240 minutes

**Key Points for Understanding:**
- Photons interact probabilistically via photoelectric effect, Compton scattering, pair production, or coherent scattering.
- Photoelectric effect dominates at low energies and high Z; Compton scattering dominates at intermediate energies (diagnostic/therapeutic range in soft tissue); Pair production dominates at high energies (>1.022 MeV, significant >10 MeV).
- Attenuation coefficients (μ, μ/ρ, μ_tr, μ_en) quantify the probability and nature of photon interactions.
- Photon beams are attenuated exponentially in matter (I = I₀e^(-μx)). HVL is the thickness required to reduce intensity by 50%.
- Charged particles lose energy continuously through numerous interactions (collisions and radiation).
- Collisional energy loss (ionization/excitation) dominates for electrons at lower energies and for heavy particles over most of their path. Described by stopping power (dE/dx).
- Radiative energy loss (Bremsstrahlung) becomes significant for electrons at high energies and in high-Z materials.
- Charged particles have a finite range in matter, related to their initial energy and stopping power.
- LET describes the rate of energy deposition along the particle track, influencing biological effectiveness.

**1.6.1 Photon Interactions:**

Photons, being uncharged, travel significant distances in matter before undergoing a major interaction. The interaction probability depends on photon energy and the composition (Z, density) of the medium.

*   **Photoelectric Effect (PEA):**
    *   **Mechanism:** Incident photon interacts with a tightly bound inner-shell electron (K, L). The photon is completely absorbed, and the electron (photoelectron) is ejected with kinetic energy E_k = hν - E_b, where E_b is the electron's binding energy.
    *   **Subsequent Events:** The resulting atomic vacancy is filled by an outer-shell electron, leading to the emission of characteristic X-rays or Auger electrons.
    *   **Dependencies:**
        *   Probability (τ) ≈ Z³/ (hν)³ (Strong Z dependence, decreases rapidly with energy).
        *   Dominant at lower energies (e.g., < 30 keV in soft tissue, < 500 keV in lead).
        *   More likely for photons with energy just above the binding energy of an electron shell (absorption edges, e.g., K-edge).
    *   **Clinical Relevance:** Major contributor to contrast in diagnostic radiology (bone vs. soft tissue, contrast agents like iodine/barium have high Z). Contributes significantly to dose at lower diagnostic and therapeutic energies.

*   **Compton Scattering (Incoherent Scattering):**
    *   **Mechanism:** Incident photon interacts with a loosely bound outer-shell electron (treated as free). The photon transfers *part* of its energy to the electron (Compton electron) and is scattered at an angle θ with reduced energy (hν'). The electron recoils at an angle φ.
    *   **Energy/Angle Relationship (derived from conservation of energy and momentum):**
        *   hν' = hν / [1 + (hν/m₀c²)(1 - cosθ)]
        *   E_k (electron) = hν - hν'
        *   Maximum energy transfer occurs at θ = 180° (backscatter).
    *   **Dependencies:**
        *   Probability (σ) depends on electron density (electrons/gram), which is relatively constant for most soft tissues (~3.34 x 10²³ e⁻/g).
        *   Weak dependence on Z.
        *   Decreases gradually with increasing photon energy.
        *   Dominant interaction mechanism in soft tissue over most diagnostic and therapeutic energy ranges (e.g., ~30 keV to ~25 MeV).
    *   **Clinical Relevance:** Primary interaction in radiation therapy dose deposition. Contributes to scattered radiation in diagnostic imaging (degrades image contrast, source of staff dose).

*   **Pair Production (PP):**
    *   **Mechanism:** High-energy photon interacts with the strong Coulomb field of a nucleus. The photon disappears, and its energy is converted into an electron-positron pair (e⁻, e⁺).
    *   **Threshold Energy:** Requires photon energy hν ≥ 2m₀c² = 1.022 MeV (rest mass energy of e⁻ + e⁺).
    *   **Excess Energy:** Kinetic energy shared by the pair: E_k(e⁻) + E_k(e⁺) = hν - 1.022 MeV.
    *   **Positron Annihilation:** The positron eventually slows down and annihilates with an electron, producing two 0.511 MeV photons emitted in opposite directions.
    *   **Dependencies:**
        *   Probability (κ) ≈ Z² · ln(hν) (Increases with Z, increases with energy above threshold).
        *   Becomes significant above a few MeV, dominant > 25 MeV in soft tissue, > 10 MeV in lead.
    *   **Clinical Relevance:** Important for high-energy photon therapy (>10 MV). Basis for PET imaging (positron emission followed by annihilation). Can occur in linac heads, contributing to neutron production at very high energies (>~8-10 MeV depending on material).

*   **Rayleigh Scattering (Coherent Scattering):**
    *   **Mechanism:** Incident photon interacts with the atom as a whole. The photon is scattered at a small angle with essentially no loss of energy. No ionization occurs.
    *   **Dependencies:**
        *   Probability ≈ Z² / E².
        *   Dominant only at very low energies (< 10 keV) and high Z.
    *   **Clinical Relevance:** Minor importance in diagnostic radiology (contributes slightly to image noise/haze) and negligible in radiation therapy.

[ILLUSTRATION: Diagram illustrating the four main photon interaction mechanisms: Photoelectric Effect, Compton Scattering, Pair Production, Rayleigh Scattering.]
[ILLUSTRATION: Graph showing the relative predominance of PEA, Compton, and PP as a function of photon energy for different materials (e.g., water/soft tissue, bone, lead).]

*   **Attenuation Coefficients:**
    *   **Linear Attenuation Coefficient (μ):** Probability per unit path length that a photon interacts by any mechanism. Units: cm⁻¹.
        *   μ = μ_PEA + μ_Compton + μ_PP + μ_Rayleigh
        *   Describes removal of photons from a narrow beam: I(x) = I₀e^(-μx).
    *   **Mass Attenuation Coefficient (μ/ρ):** Linear attenuation coefficient divided by density (ρ). Units: cm²/g.
        *   μ/ρ = (μ_PEA/ρ) + (μ_Compton/ρ) + (μ_PP/ρ) + (μ_Rayleigh/ρ)
        *   Independent of physical state (density), depends only on material composition and photon energy. Useful for comparing attenuation in different materials.
    *   **Linear Energy Transfer Coefficient (μ_tr):** Probability per unit path length multiplied by the average fraction of photon energy transferred to kinetic energy of secondary charged particles (electrons/positrons). Units: cm⁻¹.
    *   **Mass Energy Transfer Coefficient (μ_tr/ρ):** Units: cm²/g.
    *   **Linear Energy Absorption Coefficient (μ_en):** Energy transfer coefficient corrected for energy lost by secondary electrons via Bremsstrahlung (which escapes locally). Represents energy actually absorbed locally. Units: cm⁻¹.
    *   **Mass Energy Absorption Coefficient (μ_en/ρ):** Units: cm²/g. Directly related to absorbed dose in a medium under charged particle equilibrium (CPE) conditions: Dose = Fluence × (μ_en/ρ).

*   **Half-Value Layer (HVL) and Tenth-Value Layer (TVL):**
    *   **HVL:** Thickness of material required to reduce the intensity of a *monoenergetic* narrow photon beam to 50% of its initial value.
        *   HVL = ln(2) / μ = 0.693 / μ
    *   **TVL:** Thickness required to reduce intensity to 10%.
        *   TVL = ln(10) / μ = 2.303 / μ ≈ 3.32 × HVL
    *   For polyenergetic beams (like X-ray spectra), HVL increases with absorber thickness (beam hardening). The first HVL is often used to characterize beam quality.
    *   **Clinical Relevance:** Used for specifying beam quality and designing radiation shielding.

**1.6.2 Charged Particle Interactions:**

Charged particles (electrons, protons, alphas, heavier ions) lose energy gradually through numerous interactions with atomic electrons and nuclei of the medium.

*   **Energy Loss Mechanisms:**
    *   **Collisional Losses (Inelastic Collisions with Atomic Electrons):**
        *   **Mechanism:** Incident charged particle interacts electromagnetically with orbital electrons of the medium.
        *   **Excitation:** Raises an orbital electron to a higher energy level.
        *   **Ionization:** Ejects an orbital electron from the atom (creating an ion pair). Ejected electrons with sufficient energy to cause further ionizations are called delta rays (δ-rays).
        *   **Dominance:** Primary mechanism of energy loss for heavy charged particles (protons, alphas) and for electrons at lower energies (< few MeV in water).
    *   **Radiative Losses (Inelastic Collisions with Nuclei - Bremsstrahlung):**
        *   **Mechanism:** Incident charged particle is deflected by the Coulomb field of a nucleus, decelerates, and emits a Bremsstrahlung photon.
        *   **Dominance:** Significant only for light charged particles (electrons and positrons) at high energies and in high-Z materials. Negligible for heavy charged particles in the therapeutic energy range.
        *   Ratio of Radiative to Collisional Loss (for electrons) ≈ (E [MeV] × Z) / 800.
    *   **Elastic Collisions:** Collisions with nuclei (Rutherford scattering) or electrons where kinetic energy is conserved but direction changes. Important for scattering, less so for direct energy loss.

*   **Stopping Power (S or dE/dx):**
    *   **Definition:** Average rate of energy loss per unit path length by a charged particle in a medium. Units: MeV/cm or keV/μm.
    *   **Collisional Stopping Power (S_col):** Energy loss due to ionization and excitation.
        *   **Bethe-Bloch Formula (for heavy charged particles):**
            S_col = (4πk₀²z²e⁴n / m₀v²) × [ln(2m₀v² / I(1-β²)) - β²]
            Where: k₀=Coulomb constant, z=charge of incident particle, e=elementary charge, n=electron density of medium, m₀=electron rest mass, v=particle velocity, β=v/c, I=mean excitation energy of medium.
            Key Dependencies: ≈ z²/v² (increases with particle charge squared, decreases with velocity squared), ≈ ln(v²), depends on medium via n and I.
        *   **Electrons:** Similar formula but more complex due to particle identity, relativistic effects, and spin.
    *   **Radiative Stopping Power (S_rad):** Energy loss due to Bremsstrahlung.
        *   S_rad ≈ E × Z² (proportional to particle energy and medium Z squared).
    *   **Total Stopping Power (S_tot):** S_tot = S_col + S_rad.
    *   **Mass Stopping Power (S/ρ):** Stopping power divided by density. Units: MeV·cm²/g. Less dependent on physical state.

[ILLUSTRATION: Graph showing collisional and radiative stopping power for electrons in water and lead as a function of energy.]
[ILLUSTRATION: Graph showing stopping power (Bragg curve) for a heavy charged particle (e.g., proton) as a function of depth/energy, illustrating the Bragg peak.]

*   **Linear Energy Transfer (LET):**
    *   **Definition:** Average energy deposited locally per unit path length due to collisions with energy transfers *below* a specified cutoff value (Δ). Excludes energy carried away by high-energy delta rays.
    *   Units: keV/μm.
    *   Conceptually similar to S_col, but focuses on *local* energy deposition relevant to biological effects.
    *   High LET radiation (e.g., alphas, low-energy protons) deposits energy densely, causing complex DNA damage. Low LET radiation (e.g., photons, high-energy electrons) deposits energy sparsely.
    *   **Clinical Relevance:** Related to Relative Biological Effectiveness (RBE). High LET radiation generally has higher RBE.

*   **Range:**
    *   **Definition:** Average path length or depth of penetration of a charged particle before it stops.
    *   **CSDA Range (Continuous Slowing Down Approximation):** Calculated by integrating the reciprocal of the total stopping power from initial energy E₀ down to zero.
        *   R_CSDA = ∫[0 to E₀] (1 / S_tot(E)) dE
    *   **Practical Range (Rp):** Depth at which the absorbed dose from an electron beam falls to the Bremsstrahlung tail level (extrapolated range). Empirically related to initial energy (e.g., Rp [cm] ≈ E₀ [MeV] / 2 for electrons in water).
    *   **Heavy Particles:** Have a well-defined range with very little straggling (variation in path length) due to their large mass.
    *   **Electrons:** Exhibit significant range straggling and scattering due to their low mass, resulting in a less well-defined range and a broader dose fall-off.

[ILLUSTRATION: Diagram comparing the paths and ranges of electrons and heavy charged particles (protons) in matter.]

**1.6.3 Comparison Summary:**

| Feature             | Photons (X/γ rays)                      | Electrons                             | Heavy Charged Particles (p, α)       |
| :------------------ | :-------------------------------------- | :------------------------------------ | :----------------------------------- |
| Charge              | 0                                       | -1e                                   | +Ze                                  |
| Interaction Type    | Probabilistic (PEA, Compton, PP)        | Continuous (Collisions, Radiation)    | Continuous (Collisions)              |
| Path                | Straight lines between interactions     | Tortuous (significant scattering)     | Near straight lines (less scattering) |
| Range               | No definite range (exponential atten.) | Definite range (significant straggle) | Definite range (little straggle)     |
| Primary Energy Loss | Transfer KE to e⁻/e⁺                    | Collisional (low E), Radiative (high E) | Collisional                          |
| LET                 | Low                                     | Low (initially) -> Medium (end)       | High (especially near Bragg peak)    |
| Bragg Peak          | No                                      | No (broad peak near surface)          | Yes (sharp peak at end of range)     |

**Assessment Questions (ABR Style):**

1.  (Concept) The mass attenuation coefficient (μ/ρ) differs from the linear attenuation coefficient (μ) in that μ/ρ:
    A. Has units of cm⁻¹.
    B. Depends on the physical density of the material.
    C. Is independent of the physical density of the material.
    D. Only accounts for absorption processes (PEA, PP).
    E. Is only defined for monoenergetic photon beams.
    *(Answer: C)*

2.  (Concept) Which photon interaction mechanism is primarily responsible for the difference in contrast between bone and soft tissue in diagnostic radiography?
    A. Compton Scattering
    B. Pair Production
    C. Photoelectric Effect
    D. Rayleigh Scattering
    E. Photodisintegration
    *(Answer: C. Due to its strong Z³ dependence, PEA is much higher in bone (higher effective Z) than soft tissue at diagnostic energies.)*

3.  (Calculation) The linear attenuation coefficient for 1 MeV photons in lead is approximately 0.78 cm⁻¹. What is the approximate Half-Value Layer (HVL)?
    A. 0.30 cm
    B. 0.69 cm
    C. 0.89 cm
    D. 1.14 cm
    E. 2.95 cm
    *(Answer: C. HVL = 0.693 / μ = 0.693 / 0.78 cm⁻¹ ≈ 0.888 cm)*

4.  (Concept) For a 20 MeV electron beam incident on a lead shield, the dominant energy loss mechanism is:
    A. Photoelectric Effect
    B. Compton Scattering
    C. Pair Production
    D. Collisional losses (ionization/excitation)
    E. Radiative losses (Bremsstrahlung)
    *(Answer: E. Radiative losses ≈ E·Z / 800. For E=20 MeV, Z=82 (Lead), ratio ≈ (20*82)/800 ≈ 1640/800 ≈ 2. Radiative losses dominate over collisional losses.)*

5.  (Concept) The Bragg peak observed for heavy charged particles (like protons) is characterized by:
    A. A region of maximum dose deposition near the end of the particle's range.
    B. Exponential attenuation of dose with depth.
    C. A significant dose delivered beyond the particle's range.
    D. A dose maximum occurring at the surface of the medium.
    E. A uniform dose deposition throughout the particle's range.
    *(Answer: A)*

6.  (Application/Concept) Linear Energy Transfer (LET) is a crucial concept in radiobiology primarily because it correlates with:
    A. The total dose delivered to the medium.
    B. The range of the charged particle.
    C. The probability of nuclear interactions.
    D. The density of ionization events along the particle track and thus biological effectiveness.
    E. The energy spectrum of the incident radiation beam.
    *(Answer: D)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection covers the fundamental interactions of photon and particle radiation with matter, a cornerstone of medical physics knowledge required by CAMPEP and tested extensively in the ABR Part 1 exam (General Content: Section 1). It details the physics of each interaction type, relevant coefficients (attenuation, stopping power, LET), and their dependencies, providing the necessary theoretical foundation for dosimetry, imaging, and radiation protection.

##### Subsection 1.7: Dosimetry Concepts and Units

**Overview:**
Dosimetry is the measurement, calculation, and assessment of the absorbed dose resulting from the exposure of matter to ionizing radiation. It forms the quantitative basis for radiation therapy, diagnostic imaging dose estimation, and radiation protection. This subsection introduces fundamental dosimetric quantities used to characterize radiation fields and the energy deposited in matter, defines their units, explores their relationships, and discusses the crucial concept of charged particle equilibrium (CPE).

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Define and differentiate between particle fluence (Φ) and energy fluence (Ψ).
- Define kerma (K) and absorbed dose (D), explain their relationship, and identify their units.
- Define exposure (X) and its traditional unit (Roentgen), explain its limitations, and relate it to kerma and dose in air.
- Understand the conditions required for charged particle equilibrium (CPE) and transient charged particle equilibrium (TCPE).
- Explain the relationship between kerma and absorbed dose under CPE conditions (D = K_col).
- Describe the relationship between kerma and absorbed dose near interfaces and in buildup regions where CPE does not exist.
- Identify the SI and traditional units for exposure, kerma, absorbed dose, and dose equivalent (Gray (Gy), rad, Sievert (Sv), rem, Roentgen (R)).
- Convert between SI and traditional units for dosimetric quantities.

**Estimated Completion Time:** 150-180 minutes

**Key Points for Understanding:**
- **Fluence (Φ):** Number of particles incident on a small sphere per unit cross-sectional area (particles/m² or particles/cm²).
- **Energy Fluence (Ψ):** Sum of energies of all particles incident on a small sphere per unit cross-sectional area (J/m² or MeV/cm²). Ψ = Φ × E (for monoenergetic beams).
- **Kerma (K):** Kinetic Energy Released per unit MAss. Initial kinetic energy transferred from uncharged particles (photons, neutrons) to charged particles in a small volume of medium per unit mass (J/kg = Gray (Gy)). K = Ψ × (μ_tr/ρ).
- **Absorbed Dose (D):** Energy absorbed per unit mass in a small volume of medium (J/kg = Gray (Gy)). D = dĒ_abs / dm.
- **Exposure (X):** Measure of ionization produced by photons in a unit mass of air (Coulomb/kg). Traditional unit: Roentgen (R). 1 R = 2.58 × 10⁻⁴ C/kg (air).
- **Charged Particle Equilibrium (CPE):** Exists at a point if every charged particle carrying energy out of a small volume is exactly compensated by a charged particle carrying the same energy into that volume. Requires uniform medium and radiation field over distances comparable to secondary electron ranges.
- **Relationship (CPE):** Under CPE, Absorbed Dose (D) equals the collisional part of Kerma (K_col). D = K_col = K(1-g), where g is the fraction of energy lost to Bremsstrahlung.
- **Buildup Region:** Near the surface, dose increases with depth until CPE is established (d_max) because incoming electrons build up. Here, Dose < Kerma.
- **Units:**
    *   Absorbed Dose: Gray (Gy) [SI], rad [Traditional]. 1 Gy = 1 J/kg = 100 rad.
    *   Kerma: Gray (Gy) [SI], rad [Traditional].
    *   Exposure: C/kg [SI], Roentgen (R) [Traditional].
    *   Dose Equivalent (H): Sievert (Sv) [SI], rem [Traditional]. 1 Sv = 100 rem. (Covered more in Radiation Protection).

**1.7.1 Radiation Field Quantities:**

These quantities describe the radiation field itself, independent of the medium.

*   **Particle Fluence (Φ):**
    *   Definition: Φ = dN / da, where dN is the number of particles incident on a sphere of cross-sectional area da.
    *   Units: m⁻² or cm⁻².
    *   For a beam perpendicular to a plane, it's simply the number of particles crossing per unit area.
    *   Fluence Rate (φ): Φ per unit time (m⁻²s⁻¹ or cm⁻²s⁻¹).

*   **Energy Fluence (Ψ):**
    *   Definition: Ψ = dE_fl / da, where dE_fl is the sum of energies (excluding rest mass) of all particles incident on a sphere of cross-sectional area da.
    *   Units: J/m² or MeV/cm².
    *   For monoenergetic particles of energy E: Ψ = Φ × E.
    *   For polyenergetic particles: Ψ = ∫ Φ_E(E) × E dE, where Φ_E is the differential fluence spectrum.
    *   Energy Fluence Rate (ψ): Ψ per unit time (Jm⁻²s⁻¹ or MeVcm⁻²s⁻¹).

**1.7.2 Interaction Quantities:**

These quantities describe the initial transfer of energy from radiation to the medium.

*   **Kerma (K):**
    *   Acronym: Kinetic Energy Released per unit MAss (or in MAtter).
    *   Definition: K = dE_tr / dm, where dE_tr is the sum of the initial kinetic energies of all charged particles liberated by uncharged ionizing radiation (photons or neutrons) in a mass dm of material.
    *   Units: J/kg = Gray (Gy). Traditional unit: rad (1 Gy = 100 rad).
    *   Relationship to Energy Fluence: K = Ψ × (μ_tr/ρ), where μ_tr/ρ is the mass energy transfer coefficient.
    *   **Components:** Kerma can be split into energy transferred that leads to collisional losses (K_col) and energy transferred that leads to radiative losses (K_rad) by the secondary charged particles.
        *   K = K_col + K_rad
        *   K_col = K (1 - g), where g is the average fraction of secondary charged particle energy lost via radiative processes (Bremsstrahlung).
    *   Kerma is defined for uncharged particles (photons, neutrons) and describes the *first step* in energy deposition.
    *   Kerma is maximum at the surface and decreases with depth (for photon beams) due to attenuation of the primary photon fluence.
    *   **Practical Note:** While conceptually important, Kerma is generally not measured directly in clinical practice. Absorbed dose is the quantity typically measured or inferred using calibrated detectors and dosimetry protocols.

*   **Exposure (X):**
    *   Definition: X = dQ / dm, where dQ is the absolute value of the total charge of ions of one sign produced in dry air when all electrons liberated by photons in a mass dm of air are completely stopped in air.
    *   Units: Coulomb per kilogram (C/kg) [SI]. Traditional unit: Roentgen (R). 1 R = 2.58 × 10⁻⁴ C/kg (air).
    *   **Limitations:**
        *   Defined *only* for photons.
        *   Defined *only* in air.
        *   Difficult to measure accurately above ~3 MeV due to electron range.
    *   **Relationship to Kerma in Air:** Kerma in air (K_air) can be related to exposure (X) via the average energy required to produce an ion pair in air (W_air/e):
        *   K_air = X × (W_air / e)
        *   (W_air / e) ≈ 33.97 J/C ≈ 33.97 eV/ion pair.
        *   Therefore, K_air (Gy) ≈ X (C/kg) × 33.97 or K_air (rad) ≈ X (R) × 0.876.
    *   **Clinical Relevance:** Historically important, basis for calibration of older therapy units and diagnostic X-ray outputs. Still used in radiation protection survey meters (often measuring exposure rate in R/hr or mR/hr).

**1.7.3 Absorbed Dose (D):**

This is the fundamental quantity related to biological effects.

*   **Definition:** D = dĒ_abs / dm, where dĒ_abs is the mean energy absorbed from ionizing radiation by a mass dm of material.
*   Units: J/kg = Gray (Gy) [SI]. Traditional unit: rad (1 Gy = 100 rad).
*   Absorbed dose describes the energy *actually deposited* in the medium, accounting for energy entering and leaving the volume via charged particles.
*   It is defined for all types of ionizing radiation and all materials.
*   Dose Rate (Ḋ): Absorbed dose per unit time (Gy/s, Gy/min, cGy/min).
*   **Practical Note:** Absorbed dose is the quantity of primary interest in radiation therapy and radiobiology. Clinical dosimetry focuses on accurately determining the absorbed dose to the patient using calibrated detectors (like ionization chambers) and established protocols (e.g., AAPM TG-51).

**1.7.4 Charged Particle Equilibrium (CPE):**

CPE is a crucial concept linking Kerma and Absorbed Dose.

*   **Definition:** CPE exists at a point P within a uniformly irradiated medium if, for every charged particle leaving a small volume (dV) around P, another charged particle of the same type and energy enters dV.
*   **Conditions for CPE:** Requires uniformity in the radiation field (fluence, energy, direction) and medium composition over distances comparable to the maximum range of secondary charged particles.
*   **Strict CPE:** Rarely exists perfectly in practice, especially near sources or interfaces.
*   **Relationship between D and K under CPE:**
    *   Energy deposited in dV = (Energy carried in by charged particles) - (Energy carried out by charged particles) + (Energy released inside dV by uncharged particles via charged particles that stop in dV).
    *   Under CPE, (Energy in) = (Energy out).
    *   Energy released inside dV = K × dm.
    *   Energy deposited = Energy lost via collisions = K_col × dm.
    *   Therefore, under CPE: D = dĒ_abs / dm = (K_col × dm) / dm = K_col.
    *   Since K_col = K(1-g), under CPE: **D = K(1-g)**.
    *   For low energy photons where g ≈ 0 (negligible Bremsstrahlung by secondary electrons), D ≈ K under CPE.
    *   For high energy photons (MV range), g is non-negligible (e.g., ~3% for 10 MV photons in water), so D is slightly less than K even under CPE.

*   **Transient Charged Particle Equilibrium (TCPE):**
    *   Occurs in regions where the radiation field is attenuated slowly (e.g., beyond d_max in high-energy photon beams).
    *   The number and energy of charged particles leaving dV is slightly greater than those entering, but the *relative* spectrum is constant.
    *   Under TCPE, D > K_col, but the ratio D/K_col is constant. Specifically, D ≈ K / (1 - μ̄R̄), where μ̄ and R̄ are average attenuation coefficient and electron range.

*   **Regions without CPE:**
    *   **Buildup Region:** Near the surface of an irradiated medium (depth < d_max). More electrons are set in motion than stop, and more electrons enter dV from shallower depths than leave towards deeper depths. Electron fluence builds up. Here, **D < K** (and D < K_col).
    *   **Interfaces:** Near boundaries between different materials (e.g., tissue-bone, tissue-lung, tissue-air). Electron fluence is perturbed due to differences in scattering and stopping power, disrupting CPE. Dose can be significantly higher or lower than Kerma predicts.

[ILLUSTRATION: Diagram showing Kerma and Absorbed Dose curves vs. depth for a high-energy photon beam, illustrating the buildup region (D<K), d_max (approximate CPE, D≈K_col), and exponential fall-off region (TCPE possible, D>K_col but D/K ratio may vary slowly).]
[ILLUSTRATION: Diagram illustrating the concept of CPE using a small volume dV, showing incoming/outgoing charged particles.]

**1.7.5 Units Summary and Conversions:**

| Quantity          | SI Unit        | Traditional Unit | Conversion                                      |
| :---------------- | :------------- | :--------------- | :---------------------------------------------- |
| Activity          | Becquerel (Bq) | Curie (Ci)       | 1 Ci = 3.7 × 10¹⁰ Bq                            |
| Exposure (X)      | C/kg (air)     | Roentgen (R)     | 1 R = 2.58 × 10⁻⁴ C/kg                          |
| Kerma (K)         | Gray (Gy)      | rad              | 1 Gy = 1 J/kg = 100 rad                         |
| Absorbed Dose (D) | Gray (Gy)      | rad              | 1 Gy = 1 J/kg = 100 rad                         |
| Dose Equivalent (H)| Sievert (Sv)   | rem              | 1 Sv = 1 J/kg = 100 rem (depends on Q factor) |

*   **Exposure to Dose Conversion (Approximate):**
    *   For photons in soft tissue near surface: Dose (rad) ≈ f-factor × Exposure (R).
    *   f-factor depends on photon energy and medium. For soft tissue, f ≈ 0.96 for energies from 100 keV to 3 MeV.
    *   Dose (Gy) = K_air (Gy) × (μ_en/ρ)_tissue / (μ_en/ρ)_air (under CPE, using Bragg-Gray theory principles).

**Assessment Questions (ABR Style):**

1.  (Definition) Absorbed dose (D) is defined as:
    A. The number of particles incident per unit area.
    B. The initial kinetic energy transferred to charged particles per unit mass.
    C. The energy absorbed per unit mass.
    D. The charge liberated per unit mass of air.
    E. The biological effect per unit kerma.
    *(Answer: C)*

2.  (Concept) Charged Particle Equilibrium (CPE) at a point implies that:
    A. Kerma equals Absorbed Dose.
    B. The number of photons entering a volume equals the number leaving.
    C. The energy carried into a volume by charged particles equals the energy carried out.
    D. The absorbed dose is maximum at that point.
    E. Bremsstrahlung production is negligible.
    *(Answer: C)*

3.  (Relationship) In the buildup region of a high-energy photon beam (depth < d_max):
    A. Dose > Kerma
    B. Dose = Kerma
    C. Dose < Kerma
    D. CPE exists
    E. Kerma is zero
    *(Answer: C. Electron fluence is building up, so energy deposited (Dose) is less than energy initially transferred (Kerma).)*

4.  (Units) A dose of 50 Gy is equivalent to:
    A. 50 rad
    B. 500 rad
    C. 5000 rad
    D. 0.50 rad
    E. 5.0 rad
    *(Answer: C. 1 Gy = 100 rad, so 50 Gy = 50 * 100 rad = 5000 rad.)*

5.  (Calculation/Concept) If the energy fluence rate of a 1 MeV photon beam is 10⁻³ J m⁻² s⁻¹ and the mass energy transfer coefficient (μ_tr/ρ) for a material is 0.03 cm²/g (or 0.003 m²/kg), what is the approximate kerma rate?
    A. 3 × 10⁻⁶ Gy/s
    B. 3 × 10⁻⁵ Gy/s
    C. 3 × 10⁻⁴ Gy/s
    D. 3 × 10⁻³ Gy/s
    E. 3 × 10⁻² Gy/s
    *(Answer: A. Kerma Rate = Energy Fluence Rate × (μ_tr/ρ) = (10⁻³ J m⁻² s⁻¹) × (0.003 m²/kg) = 3 × 10⁻⁶ J/kg/s = 3 × 10⁻⁶ Gy/s)*

6.  (Concept) The unit Roentgen (R) is a measure of:
    A. Absorbed dose in tissue.
    B. Kerma in air.
    C. Ionization produced by photons in air.
    D. Energy fluence of a photon beam.
    E. Biological effectiveness of radiation.
    *(Answer: C)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection addresses fundamental dosimetry concepts and units as required by CAMPEP and tested in the ABR Part 1 exam (General Content: Section 1). It defines key quantities (fluence, kerma, dose, exposure), explains their interrelationships, discusses the critical concept of CPE, and clarifies units and conversions. This knowledge is essential for all subsequent topics in radiation measurement, dose calculation, and treatment planning.

---

##### Subsection 1.8: Spatial Distribution and Transmission of Radiation

**Overview:**
Beyond the fundamental interactions at the atomic level, understanding how radiation beams behave macroscopically as they travel through space and penetrate matter is crucial for clinical applications. This subsection explores the factors governing the spatial distribution and transmission of photon, electron, and proton beams, including geometric effects (inverse square law), attenuation, scatter, and the resulting dose distributions within a medium (e.g., a patient or phantom).

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Apply the inverse square law to calculate changes in intensity or dose rate with distance from a point source.
- Define and differentiate between primary and scattered radiation.
- Define Percentage Depth Dose (PDD) and explain its dependence on energy, depth, field size, and Source-to-Surface Distance (SSD).
- Define Tissue-Air Ratio (TAR), Tissue-Maximum Ratio (TMR), and Tissue-Phantom Ratio (TPR), explain their dependencies, and understand their applications, particularly in isocentric treatment techniques.
- Relate PDD, TAR, and TMR using appropriate formulas (e.g., Mayneord F-factor for PDD conversion).
- Define and explain Scatter-Air Ratio (SAR) and its use in calculating dose in irregular fields (Clarkson integration).
- Define Collimator Scatter Factor (Sc) and Phantom Scatter Factor (Sp) and explain their role in monitor unit calculations.
- Describe the characteristics of a radiation beam profile, including central axis, field edges, penumbra (geometric, transmission, scatter), flatness, and symmetry.
- Compare and contrast the depth dose characteristics and beam profiles of photon, electron, and proton beams.

**Estimated Completion Time:** 210-240 minutes

**Key Points for Understanding:**
- **Inverse Square Law (ISL):** Intensity from a point source decreases proportionally to 1/distance². I₂/I₁ = (d₁/d₂)².
- **Attenuation:** Primary radiation is removed from the beam via interactions (exponential for monoenergetic photons).
- **Scatter:** Radiation changes direction due to interactions (primarily Compton for MV photons). Scatter increases with field size and depth (initially).
- **PDD:** (Dose at depth d / Dose at d_max) × 100%. Used for SSD setups. Increases with energy, SSD; decreases with depth; increases with field size (due to scatter).
- **TAR:** (Dose at depth d in phantom / Dose at same point in free space/air). Independent of SSD. Increases with energy, field size; decreases with depth.
- **TMR:** (Dose at depth d in phantom / Dose at d_max for same field size at depth). Independent of SSD. Used for SAD/isocentric setups. Increases with energy; decreases with depth; increases with field size.
- **TPR:** (Dose at depth d in phantom / Dose at reference depth t₀ for same field size). Generalization of TMR. TPR = TMR if t₀ = d_max.
- **Scatter Factors:** Sc accounts for scatter from the collimator; Sp accounts for scatter from the phantom/patient. Output Factor = Sc × Sp.
- **Beam Profile:** Describes dose variation perpendicular to the beam axis. Characterized by flatness (variation within central 80%) and symmetry (difference between sides).
- **Penumbra:** Region of rapid dose fall-off at the field edge. Influenced by source size, SSD, SDD (Source-Diaphragm Distance), depth, and electron range.
- **Photon Beams:** Exhibit skin-sparing (buildup), gradual dose fall-off with depth, significant scatter, and relatively sharp penumbra (at depth).
- **Electron Beams:** Have a shallower d_max, rapid dose fall-off beyond the practical range (Rp), significant scattering (bulging profiles, wide penumbra), less skin-sparing than MV photons.
- **Proton Beams:** Show low entrance dose, sharp Bragg peak near end of range, rapid distal fall-off, minimal lateral scatter (sharp penumbra).

**1.8.1 Geometric Factors: Inverse Square Law (ISL)**

For a point source emitting radiation isotropically, the intensity (or fluence, or dose rate in free space) decreases with the square of the distance from the source.

*   **Formula:** I ∝ 1/d² or I₂/I₁ = (d₁/d₂)²
    *   Where I₁ and I₂ are intensities at distances d₁ and d₂, respectively.
*   **Assumptions:** Point source, isotropic emission, negligible attenuation/scatter in the medium between d₁ and d₂.
*   **Clinical Relevance:**
    *   **SSD Setups:** Dose rate changes significantly with small changes in distance near the source. PDD includes ISL effects.
    *   **SAD Setups:** The isocenter is at a fixed distance from the source, simplifying calculations (TMR/TPR are ISL-independent).
    *   **Extended Distances:** Treating at non-standard SSDs requires ISL correction.
    *   **Brachytherapy:** Dose falls off very rapidly with distance from sources.
    *   **Radiation Protection:** Increasing distance is a key principle for reducing exposure.

**1.8.2 Attenuation and Scatter**

As a beam traverses a medium, its intensity is reduced (attenuated) by interactions, and some radiation is scattered.

*   **Primary Radiation:** Photons that have not interacted.
*   **Scattered Radiation:** Photons that have undergone interactions (mainly Compton) and changed direction.
*   **Total Dose:** Sum of dose from primary and scattered radiation.
*   **Scatter Contribution:** Increases with field size (larger volume irradiated), depth (up to a point, then decreases as primary fluence decreases), and electron density of the medium. Decreases with increasing beam energy (more forward scatter).

**1.8.3 Depth Dose Characteristics (Photon Beams)**

Quantities describing dose variation along the central axis of the beam.

*   **Percentage Depth Dose (PDD):**
    *   Definition: PDD(d, FS, E, SSD) = [D(d, FS, SSD) / D(d_max, FS, SSD)] × 100%
        *   D(d, FS, SSD) = Dose at depth d for field size FS at surface, at a given SSD.
        *   d_max = Depth of maximum dose (depends on energy).
    *   **Dependencies:**
        *   **Depth (d):** Decreases with increasing depth beyond d_max (attenuation > scatter buildup).
        *   **Energy (E):** Increases with increasing energy (more penetrating beam).
        *   **Field Size (FS):** Increases with increasing field size (more scatter contribution).
        *   **SSD:** Increases with increasing SSD (due to ISL effect becoming less pronounced relative to d_max).
    *   **Application:** Primarily used for dose calculations in SSD setups.

*   **Tissue-Air Ratio (TAR):**
    *   Definition: TAR(d, FS_d, E) = [D(d, FS_d in phantom) / D(d, FS_d in free space)]
        *   FS_d = Field size defined at depth d.
        *   Dose in free space measured with enough buildup material for CPE, but minimal phantom scatter.
    *   **Dependencies:**
        *   **Depth (d):** Decreases with increasing depth.
        *   **Energy (E):** Increases with increasing energy.
        *   **Field Size (FS_d):** Increases with increasing field size.
        *   **SSD:** Independent of SSD (ratio quantity).
    *   **Application:** Historically used for SAD calculations, especially with Cobalt-60. Less common now but conceptually important.

*   **Tissue-Maximum Ratio (TMR):**
    *   Definition: TMR(d, FS_d, E) = [D(d, FS_d in phantom) / D(d_max, FS_d in phantom)]
        *   Both doses measured at the *same distance* from the source (isocenter), typically 100 cm SAD.
    *   **Dependencies:**
        *   **Depth (d):** Decreases with increasing depth beyond d_max.
        *   **Energy (E):** Increases with increasing energy.
        *   **Field Size (FS_d):** Increases with increasing field size.
        *   **SSD:** Independent of SSD.
    *   **Application:** Standard quantity for dose calculations in SAD (isocentric) setups with modern linacs.

*   **Tissue-Phantom Ratio (TPR):**
    *   Definition: TPR(d, FS_d, E) = [D(d, FS_d in phantom) / D(t₀, FS_d in phantom)]
        *   t₀ = Reference depth (e.g., 5 cm, 10 cm).
        *   Both doses measured at the same distance from the source (isocenter).
    *   **Relationship:** TPR(d, FS_d) = TMR(d, FS_d) / TMR(t₀, FS_d).
    *   **Application:** Generalization of TMR, sometimes used in specific calculation algorithms or for certain energies.

*   **Relationship between PDD and TMR/TAR:**
    *   PDD can be calculated from TMR (or TAR) using the Mayneord F-factor to account for the SSD difference (ISL effect):
        *   PDD(d, FS, SSD) ≈ TMR(d, FS_d) × [(SSD + d_max) / (SSD + d)]² × (Sp factor if needed)
        *   Mayneord F-Factor = [(SSD₂ + d) / (SSD₂ + d_max)]² × [(SSD₁ + d_max) / (SSD₁ + d)]² (for converting PDD between SSD₁ and SSD₂).

[ILLUSTRATION: Graph showing typical PDD curves for different photon energies (e.g., Co-60, 6 MV, 18 MV) vs. depth.]
[ILLUSTRATION: Graph showing TMR curves for different photon energies vs. depth.]
[ILLUSTRATION: Diagram illustrating the definitions of PDD (SSD setup) and TMR (SAD setup).]

*   **Scatter Functions:**
    *   **Scatter-Air Ratio (SAR):** Ratio of scattered dose at a point in phantom to dose at the same point in free space. SAR = TAR(d, FS_d) - TAR(d, 0). Used in Clarkson method for irregular fields.
    *   **Collimator Scatter Factor (Sc):** Ratio of output in air for a given collimator setting (FS) to the output in air for the reference field size (e.g., 10x10 cm²). Accounts for scatter from flattening filter and collimator jaws. Measured "in air" with a buildup cap.
        *   Sc(FS) = Output_air(FS) / Output_air(FS_ref)
    *   **Phantom Scatter Factor (Sp):** Ratio of the dose rate for a given field size at the reference depth (d_max or t₀) to the dose rate for the reference field size (e.g., 10x10 cm²) at the same depth, with the collimator scatter component removed. Accounts for scatter originating within the phantom.
        *   Sp(FS) = [Total Dose(FS) / Sc(FS)] / [Total Dose(FS_ref) / Sc(FS_ref)]
        *   Often measured at d_max for TMR-based calculations or t₀ for TPR-based calculations.
    *   **Total Scatter Factor (Sc,p or Output Factor):** Combined effect of collimator and phantom scatter. Ratio of dose rate for a given field size to dose rate for reference field size at reference depth (d_max or t₀).
        *   Sc,p(FS) = Output_phantom(FS) / Output_phantom(FS_ref) = Sc(FS) × Sp(FS)
    *   **Application:** Essential for monitor unit (MU) calculations in treatment planning systems and manual checks.
        *   MU = Dose / [Output_ref × Sc,p(FS) × TMR(d, FS_d) × OAR × Tray Factor × Wedge Factor × ISL_correction ...]

**1.8.4 Beam Profiles and Penumbra**

Describes the dose distribution perpendicular to the central axis (CAX).

*   **Beam Profile:** A plot of dose versus distance from the central axis at a specific depth.
*   **Central Axis (CAX):** Geometric center of the beam.
*   **Field Size:** Typically defined by the 50% dose level relative to the CAX dose at that depth.
*   **Flatness:** Variation of dose relative to the CAX dose across the central 80% of the field width at a reference depth (usually 10 cm). Typically specified as ±3%.
*   **Symmetry:** Difference in dose between corresponding points on opposite sides of the CAX. Typically specified as within ±2%.
*   **Penumbra:** Region at the edge of the beam where the dose rate changes rapidly between the high-dose central region and the low-dose region outside the field.
    *   **Definition:** Often defined as the lateral distance between the 80% and 20% dose levels relative to the CAX dose.
    *   **Components:**
        *   **Geometric Penumbra:** Due to the finite size of the radiation source (focal spot). Increases with source size, depth, and SSD; decreases with SDD (Source-Diaphragm Distance).
            *   P_geo = Source Size × (SSD + d - SDD) / SDD
        *   **Transmission Penumbra:** Due to partial transmission through the edges of the collimating blocks or MLC leaves.
        *   **Scatter Penumbra:** Due to scattered photons and electrons, particularly the lateral range of secondary electrons. Increases with energy and depth.
    *   Total penumbra is a combination of these effects.

[ILLUSTRATION: Diagram of a typical photon beam profile showing CAX, field edge (50%), flatness region (80%), penumbra (80%-20%), and symmetry.]
[ILLUSTRATION: Diagram illustrating geometric penumbra based on source size, diaphragm position, and depth.]

**1.8.5 Comparison of Beam Types**

*   **Photon Beams (MV):**
    *   **Depth Dose:** Buildup region (skin sparing), d_max depends on energy (e.g., ~1.5 cm for 6 MV, ~3.5 cm for 18 MV), gradual exponential-like decrease beyond d_max.
    *   **Profile:** Relatively flat central region (due to flattening filter), sharp penumbra that increases slightly with depth.
    *   **Scatter:** Significant lateral scatter.

*   **Electron Beams:**
    *   **Depth Dose:** Surface dose is high (~80-95%), d_max is shallow, rapid dose fall-off beyond the practical range (Rp ≈ E/2 cm in water), followed by Bremsstrahlung tail.
    *   **Profile:** Less flat than photons, often show "horns" near surface due to scattering foils, significant bulging of isodose lines with depth due to lateral scatter, wider penumbra compared to photons.
    *   **Scatter:** Dominated by electron-electron and electron-nucleus scattering, leading to wider angular spread.

*   **Proton Beams:**
    *   **Depth Dose:** Low entrance dose, sharp increase to Bragg peak near end of range, very rapid distal dose fall-off beyond the peak. Spread-Out Bragg Peak (SOBP) created using modulators for clinical use.
    *   **Profile:** Very sharp lateral penumbra due to minimal lateral scattering of heavy protons.
    *   **Scatter:** Primarily small-angle Coulomb scattering.

[ILLUSTRATION: Comparative graph showing representative depth dose curves for a photon beam, an electron beam, and a proton beam (single Bragg peak and SOBP).]
[ILLUSTRATION: Comparative diagram showing representative beam profiles/isodose lines for photon, electron, and proton beams.]

**Assessment Questions (ABR Style):**

1.  (Calculation) A point source has a dose rate of 100 cGy/min at 80 cm. What is the approximate dose rate at 100 cm, assuming inverse square law applies?
    A. 64 cGy/min
    B. 80 cGy/min
    C. 100 cGy/min
    D. 125 cGy/min
    E. 156 cGy/min
    *(Answer: A. I₂ = I₁ × (d₁/d₂)² = 100 cGy/min × (80/100)² = 100 × (0.8)² = 100 × 0.64 = 64 cGy/min)*

2.  (Concept) Percentage Depth Dose (PDD) increases with increasing:
    1.  Beam Energy
    2.  Depth beyond d_max
    3.  Field Size
    4.  SSD
    A. 1 and 3 only
    B. 1, 3, and 4 only
    C. 2 and 4 only
    D. 1, 2, 3, and 4
    E. 3 and 4 only
    *(Answer: B. PDD increases with energy, field size, and SSD. It decreases with depth beyond d_max.)*

3.  (Concept) Which of the following quantities is independent of the Source-to-Surface Distance (SSD)?
    A. Percentage Depth Dose (PDD)
    B. Dose Rate at d_max
    C. Tissue-Maximum Ratio (TMR)
    D. Geometric Penumbra
    E. Output Factor (Sc,p)
    *(Answer: C. TMR is defined for SAD setups and is inherently independent of SSD.)*

4.  (Definition) The lateral distance between the 80% and 20% isodose lines at the edge of a radiation beam profile is commonly used to define the:
    A. Field Flatness
    B. Field Symmetry
    C. Geometric Field Size
    D. Penumbra
    E. Central Axis
    *(Answer: D)*

5.  (Comparison) Compared to a 6 MV photon beam, a 12 MeV electron beam typically exhibits:
    A. Greater depth of maximum dose (d_max).
    B. Sharper lateral penumbra at depth.
    C. More pronounced skin sparing.
    D. More rapid dose fall-off beyond the therapeutic range.
    E. Lower surface dose.
    *(Answer: D. Electrons have a finite range and rapid dose fall-off, unlike the gradual attenuation of photons.)*

6.  (Concept) The Phantom Scatter Factor (Sp) primarily accounts for the change in dose at the reference point due to scatter originating from the:
    A. Flattening filter
    B. Primary collimator
    C. Secondary collimator jaws
    D. Phantom or patient
    E. Buildup cap
    *(Answer: D)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection covers the essential concepts of radiation beam spatial distribution and transmission, including inverse square law, depth dose characteristics (PDD, TMR, etc.), scatter factors, and beam profiles, as required by CAMPEP and tested in ABR Part 1 (General Content: Section 1). Understanding these concepts is fundamental for clinical dose calculations, treatment planning, and quality assurance in radiation therapy.

---


### Section 2: Radiation Instrumentation and Measurement

#### Subsection 2.1: Gas-Filled Detectors

**Overview:**
Gas-filled detectors are among the most fundamental and widely used instruments for detecting and measuring ionizing radiation. Their operation relies on the principle that radiation ionizes gas molecules within a chamber, and the resulting charged particles (ions and electrons) are collected by applying an electric field. The amount of charge collected, or the rate at which it is collected, provides a measure of the radiation intensity or dose. This subsection explores the basic principles, different operating regions based on applied voltage, and specific types of gas-filled detectors used in medical physics.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the basic components and principle of operation of a gas-filled detector.
- Explain the six distinct operating regions based on the applied voltage (recombination, ionization, proportional, limited proportional, Geiger-Mueller, continuous discharge) and the characteristic charge collection behavior in each region.
- Define gas multiplication and explain the mechanism in the proportional and Geiger-Mueller regions.
- Describe the construction, operation, and applications of various types of ionization chambers (free-air, thimble, well, extrapolation).
- Explain the concept of saturation characteristics for ionization chambers and the importance of operating in the saturation region.
- Calculate and apply correction factors for ionization chamber measurements (temperature, pressure, polarity, ion recombination).
- Describe the construction, operation, and applications of proportional counters.
- Describe the construction, operation, characteristics (dead time, recovery time), and applications of Geiger-Mueller (GM) counters.
- Compare and contrast the advantages and disadvantages of detectors operating in the different regions.

**Estimated Completion Time:** 180-210 minutes

**Key Points for Understanding:**
- **Basic Principle:** Ionizing radiation creates ion pairs (positive ions and electrons) in a gas volume. An applied voltage ($V$) creates an electric field that causes these charges to drift towards electrodes, generating a measurable current or pulse.
- **Six Regions:** The relationship between applied voltage and collected charge defines six operating regions.
    1.  **Recombination:** Low $V$, significant ion recombination, charge collected < charge created.
    2.  **Ionization (Saturation):** Moderate $V$, minimal recombination, charge collected ≈ charge created. Used by ionization chambers.
    3.  **Proportional:** Higher $V$, secondary ionization occurs near the anode (gas multiplication, $M > 1$), charge collected is proportional to initial charge created. Used by proportional counters.
    4.  **Limited Proportional:** Higher $V$, $M$ becomes non-linear, proportionality is lost.
    5.  **Geiger-Mueller (GM):** High $V$, massive gas multiplication (avalanche), charge collected is independent of initial charge created (pulse size is constant). Used by GM counters.
    6.  **Continuous Discharge:** Very high $V$, spontaneous discharge occurs without radiation.
- **Gas Multiplication (M):** Ratio of total charge collected to charge initially created by radiation. $M=1$ in ionization region, $M > 1$ in proportional and GM regions.
- **Ionization Chambers:** Operate in saturation region ($M=1$). Measure charge or current. Used for accurate dosimetry (reference and field instruments), dose calibrators.
- **Proportional Counters:** Operate in proportional region ($M \approx 10^2 - 10^6$). Produce pulses proportional to energy deposited. Used for spectroscopy of low-energy radiation, neutron detection.
- **GM Counters:** Operate in GM region ($M \approx 10^9 - 10^{10}$). Produce large, uniform pulses regardless of energy deposited. Used for contamination surveys (high sensitivity), not for accurate dosimetry or spectroscopy.
- **Saturation Correction ($P_{ion}$):** Corrects for residual ion recombination in ionization chambers. Increases with dose rate and pulse frequency. $P_{ion} > 1$.
- **Temperature/Pressure Correction ($P_{TP}$):** Corrects for changes in air density affecting the mass of air in the chamber volume. $P_{TP} = \frac{(273.15 + T)}{(273.15 + T_{ref})} \times \frac{P_{ref}}{P}$. Reference: $T_{ref}=22^\circ C$, $P_{ref}=760 mmHg$ or $101.325 kPa$.
- **Polarity Correction ($P_{pol}$):** Corrects for differences in collection efficiency between positive and negative polarizing voltages. Usually close to 1.
- **Dead Time:** Time after a pulse during which a GM counter cannot detect another event.

**2.1.1 Basic Principle and Operating Regions**

A simple gas-filled detector consists of a volume of gas enclosed between two electrodes (e.g., a central anode wire and an outer cathode cylinder or wall) across which a variable voltage ($V$) is applied.

1.  **Radiation Interaction:** Ionizing radiation passes through the gas, creating primary ion pairs (positive ions and electrons). The number of primary ion pairs ($N_0$) is proportional to the energy deposited in the gas.
2.  **Charge Drift:** The applied voltage creates an electric field ($\\vec{E}$) that exerts forces on the ions ($q\\vec{E}$) and electrons ($-e\\vec{E}$), causing them to drift towards the cathode and anode, respectively.
3.  **Charge Collection:** As charges reach the electrodes, they induce a current flow in the external circuit. This can be measured as a total charge ($Q$) collected over time or as an average current ($I = Q/t$). For pulsed radiation, individual pulses can be detected.

**The Six Voltage Regions:**
Plotting the collected charge ($Q$) or pulse height versus the applied voltage ($V$) reveals the characteristic six regions:

[ILLUSTRATION: Graph of Collected Charge (log scale) vs. Applied Voltage (log scale) showing the six operating regions: Recombination, Ionization, Proportional, Limited Proportional, Geiger-Mueller, Continuous Discharge. Indicate typical voltage ranges and gas multiplication factors (M). Show separate curves for low-energy (alpha) and high-energy (beta/gamma) radiation.]

1.  **Region I: Recombination Region:**
    *   At very low voltages, the electric field is weak. Ions and electrons move slowly and have a high probability of recombining before reaching the electrodes.
    *   Collected charge ($Q$) increases with $V$ but $Q < Q_0$ (where $Q_0$ is the initial charge created).
    *   Not useful for radiation detection.

2.  **Region II: Ionization Region (Saturation):**
    *   As $V$ increases, the electric field becomes strong enough to collect most ions before they recombine.
    *   The collected charge ($Q$) becomes nearly independent of $V$ and approaches $Q_0$. This is the saturation current ($I_{sat}$).
    *   Gas multiplication factor $M=1$.
    *   **Application:** Ionization chambers operate here, providing accurate measurements proportional to the energy deposited.

3.  **Region III: Proportional Region:**
    *   As $V$ increases further, electrons accelerated towards the anode gain enough energy between collisions to cause secondary ionization of gas molecules.
    *   This leads to gas multiplication ($M > 1$). $M$ increases rapidly with $V$.
    *   The total charge collected ($Q = M \times Q_0$) is proportional to the initial charge created ($Q_0$) and thus proportional to the energy deposited by the incident radiation.
    *   **Application:** Proportional counters operate here, allowing energy discrimination (spectroscopy) and detection of low-energy radiation.

4.  **Region IV: Limited Proportional Region:**
    *   Gas multiplication becomes very high, and space charge effects (positive ions shielding the anode) start to limit the multiplication.
    *   The proportionality between $Q$ and $Q_0$ is gradually lost.
    *   Not typically used for detectors.

5.  **Region V: Geiger-Mueller (GM) Region:**
    *   Voltage is so high that a single primary ionization event triggers a cascade (Townsend avalanche) of secondary ionizations that spreads along the entire anode wire.
    *   Gas multiplication is very large ($M \approx 10^9 - 10^{10}$) but independent of the initial energy deposited.
    *   All pulses have the same large amplitude (saturation pulse height).
    *   **Application:** GM counters operate here, providing high sensitivity for detecting the presence of radiation but no energy information.

6.  **Region VI: Continuous Discharge Region:**
    *   Voltage is extremely high, causing spontaneous, continuous discharge or arcing in the gas even without incident radiation.
    *   Detector damage can occur.

**2.1.2 Ionization Chambers**

Operate in Region II (Saturation, $M=1$). Designed for accurate measurement of radiation exposure or dose.

*   **Principle:** Measure the ionization current ($I_{sat}$) or integrated charge ($Q_{sat}$) produced by radiation in a defined volume of gas (usually air).
*   **Saturation Characteristics:** A plot of ionization current versus applied voltage. Ideally shows a flat plateau in the saturation region. In practice, recombination is never zero, especially at high dose rates.
    *   **Collection Efficiency ($f$):** Ratio of measured current to true saturation current ($f = I_{measured} / I_{sat}$). $f$ depends on voltage, dose rate, chamber geometry, and gas.
    *   **Ion Recombination Correction ($P_{ion}$):** Correction factor applied to the measured reading to account for incomplete charge collection ($P_{ion} = 1/f$). $P_{ion} \ge 1$.
        *   **General (Initial) Recombination:** Recombination between ions created along the same track. Dominant at low dose rates.
        *   **Volume (General) Recombination:** Recombination between ions from different tracks. Dominant at high dose rates (continuous radiation) or high pulse dose (pulsed radiation).
        *   **Two-Voltage Technique:** $P_{ion}$ can be estimated by measuring the charge ($Q_H$, $Q_L$) collected at the normal operating voltage ($V_H$) and a lower voltage ($V_L$, often $V_H/2$). For continuous radiation, $P_{ion} \approx \frac{(V_H/V_L)^2 - 1}{(V_H/V_L)^2 - (Q_H/Q_L)}$. For pulsed radiation, $P_{ion} \approx \frac{1 - (Q_L/Q_H)}{ (V_L/V_H) - (Q_L/Q_H)}$ (approximations vary).

[ILLUSTRATION: Graph showing typical saturation curve (Ionization Current vs. Applied Voltage) for an ionization chamber at low and high dose rates, illustrating the saturation plateau and the effect of recombination.]

*   **Correction Factors for Air Ionization Chambers:**
    *   The mass of air in the chamber volume changes with temperature ($T$) and pressure ($P$). Since the reading is proportional to the mass of air, a correction is needed.
    *   **Temperature-Pressure Correction ($P_{TP}$):** Corrects reading to reference conditions ($T_{ref} = 22^\circ C = 295.15 K$, $P_{ref} = 760 mmHg = 101.325 kPa$).
        *   $M_{corrected} = M_{reading} \times P_{TP}$
        *   $P_{TP} = \frac{\text{Air Density}_{ref}}{\text{Air Density}_{ambient}} = \frac{(273.15 + T_{ambient})}{(273.15 + T_{ref})} \times \frac{P_{ref}}{P_{ambient}}$
        *   $T$ must be in Celsius, $P$ in same units as $P_{ref}$.
    *   **Polarity Correction ($P_{pol}$):** Accounts for small differences in charge collection when the polarity of the collecting voltage is reversed. Measured by taking readings with positive ($M_+$) and negative ($M_-$) polarity.
        *   $P_{pol} = \frac{|M_+| + |M_-|}{2|M_{routine}|}$ (where $M_{routine}$ is the reading with the routinely used polarity).
        *   Usually very close to 1.0 for well-designed chambers.
    *   **Ion Recombination Correction ($P_{ion}$):** Discussed above. Corrects for incomplete charge collection.
    *   **Corrected Reading:** $M_{corr} = M_{raw} \times P_{TP} \times P_{ion} \times P_{pol} \times P_{elec}$ (where $P_{elec}$ is the electrometer correction factor).

*   **Types of Ionization Chambers:**
    *   **Free-Air Chamber:** Primary standard for measuring exposure (Roentgen) for low/medium energy X-rays. Measures ionization in a well-defined volume of air, ensuring electronic equilibrium. Laboratory instrument, not for clinical use.
    *   **Thimble Chamber (Farmer Chamber):** Most common type used for clinical dosimetry (output calibration, relative dosimetry). Small (~0.1 - 1 cc), cylindrical or spherical volume enclosed by an air-equivalent wall (e.g., graphite, C-552 plastic) and a central collecting electrode. Wall provides electronic equilibrium for the measurement energy.
        *   Requires calibration factor ($N_{D,w}$ or $N_K$) traceable to a primary standard laboratory to convert reading (corrected charge) to dose-to-water or air kerma.
    *   **Parallel-Plate Chamber:** Electrodes are flat plates. Used for surface dose measurements, electron beam dosimetry (where cylindrical geometry perturbs electron fluence), and extrapolation measurements.
    *   **Well Chamber (Dose Calibrator):** Used in nuclear medicine to assay the activity of radiopharmaceuticals before administration. Sample is placed inside a large (~liter) volume chamber, providing nearly $4\pi$ geometry for high efficiency.
    *   **Extrapolation Chamber:** Parallel-plate chamber with a variable electrode spacing. By measuring current vs. spacing and extrapolating to zero spacing, dose to a vanishingly small volume can be determined. Used for surface dose measurements and beta dosimetry.

[ILLUSTRATION: Diagrams showing the basic construction of a Free-Air Chamber, a Thimble (Farmer) Chamber, a Parallel-Plate Chamber, and a Well Chamber (Dose Calibrator).]

**2.1.3 Proportional Counters**

Operate in Region III (Proportional, $M > 1$).

*   **Principle:** Gas multiplication ($M$) is significant but controlled, such that the output pulse height is proportional to the initial energy deposited by the radiation event ($Q = M \times Q_0 \propto E_{dep}$).
*   **Construction:** Typically cylindrical geometry with a very thin central anode wire to create a high electric field near the wire, facilitating multiplication.
*   **Fill Gas:** Often uses noble gases (e.g., Argon, Xenon) mixed with a quench gas (e.g., methane, CO₂) to absorb UV photons produced during multiplication, preventing continuous discharge.
*   **Applications:**
    *   **Spectroscopy:** Can distinguish between radiations depositing different amounts of energy (e.g., alpha vs. beta).
    *   **Low-Energy Radiation Detection:** Multiplication allows detection of events creating few primary ions.
    *   **Neutron Detection:** Can be filled with BF₃ gas or lined with Boron. Neutrons interact with ¹⁰B via (n, α) reaction, and the resulting alpha particle is detected.
*   **Limitations:** More complex electronics required than ionization chambers. Sensitive to voltage fluctuations (affecting M).

**2.1.4 Geiger-Mueller (GM) Counters**

Operate in Region V (GM, $M \gg 1$).

*   **Principle:** A single ionization event triggers a large, saturated pulse due to an avalanche effect spreading along the anode. Pulse height is independent of the energy deposited.
*   **Construction:** Similar to proportional counters (cylinder with central anode), but operated at higher voltage.
*   **Fill Gas:** Noble gas (e.g., Neon, Argon) plus a quench gas (organic vapor or halogen).
    *   **Quenching:** Essential to stop the discharge after each pulse. Positive ions drifting to the cathode can liberate electrons, re-triggering the avalanche. Quench gas molecules absorb energy from ions or UV photons without causing further ionization or electron emission.
        *   Organic quench gas is consumed over time (limited lifetime).
        *   Halogen quench gas recombines (longer lifetime).
*   **Characteristics:**
    *   **GM Plateau:** Operating voltage range where the count rate is relatively independent of voltage.
    *   **Dead Time ($\\tau$):** Time immediately after a pulse during which the detector is insensitive to further events because the ion sheath reduces the electric field below the threshold for avalanche formation (~50-300 µs).
    *   **Recovery Time:** Time until the detector returns to full pulse amplitude capability.
    *   **Count Rate Limitations:** At high count rates, significant counts can be lost during the dead time. Correction needed: $n = \frac{m}{1 - m\\tau}$, where $n$ is the true count rate and $m$ is the measured count rate.
*   **Applications:**
    *   **Radiation Surveys:** High sensitivity makes them ideal for detecting low levels of contamination (e.g., survey meters).
    *   **Presence/Absence Detection:** Simple, robust, inexpensive.
*   **Limitations:**
    *   Cannot measure dose rate accurately (response is energy-dependent and saturates).
    *   Cannot perform spectroscopy (no energy information).
    *   Significant dead time limits use at high count rates.

[ILLUSTRATION: Graph showing the operating plateau (Count Rate vs. Voltage) for a GM counter.]
[ILLUSTRATION: Diagram illustrating dead time and recovery time for a GM counter.]

**Assessment Questions (ABR Style):**

1.  (Concept) In which operating region of a gas-filled detector is the collected charge approximately equal to the charge initially created by the radiation ($M=1$)?
    A. Recombination Region
    B. Ionization Region
    C. Proportional Region
    D. Geiger-Mueller Region
    E. Continuous Discharge Region
    *(Answer: B)*

2.  (Application) Which type of gas-filled detector is most suitable for accurate measurement of the absorbed dose output of a linear accelerator?
    A. Geiger-Mueller Counter
    B. Proportional Counter
    C. Thimble Ionization Chamber
    D. Well Chamber
    E. Free-Air Chamber
    *(Answer: C)*

3.  (Concept) Gas multiplication occurs in which operating region(s)?
    1.  Ionization
    2.  Proportional
    3.  Geiger-Mueller
    A. 1 only
    B. 2 only
    C. 3 only
    D. 2 and 3 only
    E. 1, 2, and 3
    *(Answer: D)*

4.  (Calculation) An ionization chamber reading is 1.25 nC at an ambient temperature of 25°C and pressure of 740 mmHg. What is the temperature-pressure correction factor ($P_{TP}$) to standard conditions (22°C, 760 mmHg)?
    A. 0.978
    B. 0.989
    C. 1.000
    D. 1.011
    E. 1.038
    *(Answer: E. $P_{TP} = \frac{(273.15 + 25)}{(273.15 + 22)} \times \frac{760}{740} = \frac{298.15}{295.15} \times \frac{760}{740} \approx (1.010) \times (1.027) \approx 1.038$)*

5.  (Characteristic) Which of the following is a characteristic feature of a Geiger-Mueller counter?
    A. Output pulse height proportional to deposited energy.
    B. Operation requires very low voltage.
    C. Insensitivity to radiation.
    D. Significant dead time following each pulse.
    E. Gas multiplication factor M=1.
    *(Answer: D)*

6.  (Concept) The primary purpose of the quench gas in a GM counter is to:
    A. Increase the gas multiplication factor.
    B. Improve the energy resolution.
    C. Prevent continuous discharge after a pulse.
    D. Increase the sensitivity to neutrons.
    E. Decrease the operating voltage.
    *(Answer: C)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection details the fundamental principles, operating regions, and characteristics of gas-filled detectors, including ionization chambers, proportional counters, and GM counters, as required by CAMPEP and tested in ABR Part 1 (Section 2: Radiation Instrumentation and Measurement). It covers essential concepts like saturation, gas multiplication, correction factors, and dead time, providing the foundation for understanding radiation measurement techniques used in clinical medical physics.

---



#### Subsection 2.2: Scintillation Detectors

**Overview:**
Scintillation detectors operate on the principle that certain materials (scintillators) emit flashes of light (scintillations) when they absorb energy from ionizing radiation. This light is then converted into an electrical signal, typically using a photomultiplier tube (PMT) or a photodiode, which is then processed. The intensity of the light flash is often proportional to the energy deposited by the radiation, allowing for energy spectroscopy. Scintillation detectors are widely used in medical imaging (gamma cameras, PET, CT) and radiation measurement due to their high efficiency for detecting gamma rays and their ability to provide energy information.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the scintillation process: excitation and de-excitation leading to light emission.
- Differentiate between organic and inorganic scintillators, listing common examples and their properties (e.g., NaI(Tl), BGO, LSO, CsI, plastic, liquid scintillators).
- Explain the role of activators (like Thallium in NaI(Tl)) in inorganic scintillators.
- Describe the key properties of scintillators: light output (efficiency), decay time, density, effective atomic number ($Z_{eff}$), emission spectrum, and hygroscopic nature.
- Explain the principles of light collection and coupling between the scintillator and the light detector (light guides, optical grease).
- Describe the construction and operation of a photomultiplier tube (PMT), including the photocathode, dynodes (electron multiplication), and anode.
- Describe the operation of photodiodes (including avalanche photodiodes - APDs and silicon photomultipliers - SiPMs) as alternative light detectors, especially their use in magnetic fields (e.g., PET/MRI).
- Explain the concept of energy resolution in scintillation detectors and the factors affecting it (statistical fluctuations, non-proportionality, electronic noise).
- Define the Full Width at Half Maximum (FWHM) as a measure of energy resolution.
- Describe the typical pulse height spectrum obtained from a scintillation detector for a monoenergetic gamma source (photopeak, Compton edge, backscatter peak, escape peaks).
- Discuss the applications of scintillation detectors in medical physics, including gamma cameras, PET scanners, CT detectors, well counters, and survey meters.

**Estimated Completion Time:** 180-210 minutes

**Key Points for Understanding:**
- **Scintillation:** Absorption of radiation energy -> excitation of scintillator material -> emission of visible or UV light photons during de-excitation.
- **Scintillator Types:**
    *   **Inorganic:** Crystalline solids, often doped with activators (e.g., NaI(Tl), CsI(Tl), BGO, LSO, GSO). High density and $Z_{eff}$ (good for gamma detection), high light output, slower decay times (except LSO/GSO).
    *   **Organic:** Plastics (e.g., polystyrene doped with fluors), liquids (solvent + fluor). Lower density and $Z_{eff}$, lower light output, very fast decay times.
- **Activators:** Impurities added to inorganic crystals (e.g., Tl in NaI) create energy levels within the band gap, facilitating efficient light emission at desired wavelengths.
- **Properties:**
    *   **Light Output:** Number of light photons produced per unit energy absorbed (e.g., ~38,000 photons/MeV for NaI(Tl)). Higher is better for energy resolution.
    *   **Decay Time:** Time constant for light emission after excitation (e.g., ~230 ns for NaI(Tl), ~40 ns for LSO, ~2-10 ns for plastics). Faster is better for high count rates.
    *   **Density & $Z_{eff}$:** Higher values increase the probability of gamma ray interaction (photoelectric effect, Compton scatter).
    *   **Emission Spectrum:** Wavelength distribution of emitted light; must match the sensitivity of the light detector (photocathode).
    *   **Hygroscopic:** Some scintillators (esp. NaI(Tl)) absorb moisture from the air and must be hermetically sealed.
- **Light Detector:** Converts scintillation light into an electrical signal.
    *   **PMT:** Vacuum tube. Light hits photocathode -> emits photoelectrons -> electrons accelerated and multiplied by series of dynodes (secondary emission) -> large charge pulse collected at anode. High gain (~$10^6 - 10^8$), sensitive, fast, but bulky and sensitive to magnetic fields.
    *   **Photodiode:** Semiconductor device (p-n junction). Light creates electron-hole pairs -> collected by reverse bias voltage. Lower gain than PMT (gain=1 for standard PD, ~$10^2-10^3$ for APD, ~$10^5-10^6$ for SiPM), compact, insensitive to magnetic fields.
- **Energy Resolution:** Ability to distinguish between radiations of slightly different energies. Limited by statistical fluctuations in the number of photoelectrons produced and electron multiplication.
    *   Measured by FWHM of the photopeak: $R = \frac{FWHM}{E_{peak}} \times 100\%$. Typical $R \approx 7-10\%$ for NaI(Tl) at 662 keV.
- **Pulse Height Spectrum:** Distribution of electrical pulse amplitudes from the detector. For monoenergetic gammas:
    *   **Photopeak:** Full energy absorption (photoelectric effect or Compton followed by scatter absorption).
    *   **Compton Continuum:** Partial energy absorption via Compton scattering, electron escapes.
    *   **Compton Edge:** Maximum energy transferred to electron in a single Compton event.
    *   **Backscatter Peak:** Detection of photons scattered back (180°) from surrounding material.
    *   **Escape Peaks:** Annihilation photon escape (pair production) or characteristic X-ray escape.
- **Applications:** Nuclear medicine imaging (SPECT/PET), CT detectors (e.g., GOS, CdWO₄), radiation surveys, well counters.

**2.2.1 The Scintillation Process**

When ionizing radiation interacts within a scintillator material, it deposits energy, primarily through excitation and ionization of the material\'s atoms or molecules.

1.  **Energy Deposition:** Incident particle/photon transfers energy to electrons in the scintillator.
2.  **Excitation/Ionization:** Valence or core electrons are raised to higher energy levels (excited states) or removed entirely (ionization).
3.  **Energy Transfer (Solids):** In crystalline solids, this energy can create electron-hole pairs or excitons, which migrate through the lattice.
4.  **Luminescence Centers (Activators):** In inorganic scintillators, migrating energy reaches activator sites (impurities like Tl in NaI). The activator atoms are excited.
5.  **Radiative De-excitation:** The excited activator atoms (or excited molecules in organic scintillators) return to their ground state by emitting one or more photons, typically in the visible or near-UV range. This is the scintillation light.

The entire process is very fast, but the time course of light emission (decay time) varies significantly between materials.

**2.2.2 Scintillator Materials**

Choice depends on application requirements (efficiency, speed, energy resolution, cost, environment).

*   **Inorganic Scintillators:**
    *   **NaI(Tl) (Thallium-activated Sodium Iodide):**
        *   Properties: High light output (~38k ph/MeV), good energy resolution (~7% at 662 keV), relatively slow decay (230 ns), high density (3.67 g/cm³), high effective Z (Z_I=53), hygroscopic (must be sealed).
        *   Applications: Standard material for gamma cameras (SPECT), well counters, handheld survey meters (gamma spectroscopy).
    *   **CsI(Tl) (Thallium-activated Cesium Iodide):**
        *   Properties: Higher light output than NaI(Tl) (~54k ph/MeV), slightly slower (1000 ns), higher density (4.51 g/cm³), higher Z (Z_Cs=55, Z_I=53), less hygroscopic than NaI, emission spectrum better matched to photodiodes.
        *   Applications: Often used in airport security scanners, some particle physics.
    *   **CsI(Na) (Sodium-activated Cesium Iodide):**
        *   Properties: Similar light output to NaI(Tl), faster decay (~630 ns) than CsI(Tl), hygroscopic.
    *   **BGO (Bismuth Germanate - Bi₄Ge₃O₁₂):**
        *   Properties: Very high density (7.13 g/cm³) and Z (Z_Bi=83), high gamma stopping power, lower light output (~8k ph/MeV), poor energy resolution, relatively slow decay (300 ns), not hygroscopic.
        *   Applications: Historically dominant in PET scanners due to high efficiency for 511 keV annihilation photons.
    *   **LSO (Lutetium Oxyorthosilicate - Lu₂SiO₅:Ce) & LYSO (Lutetium-Yttrium Oxyorthosilicate):**
        *   Properties: High density (~7.4 g/cm³), high Z (Z_Lu=71), good light output (~25-30k ph/MeV), very fast decay (~40 ns), good energy resolution, not hygroscopic.
        *   Applications: Currently the dominant material in modern PET scanners due to combination of high efficiency and fast timing.
    *   **GSO (Gadolinium Oxyorthosilicate - Gd₂SiO₅:Ce):**
        *   Properties: High density (6.7 g/cm³), high Z (Z_Gd=64), good light output, fast decay (~60 ns).
        *   Applications: PET, medical imaging.
    *   **CT Detector Materials (e.g., Cadmium Tungstate - CdWO₄, Gadolinium Oxysulfide - Gd₂O₂S:Pr or GOS):**
        *   Properties: High density and Z, high efficiency for X-ray energies, minimal afterglow (light emission after radiation stops).
        *   Applications: Solid-state detector arrays in CT scanners.

*   **Organic Scintillators:**
    *   **Plastic Scintillators:** Polystyrene or PVT base doped with fluorescent compounds.
        *   Properties: Low density (~1.03 g/cm³), low Z (mostly C & H), lower light output, very fast decay (~2-10 ns), rugged, easily shaped, inexpensive.
        *   Applications: Large area detectors, fast timing measurements, survey meters (beta detection), beam monitors.
    *   **Liquid Scintillators:** Organic scintillator dissolved in an aromatic solvent.
        *   Properties: Similar to plastics, can incorporate sample directly into liquid (good for low-energy beta emitters like ³H, ¹⁴C).
        *   Applications: Liquid scintillation counting (LSC) in research/labs.

[ILLUSTRATION: Table summarizing key properties (Light Output, Decay Time, Density, Z_eff, Hygroscopic?) of common scintillator materials: NaI(Tl), CsI(Tl), BGO, LSO/LYSO, Plastic.]

**2.2.3 Light Collection and Photodetectors**

*   **Light Collection:** Scintillation light is emitted isotropically. Efficient collection onto the photodetector is crucial.
    *   **Reflective Coating:** Scintillator surfaces (except the one facing the detector) are coated with reflective material (e.g., MgO, Teflon tape) to maximize light reaching the detector.
    *   **Light Guides:** Sometimes used to transport light from a large or awkwardly shaped scintillator to the photodetector (e.g., acrylic or quartz rods). Total internal reflection guides the light, but some losses occur.
    *   **Optical Coupling:** Transparent optical grease or cement is used between the scintillator exit window and the photodetector window to minimize light loss due to reflections at interfaces (index matching).

*   **Photomultiplier Tube (PMT):**
    *   **Construction:** Evacuated glass tube containing:
        1.  **Photocathode:** Thin layer of material (e.g., bialkali Sb-K-Cs) that emits electrons when struck by light (photoelectric effect). Quantum Efficiency (QE): % of incident photons producing an electron (~20-30%).
        2.  **Focusing Electrodes:** Direct photoelectrons towards the first dynode.
        3.  **Dynodes:** Series of electrodes (typically 8-14) held at successively higher positive potentials (e.g., +100V, +200V, ... relative to photocathode). When an electron strikes a dynode, it liberates multiple secondary electrons (typically 3-6).
        4.  **Anode:** Collects the large electron cloud produced by the dynode chain, resulting in a measurable negative charge pulse.
    *   **Gain:** Overall electron multiplication factor. Gain = $\delta^N$, where $\delta$ is the average secondary emission ratio per dynode and $N$ is the number of dynodes. Gain is highly dependent on the applied high voltage.
    *   **Advantages:** High gain, excellent signal-to-noise ratio, fast response.
    *   **Disadvantages:** Bulky, fragile (vacuum tube), requires stable high voltage supply, sensitive to external magnetic fields (disrupt electron trajectories).

[ILLUSTRATION: Diagram showing the structure of a Photomultiplier Tube (PMT) with photocathode, focusing electrodes, dynode chain, and anode.]

*   **Solid-State Photodetectors:** Semiconductor devices, increasingly replacing PMTs in some applications.
    *   **PIN Photodiode:** Simple p-i-n junction operated under reverse bias. Incident light creates electron-hole pairs in the intrinsic (i) region, which drift to electrodes, creating current. Gain = 1. Requires low-noise amplification.
    *   **Avalanche Photodiode (APD):** Similar to PIN diode but operated at higher reverse bias voltage, near breakdown. Electrons gain enough energy to cause impact ionization (avalanche effect), providing internal gain (~$10^2 - 10^3$). Faster than PMTs, compact, insensitive to magnetic fields, but gain is temperature-dependent.
    *   **Silicon Photomultiplier (SiPM) / Multi-Pixel Photon Counter (MPPC):** Array of hundreds or thousands of tiny APD pixels operated in Geiger mode on a common silicon substrate. Each pixel gives a standard pulse when hit by a photon. The total output signal is the sum of pulses from all fired pixels, proportional to the number of incident photons. High gain (~$10^5 - 10^6$), compact, insensitive to magnetic fields, good timing resolution.
    *   **Applications:** PET (especially PET/MRI), handheld probes, compact systems.

**2.2.4 Energy Resolution**

The ability of a detector system to distinguish between events depositing slightly different energies.

*   **Statistical Fluctuations:** The number of information carriers produced at each stage (scintillation photons, photoelectrons, secondary electrons) follows Poisson statistics. The standard deviation is $\sqrt{N}$, where $N$ is the average number. This inherent statistical variation limits energy resolution.
    *   Variance primarily determined by the stage with the smallest number of carriers, usually the number of photoelectrons ($N_{pe}$) produced at the photocathode.
*   **Non-Proportionality:** Light output of the scintillator may not be perfectly proportional to the deposited energy, especially at low energies or for different particle types.
*   **Other Factors:** Inhomogeneities in scintillator light output or collection efficiency, electronic noise in PMT/amplifier.
*   **Measurement (FWHM):** Energy resolution ($R$) is typically quoted as the Full Width at Half Maximum (FWHM) of the photopeak in the pulse height spectrum, expressed as a percentage of the photopeak energy ($E_{peak}$).
    *   $R = \frac{FWHM}{E_{peak}} \times 100\%$
    *   Assuming Gaussian peak shape, $FWHM \approx 2.35 \times \sigma$, where $\sigma$ is the standard deviation.
    *   If limited purely by photoelectron statistics, $R \propto \frac{1}{\sqrt{N_{pe}}} \propto \frac{1}{\sqrt{E_{peak}}}$.

**2.2.5 Pulse Height Spectrum**

A histogram of the number of pulses recorded versus their amplitude (which is proportional to energy deposited).

[ILLUSTRATION: Typical pulse height spectrum from a NaI(Tl) detector for a monoenergetic gamma source (e.g., ¹³⁷Cs, 662 keV), clearly labeling: Photopeak, Compton Continuum, Compton Edge, Backscatter Peak, (optional: Iodine X-ray escape peak, Lead X-ray peak from shielding).]

*   **Photopeak:** Corresponds to events where the full energy of the incident gamma ray is absorbed in the crystal (photoelectric absorption, or Compton scatter followed by absorption of the scattered photon).
*   **Compton Continuum:** Corresponds to events where the incident gamma ray Compton scatters in the crystal, and the scattered photon escapes. The energy deposited is the kinetic energy of the Compton electron, ranging from zero up to a maximum value.
*   **Compton Edge:** The maximum energy deposited in a single Compton interaction. $E_{CE} = E_{\gamma} - E_{\gamma\'} (180^\circ) = E_{\gamma} \times \frac{2 \alpha}{1 + 2 \alpha}$, where $\alpha = E_{\gamma} / m_e c^2$.
*   **Backscatter Peak:** Corresponds to events where the incident gamma ray first scatters from material *behind* the detector (e.g., shielding, floor) through ~180°, and the lower-energy backscattered photon is then fully absorbed in the crystal. $E_{BS} = E_{\gamma\'} (180^\circ) = E_{\gamma} - E_{CE}$.
*   **Escape Peaks:**
    *   **Characteristic X-ray Escape:** If interaction occurs near the crystal surface, a characteristic X-ray produced after photoelectric absorption (e.g., Iodine K-X-ray ~28 keV for NaI) may escape. Results in a small peak at ($E_{peak}$ - $E_{X-ray}$). More prominent for low energy gammas and small crystals.
    *   **Annihilation Escape Peaks:** If $E_{\gamma} > 1.022 MeV$, pair production can occur. If one or both 511 keV annihilation photons escape, peaks appear at ($E_{peak}$ - 511 keV) (single escape) and ($E_{peak}$ - 1022 keV) (double escape).

**Assessment Questions (ABR Style):**

1.  (Material) Which scintillator material is commonly used in modern PET scanners due to its high density, high Z, good light output, and fast decay time?
    A. NaI(Tl)
    B. BGO
    C. LSO/LYSO
    D. Plastic Scintillator
    E. CsI(Tl)
    *(Answer: C)*

2.  (Component) What component in a photomultiplier tube (PMT) is responsible for converting incident light photons into electrons?
    A. Anode
    B. Dynode
    C. Photocathode
    D. Focusing Electrode
    E. Glass Envelope
    *(Answer: C)*

3.  (Concept) The energy resolution of a scintillation detector system is primarily limited by:
    A. The decay time of the scintillator.
    B. The gain of the photomultiplier tube.
    C. Statistical fluctuations in the number of photoelectrons produced.
    D. The density of the scintillator material.
    E. Electronic noise in the preamplifier.
    *(Answer: C)*

4.  (Spectrum) In the pulse height spectrum from a NaI(Tl) detector measuring a 662 keV gamma source (¹³⁷Cs), the Compton edge corresponds to:
    A. Full absorption of the gamma ray energy.
    B. Absorption of a gamma ray backscattered from surrounding material.
    C. Escape of an Iodine K-shell X-ray after photoelectric absorption.
    D. The maximum energy deposited by a Compton electron when the scattered photon escapes.
    E. Annihilation photon escape following pair production.
    *(Answer: D)*

5.  (Calculation) If the energy resolution (FWHM/E_peak) of a NaI(Tl) detector is 8% for the 662 keV photopeak of ¹³⁷Cs, what is the approximate FWHM in keV?
    A. 8.3 keV
    B. 41.4 keV
    C. 53.0 keV
    D. 66.2 keV
    E. 82.8 keV
    *(Answer: C. FWHM = R × E_peak = 0.08 × 662 keV ≈ 53.0 keV)*

6.  (Comparison) Compared to inorganic scintillators like NaI(Tl), organic plastic scintillators generally have:
    A. Higher density and effective Z.
    B. Higher light output.
    C. Longer decay times.
    D. Better energy resolution.
    E. Faster decay times.
    *(Answer: E)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection covers the principles, materials, components (scintillators, PMTs, photodiodes), characteristics (energy resolution, pulse height spectrum), and applications of scintillation detectors, aligning with the requirements of CAMPEP and ABR Part 1 (Section 2: Radiation Instrumentation and Measurement). Understanding these detectors is crucial for nuclear medicine imaging, CT, and various radiation measurement tasks.

---



#### Subsection 2.3: Solid State Detectors

**Overview:**
Solid state detectors utilize semiconductor materials, primarily silicon, germanium, or diamond, as the sensitive medium. Similar to gas-filled detectors, ionizing radiation creates charge carriers (electron-hole pairs instead of ion pairs) within the material. An applied electric field sweeps these carriers to electrodes, generating a measurable signal (current or pulse). Compared to gas detectors, semiconductors require much less energy to create an electron-hole pair (e.g., ~3.6 eV in Silicon vs. ~34 eV in air), leading to a significantly larger number of charge carriers for the same deposited energy and thus potentially better energy resolution and signal-to-noise ratio. This subsection delves into the principles of semiconductor detectors, including diodes and MOSFETs, as well as integrating detectors like TLDs and OSLDs, highlighting their diverse applications in clinical dosimetry.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Explain the basic principles of semiconductor materials (energy bands, electrons, holes, doping, p-n junction).
- Describe the formation and operation of a p-n junction diode under reverse bias as a radiation detector, including the concept of the depletion region.
- Detail the characteristics of silicon diodes used for dosimetry (e.g., sensitivity, energy dependence, temperature dependence, directional dependence, dose rate dependence, radiation damage).
- Differentiate between p-type and n-type diodes and their respective advantages/disadvantages for photon and electron dosimetry.
- Describe the construction, operation, and dosimetric applications of Metal-Oxide-Semiconductor Field-Effect Transistors (MOSFETs), particularly their use for in vivo dosimetry.
- Discuss the properties and advantages of diamond detectors for radiation dosimetry, including near tissue equivalence, high sensitivity, small size, and radiation hardness.
- Explain the principles of Thermoluminescent Dosimetry (TLD), including electron trapping, heating, light emission (glow curve), and readout process.
- List common TLD materials (e.g., LiF:Mg,Ti (TLD-100), LiF:Mg,Cu,P, CaF₂:Mn, CaSO₄:Dy) and their key characteristics (sensitivity, energy response, fading).
- Describe the process of TLD annealing and calibration.
- Explain the principles of Optically Stimulated Luminescence (OSL) dosimetry, including electron trapping, stimulation with light (e.g., green laser), blue light emission, and readout process.
- Describe the properties and advantages of common OSL materials (e.g., Al₂O₃:C) used in clinical and personnel dosimetry.
- Compare and contrast the characteristics and applications of diodes, MOSFETs, diamond detectors, TLDs, and OSLDs in clinical medical physics.

**Estimated Completion Time:** 240-280 minutes (Increased detail)

**Key Points for Understanding:**
- **Semiconductors:** Materials with conductivity between conductors and insulators (e.g., Si, Ge, Diamond). Characterized by valence band, conduction band, and band gap ($E_g$).
- **Electron-Hole Pairs:** Ionizing radiation creates electron-hole pairs by exciting electrons from the valence band to the conduction band. Energy required ($W$) is much lower than for gas ionization ($W_{Si} \approx 3.6$ eV, $W_{Ge} \approx 2.9$ eV, $W_{Diamond} \approx 13$ eV).
- **Doping:** Intentionally adding impurities to increase charge carrier concentration. N-type (donor impurities, excess electrons), P-type (acceptor impurities, excess holes).
- **P-N Junction:** Interface between P-type and N-type semiconductors. Forms a depletion region (free of mobile carriers) with a built-in electric field.
- **Reverse Bias:** Applying external voltage opposing the built-in field widens the depletion region, making it the sensitive volume for radiation detection. Charge carriers created here are swept out, producing a signal.
- **Diodes (Si):** P-N junctions used for dosimetry. Small size, high spatial resolution, fast response, no external bias needed (photovoltaic mode) or small bias (photoconductive mode). Disadvantages: Energy dependence (over-response at keV energies due to higher Z of Si vs. water), temperature dependence, directional dependence, radiation damage (decreased sensitivity over time).
    *   **P-type vs. N-type:** P-type diodes generally preferred for photon dosimetry (less radiation damage), N-type sometimes used for electron dosimetry.
    *   **Shielding:** Small metal filters often incorporated to flatten energy response for photon beams.
- **MOSFETs:** Transistors whose threshold voltage shifts predictably with accumulated radiation dose. Small, provide real-time readout, integrated dose measurement. Used for in vivo dosimetry. Disadvantages: Temperature dependence, fading, limited lifetime, require calibration.
- **Diamond Detectors:** Based on natural or synthetic diamond (Carbon). Nearly tissue-equivalent (Z=6), high radiation hardness, small sensitive volume, high spatial resolution, near energy and temperature independence, fast response. Expensive, but increasingly used for small field dosimetry and reference measurements.
- **TLDs (Thermoluminescent Dosimeters):** Integrating detectors. Radiation creates trapped electrons/holes in metastable energy states within the crystal lattice (e.g., LiF). Heating the TLD releases trapped charges; subsequent recombination emits light proportional to the absorbed dose. Readout involves heating and measuring emitted light with a PMT (glow curve analysis).
    *   **Materials:** LiF:Mg,Ti (TLD-100) is nearly tissue-equivalent, widely used. LiF:Mg,Cu,P is much more sensitive. CaF₂, CaSO₄ are highly sensitive but show significant energy dependence.
    *   **Annealing:** Heating procedure to erase residual signal and restore crystal structure before reuse.
    *   **Fading:** Loss of signal over time. Generally low for LiF.
    *   **Applications:** Personnel dosimetry, patient dose verification, phantom measurements.
- **OSLDs (Optically Stimulated Luminescence Dosimeters):** Integrating detectors. Similar trapping mechanism to TLDs. Readout involves stimulating the detector with light (e.g., green laser), causing trapped charges to recombine and emit light (e.g., blue) proportional to dose. Readout is non-destructive (can be re-read).
    *   **Material:** Al₂O₃:C (Aluminum Oxide doped with Carbon) is common. Highly sensitive, durable.
    *   **Applications:** Dominant technology for personnel dosimetry (e.g., Luxel badges), replacing film and TLDs in many institutions.

**2.3.1 Semiconductor Principles**

Understanding solid state detectors requires familiarity with basic semiconductor physics.

*   **Energy Bands:** In crystalline solids, discrete atomic energy levels broaden into continuous bands. The highest filled band at 0K is the **valence band**, and the next empty band is the **conduction band**. They are separated by the **band gap energy ($E_g$)**.
    *   Insulators: Large $E_g$ (> 5 eV). Electrons cannot easily reach the conduction band.
    *   Semiconductors: Moderate $E_g$ (~0.5 - 3 eV). Thermal energy allows some electrons to reach the conduction band, leaving **holes** (vacancies) in the valence band. Both electrons and holes act as mobile charge carriers.
    *   Conductors: Bands overlap ($E_g \le 0$). Many free electrons available.
*   **Intrinsic Semiconductors:** Pure materials (e.g., Si, Ge). Number of electrons ($n$) equals number of holes ($p$). $n = p = n_i$ (intrinsic carrier concentration). $n_i$ increases strongly with temperature.
*   **Extrinsic Semiconductors (Doping):** Impurities are added to control conductivity.
    *   **N-type:** Doped with **donor** atoms (Group V, e.g., P, As in Si). Donors have an extra valence electron easily excited into the conduction band. Electrons become **majority carriers**, holes are **minority carriers** ($n \gg p$).
    *   **P-type:** Doped with **acceptor** atoms (Group III, e.g., B, Al in Si). Acceptors create energy levels just above the valence band, easily accepting electrons from it, effectively creating mobile holes. Holes become **majority carriers**, electrons are **minority carriers** ($p \gg n$).
*   **Charge Carrier Creation by Radiation:** Ionizing radiation passing through a semiconductor transfers energy to electrons, promoting them from the valence band to the conduction band, creating electron-hole pairs. The average energy required to create one pair ($W$) is a key property ($W_{Si} \approx 3.6$ eV, $W_{Ge} \approx 2.9$ eV, $W_{Diamond} \approx 13$ eV). Since $W$ is much smaller than the ionization energy in gases ($W_{air} \approx 34$ eV), a given amount of absorbed energy creates many more charge carriers in a semiconductor, leading to a larger intrinsic signal.

**2.3.2 P-N Junction Diodes**

The fundamental building block for many semiconductor detectors.

*   **Formation:** When P-type and N-type materials are joined, majority carriers diffuse across the junction (holes from P to N, electrons from N to P). This leaves behind fixed, charged impurity ions (negative acceptors in P, positive donors in N) near the junction.
*   **Depletion Region:** The region around the junction becomes depleted of mobile charge carriers due to diffusion and subsequent recombination. The fixed charges create a **built-in electric field** pointing from N to P, opposing further diffusion.
*   **Reverse Bias Operation:** Applying an external voltage ($V_{ext}$) with polarity opposing the built-in field (positive to N-side, negative to P-side) increases the potential barrier and widens the depletion region. This widened region acts as the sensitive volume.
    *   Width ($d$) of depletion region: $d \propto \sqrt{V_{bias} + V_{built-in}}$.
    *   Little current flows under reverse bias in the absence of radiation (leakage current).
*   **Radiation Detection:** When radiation creates electron-hole pairs within the depletion region, the strong electric field rapidly sweeps electrons towards the N-side and holes towards the P-side. This charge movement constitutes a current pulse proportional to the energy deposited in the depletion region.
    *   **Photoconductive Mode:** Operated under reverse bias. Faster response, larger sensitive volume, but has leakage current.
    *   **Photovoltaic Mode:** Operated with no external bias. Simpler, no leakage current, but smaller depletion region and slower response.

[ILLUSTRATION: Diagram showing a P-N junction, the formation of the depletion region with fixed charges and built-in field, and the effect of applying reverse bias voltage.]

*   **Silicon Diodes for Dosimetry:**
    *   **Construction:** Typically small silicon chips with P-N junctions, encapsulated for protection. Often cylindrical for beam scanning or flat for surface measurements.
    *   **Sensitivity:** Produce a much larger signal (charge/current per unit dose) than ionization chambers of similar volume due to the lower $W$-value.
    *   **Advantages:** Small size (high spatial resolution), fast response time, ruggedness, no external high voltage required (or low bias).
    *   **Disadvantages & Corrections:**
        *   **Energy Dependence:** Silicon (Z=14) has higher Z than water/tissue (Z_eff ≈ 7.4). This leads to an over-response at lower photon energies (keV range) due to the dominance of the photoelectric effect ($\\propto Z^3$). Shielding with thin high-Z filters (e.g., Tungsten) is often used to compensate and flatten the response in the MV range.
        *   **Temperature Dependence:** Sensitivity typically changes with temperature (e.g., ~0.1-0.5% per °C). Requires temperature stabilization or correction, especially for absolute dosimetry.
        *   **Directional Dependence:** Response can vary depending on the angle of radiation incidence relative to the diode axis/surface. Important for rotational therapy or non-normal incidence.
        *   **Dose Rate Dependence:** Can exhibit some dependence, especially at very high instantaneous dose rates (e.g., FFF beams). Often less significant than for ion chambers.
        *   **Radiation Damage:** Cumulative dose causes lattice defects in the silicon, trapping charge carriers and reducing sensitivity over time. Requires periodic recalibration. P-type diodes generally show less damage than N-type for MV photons.
    *   **Applications:** Relative dosimetry (PDD, profiles, output factors) in water phantoms, small field dosimetry, in vivo dosimetry (less common now due to MOSFETs/OSLDs), quality assurance checks.

[ILLUSTRATION: Graph showing the relative energy response of an unshielded silicon diode compared to water/tissue, highlighting the over-response at keV energies. Optionally show a curve for a shielded dosimetry diode.]

**2.3.3 MOSFET Detectors**

Metal-Oxide-Semiconductor Field-Effect Transistors adapted for dosimetry.

*   **Principle:** Ionizing radiation creates electron-hole pairs in the silicon dioxide (SiO₂) gate insulator layer. Under an applied positive gate bias, electrons are swept out, while holes migrate slowly towards the Si/SiO₂ interface, where they become trapped. This trapped positive charge shifts the **threshold voltage ($V_{th}$)** required to turn the transistor "on". The change in $V_{th}$ is proportional to the absorbed dose.
    *   **Readout:** $V_{th}$ is measured by applying a specific drain current and measuring the required gate voltage. This readout is typically done *after* irradiation.
    *   **Advantages:** Very small size, direct dose reading (via $V_{th}$ shift), potential for real-time readout (though typically read post-irradiation), relatively tissue-equivalent response (SiO₂ and Si), can be placed on patient surface or in cavities.
    *   **Disadvantages:**
        *   **Sensitivity:** Can vary significantly between individual MOSFETs, requiring careful calibration.
        *   **Fading:** Trapped charge can leak over time, causing the $V_{th}$ shift (and thus the dose reading) to decrease. Requires prompt readout or characterization of fading.
        *   **Temperature Dependence:** Both sensitivity during irradiation and $V_{th}$ during readout are temperature-dependent.
        *   **Bias Dependence:** Sensitivity depends on the gate bias applied during irradiation.
        *   **Limited Lifetime:** Radiation damage accumulates in the SiO₂, limiting the total dose the MOSFET can accurately measure before needing replacement.
        *   **Calibration:** Requires careful calibration against a reference dosimeter (e.g., ion chamber) for the specific beam quality and conditions used.
    *   **Applications:** Primarily used for *in vivo* dosimetry during radiotherapy treatments (e.g., measuring entrance/exit dose, intracavitary dose), providing immediate or near-immediate feedback on patient dose.

**2.3.4 Diamond Detectors**

Utilize synthetic or natural diamond as the semiconductor material.

*   **Material Properties:** Diamond is Carbon (Z=6), making it highly tissue-equivalent. It has a large band gap (~5.5 eV), leading to very low leakage current even at room temperature. It is extremely radiation hard and chemically inert.
*   **Operation:** Similar to silicon diodes, radiation creates electron-hole pairs. An applied bias voltage sweeps these charges to create a signal. Due to the higher energy required to create an e-h pair (~13 eV vs 3.6 eV in Si), the signal per unit dose is lower than silicon for the same volume, but the low leakage current and other advantages compensate.
*   **Types:**
    *   **Natural Diamond:** Historically used, but suffer from impurities and variability.
    *   **Synthetic Diamond (CVD):** Chemical Vapor Deposition allows growth of high-purity single-crystal or polycrystalline diamond films specifically for detector applications, offering better uniformity and reproducibility.
*   **Advantages:**
    *   **Tissue Equivalence:** Z=6, very close to water/tissue, minimizing energy dependence corrections.
    *   **Small Sensitive Volume:** Allows for very high spatial resolution, crucial for small field dosimetry and steep dose gradients (e.g., SRS/SBRT).
    *   **High Sensitivity (per unit volume):** Despite higher W-value, density and charge collection efficiency can lead to good signal.
    *   **Radiation Hardness:** Extremely resistant to radiation damage compared to silicon.
    *   **Near Independence:** Shows minimal dependence on dose rate, temperature, and energy (in the MV range).
    *   **Fast Response Time:** Suitable for scanning measurements.
*   **Disadvantages:**
    *   **Cost:** Generally more expensive than silicon diodes.
    *   **Priming/Stabilization:** May require pre-irradiation (priming) to stabilize response, especially polycrystalline types.
    *   **Signal Strength:** Lower signal compared to Si for same volume/dose, requires sensitive electrometers.
*   **Applications:** Reference dosimetry, small field output factor measurements, relative dosimetry (PDD, profiles) especially in stereotactic fields, quality assurance.

**2.3.5 Thermoluminescent Dosimeters (TLDs)**

Integrating passive detectors that store absorbed energy, which is released as light upon heating.

*   **Principle:** Based on the phenomenon of thermoluminescence in certain insulating crystals (e.g., LiF, CaF₂). Ionizing radiation excites electrons from the valence band. Some of these electrons become trapped in metastable energy levels (electron traps) within the crystal lattice defects or impurities. The number of trapped electrons is proportional to the absorbed dose.
*   **Readout:** The TLD material (chip, powder, rod) is heated in a controlled manner (TLD reader). Thermal energy releases the trapped electrons. These electrons return to the ground state, often via recombination with trapped holes at luminescence centers, emitting light photons. The total amount of emitted light is measured by a PMT.
*   **Glow Curve:** A plot of the emitted light intensity versus temperature (or heating time). The shape of the glow curve (position and relative height of peaks) is characteristic of the TLD material and its thermal/radiation history. The dose is typically related to the area under specific peaks or the total area.

[ILLUSTRATION: Simplified energy band diagram showing electron trapping in metastable states upon irradiation and subsequent light emission upon heating (thermoluminescence).] [ILLUSTRATION: Example TLD glow curve (e.g., for TLD-100) showing multiple peaks and indicating the main dosimetric peak.]

*   **Common Materials & Properties:**
    *   **LiF:Mg,Ti (TLD-100):** Lithium Fluoride doped with Magnesium and Titanium. Most widely used.
        *   Pros: Nearly tissue-equivalent (Z_eff ≈ 8.2), wide dose range (μGy to kGy), good linearity, low fading (~5% per year at room temp).
        *   Cons: Complex glow curve with multiple peaks, requires careful annealing, sensitive to light exposure before readout.
    *   **LiF:Mg,Cu,P (e.g., TLD-100H, GR-200):** Lithium Fluoride doped with Magnesium, Copper, and Phosphorus.
        *   Pros: Much higher sensitivity (~20-50x TLD-100), simpler glow curve, tissue-equivalent.
        *   Cons: Lower saturation dose limit, more complex annealing, potential for supralinearity at lower doses than TLD-100.
    *   **CaF₂:Mn (Calcium Fluoride doped with Manganese):**
        *   Pros: High sensitivity.
        *   Cons: Significant energy dependence (Z_Ca=20, Z_F=9), rapid fading.
    *   **CaSO₄:Dy (Calcium Sulfate doped with Dysprosium):**
        *   Pros: Very high sensitivity.
        *   Cons: Significant energy dependence (Z_Ca=20, Z_S=16), significant fading.
*   **Annealing:** Critical step to prepare TLDs for reuse. Involves heating the TLDs to high temperatures (e.g., 400°C for 1 hour for TLD-100) to empty all traps and restore the crystal structure, followed by controlled cooling and often a lower temperature pre-readout anneal (e.g., 80-100°C) to remove unstable low-temperature peaks.
*   **Calibration:** TLD response (light output per unit dose) can vary between batches and individual chips. Requires careful calibration by irradiating a set of TLDs to known doses using a reference beam quality and establishing a calibration curve.
*   **Applications:** Personnel dosimetry (historical, largely replaced by OSLD), environmental monitoring, patient dose verification (e.g., skin dose, intracavitary dose), phantom measurements, postal dose audits.

**2.3.6 Optically Stimulated Luminescence Dosimeters (OSLDs)**

Integrating passive detectors, similar to TLDs, but readout uses light stimulation instead of heat.

*   **Principle:** Similar to TLDs, radiation creates trapped electrons in metastable states within the material (commonly Al₂O₃:C - Aluminum Oxide doped with Carbon). Traps are typically deeper than TLD traps.
*   **Readout:** The detector material is stimulated with light of a specific wavelength (e.g., green laser or LEDs). This light energy releases the trapped electrons. Recombination at luminescence centers emits light of a different (shorter) wavelength (e.g., blue), which is detected by a PMT. The intensity of the emitted blue light is proportional to the absorbed dose.
*   **Advantages over TLDs:**
    *   **High Sensitivity:** Al₂O₃:C is very sensitive.
    *   **Non-destructive Readout:** Light stimulation only empties a fraction of the traps, allowing the dosimeter to be re-read multiple times to confirm dose or archive the signal. Heating in TLD readout destroys the signal.
    *   **No Annealing Required:** Signal can be optically bleached (erased) for reuse, simpler than TLD annealing.
    *   **Low Fading:** Signal is very stable over time.
    *   **Tissue Equivalence:** Al₂O₃:C is not perfectly tissue-equivalent (Z_eff ≈ 11.3), showing some over-response at keV energies compared to LiF. This is often compensated for using filters in badge designs.
*   **Material (Al₂O₃:C):** Dominant material. Robust, insensitive to environmental factors like humidity.
*   **Applications:** Has largely replaced TLDs and film for **personnel dosimetry** (e.g., Luxel+ and InLight badges by Landauer). Also used for environmental monitoring and increasingly explored for clinical applications like patient dose verification, especially where re-read capability is advantageous.

[ILLUSTRATION: Simplified energy band diagram for OSL, showing trapping upon irradiation and light emission upon optical stimulation.]

**2.3.7 Comparison and Summary**

| Feature             | Silicon Diode         | MOSFET                | Diamond Detector      | TLD (LiF:Mg,Ti)       | OSLD (Al₂O₃:C)        |
| :------------------ | :-------------------- | :-------------------- | :-------------------- | :-------------------- | :-------------------- |
| **Type**            | Active (Real-time)    | Active (Integrated)   | Active (Real-time)    | Passive (Integrated)  | Passive (Integrated)  |
| **Signal**          | Current/Charge        | $V_{th}$ Shift        | Current/Charge        | Light (Heated)        | Light (Stimulated)    |
| **Size**            | Small                 | Very Small            | Very Small            | Small                 | Small                 |
| **Spatial Res.**    | High                  | Very High             | Very High             | Moderate              | Moderate              |
| **Sensitivity**     | High                  | Moderate              | Moderate              | Moderate              | High                  |
| **Tissue Equiv.**   | Moderate (Z=14)       | Good (Si/SiO₂)        | Excellent (Z=6)       | Good (Z_eff≈8.2)      | Moderate (Z_eff≈11.3) |
| **Energy Dep.**     | Yes (keV over-resp)   | Minor                 | Minimal (MV)          | Minor                 | Yes (keV over-resp)   |
| **Temp. Dep.**      | Yes                   | Yes                   | Minimal               | Minor                 | Minimal               |
| **Dose Rate Dep.**  | Minor                 | Minor                 | Minimal               | No                    | No                    |
| **Directional Dep.**| Yes                   | Minor                 | Minor                 | Minor                 | Minor                 |
| **Fading**          | N/A                   | Yes                   | N/A                   | Low                   | Very Low              |
| **Readout**         | Instant               | Post-Irrad (delayed)  | Instant               | Destructive (Heat)    | Non-destructive (Light)|
| **Reuse**           | Yes (w/ recalib.)     | Limited Lifetime      | Yes                   | Yes (w/ annealing)    | Yes (w/ bleaching)    |
| **Primary Apps**    | Relative Dosimetry, QA| *In Vivo* Dosimetry   | Small Field, Reference| Personnel, Pt Dose QA | Personnel Dosimetry   |

**Assessment Questions (ABR Style):**

1.  (Principle) The primary reason silicon diodes produce a larger signal per unit absorbed dose compared to an air-filled ionization chamber of the same volume is:
    A. Silicon has a higher density than air.
    B. Silicon has a higher effective atomic number than air.
    C. The energy required to create an electron-hole pair in silicon is much lower than the energy required to create an ion pair in air.
    D. Silicon diodes are typically operated at a higher bias voltage.
    E. Recombination effects are less significant in silicon.
    *(Answer: C)*

2.  (Characteristic) Which of the following is a significant disadvantage of using unshielded silicon diodes for dosimetry in clinical photon beams?
    A. Poor spatial resolution.
    B. Slow response time.
    C. Significant over-response at kilovoltage energies due to the photoelectric effect.
    D. Requirement for cryogenic cooling.
    E. Insensitivity to radiation.
    *(Answer: C)*

3.  (Detector Type) Which solid state detector operates by measuring the radiation-induced shift in its threshold voltage?
    A. Silicon Diode
    B. Diamond Detector
    C. MOSFET
    D. TLD
    E. OSLD
    *(Answer: C)*

4.  (Material) Diamond detectors are considered advantageous for small field dosimetry primarily due to their:
    A. High sensitivity compared to TLDs.
    B. Low cost and wide availability.
    C. Tissue equivalence and high spatial resolution.
    D. Ability to measure dose rate dependence accurately.
    E. Insensitivity to temperature variations.
    *(Answer: C)*

5.  (Process) The readout process for a Thermoluminescent Dosimeter (TLD) involves:
    A. Stimulating the detector with green light and measuring blue light emission.
    B. Applying a high voltage and measuring leakage current.
    C. Measuring the shift in threshold voltage after irradiation.
    D. Heating the detector and measuring the emitted light intensity versus temperature (glow curve).
    E. Measuring the current generated under reverse bias during irradiation.
    *(Answer: D)*

6.  (Comparison) A key advantage of OSLDs (e.g., Al₂O₃:C) compared to TLDs (e.g., LiF:Mg,Ti) for personnel dosimetry is:
    A. Perfect tissue equivalence.
    B. Lower cost per reading.
    C. Ability to be re-read multiple times (non-destructive readout).
    D. Complete absence of energy dependence.
    E. Faster signal fading.
    *(Answer: C)*

7.  (Application) Which detector type is most commonly used for modern personnel radiation monitoring badges due to its sensitivity, durability, and re-read capability?
    A. Silicon Diode
    B. MOSFET
    C. Film Badge
    D. TLD
    E. OSLD
    *(Answer: E)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection provides detailed coverage of various solid state detectors including semiconductor diodes (Si, Diamond), MOSFETs, and luminescent dosimeters (TLD, OSLD). It addresses their physical principles, operational characteristics, sources of error/correction factors, and clinical applications, aligning with the requirements of CAMPEP and ABR Part 1 (Section 2: Radiation Instrumentation and Measurement). The increased detail addresses the nuances required for a graduate-level understanding and clinical practice.

---



#### Subsection 2.4: Neutron Detectors

**Overview:**
Neutrons, being uncharged particles, do not interact via the Coulomb force and thus do not directly ionize or excite atomic electrons in the same way as charged particles or photons. Their detection relies on **indirect methods**, primarily through nuclear reactions initiated by the neutrons within a detector medium or a converter material. These reactions produce secondary charged particles (protons, alpha particles, fission fragments) or photons (gamma rays) that *can* be detected by conventional means (gas ionization, scintillation, semiconductor signal). Neutron detection is crucial in environments where neutron fields are present, such as around high-energy medical linear accelerators (linacs), nuclear reactors, particle accelerators, and in specific therapeutic applications like Boron Neutron Capture Therapy (BNCT).

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the primary interaction mechanisms of neutrons with matter relevant to detection: elastic scattering, inelastic scattering, and nuclear reactions (especially neutron capture).
- Explain the energy classification of neutrons (thermal, epithermal, fast) and the importance of moderation for detecting thermal neutrons.
- Detail the operation of gas-filled detectors for thermal neutrons, focusing on BF₃ and ³He proportional counters, including the relevant nuclear reactions and Q-values.
- Describe the use of scintillators for neutron detection, including boron-loaded or lithium-loaded scintillators (e.g., Li-glass, boron-loaded plastics/liquids) and the principles of pulse shape discrimination (PSD) for fast neutron detection in mixed fields.
- Explain the principles of activation foil detectors and fission chambers for neutron fluence measurement.
- Describe the operation and application of superheated drop detectors (bubble detectors) for neutron dosimetry.
- Discuss the challenges in neutron dosimetry, including energy dependence and discrimination against gamma backgrounds.
- Outline the applications of neutron detectors in medical physics, particularly for radiation protection surveys around linacs and in neutron therapy environments.

**Estimated Completion Time:** 240-280 minutes (Increased detail)

**Key Points for Understanding:**
- **Indirect Detection:** Neutrons are detected via secondary radiation produced in nuclear reactions.
- **Neutron Interactions:**
    *   **Elastic Scattering (n,n):** Neutron collides with a nucleus, transferring kinetic energy. Most efficient energy transfer occurs with light nuclei (esp. Hydrogen). Basis for moderation.
    *   **Inelastic Scattering (n,n"):** Neutron excites the target nucleus, which de-excites by emitting gamma rays. Threshold energy required.
    *   **Neutron Capture (n,γ), (n,p), (n,α):** Neutron is absorbed by a nucleus, forming a compound nucleus which decays by emitting gamma rays, protons, or alpha particles. Cross-sections ($\\sigma$) for capture are often much higher for **thermal neutrons** (E ≈ 0.025 eV) and typically follow a $1/v$ dependence (where $v$ is neutron velocity) at low energies.
- **Moderation:** Fast neutrons are difficult to detect efficiently. They are slowed down (thermalized) by elastic scattering in **moderator** materials rich in light nuclei (e.g., water, paraffin, polyethylene, graphite).
- **Thermal Neutron Detectors:** Utilize reactions with high thermal neutron capture cross-sections.
    *   **BF₃ Proportional Counter:** Boron trifluoride gas (enriched in ¹⁰B). Reaction: ¹⁰B(n,α)⁷Li. $Q \approx 2.8$ MeV (mostly to α and Li kinetic energy). Detects the resulting alpha particle and lithium ion via gas ionization.
    *   **³He Proportional Counter:** Helium-3 gas. Reaction: ³He(n,p)³H (Tritium). $Q \approx 0.764$ MeV (to proton and tritium kinetic energy). Higher cross-section than ¹⁰B, no corrosive gas.
    *   **Li-lined/coated detectors:** Gas chamber lined with ⁶Li. Reaction: ⁶Li(n,α)³H. $Q \approx 4.78$ MeV.
- **Scintillation Detectors:**
    *   **Thermal Neutrons:** Incorporate high cross-section nuclides (⁶Li, ¹⁰B) into scintillator material (e.g., ⁶LiI(Eu) - lithium iodide scintillator, boron-loaded plastics/liquids, Li-glass).
    *   **Fast Neutrons:** Utilize elastic scattering off protons in hydrogenous organic scintillators (plastics, liquids). The recoiling proton causes scintillation. **Pulse Shape Discrimination (PSD)** can distinguish between neutron events (proton recoil) and gamma events (electron recoil) based on the different decay times of the light pulse components in certain organic scintillators (e.g., NE-213, stilbene).
- **Activation Foils:** Materials (e.g., Indium, Gold, Rhodium) that become radioactive upon neutron capture. The induced activity (measured post-irradiation via beta/gamma counting) is proportional to the neutron fluence. Different materials have different energy sensitivities (resonance capture). Used for fluence mapping and spectral information (using multiple foils).
- **Fission Chambers:** Gas ionization chamber lined with fissile material (e.g., ²³⁵U, ²³⁹Pu). Neutron capture induces fission, producing highly ionizing fission fragments detected in the gas. Primarily used for high neutron fluxes (reactors).
- **Superheated Drop / Bubble Detectors:** Passive, integrating detectors. Contain droplets of superheated liquid (e.g., freon) suspended in a gel. Neutron interactions (primarily elastic scattering) can deposit enough energy locally to nucleate vaporization, forming a visible bubble. The number of bubbles is proportional to the neutron dose equivalent. Tissue-equivalent response, insensitive to photons.
- **Challenges:** Energy dependence (detector efficiency varies strongly with neutron energy), gamma discrimination (many neutron fields have significant gamma component).
- **Applications (Medical):** Radiation protection surveys around high-energy (>10 MV) linacs (photoneutrons produced in head), shielding assessment, dose measurement in neutron therapy (historical and BNCT).

**2.4.1 Neutron Interactions and Classification**

Neutrons interact with atomic nuclei, not electrons. Key interactions for detection:

*   **Elastic Scattering (A(n,n)A):** Neutron transfers kinetic energy to the nucleus. Energy transfer is maximized for light nuclei, especially hydrogen ($^1$H). The average energy loss per collision is significant in materials like polyethylene (CH₂) or water (H₂O), making them effective **moderators** for slowing down fast neutrons.
*   **Inelastic Scattering (A(n,n"))A*):** Neutron excites the nucleus, losing energy. The nucleus de-excites by emitting gamma rays. Requires a threshold neutron energy (typically > 1 MeV for medium/heavy nuclei). Less important for moderation but contributes to gamma background.
*   **Radiative Capture (A(n,γ)A+1):** Neutron is absorbed, forming a compound nucleus which de-excites by emitting one or more gamma rays. Cross-section ($\\sigma_{n,\gamma}$) is often large for thermal neutrons and can exhibit sharp **resonances** at specific higher energies.
*   **Charged Particle Emission (A(n,p)B, A(n,α)C):** Neutron absorption leads to emission of a proton or alpha particle. These reactions often have high positive Q-values (energy release) and large cross-sections for specific isotopes with thermal neutrons, making them ideal for detection. Examples:
    *   ¹⁰B + n → ⁷Li* + α ($Q = 2.79$ MeV, 94% branch to excited ⁷Li*, then 0.48 MeV γ; 6% branch directly to ground state ⁷Li, $Q=2.79$ MeV)
    *   ³He + n → ³H + p ($Q = 0.764$ MeV)
    *   ⁶Li + n → ³H + α ($Q = 4.78$ MeV)
*   **Fission (A(n,f)B+C+xn):** Heavy nuclei (e.g., ²³⁵U) absorb a neutron and split into two large fragments, releasing significant energy (~200 MeV) and more neutrons. High cross-section for thermal neutrons in fissile materials.

**Neutron Energy Classification:**
- **Thermal Neutrons:** In thermal equilibrium with surroundings (~ room temp). Maxwell-Boltzmann energy distribution peaking around $E \approx kT \approx 0.025$ eV.
- **Epithermal Neutrons:** Energies from ~0.5 eV up to ~100 keV.
- **Fast Neutrons:** Energies from ~100 keV up to ~20 MeV.
- **High-Energy Neutrons:** Energies > 20 MeV.

Detection efficiency often depends strongly on neutron energy. Many detectors rely on reactions with high thermal neutron cross-sections, requiring moderation for detecting faster neutrons.

**2.4.2 Moderation**

Process of slowing down fast neutrons, typically to thermal energies, to increase detection probability via capture reactions.

*   **Mechanism:** Primarily elastic scattering.
*   **Moderator Materials:** Must be rich in light nuclei (for efficient energy transfer) and have low neutron absorption cross-section (to avoid losing neutrons before detection).
    *   Common: Polyethylene (CH₂), paraffin (similar to CH₂), water (H₂O), heavy water (D₂O), graphite (C).
*   **Detector Design:** Many thermal neutron detectors (e.g., BF₃, ³He counters) are embedded within a moderator (e.g., polyethylene cylinder) to make them sensitive to fast neutrons as well. The moderator thermalizes incident fast neutrons, which then diffuse into the detector volume.

[ILLUSTRATION: Diagram showing a fast neutron entering a moderator block (e.g., polyethylene) and undergoing multiple elastic scatters before becoming a thermal neutron and being detected by an embedded thermal detector (e.g., BF₃ tube).] 

**2.4.3 Gas-Filled Detectors (BF₃, ³He)**

Operate as proportional counters, detecting the ionization produced by charged particles from neutron capture reactions.

*   **BF₃ Proportional Counter:**
    *   **Gas:** Boron trifluoride (BF₃), often enriched in ¹⁰B (natural abundance ~20%) to increase efficiency. ¹⁰B has a very high thermal neutron capture cross-section (~3840 barns).
    *   **Reaction:** ¹⁰B(n,α)⁷Li. The energetic α (~1.47 MeV) and ⁷Li (~0.84 MeV) particles (for the 94% branch) cause significant ionization in the gas.
    *   **Operation:** Operated in the proportional region. The collected charge is proportional to the initial ionization, allowing discrimination against lower-ionization gamma events.
    *   **Advantages:** Good gamma discrimination (due to high Q-value), relatively inexpensive.
    *   **Disadvantages:** BF₃ is toxic and corrosive, efficiency limited by gas pressure and ¹⁰B enrichment, voltage requirements typical of proportional counters.
*   **³He Proportional Counter:**
    *   **Gas:** Helium-3 (³He), often mixed with a quench gas (e.g., CO₂, CH₄).
    *   **Reaction:** ³He(n,p)³H. $Q = 0.764$ MeV. The proton (~0.573 MeV) and triton (~0.191 MeV) cause ionization.
    *   **Advantages:** Very high thermal neutron cross-section (~5330 barns), non-toxic/corrosive gas, can operate at higher pressures (higher efficiency), lower Q-value but still allows reasonable gamma discrimination.
    *   **Disadvantages:** ³He is very expensive and availability can be limited.
*   **Gamma Discrimination:** The large energy deposition from the (n,α) or (n,p) reactions produces significantly larger pulses than typical gamma interactions (Compton electrons) in the low-pressure gas. Setting a pulse height discriminator can effectively reject most gamma events.
*   **Applications:** Neutron survey meters (often embedded in moderator - "rem meters"), neutron flux monitoring, research.

**2.4.4 Scintillation Detectors for Neutrons**

*   **Thermal Neutron Scintillators:**
    *   **⁶LiI(Eu):** Europium-activated Lithium Iodide, enriched in ⁶Li. Reaction: ⁶Li(n,α)³H ($Q=4.78$ MeV). High light output, good gamma discrimination possible due to high Q-value. Hygroscopic.
    *   **Li-glass:** Cerium-activated lithium silicate glass. Lower light output than ⁶LiI(Eu), but robust and available in various shapes. Gamma sensitivity can be significant.
    *   **Boron-loaded Scintillators:** ¹⁰B incorporated into plastic or liquid scintillators. Reaction: ¹⁰B(n,α)⁷Li ($Q=2.8$ MeV). Lower light output compared to Li-based, but can be made large and relatively inexpensive.
*   **Fast Neutron Scintillators & Pulse Shape Discrimination (PSD):**
    *   **Mechanism:** Fast neutrons elastically scatter off protons in hydrogenous organic scintillators (e.g., liquid scintillators like NE-213, xylene-based; plastic scintillators; crystalline stilbene). The recoil protons deposit energy and cause scintillation.
    *   **PSD:** Certain organic scintillators exhibit different scintillation light decay profiles depending on the ionizing particle type. Excitation by heavy charged particles (like recoil protons from neutrons) preferentially populates longer-lived triplet states compared to excitation by electrons (from gamma interactions). This results in a light pulse with a more prominent slow decay component for neutrons than for gammas.
    *   **Technique:** Electronic circuits analyze the shape of the output pulse (e.g., comparing charge in the tail vs. total charge, or using zero-crossing timing) to distinguish neutron events from gamma events.
    *   **Applications:** Mixed neutron/gamma field measurements, neutron spectroscopy (using unfolding techniques on recoil proton energy spectrum), fast neutron detection.

[ILLUSTRATION: Diagram comparing the pulse shapes from an organic scintillator for a gamma interaction (fast decay) and a neutron interaction (slower tail component), illustrating the principle of PSD.]

**2.4.5 Activation Foils**

Passive technique for measuring neutron fluence (time-integrated flux).

*   **Principle:** A material foil with a known neutron capture cross-section is placed in the neutron field. Neutron capture induces radioactivity in the foil. After irradiation, the foil is removed, and its activity ($A$) is measured using a suitable detector (e.g., Geiger counter, gamma spectrometer).
*   **Fluence Calculation:** The neutron fluence ($\\Phi$) can be related to the induced activity, the capture cross-section ($\\sigma$), the number of target nuclei ($N$), and the decay constant ($\\lambda$) of the product nucleus. For irradiation time $t_{irr}$ and measurement time $t_{meas}$ after irradiation:
    $A(t_{meas}) = N \\sigma \\phi (1 - e^{-\\lambda t_{irr}}) e^{-\\lambda t_{meas}}$ (where $\\phi$ is flux, $\\Phi = \\phi t_{irr}$ for constant flux).
*   **Materials:** Choice depends on the neutron energy range of interest.
    *   **Thermal Neutrons:** Indium (¹¹⁵In(n,γ)¹¹⁶mIn), Gold (¹⁹⁷Au(n,γ)¹⁹⁸Au). High thermal cross-sections.
    *   **Resonance Neutrons:** Indium, Gold, Cobalt show strong capture resonances at specific epithermal energies. Using foils covered with Cadmium (which strongly absorbs thermal neutrons) allows measurement of epithermal fluence.
    *   **Fast Neutrons:** Threshold reactions like ³²S(n,p)³²P, ²⁷Al(n,α)²⁴Na, ⁵⁸Ni(n,p)⁵⁸Co. Only occur above a certain neutron energy threshold.
*   **Spectral Unfolding:** By using a set of multiple foils with different energy responses, information about the neutron energy spectrum can be inferred using unfolding algorithms.
*   **Advantages:** Simple, inexpensive, passive (no power required), can map fluence distributions.
*   **Disadvantages:** Not real-time, requires post-irradiation counting, provides fluence not dose equivalent, interpretation requires knowledge of cross-sections and spectrum.

**2.4.6 Fission Chambers**

Ionization chambers lined with fissile material.

*   **Principle:** Neutron capture by the fissile lining (e.g., ²³⁵U, ²³⁹Pu) induces fission. The resulting fission fragments are heavy, highly charged particles that deposit a large amount of energy (~160 MeV kinetic energy) in the chamber gas via dense ionization tracks.
*   **Operation:** Operated in ionization or proportional region. The very large pulses from fission fragments are easily discriminated from smaller pulses due to gamma interactions or alpha decay of the lining material.
*   **Advantages:** Excellent gamma discrimination, high sensitivity to neutrons, can operate in high gamma fields and high temperatures.
*   **Disadvantages:** Use of fissile materials (regulatory issues), complexity.
*   **Applications:** Primarily neutron flux monitoring in nuclear reactors.

**2.4.7 Superheated Drop / Bubble Detectors**

Passive, integrating personal neutron dosimeters.

*   **Principle:** Based on the theory of bubble nucleation in superheated liquids. The detector contains small droplets (~10-100 μm) of a volatile liquid (e.g., halocarbon like Freon) suspended in an elastic polymer or gel matrix. The liquid is maintained at a temperature and pressure where it is superheated (i.e., above its normal boiling point but remaining liquid due to lack of nucleation sites).
*   **Neutron Interaction:** When a neutron interacts within or near a droplet (primarily via elastic scattering with C, F, Cl nuclei), the recoiling nucleus deposits energy in a very small volume. If the deposited energy density exceeds a threshold, it can trigger explosive vaporization of the superheated droplet, forming a macroscopic bubble trapped in the gel.
*   **Dose Measurement:** The number of visible bubbles formed is proportional to the neutron dose equivalent. Readout is done by visually counting the bubbles or using automated optical/acoustic counters.
*   **Tissue Equivalence & Gamma Insensitivity:** The response is related to the energy deposition by recoil nuclei, similar to tissue. The energy deposition required for nucleation is much higher than that typically deposited by secondary electrons from photon interactions, making the detectors effectively insensitive to photons.
*   **Advantages:** Tissue-equivalent response for dose equivalent, passive, integrating, immediate visual indication (bubbles), insensitive to photons.
*   **Disadvantages:** Temperature dependence (superheat changes with T), sensitivity can vary, limited dose range, bubbles cannot be easily erased (single use or requires recompression for some types), potential sensitivity to shock/vibration.
*   **Applications:** Personal neutron dosimetry, particularly in mixed fields where gamma discrimination is important.

**Assessment Questions (ABR Style):**

1.  (Principle) The detection of thermal neutrons in a BF₃ proportional counter relies on which nuclear reaction?
    A. Elastic scattering of neutrons off Boron.
    B. Inelastic scattering of neutrons off Fluorine.
    C. The ¹⁰B(n,α)⁷Li reaction.
    D. The ¹⁹F(n,γ)²⁰F reaction.
    E. Fission of Boron nuclei.
    *(Answer: C)*

2.  (Technique) Slowing down fast neutrons to thermal energies to increase their detection probability by capture reactions is known as:
    A. Activation
    B. Moderation
    C. Scintillation
    D. Fission
    E. Pulse Shape Discrimination
    *(Answer: B)*

3.  (Detector) Which detector type is commonly embedded within a polyethylene moderator to create a "rem meter" for measuring neutron dose equivalent rate?
    A. NaI(Tl) scintillator
    B. Silicon diode
    C. Geiger-Mueller counter
    D. BF₃ or ³He proportional counter
    E. MOSFET detector
    *(Answer: D)*

4.  (Technique) Pulse Shape Discrimination (PSD) is a technique used with certain organic scintillators primarily to:
    A. Improve energy resolution for gamma rays.
    B. Distinguish between neutron events and gamma events.
    C. Measure the activity of activation foils.
    D. Increase the light output of the scintillator.
    E. Compensate for temperature dependence.
    *(Answer: B)*

5.  (Detector) Activation foils, such as Indium or Gold, are used to measure neutron:
    A. Dose equivalent in real-time.
    B. Energy spectrum directly.
    C. Fluence by measuring induced radioactivity.
    D. LET distribution.
    E. Pulse height distribution.
    *(Answer: C)*

6.  (Detector) Superheated drop (bubble) detectors are particularly useful for personal neutron dosimetry because they:
    A. Provide excellent energy resolution for fast neutrons.
    B. Are based on neutron activation of a liquid.
    C. Offer good discrimination against photon radiation and provide a dose equivalent response.
    D. Use fissile materials for high sensitivity.
    E. Require high voltage for operation.
    *(Answer: C)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection details the principles and methods for detecting neutrons, covering interactions, moderation, and various detector types (gas-filled, scintillators with PSD, activation foils, bubble detectors). It addresses the challenges of neutron dosimetry and applications relevant to medical physics (radiation protection around linacs), aligning with CAMPEP/ABR Part 1 requirements (Section 2: Radiation Instrumentation and Measurement). The increased detail provides a thorough grounding in this specialized area.

---


#### Subsection 2.5: Emerging and Miscellaneous Detectors

**Overview:**
Beyond the major categories of gas-filled, scintillation, and solid-state detectors, several other detection methods and emerging technologies play important roles in medical physics, particularly in reference dosimetry, high-resolution spatial dosimetry, and specialized applications. This subsection explores chemical dosimeters (Fricke, radiochromic film), calorimetry (the fundamental method for absorbed dose measurement), Cherenkov detectors, and plastic scintillation detectors, highlighting their unique principles, advantages, limitations, and clinical relevance.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Explain the principle of chemical dosimetry and the concept of chemical yield (G-value).
- Describe the Fricke dosimeter system (ferrous sulfate solution), including the chemical reaction, readout method (spectrophotometry), and its role as a reference dosimeter.
- Detail the mechanism of radiochromic film dosimetry, including radiation-induced polymerization and color change.
- Discuss the advantages (high spatial resolution, tissue equivalence, self-developing) and disadvantages (dose rate dependence, environmental sensitivity) of radiochromic film (e.g., Gafchromic™ EBT series).
- Explain the procedure for radiochromic film calibration and scanning (e.g., using flatbed scanners).
- Describe the fundamental principle of calorimetry: measuring absorbed dose via temperature rise ($\\Delta T = D/c_p$).
- Explain the operation and significance of water calorimeters and graphite calorimeters as primary standards for absorbed dose.
- Discuss the challenges associated with calorimetry (small temperature changes, heat loss/transfer corrections, heat defect).
- Explain the origin and characteristics of Cherenkov radiation.
- Describe the potential applications of Cherenkov detectors in medical physics, such as beam monitoring and Cherenkov emission imaging for *in vivo* dosimetry or treatment verification.
- Discuss the properties and applications of plastic scintillation detectors (PSDs) in radiotherapy dosimetry, emphasizing their water equivalence and potential for real-time measurements.
- Compare the relative advantages and disadvantages of these miscellaneous and emerging detector types for specific dosimetric tasks.

**Estimated Completion Time:** 240-280 minutes (Increased detail)

**Key Points for Understanding:**
- **Chemical Dosimetry:** Relies on measuring radiation-induced chemical changes in a medium. The **chemical yield (G-value)** quantifies the number of molecules changed per unit energy absorbed (typically per 100 eV).
- **Fricke Dosimeter:** Aqueous solution of ferrous sulfate (Fe²⁺), sodium chloride (NaCl), and sulfuric acid (H₂SO₄). Radiation oxidizes Fe²⁺ to Fe³⁺. The concentration of Fe³⁺ is measured via UV spectrophotometry (absorption peak ~304 nm). G-value is well-characterized. Considered a reference dosimeter system.
- **Radiochromic Film:** Thin active layer containing a monomer dye, coated on a transparent polyester base. Radiation causes polymerization of the monomer, leading to a color change (darkening) proportional to dose. Self-developing (no chemical processing). Nearly tissue-equivalent. High spatial resolution (~μm). Used for 2D/3D relative dosimetry (IMRT/VMAT QA, SRS/SBRT, brachytherapy). Requires careful calibration and handling (sensitive to UV light, temperature, humidity, scanner variations).
- **Calorimetry:** Fundamental method measuring absorbed dose directly from the temperature rise ($\\Delta T$) it produces in a known mass of material with specific heat capacity ($c_p$). $D = c_p \\Delta T$ (ignoring heat defect).
    *   **Primary Standard:** Calorimeters (esp. water and graphite) serve as primary standards in national laboratories (e.g., NIST, NPL) for calibrating reference ionization chambers.
    *   **Challenges:** Very small temperature changes (e.g., 1 Gy in water ≈ 0.24 mK), requires extremely sensitive thermistors, careful thermal isolation, and corrections for heat loss/transfer and **heat defect** (difference between absorbed energy and energy appearing as heat due to endo/exothermic chemical reactions).
- **Cherenkov Radiation:** Electromagnetic radiation (typically blue light) emitted when a charged particle travels through a dielectric medium faster than the phase velocity of light in that medium ($v > c/n$). The light is emitted in a cone. Intensity is related to particle energy and path length.
    *   **Detection:** Can be detected using sensitive cameras (CCDs, EMCCDs) or PMTs.
    *   **Applications:** Used in high-energy physics particle identification. Emerging applications in medical physics include beam monitoring, quality assurance, and potentially *in vivo* dosimetry by imaging Cherenkov light produced within tissue during radiotherapy.
- **Plastic Scintillation Detectors (PSDs):** Organic scintillators in a plastic matrix (e.g., polystyrene). Nearly water-equivalent, allowing dose measurements with minimal perturbation compared to higher-Z detectors. Can be fabricated into small sizes (fibers, points) for high-resolution measurements. Signal requires correction for Cherenkov light generated in the detector/light guide. Used for relative dosimetry, potentially real-time *in vivo* dosimetry.

**2.5.1 Chemical Dosimeters**

These dosimeters utilize radiation-induced chemical reactions where the extent of the reaction is proportional to the absorbed dose.

*   **G-value (Chemical Yield):** Defined as the number of molecules, ions, or radicals produced, destroyed, or changed per 100 eV of energy absorbed by the medium. $G = \frac{N}{E} \times 100$, where N is the number of species changed and E is the energy absorbed in eV. It depends on the medium, radiation type, LET, dose rate, and environmental conditions.

*   **Fricke Dosimeter:**
    *   **Composition:** Standard solution: 1 mM ferrous sulfate (FeSO₄) or ferrous ammonium sulfate, 1 mM sodium chloride (NaCl), and 0.4 M (or 0.8 N) sulfuric acid (H₂SO₄) in high-purity water.
        *   NaCl: Inhibits effects of organic impurities.
        *   H₂SO₄: Provides acidic medium, suppresses competing reactions.
    *   **Mechanism:** Ionizing radiation produces radicals in water (e.g., H•, OH•, e⁻_aq, H₂O₂). These radicals oxidize ferrous ions (Fe²⁺) to ferric ions (Fe³⁺). The primary reaction is: $Fe^{2+} + OH• → Fe^{3+} + OH⁻$.
    *   **G-value:** For MV photons and electrons, the G-value for Fe³⁺ production is well-established and relatively constant, approximately 15.5 ions per 100 eV (or 1.61 μmol/J).
    *   **Readout:** The concentration of Fe³⁺ ions is determined by measuring the change in optical absorbance ($\\Delta A$) at the peak absorption wavelength (~304 nm) using a UV spectrophotometer. According to the Beer-Lambert law, $\\Delta A = \\epsilon \\cdot [Fe^{3+}] \\cdot l$, where $\\epsilon$ is the molar extinction coefficient and $l$ is the optical path length.
    *   **Dose Calculation:** $D = \frac{\\Delta A}{\\rho \\cdot G(Fe^{3+}) \\cdot \\epsilon \\cdot l}$, where $\\rho$ is the density of the solution.
    *   **Advantages:** Considered a reference dosimeter system with accuracy ~1-2%, dose rate independent over a wide range, response is proportional to absorbed dose in water (with small corrections).
    *   **Disadvantages:** Relatively low sensitivity (requires doses > ~5 Gy for high precision), sensitive to impurities, requires careful solution preparation and spectrophotometry, not real-time, liquid (handling issues).
    *   **Applications:** Reference dosimetry in standards laboratories, calibration of beams, measurement of high doses.

*   **Radiochromic Film:**
    *   **Composition:** Typically consists of a thin (~5-30 μm) **active layer** containing microscopic crystals of a diacetylene monomer dye, sandwiched between or coated onto transparent polyester base layers.
    *   **Mechanism:** Exposure to ionizing radiation induces solid-state polymerization of the monomer molecules within the active layer. This polymerization process alters the electronic structure of the conjugated bonds, leading to increased absorption of visible light, particularly in the red region of the spectrum, resulting in a visible color change (typically becoming blue/darker).
    *   **Self-Developing:** The color change occurs directly upon irradiation and continues slowly post-irradiation (requiring a waiting period for stabilization, e.g., 24 hours). No wet chemical processing is needed.
    *   **Tissue Equivalence:** The active layer and polyester base have effective atomic numbers and densities close to water, resulting in a response that is nearly water-equivalent over a wide range of photon and electron energies (minimal energy dependence in MV range).
    *   **Advantages:**
        *   High Spatial Resolution: Active layer is thin and grainless, allowing resolution down to micrometers.
        *   Tissue Equivalence: Minimal perturbation of radiation field.
        *   Self-Developing & Dry Handling: Convenient to use.
        *   Insensitive to visible light (most types, e.g., EBT3).
        *   Large dynamic range (can measure doses from cGy to kGy depending on film type).
    *   **Disadvantages:**
        *   **Environmental Sensitivity:** Response can be affected by temperature during irradiation and scanning, humidity, UV light exposure (pre- and post-irradiation).
        *   **Dose Rate Dependence:** Some dependence reported, especially at very high or low dose rates.
        *   **Scanner Dependence:** Response depends on the scanner used for readout (light source spectrum, detector response, orientation, scattering effects). Requires consistent scanning protocol and scanner calibration/correction.
        *   **Post-Irradiation Darkening:** Color continues to develop slowly after exposure, requiring a consistent waiting time before scanning.
        *   **Non-Linear Dose Response:** Optical density vs. dose relationship is non-linear, requiring careful calibration.
    *   **Calibration & Readout:**
        *   Calibration: Films are irradiated to known doses (using a calibrated ion chamber) covering the expected range. A calibration curve (e.g., net Optical Density vs. Dose) is generated.
        *   Scanning: Typically read using flatbed color transmission scanners. Often scanned in transmission mode using the red color channel (or sometimes green/blue depending on dose range and film type). Corrections for scanner uniformity and inter-scan variations are crucial (e.g., using an unexposed film strip).
        *   Software: Specialized software is used to convert scanned images (pixel values) to optical density and then to dose using the calibration curve.
    *   **Film Types:** Gafchromic™ is the primary brand. EBT series (EBT, EBT2, EBT3) designed for external beam therapy QA. MD series for medium doses, HD series for high doses (e.g., SRS). XR series for kV energies.
    *   **Applications:** High-resolution 2D dosimetry (IMRT/VMAT QA, patient-specific QA), small field dosimetry, brachytherapy source QA, surface dose measurements, stereotactic procedures, electron beam cutouts.

[ILLUSTRATION: Diagram showing the structure of radiochromic film (active layer, polyester base). Graph showing a typical non-linear calibration curve (Net Optical Density vs. Dose) for EBT3 film.]

**2.5.2 Calorimetry**

Calorimetry provides the most fundamental method for determining absorbed dose by measuring the temperature rise produced by radiation.

*   **Principle:** Absorbed dose ($D$) is defined as energy absorbed ($E_{abs}$) per unit mass ($m$). $D = dE_{abs}/dm$. If the absorbed energy is completely converted into heat within an absorber material of specific heat capacity ($c_p$), the temperature rise ($\\Delta T$) is directly proportional to the dose: $D = c_p \\Delta T$. (This assumes no heat loss and no heat defect).
*   **Significance:** Provides a direct measurement of absorbed dose without relying on radiation interaction coefficients or calibration factors derived from other quantities (like exposure or air kerma). It forms the basis for primary standards of absorbed dose.
*   **Types:**
    *   **Graphite Calorimeter:** Graphite is often used as the absorber material due to its known specific heat capacity, good thermal properties, and near tissue equivalence for MV photons. A small graphite core (absorber) is thermally isolated within a larger graphite body (jacket/shield) under vacuum. Sensitive thermistors measure the temperature difference between the core and the jacket.
    *   **Water Calorimeter:** Water is the ideal medium as dose is typically specified to water. A small volume of high-purity water acts as the absorber. Thermistors measure the temperature rise. Challenges include convection currents, heat transfer, and water purity effects. Various designs exist to minimize these issues (e.g., sealed vessels, stagnant water).
    *   **Other Materials:** Polystyrene, A-150 tissue-equivalent plastic have also been used.
*   **Measurement Challenges:**
    *   **Small Temperature Rise:** 1 Gy dose produces only ~0.24 mK rise in water. Requires extremely sensitive temperature sensors (thermistors with ~μK resolution) and low-noise electronics.
    *   **Thermal Isolation:** The absorber must be thermally isolated to prevent heat exchange with the surroundings during the measurement period.
    *   **Heat Loss/Transfer Corrections:** Sophisticated analysis (e.g., extrapolation methods) is needed to correct for unavoidable heat losses or gains.
    *   **Heat Defect:** The assumption that all absorbed energy appears as heat may not be perfectly true. Some energy might be stored in chemical changes (endothermic reactions) or released from them (exothermic reactions). The heat defect ($h$) modifies the basic equation: $D = \frac{c_p \\Delta T}{1-h}$. The heat defect needs to be determined or assumed (often assumed zero for graphite, small and slightly uncertain for water, potentially significant in plastics).
*   **Applications:** Primarily used in national standards laboratories (e.g., NIST, NPL, NRC) to establish primary standards for absorbed dose to water or graphite. These standards are then used to calibrate reference ionization chambers for dissemination to clinical centers.

[ILLUSTRATION: Schematic diagram of a graphite calorimeter showing the core, jacket, shield, vacuum enclosure, and thermistors.]

**2.5.3 Cherenkov Detectors**

Detectors based on the emission of Cherenkov light.

*   **Cherenkov Radiation:** When a charged particle travels through a dielectric medium (refractive index $n$) with a velocity ($v$) greater than the phase velocity of light in that medium ($c/n$), it emits electromagnetic radiation called Cherenkov light. Condition: $v > c/n$ or $\\beta = v/c > 1/n$.
    *   **Emission Angle:** Light is emitted in a cone with half-angle $\\theta_C$ given by $\\cos(\\theta_C) = \frac{1}{\\beta n}$.
    *   **Spectrum:** Continuous spectrum, with intensity weighted towards shorter wavelengths (blue/UV), roughly proportional to $1/\\lambda^2$. $dN/d\\lambda \\propto \sin^2(\\theta_C) / \\lambda^2$.
    *   **Threshold Energy:** There is a minimum kinetic energy the charged particle must possess to exceed the velocity threshold.
*   **Detection in Medical Physics:** High-energy electrons produced by MV photon or electron beams in water/tissue often exceed the Cherenkov threshold ($E_{th} \approx 260$ keV for electrons in water, $n \approx 1.33$). The emitted Cherenkov light can be detected.
*   **Detector Types & Applications:**
    *   **Optical Fibers:** Cherenkov light generated in an optical fiber (or a small scintillator coupled to it) can be guided to a photodetector (PMT, photodiode). Can be used for beam monitoring or potentially point dosimetry. Often requires separation from scintillation signal if using scintillating fibers.
    *   **Cherenkov Emission Imaging:** Using sensitive cameras (intensified CCDs, EMCCDs) to image the Cherenkov light produced directly within the patient or phantom during irradiation.
        *   **Potential Applications:** Real-time treatment verification (comparing measured light distribution to expected distribution), *in vivo* dosimetry (intensity related to dose), beam range verification (light emission stops near end of particle range).
        *   **Challenges:** Weak signal requires sensitive detectors, signal is complex (depends on dose, beam path, optical properties of tissue), separating Cherenkov from tissue fluorescence/bioluminescence, converting light intensity accurately to dose.
*   **Cherenkov in Plastic Scintillators:** Cherenkov light is also produced in plastic scintillators and optical fibers used with them. This can be a confounding signal that needs to be corrected for, especially in non-water-equivalent PSDs, as it is prompt and directional, unlike the isotropic scintillation light.

**2.5.4 Plastic Scintillation Detectors (PSDs)**

While scintillators were covered earlier, plastic scintillators deserve special mention for their dosimetry applications.

*   **Composition:** Typically based on a plastic matrix like polystyrene (PS) or polyvinyltoluene (PVT), doped with fluorescent compounds (primary and secondary fluors) to shift the emission wavelength.
*   **Water Equivalence:** Composed mainly of Carbon and Hydrogen, making their effective atomic number and density very close to water. This results in minimal perturbation of the radiation beam and a response that is nearly water-equivalent over a wide range of MV photon and electron energies.
*   **Advantages for Dosimetry:**
    *   Water Equivalence: Reduces need for complex correction factors required for non-water-equivalent detectors (like diodes, ion chambers in some situations).
    *   Energy Independence (MV range): Response per unit dose is relatively constant for typical therapy beams.
    *   Dose Rate Independence (mostly): Generally good linearity up to high dose rates.
    *   Temperature Independence (minor): Less sensitive to temperature than diodes or MOSFETs.
    *   Small Sensitive Volumes: Can be fabricated into small points or fibers for high-resolution measurements.
    *   Real-time Readout: Provides instantaneous dose rate or integrated dose information.
*   **Disadvantages & Corrections:**
    *   **Cherenkov Stem Effect:** Cherenkov light generated by radiation interacting within the light guide (optical fiber) carrying the scintillation signal to the photodetector can be a significant artifact. Requires correction methods (e.g., background subtraction using a parallel fiber shielded from scintillation, spectral filtering, temporal gating).
    *   **Lower Light Output:** Generally lower light yield compared to inorganic scintillators like NaI(Tl).
    *   **Calibration:** Requires careful calibration against a reference standard.
*   **Applications:** Relative dosimetry (PDD, profiles) in water phantoms, small field dosimetry, output factor measurements, potentially *in vivo* dosimetry (using fiber-coupled detectors), QA measurements where water equivalence is critical.

**Assessment Questions (ABR Style):**

1.  (Principle) The Fricke dosimeter measures absorbed dose based on the radiation-induced:
    A. Polymerization of a monomer dye.
    B. Temperature rise in an isolated absorber.
    C. Oxidation of ferrous ions (Fe²⁺) to ferric ions (Fe³⁺).
    D. Emission of Cherenkov light.
    E. Trapping of electrons in crystal defects.
    *(Answer: C)*

2.  (Characteristic) A major advantage of radiochromic film (e.g., Gafchromic EBT3) for clinical dosimetry QA is its:
    A. Linear dose response.
    B. Insensitivity to environmental conditions.
    C. High spatial resolution and near tissue equivalence.
    D. Ability to be read out immediately after irradiation.
    E. Low cost compared to ionization chambers.
    *(Answer: C)*

3.  (Principle) Calorimetry is considered a fundamental method for absorbed dose measurement because it:
    A. Relies on well-known chemical G-values.
    B. Directly relates dose to a measurable temperature change.
    C. Uses detectors with minimal energy dependence.
    D. Has the highest spatial resolution.
    E. Is insensitive to the heat defect.
    *(Answer: B)*

4.  (Phenomenon) Cherenkov radiation is produced when:
    A. A neutron is captured by a nucleus.
    B. An electron recombines with a hole in a semiconductor.
    C. A charged particle travels faster than the speed of light in a vacuum.
    D. A charged particle travels faster than the speed of light in the medium.
    E. A TLD is heated after irradiation.
    *(Answer: D)*

5.  (Detector) Plastic scintillation detectors are often favored for certain radiotherapy dosimetry tasks primarily due to their:
    A. High atomic number.
    B. Ability to perform pulse shape discrimination.
    C. Very high light output compared to NaI(Tl).
    D. Near water equivalence.
    E. Insensitivity to radiation damage.
    *(Answer: D)*

6.  (Correction) A significant correction often required when using fiber-coupled plastic scintillation detectors for accurate dosimetry is for the:
    A. Heat defect of the plastic.
    B. Energy dependence due to photoelectric effect.
    C. Cherenkov light generated in the optical fiber (stem effect).
    D. Recombination losses at high dose rates.
    E. Temperature dependence of the scintillation efficiency.
    *(Answer: C)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection covers important miscellaneous and emerging detector systems relevant to medical physics, including chemical dosimeters (Fricke, radiochromic film), calorimetry (primary standard principles), Cherenkov detection, and plastic scintillators. It addresses their principles, characteristics, and applications, aligning with CAMPEP/ABR Part 1 requirements (Section 2: Radiation Instrumentation and Measurement). The increased detail provides necessary depth on these specialized but important topics.

---


#### Subsection 2.6: Measurement Procedures

**Overview:**
Accurate and reliable radiation measurements depend not only on the choice of detector but also on understanding the statistical nature of radiation emission and detection, the proper functioning of associated electronics, and the systematic analysis of uncertainties. This subsection delves into the fundamental principles of counting statistics, the components and functions of pulse processing electronics, the concept and correction of detector dead time, coincidence/anti-coincidence techniques, signal-to-noise optimization, and the framework for evaluating and reporting measurement uncertainty. Mastery of these procedures is essential for quantitative work in all areas of medical physics.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the statistical nature of radioactive decay and radiation detection using the Poisson distribution.
- Apply the Gaussian approximation for large numbers of counts and calculate standard deviations ($\\sigma = \\sqrt{N}$).
- Propagate uncertainties for measurements involving sums, differences, products, quotients, and functions of measured quantities.
- Determine the minimum counting time required to achieve a desired statistical precision.
- Identify the key components of a nuclear instrumentation signal chain (preamplifier, amplifier, discriminator, MCA) and explain their functions.
- Differentiate between charge-sensitive and voltage-sensitive preamplifiers.
- Explain the purpose of pulse shaping in amplifiers (improving SNR, preventing pile-up).
- Describe the function of lower-level (LLD), upper-level (ULD), and single-channel analyzers (SCA) in pulse height selection.
- Explain the operation and purpose of a multichannel analyzer (MCA) in energy spectroscopy.
- Define detector dead time and distinguish between paralyzable and non-paralyzable system models.
- Apply appropriate correction formulas to determine the true count rate from the measured count rate and dead time.
- Describe methods for measuring dead time, such as the two-source method.
- Explain the principles of coincidence and anti-coincidence counting and provide examples of their application (e.g., PET, low-level counting).
- Discuss factors influencing the signal-to-noise ratio (SNR) in radiation measurements.
- Differentiate between Type A (statistical) and Type B (systematic/other) uncertainties according to the GUM framework.
- Combine different sources of uncertainty to calculate the combined standard uncertainty and expanded uncertainty (coverage factor, confidence level).

**Estimated Completion Time:** 280-320 minutes (Increased detail)

**Key Points for Understanding:**
- **Counting Statistics:** Radioactive decay and detection events are random, independent processes, well-described by the **Poisson distribution**. $P(k; \\mu) = \frac{\\mu^k e^{-\\mu}}{k!}$, where $\\mu$ is the true mean number of events and $P(k; \\mu)$ is the probability of observing $k$ events.
    *   For a Poisson distribution, the variance equals the mean: $\\sigma^2 = \\mu$. The best estimate of the mean $\\mu$ from a single measurement of $N$ counts is $N$ itself. Therefore, the standard deviation is estimated as $\\sigma \\approx \\sqrt{N}$.
    *   **Gaussian Approximation:** For large $N$ (typically $N > 20$), the Poisson distribution approaches a Gaussian (Normal) distribution with mean $\\mu=N$ and standard deviation $\\sigma=\\sqrt{N}$. Confidence intervals can be estimated (e.g., $N \\pm \\sqrt{N}$ for ~68%, $N \\pm 2\\sqrt{N}$ for ~95%).
    *   **Relative Uncertainty:** $\\sigma/N = \\sqrt{N}/N = 1/\\sqrt{N}$. To decrease relative uncertainty by a factor of 2, the number of counts must increase by a factor of 4.
- **Uncertainty Propagation:** For a calculated quantity $y = f(x_1, x_2, ...)$ based on measured variables $x_i$ with standard uncertainties $u(x_i)$:
    *   Addition/Subtraction ($y = ax_1 \\pm bx_2$): $u(y)^2 = (a \cdot u(x_1))^2 + (b \cdot u(x_2))^2$ (assuming $x_1, x_2$ uncorrelated).
    *   Multiplication/Division ($y = ax_1^p x_2^q$): $(\\frac{u(y)}{y})^2 = (p \cdot \\frac{u(x_1)}{x_1})^2 + (q \cdot \\frac{u(x_2)}{x_2})^2$. Relative uncertainties add in quadrature.
    *   General Case: $u(y)^2 = \\sum_i (\\frac{\\partial f}{\\partial x_i})^2 u(x_i)^2 + \\sum_{i \\neq j} \\frac{\\partial f}{\\partial x_i} \\frac{\\partial f}{\\partial x_j} u(x_i, x_j)$, where $u(x_i, x_j)$ is the covariance.
- **Pulse Processing Electronics:** Convert the weak detector signal into a usable form for analysis.
    *   **Preamplifier:** First stage, located near the detector. Provides initial amplification, impedance matching, and shapes the pulse slightly. **Charge-sensitive preamps** integrate the charge pulse from the detector (common for semiconductors, proportional counters). **Voltage-sensitive preamps** amplify the voltage pulse (less common for pulse counting).
    *   **Amplifier (Shaping Amplifier):** Further amplifies the signal and shapes the pulse (e.g., using CR-RC or Gaussian shaping networks) to optimize SNR, reduce noise bandwidth, and create a defined pulse shape suitable for subsequent analysis, minimizing pulse pile-up at high count rates. Shaping time constants affect resolution and dead time.
    *   **Discriminators/SCA:** Select pulses based on their height (amplitude), which is often related to energy deposited.
        *   **LLD:** Passes pulses above a certain threshold.
        *   **ULD:** Rejects pulses above a certain threshold.
        *   **SCA:** Uses LLD and ULD to define an energy window, passing only pulses within the window.
    *   **Multichannel Analyzer (MCA):** Sorts incoming pulses based on their height and stores the counts in corresponding channels (bins), building up an energy spectrum. Consists of an Analog-to-Digital Converter (ADC) and memory.
- **Dead Time ($\\tau$):** The minimum time required after detecting one event before the system (detector or electronics) can successfully detect a subsequent event. Limits the maximum measurable count rate.
    *   **Non-paralyzable Model:** If an event occurs during the dead time $\\tau$, it is simply ignored, and the system becomes ready again after the original dead time period expires. True rate $n = \frac{m}{1 - m\\tau}$, where $m$ is the measured rate. Maximum measurable rate is $1/\\tau$.
    *   **Paralyzable Model:** If an event occurs during the dead time $\\tau$, it is ignored BUT it extends the dead time by another period $\\tau$ from the time of *that* event. True rate $n = m e^{n\\tau}$ (implicit equation) or $m = n e^{-n\\tau}$. The measured rate $m$ reaches a maximum ($1/(e\\tau)$) and then decreases as $n$ increases further ("paralysis").
    *   **Measurement (Two-Source Method):** Measure rate of source 1 ($m_1$), source 2 ($m_2$), and sources 1+2 together ($m_{12}$). Calculate approximate dead time $\\tau$ (formula depends on model, simpler for non-paralyzable: $\\tau \\approx \\frac{m_1 + m_2 - m_{12}}{m_{12}^2 - m_1^2 - m_2^2}$ or $\\tau \\approx \\frac{m_1 + m_2 - m_{12}}{2 m_1 m_2}$ if $m_1 \\approx m_2$).
- **Coincidence/Anti-coincidence:**
    *   **Coincidence:** Requires two or more events to be detected within a specific short time window ($\\Delta t$). Used in PET (detecting two 511 keV photons from annihilation), complex decay scheme analysis.
    *   **Anti-coincidence:** Rejects events that occur simultaneously (within $\\Delta t$) in two different detectors. Used for background reduction (e.g., surrounding a primary detector with a guard detector to veto cosmic ray events).
- **Signal-to-Noise Ratio (SNR):** Ratio of the desired signal magnitude to the magnitude of background noise. Optimization involves maximizing signal collection, minimizing electronic noise (cooling detectors, proper grounding/shielding, optimal pulse shaping), and potentially using filtering or discrimination techniques.
- **Measurement Uncertainty (GUM Framework):**
    *   **Type A Uncertainty:** Evaluated by statistical methods (e.g., standard deviation of the mean of repeated measurements). $u_A = s / \\sqrt{n}$, where $s$ is sample standard deviation, $n$ is number of measurements.
    *   **Type B Uncertainty:** Evaluated by other means (non-statistical), based on scientific judgment, experience, calibration certificates, manufacturer specifications, handbooks. Expressed as an equivalent standard deviation.
    *   **Combined Standard Uncertainty ($u_c$):** Square root of the sum of variances of all independent Type A and Type B uncertainty components, propagated using the law of propagation of uncertainty. $u_c(y) = \\sqrt{\\sum_i (\\frac{\\partial f}{\\partial x_i})^2 u(x_i)^2}$.
    *   **Expanded Uncertainty ($U$):** Defines an interval expected to encompass a large fraction (confidence level, e.g., 95%) of the distribution of values attributable to the measurand. $U = k \\cdot u_c(y)$, where $k$ is the **coverage factor** (typically $k=2$ for ~95% confidence assuming normal distribution).
    *   **Reporting:** Result should be reported as $y \\pm U$, with the coverage factor $k$ and confidence level stated.

**2.6.1 Counting Statistics**

Radiation events occur randomly. Understanding the statistics is crucial for interpreting measurements and assessing their reliability.

*   **Poisson Distribution:** Describes the probability $P(k; \\mu)$ of observing $k$ events in a given interval when the true average number of events in that interval is $\\mu$. Assumes events are independent and occur at a constant average rate.
    $P(k; \\mu) = \frac{\\mu^k e^{-\\mu}}{k!}$
    *   Mean: $E[k] = \\mu$
    *   Variance: $Var(k) = \\sigma^2 = \\mu$
*   **Estimating Mean and Standard Deviation:** From a single measurement of $N$ counts, the best estimate of the true mean $\\mu$ is $N$. The standard deviation $\\sigma$ is estimated as $\\sqrt{N}$.
    *   Example: If 100 counts are measured, $\\mu \\approx 100$, $\\sigma \\approx \\sqrt{100} = 10$. The result is often stated as $100 \\pm 10$ (representing approx. 68% confidence interval).
*   **Gaussian Approximation:** For $N > 20$, the Poisson distribution is well approximated by a Gaussian distribution with mean $N$ and standard deviation $\\sqrt{N}$. This simplifies calculating confidence intervals:
    *   $N \\pm 1 \\sigma$ (i.e., $N \\pm \\sqrt{N}$): ~68.3% confidence interval
    *   $N \\pm 1.96 \\sigma$ (i.e., $N \\pm 1.96 \\sqrt{N}$): 95% confidence interval (often approximated as $N \\pm 2\\sqrt{N}$)
    *   $N \\pm 3 \\sigma$ (i.e., $N \\pm 3 \\sqrt{N}$): ~99.7% confidence interval
*   **Count Rates:** If $N$ counts are measured in time $t$, the count rate is $R = N/t$. The standard deviation of the count rate is $\\sigma_R = \\sigma_N / t = \\sqrt{N} / t$. Substituting $N = Rt$, we get $\\sigma_R = \\sqrt{Rt} / t = \\sqrt{R/t}$.
*   **Relative Uncertainty (Precision):** The fractional standard deviation is $\\epsilon = \\sigma_N / N = \\sqrt{N} / N = 1 / \\sqrt{N}$. To achieve a desired precision (e.g., 1% or $\\epsilon = 0.01$), the required number of counts is $N = (1/\\epsilon)^2$. For 1% precision, $N = (1/0.01)^2 = 10,000$ counts.
*   **Background Subtraction:** If measuring a source count $N_S$ in time $t_S$ and background count $N_B$ in time $t_B$, the net count is $N_{net} = N_S - N_B \\frac{t_S}{t_B}$. The net rate is $R_{net} = R_S - R_B = N_S/t_S - N_B/t_B$. The variance of the net rate is $Var(R_{net}) = Var(R_S) + Var(R_B) = \\frac{N_S}{t_S^2} + \\frac{N_B}{t_B^2} = \\frac{R_S}{t_S} + \\frac{R_B}{t_B}$. The standard deviation is $\\sigma_{R_{net}} = \\sqrt{\\frac{R_S}{t_S} + \\frac{R_B}{t_B}}$. Optimal allocation of total time $T = t_S + t_B$ to minimize $\\sigma_{R_{net}}$ occurs when $\\frac{t_S}{t_B} = \\sqrt{\\frac{R_S}{R_B}}$.

**2.6.2 Uncertainty Propagation**

How uncertainties in measured quantities affect the uncertainty of a calculated result.

*   **Basic Formulas (Uncorrelated Variables):**
    *   $y = x_1 + x_2$: $u(y)^2 = u(x_1)^2 + u(x_2)^2$
    *   $y = x_1 - x_2$: $u(y)^2 = u(x_1)^2 + u(x_2)^2$
    *   $y = c \cdot x$: $u(y) = |c| \cdot u(x)$
    *   $y = x_1 \cdot x_2$: $(\\frac{u(y)}{y})^2 = (\\frac{u(x_1)}{x_1})^2 + (\\frac{u(x_2)}{x_2})^2$
    *   $y = x_1 / x_2$: $(\\frac{u(y)}{y})^2 = (\\frac{u(x_1)}{x_1})^2 + (\\frac{u(x_2)}{x_2})^2$
    *   $y = x^p$: $\\frac{u(y)}{y} = |p| \\frac{u(x)}{x}$
    *   $y = \\ln(x)$: $u(y) = \\frac{u(x)}{x}$
    *   $y = e^x$: $\\frac{u(y)}{y} = u(x)$
*   **Example:** Calculating net rate $R_{net} = R_S - R_B$. Measured $N_S=1100$ in $t_S=100$s, $N_B=400$ in $t_B=200$s.
    *   $R_S = 1100/100 = 11.0$ cps. $u(N_S) = \\sqrt{1100} \\approx 33.2$. $u(R_S) = u(N_S)/t_S = 33.2/100 = 0.332$ cps.
    *   $R_B = 400/200 = 2.0$ cps. $u(N_B) = \\sqrt{400} = 20.0$. $u(R_B) = u(N_B)/t_B = 20.0/200 = 0.100$ cps.
    *   $R_{net} = 11.0 - 2.0 = 9.0$ cps.
    *   $u(R_{net})^2 = u(R_S)^2 + u(R_B)^2 = (0.332)^2 + (0.100)^2 = 0.110 + 0.010 = 0.120$.
    *   $u(R_{net}) = \\sqrt{0.120} \\approx 0.346$ cps.
    *   Result: $R_{net} = 9.0 \\pm 0.35$ cps (standard uncertainty).

**2.6.3 Pulse Processing Electronics**

Standard NIM (Nuclear Instrument Module) or CAMAC components often used.

*   **Signal Chain:** Detector → Preamplifier → Amplifier → (Discriminator/SCA/Timing) → MCA/Counter/Rate Meter.
*   **Preamplifier:** Matches detector impedance, provides initial gain, minimizes noise pickup. Charge-sensitive preferred for good energy resolution as output is proportional to collected charge, independent of detector capacitance.
*   **Amplifier:** Provides gain, shapes pulse for optimal SNR and timing. Common shapes: Gaussian, semi-Gaussian (CR-RCⁿ). Shaping time constant ($\\tau_{shape}$) is a trade-off: shorter $\\tau_{shape}$ allows higher count rates but degrades energy resolution (more noise); longer $\\tau_{shape}$ improves resolution but increases pile-up and dead time.
*   **Pulse Pile-up:** Overlap of pulses at high count rates, leading to distorted amplitude and timing information. Minimized by using faster shaping times and pile-up rejection circuits.
*   **Discriminators/SCA:** Select pulses based on amplitude. Essential for rejecting noise (LLD), selecting specific energy peaks (SCA), or defining energy ranges.
*   **MCA:** Core component for spectroscopy. ADC converts pulse height to digital number. Memory accumulates counts in channels corresponding to digital numbers, building the spectrum (Counts vs. Channel Number/Energy).

[ILLUSTRATION: Block diagram of a typical nuclear pulse processing chain showing Detector, Preamp, Amp, SCA, and MCA/Counter.]

**2.6.4 Dead Time**

Crucial correction at moderate to high count rates.

*   **Origin:** Finite time required for detector recovery (e.g., gas quenching in GM tube, charge collection in semiconductor) or electronic processing (pulse shaping, ADC conversion).
*   **Models:**
    *   **Non-paralyzable (Extending):** System is insensitive for a fixed time $\\tau$ after *each recorded* event. Correction: $n = m / (1 - m\\tau)$.
    *   **Paralyzable (Non-extending):** System is insensitive for a fixed time $\\tau$ after *each event*, regardless of whether it was recorded. Correction: $m = n e^{-n\\tau}$.
*   **Determining Model:** Often depends on the limiting component (detector or electronics). Some systems are complex mixtures.
*   **Correction Importance:** Failure to correct for dead time leads to underestimation of true activity or flux. The fractional loss is $ (n-m)/n $. For non-paralyzable, loss = $m\\tau$. For paralyzable, loss = $1 - e^{-n\\tau}$. At low rates ($m\\tau \\ll 1$), both models give $n \\approx m(1 + m\\tau)$.
*   **Two-Source Method Example (Non-paralyzable):**
    *   Measure $m_1$, $m_2$, $m_{12}$. Also measure background $m_b$.
    *   Corrected rates: $m'_1 = m_1 - m_b$, $m'_2 = m_2 - m_b$, $m'_{12} = m_{12} - m_b$.
    *   Calculate $\\tau \\approx \\frac{m'_1 + m'_2 - m'_{12}}{2 m'_1 m'_2}$ (approximate formula valid if background is low and sources are similar).
    *   Once $\\tau$ is known, correct any measured rate $m$ using $n = m / (1 - m\\tau)$.

**2.6.5 Coincidence and Anti-coincidence Counting**

Techniques using timing relationships between multiple detectors.

*   **Coincidence Circuit:** Produces an output pulse only if input pulses from two or more detectors arrive within a specified resolving time ($\\tau_R$).
    *   **Applications:** PET (detecting simultaneous 511 keV photons), measuring activity of sources with complex decay schemes (e.g., gamma-gamma coincidence), reducing background from uncorrelated events.
    *   **True vs. Random Coincidences:** True coincidences originate from the same decay event. Random (accidental) coincidences occur when unrelated events from different decays happen to fall within $\\tau_R$. Random rate $R_{random} = 2 \\tau_R R_1 R_2$, where $R_1, R_2$ are singles rates in each detector.
*   **Anti-coincidence Circuit:** Produces an output pulse from one detector only if there is *no* simultaneous pulse from a second (guard) detector.
    *   **Applications:** Background reduction in low-level counting. A primary detector is surrounded by a guard detector (e.g., plastic scintillator). Cosmic rays passing through both are vetoed by the anti-coincidence logic, while events occurring only in the primary detector (e.g., sample decay) are counted.

**2.6.6 Signal-to-Noise Ratio (SNR)**

Quality metric for measurements, especially important in imaging and low-level counting.

*   **Definition:** SNR = (Magnitude of Signal) / (Magnitude of Noise).
*   **Sources of Noise:** Statistical fluctuations (Poisson noise), electronic noise (thermal, shot noise in detectors/electronics), background radiation, interference.
*   **Optimization:**
    *   Increase Signal: Higher detector efficiency, larger detector, longer measurement time (improves statistical noise).
    *   Reduce Noise: Shielding (background), cooling detectors/preamps (electronic noise), proper grounding, optimal pulse shaping (electronic noise filtering), energy discrimination (reject background/scatter).

**2.6.7 Measurement Uncertainty (GUM)**

Standardized framework for evaluating and expressing uncertainty.

*   **Measurand:** The quantity intended to be measured.
*   **Uncertainty:** Parameter characterizing the dispersion of values reasonably attributable to the measurand.
*   **Type A:** Based on statistical analysis of repeated observations. Quantified by standard deviation or standard deviation of the mean.
*   **Type B:** Based on other information (calibration reports, specs, prior knowledge, judgment). Converted to an equivalent standard deviation (e.g., for a rectangular distribution of half-width $a$, $u = a/\\sqrt{3}$; for a manufacturer tolerance $\\pm t$ assumed uniform, $u = t/\\sqrt{3}$; if tolerance is 95% confidence normal, $u = t/2$).
*   **Combined Standard Uncertainty ($u_c$):** Represents the estimated standard deviation of the result, considering all identified sources of uncertainty. Calculated using the law of propagation of uncertainty, summing Type A and Type B components in quadrature (assuming independence).
*   **Expanded Uncertainty ($U$):** Provides a confidence interval. $U = k \\cdot u_c$. The coverage factor $k$ is chosen based on the desired level of confidence (e.g., $k=2$ for approx. 95% confidence if the combined uncertainty distribution is approximately normal).
*   **Budget:** A table listing all sources of uncertainty, their estimated standard uncertainties ($u_i$), sensitivity coefficients ($\\partial f / \\partial x_i$), and contribution to the combined variance ($(\\partial f / \\partial x_i)^2 u(x_i)^2$). Helps identify dominant sources.

**Assessment Questions (ABR Style):**

1.  (Statistics) If 400 counts are detected in a measurement, the estimated standard deviation ($\\sigma$) associated with this number of counts is:
    A. 4
    B. 10
    C. 20
    D. 40
    E. 400
    *(Answer: C. $\\sigma = \\sqrt{N} = \\sqrt{400} = 20$)*

2.  (Statistics) To reduce the statistical uncertainty (relative standard deviation) in a count rate measurement by a factor of 3, the counting time must be increased by a factor of:
    A. $\\sqrt{3}$
    B. 3
    C. 6
    D. 9
    E. 27
    *(Answer: D. Relative uncertainty $\\propto 1/\\sqrt{N} \\propto 1/\\sqrt{Rt}$. To reduce by 3, need $1/\\sqrt{t}$ to reduce by 3, so $t$ must increase by $3^2=9$.)*

3.  (Electronics) The primary function of a shaping amplifier in a nuclear pulse counting system is to:
    A. Convert charge signal to voltage signal.
    B. Provide initial signal gain near the detector.
    C. Digitize the pulse height.
    D. Optimize signal-to-noise ratio and prevent pulse pile-up.
    E. Select pulses within a specific energy window.
    *(Answer: D)*

4.  (Dead Time) A non-paralyzable counting system has a dead time of 5 μs. If the measured count rate is 40,000 cps, what is the approximate true count rate?
    A. 33,333 cps
    B. 40,000 cps
    C. 48,000 cps
    D. 50,000 cps
    E. 60,000 cps
    *(Answer: D. $m = 40,000$ cps, $\\tau = 5 \\times 10^{-6}$ s. $m\\tau = 40000 \\times 5 \\times 10^{-6} = 0.2$. $n = m / (1 - m\\tau) = 40000 / (1 - 0.2) = 40000 / 0.8 = 50,000$ cps.)*

5.  (Technique) Anti-coincidence counting is commonly used in low-level radiation measurements to:
    A. Correct for detector dead time.
    B. Measure the energy spectrum of the source.
    C. Reduce background counts from external penetrating radiation (e.g., cosmic rays).
    D. Determine the absolute activity of a source with complex decay.
    E. Improve the signal-to-noise ratio by pulse shaping.
    *(Answer: C)*

6.  (Uncertainty) According to the GUM framework, uncertainties derived from calibration certificates or manufacturer specifications are classified as:
    A. Type A uncertainties.
    B. Type B uncertainties.
    C. Random uncertainties.
    D. Statistical uncertainties.
    E. Correlated uncertainties.
    *(Answer: B)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection covers essential principles of radiation measurement statistics, electronics, dead time, coincidence techniques, and uncertainty analysis, directly aligning with CAMPEP/ABR Part 1 requirements (Section 2: Radiation Instrumentation and Measurement). The detailed treatment of these topics, including uncertainty propagation and GUM framework, provides the necessary foundation for quantitative analysis in medical physics at a graduate level.

---


#### Subsection 2.7: Quality Control and Quality Assurance (QC/QA)

**Overview:**
Ensuring the accuracy, reliability, and safety of radiation measurements is paramount in medical physics. This requires a robust program encompassing both Quality Control (QC) – the routine operational procedures to maintain equipment performance – and Quality Assurance (QA) – the overall systematic actions necessary to provide adequate confidence that a facility, system, or component will perform satisfactorily and safely. This subsection details the principles of instrument calibration, constancy checks, performance characterization, record keeping, and regulatory considerations essential for maintaining high standards in radiation instrumentation.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Define and differentiate between Quality Control (QC) and Quality Assurance (QA) in the context of radiation instrumentation.
- Explain the concept of calibration traceability to national/international standards (e.g., NIST, BIPM).
- Describe different types of calibration factors (e.g., absorbed dose-to-water $N_{D,w}$, air kerma $N_K$, exposure $N_X$) and their application.
- Outline procedures for cross-calibrating field instruments against reference instruments.
- Explain the purpose and methodology of routine constancy checks for various detectors (e.g., ion chambers, survey meters, well chambers).
- Describe key performance parameters for radiation detectors and the methods used to evaluate them (e.g., linearity, energy dependence, directional dependence).
- Explain the importance and methods for applying correction factors for influence quantities, including temperature/pressure ($P_{TP}$), ion recombination ($P_{ion}$), and polarity effects ($P_{pol}$) for ionization chambers.
- Detail the requirements for comprehensive record keeping for instrument QC/QA and calibration.
- Summarize relevant regulatory and accreditation requirements (e.g., NRC, Agreement States, TJC, ACR) pertaining to instrument quality assurance.
- Describe specific QC procedures for common medical physics instruments, including ionization chambers/electrometers, survey meters, TLD/OSLD systems, and radionuclide dose calibrators (well chambers).

**Estimated Completion Time:** 300-350 minutes (Increased detail)

**Key Points for Understanding:**
- **QA vs. QC:**
    *   **QA:** The overall management system designed to ensure quality. Includes policies, procedures, training, documentation, and QC activities.
    *   **QC:** The operational techniques and activities used to fulfill requirements for quality. Focuses on testing and monitoring equipment performance.
- **Calibration Traceability:** Measurements must be linked to recognized standards through an unbroken chain of comparisons, all having stated uncertainties. In the US, this typically means traceability to the National Institute of Standards and Technology (NIST). Accredited Dosimetry Calibration Laboratories (ADCLs) provide calibrations traceable to NIST.
- **Calibration Factors:** Relate the instrument reading (e.g., charge, current, counts) to a dosimetric quantity.
    *   **Exposure Calibration Factor ($N_X$):** Relates reading to exposure (C/kg or R). Used for older protocols or specific applications.
    *   **Air Kerma Calibration Factor ($N_K$):** Relates reading to air kerma (Gy). Common for diagnostic x-ray energies and gamma sources like $^{60}$Co.
    *   **Absorbed Dose-to-Water Calibration Factor ($N_{D,w}$):** Relates reading (corrected for influence quantities) directly to absorbed dose-to-water under reference conditions (Gy). Preferred factor for modern radiotherapy dosimetry protocols (e.g., AAPM TG-51).
    *   $D_{w}^{Q} = M_{corr}^{Q} \cdot N_{D,w}^{60Co} \cdot k_Q$, where $M_{corr}^{Q}$ is the fully corrected reading in beam quality $Q$, $N_{D,w}^{60Co}$ is the calibration factor at $^{60}$Co, and $k_Q$ is the beam quality conversion factor.
- **Cross-Calibration:** Transferring calibration from a reference instrument (calibrated by an ADCL) to a field instrument. Typically involves simultaneous or sequential measurements under identical, stable conditions.
- **Constancy Checks:** Simple, routine tests to verify instrument stability between full calibrations. Often involves measuring a long-lived radioactive check source under reproducible geometry. Results should be within established tolerance limits (e.g., ±5% or ±10% depending on instrument and regulation).
- **Performance Characterization & Correction Factors (Ion Chambers):**
    *   **Temperature and Pressure ($P_{TP}$):** Corrects for air density changes in open-to-atmosphere ion chambers. $P_{TP} = \frac{(273.15 + T)}{(273.15 + T_{ref})} \times \frac{P_{ref}}{P}$, where $T$ and $P$ are current temperature (°C) and pressure (e.g., kPa, mmHg), and $T_{ref}, P_{ref}$ are reference conditions (often 22°C, 101.325 kPa or 760 mmHg).
    *   **Ion Recombination ($P_{ion}$):** Corrects for incomplete charge collection due to recombination of ions before they reach the electrodes. Increases with dose rate and chamber volume, decreases with higher collecting voltage. Measured using the **two-voltage technique**: $P_{ion} = \frac{(V_H/V_L)^2 - 1}{(V_H/V_L)^2 - (M_H/M_L)}$ for continuous beams (where $V_H, V_L$ are high and low voltages, $M_H, M_L$ are corresponding readings), or $P_{ion} = \frac{1 - (M_H/M_L)}{ (V_H/V_L) - (M_H/M_L)}$ for pulsed beams (Jaffé plot analysis is more rigorous). $P_{ion}$ is typically > 1 (correction factor multiplies reading).
    *   **Polarity Effect ($P_{pol}$):** Corrects for differences in reading when the collecting voltage polarity is reversed. Caused by charge deposition by secondary electrons in chamber components. $P_{pol} = \frac{|M_{+}| + |M_{-}|}{2M}$, where $M_{+}, M_{-}$ are readings at positive and negative polarity, and $M$ is the reading at the polarity used routinely. Correction factor is applied to the reading taken at the routine polarity. Ideally $P_{pol}$ is close to 1.000.
    *   **Electrometer Correction ($P_{elec}$):** Corrects for inaccuracy of the electrometer reading (if calibrated separately from chamber).
    *   **Leakage:** Current measured with no radiation present. Should be negligible (<0.1% of signal). Tested by measuring charge collected over time with voltage applied but no beam.
    *   **Linearity:** Response should be proportional to dose or dose rate over the intended operating range.
    *   **Energy Dependence:** Variation in response per unit dose/kerma as a function of radiation energy/quality.
    *   **Directional Dependence:** Variation in response with angle of radiation incidence.
- **Record Keeping:** Essential for demonstrating compliance, tracking performance trends, and troubleshooting. Records should include instrument identification, date of test/calibration, procedure used, results, acceptance criteria, environmental conditions, person performing test, and any corrective actions.
- **Regulatory/Accreditation:** Requirements vary but often mandate annual calibration, routine constancy checks (e.g., daily, quarterly), specific QC tests, action levels, and documentation (e.g., NRC 10 CFR Part 35 for dose calibrators, TJC/ACR for imaging/therapy equipment).

**2.7.1 Calibration Principles**

Calibration establishes the relationship between the instrument reading and the physical quantity being measured, traceable to a standard.

*   **Hierarchy:** National Standard (NIST) → Accredited Dosimetry Calibration Laboratory (ADCL) → Institutional Reference Instrument → Field Instruments.
*   **Reference Conditions:** Calibration is performed under specific, well-defined conditions (e.g., beam quality, field size, distance, phantom material/depth, temperature, pressure). These must be documented on the calibration certificate.
*   **Calibration Factor Application:** The calibration factor ($N_{D,w}$, $N_K$, etc.) is valid *only* under the reference conditions specified. Corrections must be applied for measurements made under different conditions.
*   **Uncertainty:** Calibration certificates must state the uncertainty associated with the calibration factor (typically expanded uncertainty, $k=2$). This uncertainty contributes to the overall uncertainty budget of measurements made with the instrument.

**2.7.2 Constancy and Performance Checks**

Routine checks ensure the instrument continues to function correctly between calibrations.

*   **Constancy:** Verifies stability using a reproducible setup, often a long-lived check source (e.g., $^{137}$Cs, $^{241}$Am). Key is reproducibility, not absolute accuracy. Results logged and trended.
    *   **Action Levels:** Pre-defined limits (e.g., ±5% deviation from baseline) triggering investigation or corrective action.
*   **Performance Checks (Examples):**
    *   **Ion Chamber/Electrometer:** Leakage test, battery check (if applicable), $P_{ion}$, $P_{pol}$ (often checked at calibration or commissioning, less frequently routinely unless indicated).
    *   **Survey Meter:** Battery check (daily/before use), source check (daily/before use), calibration (annual), specific checks for energy/directional dependence if relevant.
    *   **Dose Calibrator (Well Chamber):** Constancy (daily, using check sources like $^{137}$Cs, $^{57}$Co, $^{133}$Ba), Linearity (quarterly, using decaying source like $^{99m}$Tc or calibrated attenuators), Accuracy (annually, using NIST-traceable sources of different energies), Geometry (at installation/repair, checking response variation with sample volume/position).
    *   **TLD/OSLD Systems:** Reader stability/calibration (daily/per batch), element sensitivity normalization, background checks, annealing procedures (TLD).

**2.7.3 Correction Factors for Influence Quantities**

Ionization chamber readings are influenced by environmental and operational factors.

*   **$P_{TP}$:** Corrects reading $M_{raw}$ to reference conditions $T_{ref}, P_{ref}$. $M = M_{raw} \cdot P_{TP}$. Essential for unsealed chambers.
*   **$P_{ion}$:** Corrects for incomplete charge collection. $M = M_{raw} \cdot P_{ion}$. Always $\\ge 1$. Particularly important for high dose-per-pulse beams (linacs) and high dose rates. Measured using two-voltage technique.
*   **$P_{pol}$:** Corrects for polarity imbalance. $M = M_{raw} \cdot P_{pol}$. Applied to reading at the routine operating polarity. Usually very close to 1.000 for well-designed chambers.
*   **Fully Corrected Reading:** $M_{corr} = M_{raw} \cdot P_{TP} \cdot P_{ion} \cdot P_{pol} \cdot P_{elec}$. This $M_{corr}$ is then used with the calibration factor.

[ILLUSTRATION: Graph showing typical ion collection efficiency vs. collecting voltage, illustrating the recombination region and saturation region. Indicate where $V_H$ and $V_L$ might be chosen for the two-voltage technique.]

**2.7.4 Documentation and Regulatory Aspects**

Comprehensive documentation is a cornerstone of QA.

*   **Logbooks/Databases:** Record all QC tests, calibration data, maintenance, repairs. Should be easily accessible and retained for specified periods (often years).
*   **Procedures:** Written procedures should detail how each QC test and calibration is performed, including equipment used, frequency, acceptance criteria, and actions for failed tests.
*   **Regulatory Bodies:** NRC (federal), Agreement States (state-level regulation of radioactive materials), FDA (medical devices), EPA (environmental). Mandate specific QC requirements, frequencies, and record keeping, especially for licensed activities (e.g., nuclear medicine, brachytherapy).
*   **Accreditation Organizations:** The Joint Commission (TJC), American College of Radiology (ACR). Often have specific QA/QC standards for imaging and therapy equipment, including associated dosimetry instrumentation, as part of their accreditation programs.

**Assessment Questions (ABR Style):**

1.  (Definitions) The routine operational procedures used to monitor and maintain the performance of radiation detection equipment within predefined limits are best described as:
    A. Quality Assurance (QA)
    B. Quality Control (QC)
    C. Calibration Traceability
    D. Uncertainty Analysis
    E. Regulatory Compliance
    *(Answer: B)*

2.  (Calibration) An ionization chamber is sent to an ADCL and receives an absorbed dose-to-water calibration factor $N_{D,w}^{60Co}$. This factor directly relates the corrected chamber reading to absorbed dose-to-water under which conditions?
    A. The user's clinical beam quality $Q$.
    B. Reference conditions specified by the ADCL (typically $^{60}$Co beam).
    C. Standard temperature and pressure (0°C, 101.325 kPa).
    D. Air kerma conditions.
    E. Any conditions, provided $k_Q$ is applied.
    *(Answer: B)*

3.  (Corrections) An unsealed ionization chamber reading $M_{raw}$ is taken at 25.0°C and 740 mmHg. If the reference conditions are 22.0°C and 760 mmHg, the temperature-pressure correction factor $P_{TP}$ is calculated as:
    A. $\\frac{(273.15 + 25.0)}{(273.15 + 22.0)} \times \frac{740}{760}$
    B. $\\frac{(273.15 + 22.0)}{(273.15 + 25.0)} \times \frac{760}{740}$
    C. $\\frac{(273.15 + 25.0)}{(273.15 + 22.0)} \times \frac{760}{740}$
    D. $\\frac{(273.15 + 22.0)}{(273.15 + 25.0)} \times \frac{740}{760}$
    E. $\\frac{25.0}{22.0} \times \frac{760}{740}$
    *(Answer: C. $P_{TP} = \frac{T_{abs}}{T_{ref,abs}} \times \frac{P_{ref}}{P} = \frac{(273.15 + 25.0)}{(273.15 + 22.0)} \times \frac{760}{740}$)*

4.  (Corrections) The ion recombination correction factor, $P_{ion}$, is determined using the two-voltage technique. For a properly functioning ionization chamber used within its intended dose rate range, $P_{ion}$ is expected to be:
    A. Significantly less than 1.0
    B. Equal to 1.0
    C. Slightly greater than 1.0
    D. Significantly greater than 1.0
    E. Negative
    *(Answer: C. Recombination causes charge loss, so the reading is lower than it should be. The correction factor must multiply the reading to increase it, hence $P_{ion} > 1$. It's typically only slightly greater than 1, e.g., 1.005 to 1.03, depending on chamber, voltage, and dose rate.)*

5.  (QC Procedures) Which of the following QC tests for a radionuclide dose calibrator (well chamber) is typically performed MOST frequently?
    A. Accuracy
    B. Linearity
    C. Geometry
    D. Constancy
    E. Calibration
    *(Answer: D. Constancy checks are usually performed daily.)*

6.  (Regulations) In the United States, the calibration of instruments used for radiation measurements required by regulation (e.g., therapy dose, personnel monitoring, surveys) must generally be traceable to:
    A. The American Association of Physicists in Medicine (AAPM)
    B. The International Atomic Energy Agency (IAEA)
    C. The National Institute of Standards and Technology (NIST)
    D. The American College of Radiology (ACR)
    E. The manufacturer of the instrument
    *(Answer: C)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection directly addresses the ABR Part 1 syllabus item on "Quality control and quality assurance" within the Instrumentation section. It covers the core concepts of calibration, traceability, correction factors ($P_{TP}, P_{ion}, P_{pol}$), routine QC tests, documentation, and regulatory context at a level appropriate for graduate study and board preparation. The detailed explanation of correction factors and specific QC procedures for common instruments provides practical knowledge essential for clinical medical physicists.

---


#### Subsection 2.8: Applications in Imaging, Nuclear Medicine, Therapy and Safety

**Overview:**
This subsection synthesizes the detector principles and measurement techniques covered throughout Section 2, illustrating their practical applications across the major domains of medical physics. Understanding how specific detectors are selected and optimized for different clinical applications is essential for medical physicists. The selection criteria often involve trade-offs between sensitivity, energy response, spatial resolution, temporal resolution, and practical considerations like cost, reliability, and ease of use. This section bridges the gap between theoretical knowledge of radiation detection and the practical implementation of these technologies in clinical settings.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Identify the types of radiation detectors used in various diagnostic imaging modalities and explain their operating principles.
- Describe the detector systems employed in nuclear medicine imaging and non-imaging applications, including their specific requirements and limitations.
- Explain the detector systems used for absolute and relative dosimetry in radiation therapy.
- Discuss the selection criteria for *in vivo* dosimetry systems in different radiotherapy applications.
- Identify appropriate detectors for radiation safety applications, including area monitoring, personnel dosimetry, and contamination detection.
- Analyze the relationship between detector characteristics (energy response, sensitivity, spatial resolution, etc.) and their suitability for specific clinical applications.
- Explain how the fundamental principles of radiation detection are implemented in specialized clinical devices.
- Evaluate the advantages and limitations of different detector technologies for specific clinical tasks.

**Estimated Completion Time:** 320-380 minutes (Increased detail)

**Key Points for Understanding:**
- **Application-Specific Requirements:** Different clinical applications impose unique requirements on detector systems:
    *   **Diagnostic Imaging:** High spatial resolution, wide dynamic range, rapid response, energy discrimination (for dual-energy applications).
    *   **Nuclear Medicine:** High sensitivity for gamma/annihilation photons, good energy resolution (for scatter rejection), position sensitivity, coincidence detection capability (PET).
    *   **Radiation Therapy:** Accuracy, precision, reproducibility, minimal energy/directional dependence, tissue equivalence, linearity over wide dose ranges.
    *   **Radiation Safety:** Sensitivity appropriate to regulatory limits, energy response matched to quantities of interest (e.g., $H_p(10)$ for personal dosimetry), ruggedness, reliability.
- **Technology Evolution:** Many applications have seen transitions in detector technology (e.g., film → CR → DR in radiography; NaI(Tl) → BGO → LSO/LYSO in PET; TLD → OSLD in personnel monitoring). Understanding both current and historical technologies provides context for ongoing developments.
- **Detector Limitations:** All detectors have inherent limitations that must be understood for proper clinical use (e.g., energy dependence of solid-state detectors in therapy dosimetry, dead-time limitations in high-count-rate nuclear medicine applications).
- **Calibration and Correction Factors:** Application-specific calibration procedures and correction factors are essential for accurate measurements (e.g., $k_Q$ factors for therapy chambers, energy correction factors for diagnostic dosimetry).

**2.8.1 Applications in Diagnostic Imaging**

Diagnostic imaging modalities use various detector technologies to convert x-ray photons into measurable signals.

*   **Radiography:**
    *   **Film-Screen Systems (Historical):** Silver halide emulsion film coupled with phosphor intensifying screens. Advantages: high spatial resolution, simplicity. Disadvantages: limited dynamic range, non-linear response, chemical processing, fixed exposure latitude.
    *   **Computed Radiography (CR):** Photostimulable phosphor plates (typically BaFBr:Eu²⁺) that store latent image as trapped electrons. Laser scanning causes luminescence proportional to absorbed x-ray energy. Advantages: reusable plates, wider dynamic range than film, digital workflow. Disadvantages: lower detective quantum efficiency (DQE) than DR, two-step process.
    *   **Digital Radiography (DR):** 
        *   **Indirect Conversion:** X-rays → scintillator (e.g., CsI:Tl, Gd₂O₂S:Tb) → light → photodiode array/TFT readout. Higher DQE than CR, immediate image availability.
        *   **Direct Conversion:** X-rays → semiconductor (e.g., amorphous selenium, a-Se) → electron-hole pairs → direct electronic signal. Better spatial resolution than indirect systems due to minimal lateral spread.
    *   **Detector Performance Metrics:** Detective Quantum Efficiency (DQE), Modulation Transfer Function (MTF), Noise Power Spectrum (NPS).

*   **Fluoroscopy:**
    *   **Image Intensifiers (Older Technology):** Vacuum tube devices with input phosphor (typically CsI:Na), photocathode, electron optics, and output phosphor. Brightness gain of 5,000-20,000. Limitations include bulkiness, geometric distortion, veiling glare.
    *   **Flat-Panel Detectors:** Similar technology to DR systems but optimized for real-time imaging (higher frame rates, lower dose per frame). Typically use CsI:Tl scintillators for higher absorption efficiency and structured crystals to reduce lateral light spread.

*   **Computed Tomography (CT):**
    *   **Early Detectors (Historical):** Xenon gas ionization chambers. Limited efficiency at higher energies.
    *   **Modern Detectors:** Solid-state scintillation detectors (e.g., cadmium tungstate, rare-earth ceramics like gadolinium oxysulfide, or structured CsI:Tl) coupled to photodiodes. Arranged in arrays of 800-1000+ elements per row with 16-320 rows.
    *   **Photon-Counting Detectors (Emerging):** Direct conversion semiconductors (e.g., CdZnTe, CdTe) that count individual photons and measure their energy. Advantages include improved contrast resolution, reduced electronic noise, spectral information, and potentially lower dose.

*   **Mammography:**
    *   **Specialized Requirements:** High spatial resolution (50-100 μm), high contrast sensitivity, efficient detection of low-energy x-rays (26-32 kVp).
    *   **Film-Screen (Historical):** Single-emulsion film with single intensifying screen to maximize spatial resolution.
    *   **Digital Mammography:** 
        *   **Indirect Systems:** Structured CsI:Tl scintillators with photodiode arrays.
        *   **Direct Systems:** a-Se direct conversion detectors, offering excellent spatial resolution due to minimal charge spread and good absorption efficiency at mammographic energies.
    *   **Digital Breast Tomosynthesis:** Similar detectors to digital mammography but optimized for rapid acquisition of multiple low-dose projections.

**2.8.2 Applications in Nuclear Medicine**

Nuclear medicine uses detectors to measure gamma rays emitted from radionuclides administered to patients.

*   **Gamma Cameras (Anger Cameras):**
    *   **Detection System:** Large NaI(Tl) crystal (typically 3/8" to 1" thick, 40-50 cm diameter) coupled to an array of photomultiplier tubes (PMTs).
    *   **Collimation:** Lead collimators (parallel-hole, diverging, converging, pinhole) to define the projection geometry.
    *   **Position Determination:** Anger logic - weighted averaging of PMT signals to determine interaction position.
    *   **Energy Discrimination:** Pulse height analysis to select primary photopeak and reject scatter (e.g., 20% window centered on 140 keV for $^{99m}$Tc).
    *   **Performance Characteristics:** Spatial resolution (intrinsic: ~3-4 mm, system: ~7-10 mm), energy resolution (~9-10% at 140 keV), sensitivity (~100-300 cps/MBq), count rate capability (limited by dead time, typically linear up to ~50-100 kcps).

*   **SPECT (Single Photon Emission Computed Tomography):**
    *   **Detector Configuration:** One to three gamma camera heads rotating around the patient.
    *   **Reconstruction:** Filtered back projection or iterative methods (e.g., OSEM, MLEM).
    *   **Corrections:** Attenuation correction, scatter correction, resolution recovery.
    *   **Hybrid Systems:** SPECT/CT combines functional (SPECT) and anatomical (CT) information.

*   **PET (Positron Emission Tomography):**
    *   **Detection Principle:** Coincidence detection of 511 keV annihilation photons from positron-electron annihilation.
    *   **Detector Evolution:**
        *   **Traditional Block Detectors:** Segmented scintillation crystals (BGO, LSO, LYSO) coupled to PMTs.
        *   **Modern Systems:** Smaller crystal elements (2-4 mm) for better spatial resolution, time-of-flight capability (350-500 ps coincidence timing resolution) for improved signal-to-noise.
        *   **Photodetector Evolution:** PMTs → Avalanche Photodiodes (APDs) → Silicon Photomultipliers (SiPMs) enabling better timing resolution and MR compatibility.
    *   **Performance Metrics:** Spatial resolution (4-5 mm), sensitivity (5-10 cps/kBq), noise equivalent count rate (NECR), scatter fraction.
    *   **Hybrid Systems:** PET/CT and PET/MRI for combined functional/anatomical imaging.

*   **Non-Imaging Applications:**
    *   **Dose Calibrators:** Well-type ionization chambers for measuring radiopharmaceutical activity. Typically pressurized with argon gas. Calibration factors for different radionuclides account for varying detection efficiencies with energy.
    *   **Thyroid Uptake Probes:** NaI(Tl) scintillation detectors with collimation for measuring thyroid uptake of $^{131}$I or $^{123}$I.
    *   **Intraoperative Probes:** Compact gamma probes (CsI(Tl), NaI(Tl), or CdTe) for sentinel node localization or tumor detection during surgery.
    *   **Well Counters:** NaI(Tl) well-type scintillation detectors for high-sensitivity counting of small samples (e.g., blood, urine).

**2.8.3 Applications in Radiation Therapy**

Radiation therapy requires precise measurement of absorbed dose for treatment planning, delivery verification, and quality assurance.

*   **Reference Dosimetry (Absolute):**
    *   **Ionization Chambers:** Primary standard for absorbed dose determination following protocols like AAPM TG-51 or IAEA TRS-398.
        *   **Farmer-type Chambers:** Cylindrical chambers with 0.6 cc sensitive volume, the gold standard for photon beam calibration.
        *   **Specialized Chambers:** Smaller volumes (0.01-0.3 cc) for small fields, plane-parallel chambers for electron beams.
        *   **Calibration Process:** Chambers calibrated at ADCLs with traceability to primary standards, used with appropriate beam quality conversion factors ($k_Q$).
    *   **Calorimeters:** Primary standard at national laboratories (e.g., NIST), based on temperature rise in water or graphite.

*   **Relative Dosimetry:**
    *   **Scanning Water Phantoms:** Automated systems using small-volume ionization chambers or diodes to measure beam profiles, percentage depth dose (PDD) curves, and output factors.
    *   **Arrays:** 2D or 3D arrays of ionization chambers or diodes for field verification, IMRT QA.
    *   **Film:**
        *   **Radiochromic Film (e.g., EBT3):** Self-developing, tissue-equivalent, high spatial resolution. Used for IMRT QA, small field dosimetry, brachytherapy.
        *   **Advantages:** High spatial resolution (~0.1 mm), minimal energy dependence, near tissue-equivalence, self-developing.
        *   **Limitations:** Requires careful handling, scanner calibration, and analysis protocols.
    *   **TLD/OSLD:** Used for point measurements, mail-in audits (e.g., IROC Houston), *in vivo* dosimetry.
    *   **Plastic Scintillation Detectors (PSDs):** Water-equivalent, minimal energy dependence, real-time readout. Emerging technology for small field dosimetry.

*   ***In Vivo* Dosimetry:**
    *   **Diodes:** p-n junction semiconductor detectors. High sensitivity, small size, immediate readout. Limitations include temperature dependence, directional dependence, and need for frequent calibration.
    *   **MOSFETs:** Measure threshold voltage shift due to radiation-induced charge trapping. Very small size, permanent record of accumulated dose. Limited lifetime (sensitivity degrades with accumulated dose).
    *   **OSLDs (e.g., Al₂O₃:C):** Used for entrance/exit dose measurements. Reusable with appropriate annealing.
    *   **Electronic Portal Imaging Devices (EPIDs):** Amorphous silicon flat panels used for transit dosimetry (measuring radiation after it passes through the patient).

*   **Brachytherapy:**
    *   **Well Chambers:** For source strength verification of HDR sources (e.g., $^{192}$Ir) and low energy sources (e.g., $^{125}$I, $^{103}$Pd seeds).
    *   **TLD/OSLD/Film:** For source localization and dose distribution verification.

*   **Machine QA:**
    *   **Daily QA:** Constancy checks using ionization chambers, diodes, or specialized QA devices.
    *   **Monthly/Annual QA:** Comprehensive testing of output, energy, beam profiles, MLC performance using various detectors (ion chambers, diodes, film, arrays).
    *   **Specialized QA Devices:** Combination devices with multiple detectors for efficient routine QA.

**2.8.4 Applications in Radiation Safety**

Radiation safety applications require detectors suitable for environmental monitoring, personnel dosimetry, and contamination control.

*   **Area Monitoring:**
    *   **Survey Meters:**
        *   **Ionization Chambers:** For measuring exposure or dose rates in air. Energy-independent response, wide range of sensitivities available (μR/h to R/h).
        *   **GM Counters:** For detecting low levels of radiation. High sensitivity but energy-dependent response, saturation at high rates.
        *   **Proportional Counters:** For alpha/beta contamination surveys.
        *   **Neutron Survey Meters:** Moderator-based systems with BF₃ or ³He proportional counters or specialized scintillators.
    *   **Area Monitors:** Fixed installation monitors using GM tubes or ionization chambers for continuous monitoring of radiation levels in controlled areas.
    *   **Environmental Monitors:** TLD/OSLD arrays for long-term monitoring around facilities.

*   **Personnel Dosimetry:**
    *   **Film Badges (Historical):** Limited dynamic range, energy dependence requiring filters for energy compensation.
    *   **TLDs:** LiF:Mg,Ti (TLD-100) or LiF:Mg,Cu,P (TLD-100H) for whole-body monitoring. Tissue-equivalent, reusable, wide dose range (10 μGy to 10 Gy).
    *   **OSLDs:** Al₂O₃:C for whole-body and extremity monitoring. Advantages include reanalysis capability, higher sensitivity than TLD-100.
    *   **Electronic Personal Dosimeters (EPDs):** Real-time monitoring using silicon diodes or small GM tubes. Advantages include immediate readout, alarm capability, and dose rate information.
    *   **Neutron Dosimetry:** Specialized TLDs with ⁶Li/⁷Li pairs, CR-39 track detectors, or bubble detectors.

*   **Contamination Monitoring:**
    *   **Surface Contamination:** GM pancake probes (for beta/gamma), ZnS(Ag) scintillation probes or proportional counters (for alpha).
    *   **Wipe Tests:** Liquid scintillation counting or gamma well counters for removable contamination.
    *   **Portal Monitors:** Large plastic scintillators or NaI(Tl) detectors for personnel/vehicle monitoring at facility exits.
    *   **Hand/Foot Monitors:** Arrays of gas-flow proportional counters or large-area plastic scintillators.

*   **Special Applications:**
    *   **Radon Monitoring:** Alpha track detectors, electret ion chambers, or continuous radon monitors using ZnS(Ag) scintillators.
    *   **Emergency Response:** Portable spectroscopic systems (NaI(Tl) or HPGe) for radionuclide identification.
    *   **Biodosimetry:** Techniques like chromosome aberration analysis or electron paramagnetic resonance (EPR) for dose reconstruction after accidental exposures.

**Assessment Questions (ABR Style):**

1.  (Diagnostic Imaging) Which of the following detector technologies offers the highest detective quantum efficiency (DQE) for digital radiography?
    A. Film-screen systems
    B. Computed radiography (photostimulable phosphor)
    C. Indirect conversion flat-panel detectors (scintillator + photodiode array)
    D. Direct conversion flat-panel detectors (a-Se)
    E. Xenon gas ionization chambers
    *(Answer: C. Indirect conversion flat-panel detectors typically have higher DQE than the other options, though D can be close in some energy ranges.)*

2.  (Nuclear Medicine) A gamma camera using a NaI(Tl) crystal has an energy resolution of 10% at 140 keV. What is the full width at half maximum (FWHM) of the photopeak?
    A. 7 keV
    B. 10 keV
    C. 14 keV
    D. 28 keV
    E. 140 keV
    *(Answer: C. FWHM = 10% of 140 keV = 14 keV)*

3.  (Radiation Therapy) Which of the following detectors would be MOST appropriate for commissioning small stereotactic fields (< 2 cm × 2 cm)?
    A. Farmer-type ionization chamber (0.6 cc)
    B. Radiochromic film
    C. TLD-100 chips (3.2 mm × 3.2 mm × 0.9 mm)
    D. Parallel-plate ionization chamber (sensitive diameter 4 cm)
    E. 2D array of ionization chambers with 1 cm spacing
    *(Answer: B. Radiochromic film offers high spatial resolution needed for small field dosimetry, without significant volume averaging effects.)*

4.  (Radiation Safety) Which of the following personnel dosimeters provides real-time dose and dose rate information with alarm capability?
    A. Film badge
    B. Thermoluminescent dosimeter (TLD)
    C. Optically stimulated luminescence dosimeter (OSLD)
    D. Electronic personal dosimeter (EPD)
    E. CR-39 track detector
    *(Answer: D)*

5.  (Detector Selection) For a PET scanner, which detector characteristic is MOST important for implementing time-of-flight capability?
    A. High stopping power for 511 keV photons
    B. Good energy resolution
    C. Fast timing resolution
    D. Large crystal size
    E. Low cost
    *(Answer: C. Fast timing resolution is essential for time-of-flight PET, which requires precise measurement of the difference in arrival times of the coincident photons.)*

6.  (Clinical Application) A medical physicist needs to verify the output of a new HDR $^{192}$Ir brachytherapy source. Which detector system would be MOST appropriate for this task?
    A. Farmer-type ionization chamber in water
    B. Well-type ionization chamber
    C. TLD chips
    D. Radiochromic film
    E. Semiconductor diode
    *(Answer: B. Well-type ionization chambers are the standard for HDR source strength verification, providing reproducible geometry and traceability to standards.)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection directly addresses the ABR Part 1 syllabus item on "Applications in imaging, nuclear medicine, therapy and safety" within the Instrumentation section. It provides a comprehensive overview of how radiation detectors are applied across the major domains of medical physics, emphasizing the relationship between detector characteristics and clinical requirements. The detailed treatment of detector selection criteria and performance metrics prepares students for both practical clinical work and board examinations.

---


### Section 3: Diagnostic Medical Physics

**Overview:**
This section transitions from the fundamental physics of radiation and detection principles to their specific application in creating diagnostic medical images. Diagnostic medical physics focuses on optimizing image quality while minimizing radiation dose to the patient. It encompasses the physics of image formation, the technology of imaging equipment, quality assurance procedures, and radiation safety considerations specific to diagnostic modalities. We begin with the foundational projection imaging techniques: radiography, fluoroscopy, and mammography.

#### Subsection 3.1: Radiography, Fluoroscopy and Mammography

**Overview:**
Radiography, fluoroscopy, and mammography are cornerstone imaging modalities based on the differential attenuation of x-rays as they pass through the body. Understanding the intricate physics of x-ray production, interaction with matter, image detection, and the factors influencing image quality and patient dose is crucial for the diagnostic medical physicist. This subsection provides an in-depth exploration of these principles, emphasizing the clinical relevance and practical considerations encountered daily.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the detailed operation of an x-ray tube, including electron generation, acceleration, focusing, and target interactions (bremsstrahlung and characteristic x-ray production).
- Analyze the factors influencing the x-ray spectrum (kVp, mA, time, filtration, target material, anode angle, voltage waveform) and their impact on image contrast and patient dose.
- Explain the physical processes governing image formation: differential attenuation, beam hardening, scatter radiation (Compton, Rayleigh), and methods for scatter reduction (grids, air gap).
- Evaluate the construction, function, and clinical implications of anti-scatter grids (grid ratio, frequency, focusing, material, Bucky factor, grid cutoff).
- Analyze geometric factors affecting image quality: magnification, focal spot blur (penumbra), and distortion, and relate them to clinical positioning and technique selection.
- Define and differentiate key image quality metrics: contrast (subject contrast, radiographic contrast), noise (quantum mottle, electronic noise, structural noise), spatial resolution (MTF), and contrast-to-noise ratio (CNR).
- Explain the operation and clinical significance of Automatic Exposure Control (AEC) systems, including detector placement and density settings.
- Compare and contrast continuous and pulsed fluoroscopy modes, detailing the trade-offs between image quality, temporal resolution, and patient dose.
- Describe the components and function of image intensifiers and flat-panel detectors in fluoroscopy, including automatic brightness/dose rate control mechanisms.
- Detail the specialized requirements and technology of mammography, including target/filter combinations (Mo/Mo, Mo/Rh, Rh/Rh, W/Rh, W/Ag, W/Al), compression, magnification techniques, and detector characteristics.
- Compare screen-film mammography (SFM) with full-field digital mammography (FFDM) and digital breast tomosynthesis (DBT).
- Define and explain the clinical relevance of dosimetry quantities used in diagnostic radiology (exposure, air kerma, entrance skin dose/air kerma, dose area product - DAP, effective dose).

**Estimated Completion Time:** 400-480 minutes (Increased detail & clinical focus)

**Key Points for Understanding:**
- **X-ray Production is Inefficient:** Less than 1% of electron energy is converted to x-rays; the rest becomes heat, necessitating anode cooling mechanisms (rotating anode, heat exchangers).
- **Spectrum Control is Key:** kVp primarily controls beam energy/penetrability (contrast), while mAs (mA × time) primarily controls beam quantity/intensity (image blackening/receptor exposure). Filtration removes low-energy photons, hardening the beam, reducing patient skin dose, and slightly decreasing contrast.
- **Scatter is the Enemy of Contrast:** Scatter adds a uniform background fog, reducing image contrast. Grids are the primary tool for scatter reduction but increase patient dose (Bucky factor).
- **Geometric Unsharpness:** Finite focal spot size causes blurring (penumbra), which worsens with increased magnification and larger focal spots. $U_g = f \times (M-1)$, where $U_g$ is geometric unsharpness, $f$ is focal spot size, $M$ is magnification factor ($M = SID/SOD$).
- **Noise Limits Detectability:** Quantum mottle (statistical fluctuation in photon count) is often the dominant noise source, inversely related to the number of photons detected. $SNR \propto \sqrt{N}$.
- **AEC Standardizes Receptor Exposure:** AEC systems terminate exposure when a predefined amount of radiation reaches detectors behind/in front of the image receptor, aiming for consistent image density/brightness despite variations in patient thickness/composition.
- **Fluoroscopy Dose Management:** Pulsed fluoroscopy significantly reduces dose compared to continuous mode. Techniques like last image hold, virtual collimation, and optimized ABC/ADRC settings are crucial.
- **Mammography Optimization:** Low kVp (25-32 kVp) maximizes subject contrast for subtle soft tissue differences. Compression reduces thickness, scatter, motion blur, and dose. Specialized target/filter combinations optimize the spectrum for breast tissue.
- **Dosimetry is Indirect:** Diagnostic dose is typically estimated using quantities like Entrance Skin Air Kerma (ESAK) or DAP, rather than direct organ dose measurement.

**3.1.1 X-ray Production**

Understanding the x-ray tube is fundamental.

*   **Components & Operation:**
    *   **Cathode:** Tungsten filament heated by filament current (thermionic emission) produces electron cloud. Focusing cup (negatively biased molybdenum or nickel) shapes electron beam towards anode.
    *   **Anode:** Typically rotating tungsten target (high Z for efficient bremsstrahlung, high melting point) embedded in molybdenum/graphite base (for heat dissipation). Rotation spreads heat load over larger area. Anode angle (typically 7-17 degrees) influences effective focal spot size (line focus principle: effective size = actual size × sin(θ)).
    *   **Vacuum Envelope:** Glass or metal enclosure maintaining high vacuum to prevent electron collisions with air molecules.
    *   **Tube Housing:** Lead-lined metal housing providing radiation shielding (leakage radiation limit: < 1 mGy/hr or 100 mR/hr at 1 meter) and oil bath for cooling/insulation.
*   **Bremsstrahlung Radiation:** Primary source of x-rays. Produced when high-speed electrons decelerate near atomic nuclei of target material. Continuous energy spectrum from zero up to the peak electron energy (kVp). Intensity $\propto Z \times (kVp)^2 \times mA$.
*   **Characteristic Radiation:** Produced when incident electron ejects inner-shell electron (e.g., K-shell) from target atom, and outer-shell electron fills vacancy, emitting photon with energy equal to difference in binding energies. Discrete energy lines specific to target material (e.g., Tungsten K-shell energies ~58-69 keV). Only significant when kVp exceeds K-shell binding energy (e.g., ~70 kVp for Tungsten).
*   **X-ray Spectrum Factors:**
    *   **kVp:** Increases maximum energy, average energy, and total number of photons. Primary controller of beam quality/penetrability and subject contrast.
    *   **mAs:** Directly proportional to number of electrons hitting target, thus proportional to number of x-ray photons produced (quantity). Affects receptor exposure/image brightness.
    *   **Filtration:** Removes low-energy photons. **Inherent filtration** (tube window, oil) + **Added filtration** (Al, Cu sheets). Increases average energy (beam hardening), reduces quantity, reduces patient skin dose. Measured in mm Al equivalent. Half-Value Layer (HVL) characterizes beam quality.
    *   **Target Material (Z):** Higher Z increases bremsstrahlung efficiency and characteristic energies.
    *   **Voltage Waveform:** Generator type (single-phase, three-phase, high-frequency) affects effective kVp and output efficiency. High-frequency generators provide nearly constant potential, maximizing output and average energy for a given kVp setting.
    *   **Anode Heel Effect:** X-ray intensity is lower on anode side due to self-attenuation within target. More pronounced with smaller anode angles, larger field sizes, and shorter SIDs. Clinically used by placing thicker body part towards cathode side.

[ILLUSTRATION: Diagram of a rotating anode x-ray tube labeling cathode (filament, focusing cup), anode (target track, rotor, stator), vacuum envelope, window, housing. Show line focus principle.]
[ILLUSTRATION: Typical x-ray spectrum showing continuous bremsstrahlung curve and discrete characteristic peaks. Illustrate effect of changing kVp, mAs, and filtration on the spectrum.]

**3.1.2 Image Formation Physics**

Image contrast arises from differential attenuation as x-rays pass through varying tissue types.

*   **Attenuation:** Governed by Beer-Lambert Law: $I = I_0 e^{-\mu x}$. Linear attenuation coefficient (μ) depends on photon energy and material properties (density ρ, atomic number Z). Photoelectric effect dominates at low energies and high Z (contrast!), Compton scattering dominates at diagnostic energies in soft tissue (scatter!).
*   **Beam Hardening:** Preferential removal of low-energy photons as beam passes through patient. Increases average beam energy, reduces contrast slightly, affects quantitative measurements (e.g., CT numbers).
*   **Scatter Radiation:** Primarily Compton scatter. Degrades contrast by adding non-information background signal. Amount depends on kVp, field size, and patient thickness.
*   **Scatter Reduction:**
    *   **Collimation:** Restricting field size reduces irradiated volume, thus reducing scatter production.
    *   **Anti-Scatter Grids:** Placed between patient and detector. Thin lead strips separated by radiolucent interspace material (Al, fiber). Allow primary photons (traveling parallel to strips) to pass but absorb scattered photons (traveling at an angle). 
        *   **Grid Ratio (h/D):** Height of Pb strips (h) to width of interspace (D). Higher ratio = better scatter cleanup but requires more precise alignment and higher patient dose.
        *   **Grid Frequency (lines/cm or lines/inch):** Number of Pb strips per unit distance. Higher frequency = thinner strips, less visible grid lines but potentially lower scatter cleanup for same ratio.
        *   **Types:** Linear (strips parallel), Crossed (two linear grids perpendicular), Focused (strips angled to match beam divergence at specific SID), Parallel (strips parallel, prone to cutoff at edges).
        *   **Bucky Factor (B):** Ratio of radiation incident on grid to radiation transmitted through grid ($B = \frac{Incident}{Transmitted}$). Represents increase in patient dose required when using grid (typically 2-6). $B = 1 / (T_p + T_s)$, where $T_p$ is primary transmission, $T_s$ is scatter transmission.
        *   **Grid Cutoff:** Undesirable absorption of primary radiation due to grid misalignment (off-level, off-center, off-focus, upside-down). Causes non-uniform image density.
    *   **Air Gap Technique:** Increasing distance between patient and detector allows some scattered photons (traveling obliquely) to miss the detector. Requires increased SID to maintain image size, potentially increasing focal spot blur.

[ILLUSTRATION: Diagram showing primary vs. scattered photons reaching detector with and without a grid. Illustrate grid ratio and different types of grid cutoff.]

**3.1.3 Radiographic Techniques and Image Quality**

Optimizing technique factors is essential for diagnostic image quality.

*   **Geometric Factors:**
    *   **Magnification (M):** $M = SID / SOD$. Always > 1. Minimized by maximizing SID and minimizing OID (Object-to-Image Distance).
    *   **Focal Spot Blur (Penumbra):** $U_g = f \times (OID / SOD) = f \times (M-1)$. Minimized by using small focal spot ($f$), minimizing OID, maximizing SID.
    *   **Distortion:** Unequal magnification of different parts of the object due to object shape or angulation relative to beam/detector.
*   **Image Quality Metrics:**
    *   **Contrast:** Difference in signal intensity between areas of interest. **Subject Contrast** (determined by patient attenuation differences, kVp) × **Detector Contrast** (inherent detector response, processing) = **Radiographic Contrast**.
    *   **Noise:** Random fluctuations in image signal. **Quantum Mottle** (statistical variation in x-ray photons detected) is often dominant. $Noise \propto 1 / \sqrt{N}$. Also includes **Electronic Noise** (detector readout) and **Structural Noise** (superimposed anatomy).
    *   **Spatial Resolution:** Ability to distinguish small objects close together. Limited by geometric blur, detector element size (pixel pitch), and scatter. Quantified by Modulation Transfer Function (MTF).
    *   **Contrast-to-Noise Ratio (CNR):** $CNR = \frac{|S_A - S_B|}{\sigma}$, where $S_A, S_B$ are signals in regions A and B, and $\sigma$ is noise standard deviation. Measures conspicuity of an object against its background.
    *   **Detective Quantum Efficiency (DQE):** Efficiency of detector in transferring input signal-to-noise ratio (SNR) to output SNR. $DQE(f) = \frac{SNR_{out}^2(f)}{SNR_{in}^2(f)}$. Higher DQE means better image quality for a given dose, or lower dose for equivalent image quality.
*   **Automatic Exposure Control (AEC):**
    *   **Operation:** Ionization chambers or solid-state detectors placed between patient and detector (or within detector layers). Exposure terminates when charge/signal corresponding to desired receptor exposure is reached.
    *   **Clinical Use:** Select appropriate detector(s) covering anatomy of interest. Density settings (+1, 0, -1 etc.) adjust termination threshold for specific clinical needs or patient variations. Backup timer prevents extreme overexposure.
    *   **Limitations:** Requires proper patient positioning relative to detectors. Can be fooled by radiopaque objects (prostheses), collimation within detector area, or unusual patient anatomy.

**3.1.4 Fluoroscopy**

Real-time imaging requires balancing image quality and radiation dose.

*   **Continuous vs. Pulsed Fluoroscopy:**
    *   **Continuous:** X-ray beam on constantly (e.g., 30 frames/sec). High temporal resolution but higher patient dose.
    *   **Pulsed:** X-ray beam delivered in short pulses (e.g., 3-15 pulses/sec). Reduces dose significantly, especially at lower pulse rates. Image display often uses last image hold between pulses.
*   **Dose Rates:** Typically limited by regulations (e.g., < 10 R/min or 87 mGy/min at tabletop for normal mode, < 20 R/min or 174 mGy/min for high-level control mode in US).
*   **Detector Systems:**
    *   **Image Intensifiers (II):** Convert x-rays to light (input phosphor), light to electrons (photocathode), accelerate/focus electrons, convert electrons back to bright light (output phosphor). Coupled to video camera (CCD/CMOS). Suffers from geometric distortions (pincushion, S-distortion), veiling glare.
    *   **Flat-Panel Detectors (FPD):** Amorphous silicon with CsI:Tl scintillator. Advantages over II: No geometric distortion, wider dynamic range, better contrast resolution, more compact.
*   **Automatic Brightness Control (ABC) / Automatic Dose Rate Control (ADRC):** Systems automatically adjust kVp, mA, and/or pulse width to maintain constant brightness/signal at detector input as beam passes through varying patient thickness. Different modes prioritize kVp vs mA adjustments, affecting contrast and dose.

**3.1.5 Mammography**

Specialized techniques optimize imaging of breast tissue.

*   **X-ray Tube:**
    *   **Target/Filter:** Mo target/Mo filter (characteristic x-rays ~17-19 keV, good for smaller/average breasts), Mo/Rh, Rh/Rh (higher energy characteristic x-rays ~20-23 keV, better penetration for larger/denser breasts), Tungsten (W) target with Rh, Ag, or Al filters (bremsstrahlung-based spectrum, used often for tomosynthesis and contrast-enhanced mammography).
    *   **Window:** Beryllium (Be) window minimizes inherent filtration for low-energy photons.
    *   **Focal Spots:** Small focal spots (e.g., 0.3 mm / 0.1 mm) essential for high spatial resolution, especially for magnification views.
*   **Compression:** Reduces tissue thickness (lower dose, less scatter, less motion), immobilizes breast, separates overlapping tissues. Force typically 111-200 N (25-45 lbs).
*   **Magnification:** Uses air gap for scatter reduction and geometric magnification (typically 1.5x-2.0x) to visualize microcalcifications. Requires very small focal spot (e.g., 0.1 mm).
*   **Detectors:**
    *   **Screen-Film (SFM - Historical):** Single screen/single emulsion film for high resolution.
    *   **Full-Field Digital Mammography (FFDM):** CR (less common now) or DR (indirect CsI or direct a-Se). Offers wider latitude, post-processing capabilities.
*   **Digital Breast Tomosynthesis (DBT):** Acquires multiple low-dose projection images over limited angular range (~15-50 degrees). Reconstructs quasi-3D images, reducing impact of overlapping tissue. Requires detectors with fast readout.
*   **Quality Control:** Rigorous QC essential (e.g., MQSA in US) covering processor/detector performance, phantom image quality, dose, AEC, compression force.

**3.1.6 Dosimetry in Projection Imaging**

Quantifying patient dose is complex; surrogate measures are used.

*   **Exposure (X):** Measure of ionization produced in air (Roentgen R, or C/kg). Historical unit.
*   **Air Kerma (K_air):** Kinetic Energy Released per unit MAss in air (Gray Gy). Standard quantity for specifying beam intensity.
*   **Entrance Skin Dose/Air Kerma (ESD/ESAK):** Dose/Kerma at point where beam enters patient. Includes backscatter. Easily measurable/calculable surrogate for patient dose.
*   **Dose Area Product (DAP) / Kerma Area Product (KAP):** Product of air kerma and beam area at a specific plane (Gy·cm²). Often measured by transmission ionization chamber mounted on collimator. Correlates with total energy imparted and stochastic risk.
*   **Effective Dose (E):** Weighted sum of organ doses, representing overall stochastic risk (Sievert Sv). Calculated using Monte Carlo methods or conversion factors from DAP/ESAK based on exam type and patient model. $E = \sum_T w_T H_T = \sum_T w_T \sum_R w_R D_{T,R}$, where $w_T$ is tissue weighting factor, $H_T$ is equivalent dose, $w_R$ is radiation weighting factor (1 for photons), $D_{T,R}$ is absorbed dose in tissue T from radiation R.

**Assessment Questions (ABR Style):**

1.  (X-ray Production) Increasing the x-ray tube kVp will result in an increase in all of the following EXCEPT:
    A. Maximum photon energy
    B. Average photon energy
    C. Quantity of photons produced
    D. Proportion of characteristic x-rays
    E. Patient dose
    *(Answer: D. While the total number of characteristic photons increases with kVp above the threshold, their proportion relative to the rapidly increasing bremsstrahlung often decreases.)*

2.  (Image Formation) An anti-scatter grid has a grid ratio of 12:1 and a frequency of 40 lines/cm. If the lead strips are 300 μm high, what is the width of the interspace material?
    A. 25 μm
    B. 83 μm
    C. 120 μm
    D. 250 μm
    E. 3600 μm
    *(Answer: A. Grid Ratio = h/D => 12 = 300 μm / D => D = 300 μm / 12 = 25 μm)*

3.  (Image Quality) Geometric unsharpness (focal spot blur) in a radiographic image is increased by:
    A. Decreasing the object-to-image distance (OID)
    B. Increasing the source-to-image distance (SID)
    C. Using a smaller focal spot size
    D. Increasing the magnification factor
    E. Using an anti-scatter grid
    *(Answer: D. $U_g = f \times (M-1)$. Increasing M increases unsharpness. Decreasing OID or increasing SID reduces M and thus unsharpness. Smaller focal spot reduces unsharpness. Grids affect scatter, not geometric blur.)*

4.  (Fluoroscopy) Switching from continuous fluoroscopy at 30 frames/sec to pulsed fluoroscopy at 10 pulses/sec, while maintaining the same dose per pulse, would primarily:
    A. Increase spatial resolution
    B. Decrease temporal resolution
    C. Increase patient dose by a factor of 3
    D. Decrease patient dose by approximately 67%
    E. Improve image contrast
    *(Answer: D. Dose is roughly proportional to the number of pulses/frames per second. Reducing from 30 to 10 reduces dose by (30-10)/30 = 2/3 or ~67%. Temporal resolution decreases.)*

5.  (Mammography) Which target/filter combination is typically used in mammography to provide a higher energy spectrum suitable for imaging larger or denser breasts?
    A. Molybdenum/Molybdenum (Mo/Mo)
    B. Tungsten/Beryllium (W/Be)
    C. Rhodium/Rhodium (Rh/Rh)
    D. Tungsten/Aluminum (W/Al)
    E. Molybdenum/Aluminum (Mo/Al)
    *(Answer: C. Rhodium produces characteristic x-rays (~20-23 keV) higher than Molybdenum (~17-19 keV), providing better penetration.)*

6.  (Dosimetry) A transmission ionization chamber mounted on the collimator of a fluoroscopy unit measures Dose Area Product (DAP). If the indicated DAP is 50 Gy·cm² and the source-to-chamber distance is 20 cm while the source-to-patient entrance distance is 60 cm, the Entrance Skin Air Kerma (ESAK) for a 10 cm × 10 cm field at the entrance plane is approximately:
    A. 5.6 mGy
    B. 16.7 mGy
    C. 50 mGy
    D. 150 mGy
    E. 500 mGy
    *(Answer: E. DAP is constant with distance (ignoring air attenuation). $ESAK = K_{air}(entrance) = DAP / Area(entrance) = 50 Gy·cm² / (10 cm \times 10 cm) = 50 Gy·cm² / 100 cm² = 0.5 Gy = 500 mGy$. Note: Backscatter factor is not included in ESAK definition, but Entrance Skin Dose (ESD) would include it.)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection thoroughly covers the ABR Part 1 syllabus items related to Radiography, Fluoroscopy, and Mammography within the Diagnostic Medical Physics section. It details x-ray production, image formation physics, scatter control, image quality metrics, specific modality considerations (fluoro, mammo), and relevant dosimetry concepts, all with an enhanced focus on clinical application and underlying physics principles as requested.

---


#### Subsection 3.2: Computed Tomography (CT)

**Overview:**
Computed Tomography (CT) revolutionized diagnostic imaging by providing cross-sectional anatomical images, overcoming the limitations of superimposed structures inherent in projection radiography. It utilizes an x-ray source rotating around the patient and an array of detectors measuring transmitted radiation from multiple angles. Complex mathematical algorithms then reconstruct these measurements into detailed images representing the linear attenuation coefficients of tissues within the scanned slice. This subsection delves into the physics, technology, image reconstruction, image quality considerations, artifacts, dosimetry, and quality assurance aspects of CT, emphasizing clinical applications and the underlying principles that enable its diagnostic power.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Trace the historical development of CT scanner generations and describe the components of a modern CT system.
- Differentiate between axial (step-and-shoot) and helical (spiral) scanning modes and explain the concept and clinical significance of pitch.
- Explain the function of slip-ring technology in enabling continuous gantry rotation.
- Describe the process of CT data acquisition, including projection measurements and sinogram formation.
- Detail the principles of Filtered Back Projection (FBP), including the role of convolution kernels (filters) in balancing spatial resolution and noise.
- Explain the fundamental concepts and advantages/disadvantages of Iterative Reconstruction (IR) algorithms compared to FBP.
- Define Hounsfield Units (HU), explain their relationship to linear attenuation coefficients, and describe the process of CT number calibration.
- Explain the concept of windowing (window width and window level) for image display and its clinical importance.
- Analyze the factors influencing CT image quality: spatial resolution (in-plane, z-axis), contrast resolution (low-contrast detectability), noise, and temporal resolution.
- Identify common CT artifacts (beam hardening, partial volume, motion, metal, ring, streak), explain their physical causes and appearance, and discuss methods for their reduction or correction.
- Describe the principles and clinical applications of Multidetector CT (MDCT), including detector configuration and beam geometry.
- Explain the concepts and applications of Dual-Energy CT (DECT).
- Outline the principles of Cone-Beam CT (CBCT) and its applications, particularly in radiation therapy guidance.
- Define and differentiate CT dosimetry metrics: CTDI₁₀₀, CTDI_w, CTDI_vol, Dose Length Product (DLP), and Size-Specific Dose Estimate (SSDE).
- Discuss strategies for CT dose optimization, including Automatic Tube Current Modulation (ATCM), kVp selection, iterative reconstruction, and protocol optimization.
- Outline the key components of a CT quality assurance program according to established guidelines (e.g., ACR, AAPM).

**Estimated Completion Time:** 450-540 minutes (Increased detail & clinical focus)

**Key Points for Understanding:**
- **CT Measures Attenuation:** CT reconstructs a map of linear attenuation coefficients (μ) within the patient, displayed as Hounsfield Units ($HU = 1000 \times \frac{\mu_{tissue} - \mu_{water}}{\mu_{water}}$).
- **Reconstruction is Key:** Sophisticated algorithms (FBP, IR) are required to transform projection data (transmission measurements) into cross-sectional images.
- **Helical Scanning & Pitch:** Slip rings enable continuous rotation and table movement, allowing rapid volumetric acquisition. Pitch ($Pitch = \frac{Table Movement per Rotation}{Total Collimation Width}$) affects scan time, z-axis resolution, and dose.
- **FBP vs. IR:** FBP is fast but can be noisy at lower doses. IR methods model the imaging process and noise statistics, allowing significant noise reduction (and thus potential dose reduction) or improved image quality, but are computationally more intensive.
- **Windowing is Crucial for Visualization:** The wide range of HU values requires specific window width (range of HU displayed) and window level (center of the range) settings to visualize different tissues (e.g., lung, soft tissue, bone windows).
- **MDCT Enables Speed & Volume:** Multiple detector rows allow acquisition of multiple slices per rotation, dramatically increasing scan speed and enabling isotropic resolution.
- **Artifacts are Common:** Understanding artifact causes is essential for image interpretation and troubleshooting.
- **CT Dose is Significant:** CT contributes substantially to medical radiation exposure. CTDI and DLP are scanner output metrics, while SSDE provides a more patient-specific dose estimate. Dose optimization is a primary focus for medical physicists.

**3.2.1 Fundamentals and System Components**

*   **Historical Development:** From Hounsfield's first-generation (translate-rotate, pencil beam, single detector) to modern MDCT systems (rotate-rotate, fan/cone beam, thousands of detectors).
*   **System Components:**
    *   **Gantry:** Rotating framework housing the x-ray tube, detector array, and high-voltage generator.
    *   **X-ray Tube:** High-output rotating anode tube designed for high heat loads (large anode diameter, high rotation speed, efficient cooling). Often uses flying focal spot techniques to improve spatial/temporal resolution.
    *   **Filtration & Collimation:** Shaped filters (bow-tie filters) compensate for patient shape, reducing dynamic range requirements and dose. Pre-patient collimators define slice thickness (single-slice CT) or beam width (MDCT). Post-patient collimators/anti-scatter grids reduce scatter reaching detectors.
    *   **Detectors:** Modern systems use solid-state scintillation detectors (e.g., Gadolinium Oxysulfide (GOS) ceramic, Cadmium Tungstate (CdWO₄) - older) coupled to photodiodes. High efficiency, fast response, high stability, small size. Arranged in arcs with thousands of elements.
    *   **Data Acquisition System (DAS):** Amplifies and digitizes signals from detector elements.
    *   **Slip Rings:** Electromechanical devices allowing continuous power/signal transmission to/from rotating gantry components.
    *   **Patient Table:** Motorized couch for precise patient positioning and movement through the gantry.
    *   **Operator Console & Computer System:** Controls scan parameters, reconstructs images, provides display and archival functions.

[ILLUSTRATION: Diagram of a modern CT gantry showing key components: x-ray tube, bow-tie filter, pre-patient collimator, patient, anti-scatter grid/collimator, detector array, DAS, slip rings.]

**3.2.2 Data Acquisition**

*   **Axial (Step-and-Shoot):** Gantry rotates 360° while table is stationary, table moves to next position, repeat. Historically used, still employed for some high-resolution protocols or gated studies. Interscan delay limits speed.
*   **Helical (Spiral/Volumetric):** Continuous gantry rotation combined with continuous table movement. Enabled by slip-ring technology. Allows rapid acquisition of large volumes.
    *   **Pitch:** Ratio of table travel per rotation to the total nominal beam width (N × T, where N is number of detector rows used and T is nominal slice thickness/detector row width). 
        *   $Pitch = 1$: Contiguous helices.
        *   $Pitch > 1$: Gapped helices, faster scan, lower dose, potential for artifacts (windmill), reduced z-axis resolution.
        *   $Pitch < 1$: Overlapping helices, slower scan, higher dose, improved z-axis resolution/sampling.
    *   **Helical Interpolation:** Data acquired along a helix must be interpolated to create planar datasets for reconstruction (e.g., 180° or 360° linear interpolation). Affects slice sensitivity profile and noise.
*   **Projection Data & Sinograms:** Each detector element measures transmitted intensity ($I$) relative to incident intensity ($I_0$). Projection $p = -\ln(I/I_0) = \int \mu(x,y) dl$ along the ray path. A set of projections at one angle forms a view. Collecting views over 180° or 360° forms a sinogram (visual representation of projections vs. angle).

[ILLUSTRATION: Diagram comparing axial vs. helical scanning geometry. Diagram illustrating the concept of pitch. Example sinogram.]

**3.2.3 Image Reconstruction**

Transforms raw projection data into cross-sectional images.

*   **Filtered Back Projection (FBP):**
    1.  **Back Projection:** Smearing each projection back across the image matrix at its corresponding angle. Simple back projection results in blurry images ($1/r$ blurring).
    2.  **Filtering (Convolution):** Applying a high-pass filter (convolution kernel) to each projection *before* back projection to correct for blurring and enhance edges. The choice of kernel is a trade-off:
        *   **Sharp Kernels (e.g., Bone, Edge):** Enhance high spatial frequencies, improving spatial resolution but increasing noise.
        *   **Smooth Kernels (e.g., Standard, Soft):** Suppress high spatial frequencies, reducing noise but slightly degrading spatial resolution.
    *   **Advantages:** Fast, computationally efficient, well-understood.
    *   **Disadvantages:** Can be noisy, especially at low dose; assumes ideal data (monoenergetic beam, perfect detectors, no scatter/motion).
*   **Iterative Reconstruction (IR):**
    1.  **Initialization:** Start with an initial image estimate (e.g., FBP image or uniform field).
    2.  **Forward Projection:** Simulate the acquisition process by calculating estimated projections from the current image estimate.
    3.  **Comparison:** Compare estimated projections with actual measured projections.
    4.  **Update:** Update the image estimate based on the difference, often incorporating statistical models of noise (e.g., Poisson) and system physics (beam hardening, detector response).
    5.  **Iteration:** Repeat steps 2-4 until convergence (image estimate stabilizes or reaches desired quality).
    *   **Examples:** ASIR (GE), iDose/IMR (Philips), SAFIRE/ADMIRE (Siemens), AIDR 3D (Canon/Toshiba).
    *   **Advantages:** Significant noise reduction (allowing lower dose for equivalent noise), potential for improved low-contrast detectability, artifact reduction (e.g., metal artifacts).
    *   **Disadvantages:** Computationally intensive (though improving), image texture can appear different (

blotchy" or "plastic"), requires careful optimization and validation.

[ILLUSTRATION: Diagram illustrating Filtered Back Projection (showing blurring from simple back projection and correction via filtering). Diagram comparing image noise levels for FBP vs. IR at different dose levels.]

**3.2.4 CT Numbers (Hounsfield Units) and Windowing**

*   **Hounsfield Units (HU):** A relative linear scale for attenuation values, defined as:
    $$ HU = 1000 \times \frac{\mu_{tissue} - \mu_{water}}{\mu_{water}} $$
    By definition, water = 0 HU, air ≈ -1000 HU. Dense bone ≈ +1000 HU or higher. Soft tissues typically range from -100 to +100 HU.
*   **Calibration:** CT scanners are calibrated daily using water phantoms to ensure HU accuracy.
*   **Windowing:** Human eye can only distinguish limited shades of gray (~30-60). CT data spans >2000 HU. Windowing maps a selected range of HU values (Window Width, WW) centered around a specific value (Window Level, WL) to the available grayscale display.
    *   **Window Width (WW):** Determines the range of HU values displayed, affecting image contrast. Narrow WW = high contrast (good for differentiating tissues with similar attenuation, e.g., brain gray/white matter). Wide WW = low contrast (good for visualizing tissues with large attenuation differences, e.g., lung, bone).
    *   **Window Level (WL):** Determines the center HU value of the displayed range, affecting image brightness. WL should be set near the average HU of the tissue of interest.
    *   **Clinical Examples:** Lung window (WW=1500, WL=-600), Soft Tissue window (WW=400, WL=40), Bone window (WW=2000, WL=400).

[ILLUSTRATION: Graph showing the mapping of HU values to grayscale based on Window Width and Window Level. Show examples of the same CT slice displayed with different window settings (Lung, Soft Tissue, Bone).] 

**3.2.5 Image Quality in CT**

*   **Spatial Resolution:** Ability to distinguish small, high-contrast objects.
    *   **In-plane (x-y):** Determined by focal spot size, detector aperture size, reconstruction kernel, pixel size (FOV/matrix size). Measured using bar patterns or MTF (Modulation Transfer Function). Typical limiting resolution: 0.5 - 1.0 lp/mm.
    *   **Z-axis (Slice Sensitivity Profile - SSP):** Determined by beam collimation (SSCT) or detector row width and helical interpolation (MDCT). Affects partial volume averaging. Isotropic resolution (equal in-plane and z-axis) is achievable with MDCT.
*   **Contrast Resolution (Low-Contrast Detectability - LCD):** Ability to distinguish objects with small attenuation differences from background. Limited primarily by noise. Improves with increased dose, larger object size, smoother reconstruction kernels, and IR.
*   **Noise:** Random fluctuations in HU values, primarily quantum noise. $Noise \propto \frac{1}{\sqrt{N_{photons}}}$. Depends on mAs, kVp, slice thickness, pixel size, reconstruction kernel. Measured as standard deviation of HU in a uniform region of a phantom.
*   **Temporal Resolution:** Ability to freeze motion. Determined by gantry rotation speed (and potentially partial scan reconstruction). Crucial for cardiac CT. Modern scanners have rotation times < 0.3 seconds.

**3.2.6 CT Artifacts**

Artifacts degrade image quality and can mimic or obscure pathology.

*   **Physics-Based Artifacts:**
    *   **Beam Hardening:** X-ray beam becomes harder (higher average energy) as it passes through patient. Reconstruction assumes monoenergetic beam, leading to errors. Causes **cupping artifact** (center appears darker than periphery in uniform object) and **streaks/dark bands** between dense objects (e.g., petrous bones).
        *   *Mitigation:* Filtration (bow-tie), calibration corrections, dual-energy CT, iterative reconstruction.
    *   **Partial Volume Averaging:** HU in a voxel represents average attenuation of all materials within that voxel. Occurs when dense object only partially occupies voxel or at interfaces between tissues. Appears as blurring or indistinct margins, especially with thick slices.
        *   *Mitigation:* Use thin slices.
*   **Patient-Based Artifacts:**
    *   **Motion:** Voluntary or involuntary (respiratory, cardiac, peristalsis) motion during scan causes blurring, ghosting, or streaks.
        *   *Mitigation:* Fast scanning, patient immobilization, breath-holding instructions, cardiac gating, motion correction algorithms.
    *   **Metal Artifacts:** Extreme attenuation by high-density metal implants causes severe streaking and shadowing due to beam hardening, scatter, noise, and incomplete projections.
        *   *Mitigation:* Remove external metal, use specialized Metal Artifact Reduction (MAR) algorithms (iterative or projection completion based), increase kVp, use thin slices.
*   **Scanner-Based Artifacts:**
    *   **Ring Artifacts:** Circular artifacts centered on axis of rotation. Caused by miscalibrated or defective detector element(s). More common in 3rd generation (rotate-rotate) scanners.
        *   *Mitigation:* Detector calibration, software corrections, detector replacement.
    *   **Streak Artifacts (Non-metal):** Can arise from data inconsistencies, noise, or undersampling (aliasing).

[ILLUSTRATION: Examples of common CT artifacts: Cupping, Streaks between dense objects, Partial Volume effect, Motion artifact, Metal artifact, Ring artifact.]

**3.2.7 Advanced CT Technologies**

*   **Multidetector CT (MDCT):** Uses multiple rows of detectors (4 to 320+ rows). Allows acquisition of multiple slices per rotation. Enables faster scanning, larger volume coverage, thinner slices, and isotropic resolution. Detector configurations vary (uniform vs. adaptive array sizes).
*   **Dual-Energy CT (DECT):** Acquires data at two different kVp settings (e.g., 80 kVp and 140 kVp) nearly simultaneously (fast kVp switching, dual source, or dual-layer detector). Different materials exhibit different attenuation changes with energy. Allows material decomposition (e.g., differentiate iodine contrast from calcium), creation of virtual non-contrast images, virtual monoenergetic images (reducing beam hardening), and material quantification (e.g., gout detection).
*   **Cone-Beam CT (CBCT):** Uses a cone-shaped x-ray beam and a large area flat-panel detector (similar to digital radiography/fluoro). Acquires volumetric data in a single gantry rotation. Widely used for image guidance in radiation therapy (IGRT), dentistry, and interventional radiology. 
    *   *Challenges:* Increased scatter (due to large cone angle) degrades image quality (contrast, HU accuracy) compared to fan-beam CT. Slower rotation times. Reconstruction algorithms are more complex.

**3.2.8 CT Dosimetry**

Quantifying and managing dose is critical.

*   **CT Dose Index (CTDI):** Represents average dose over central scan volume from a series of contiguous axial scans. Measured using 100 mm long pencil ionization chamber in standard head (16 cm diameter) and body (32 cm diameter) acrylic phantoms.
    *   $CTDI_{100} = \frac{1}{N \times T} \int_{-50mm}^{+50mm} D(z) dz$, where $N \times T$ is nominal beam width.
    *   **Weighted CTDI ($CTDI_w$):** Accounts for non-uniform dose profile (higher at periphery). $CTDI_w = \frac{1}{3} CTDI_{100, center} + \frac{2}{3} CTDI_{100, periphery}$. Represents average dose in scanned plane for axial scanning.
    *   **Volume CTDI ($CTDI_{vol}$):** Accounts for gaps/overlaps in helical scanning. $CTDI_{vol} = \frac{CTDI_w}{Pitch}$. Represents average dose over the scanned volume. **Primary scanner output metric displayed on console.**
*   **Dose Length Product (DLP):** Represents total energy imparted over entire scan length. $DLP = CTDI_{vol} \times Scan Length$. Units: mGy·cm.
*   **Size-Specific Dose Estimate (SSDE):** Adjusts $CTDI_{vol}$ based on patient size (e.g., using lateral or AP dimensions, or effective diameter) using conversion factors from AAPM Report 204. Provides a better estimate of average patient dose than $CTDI_{vol}$.
*   **Effective Dose (E):** Estimated using conversion factors ($k$) applied to DLP ($E = k \times DLP$). Factors depend on scanned body region (from AAPM Report 204/220 or ICRP 103). Represents overall stochastic risk.
*   **Dose Reduction Strategies:**
    *   **Protocol Optimization:** Justification (only scan when necessary), optimize scan length, use appropriate kVp/mAs.
    *   **Automatic Tube Current Modulation (ATCM):** Adjusts mA based on patient attenuation along z-axis (longitudinal modulation) and/or angularly within rotation (angular modulation) to maintain constant image noise while reducing dose.
    *   **kVp Selection:** Lower kVp increases contrast (especially with iodine) and can reduce dose, but increases noise and beam hardening. Optimal kVp depends on patient size and clinical task.
    *   **Iterative Reconstruction (IR):** Allows significant mAs reduction (20-70%) for equivalent noise compared to FBP.
    *   **Shielding:** Bismuth shields (controversial due to potential artifacts/impact on ATCM).

[ILLUSTRATION: Diagram showing CTDI measurement setup with phantom and pencil chamber. Graph illustrating ATCM adjusting mA based on patient attenuation.]

**3.2.9 Quality Assurance (QA)**

Ensures scanner operates safely and accurately.

*   **Frequency:** Daily, weekly, monthly, quarterly, annually based on test importance and component stability.
*   **Key Tests (Examples based on ACR/AAPM guidelines):**
    *   **Water CT Number & Standard Deviation (Noise):** Check HU accuracy and noise levels using water phantom (Daily/Weekly).
    *   **Artifact Evaluation:** Check for artifacts using uniform phantom (Daily/Weekly).
    *   **CT Number Accuracy:** Verify HU for multiple materials (e.g., air, acrylic, polyethylene, bone-mimicking) using phantom (Monthly/Annually).
    *   **Low-Contrast Detectability (LCD):** Assess ability to see low-contrast objects using phantom (e.g., ACR phantom) (Monthly/Annually).
    *   **High-Contrast (Spatial) Resolution:** Measure limiting resolution using bar patterns or MTF (Annually).
    *   **Slice Thickness / Slice Sensitivity Profile:** Verify accuracy of prescribed slice thickness (Annually).
    *   **Laser Light Accuracy:** Ensure alignment of positioning lasers with scan plane (Semi-annually).
    *   **Table Travel Accuracy:** Verify accuracy of table movement (Annually).
    *   **CTDI Accuracy:** Verify scanner-reported CTDI against independent measurement (Annually - Physicist).
    *   **Automatic Tube Current Modulation (ATCM) Performance:** Verify appropriate dose reduction (Annually - Physicist).
    *   **Safety:** Check door interlocks, emergency stops, patient communication (Annually).

**Assessment Questions (ABR Style):**

1.  (Reconstruction) Compared to Filtered Back Projection (FBP), Iterative Reconstruction (IR) algorithms generally allow for:
    A. Faster image reconstruction times
    B. Increased image noise at the same dose level
    C. Significant dose reduction for similar image noise
    D. Improved spatial resolution with sharp kernels
    E. Increased susceptibility to ring artifacts
    *(Answer: C. IR's primary advantage is noise reduction, enabling lower dose scans.)*

2.  (Image Quality) Which of the following parameter changes would most likely improve the low-contrast detectability in a CT image?
    A. Decreasing slice thickness
    B. Using a sharper reconstruction kernel
    C. Decreasing the mAs
    D. Increasing the slice thickness
    E. Increasing the pitch
    *(Answer: D. Increasing slice thickness increases the number of photons per voxel, reducing noise and thus improving low-contrast detectability, although it worsens z-axis resolution.)*

3.  (Artifacts) A CT image of the abdomen shows dark streaks originating from the ribs and extending across the liver. This artifact is most likely:
    A. Ring artifact
    B. Partial volume artifact
    C. Motion artifact
    D. Beam hardening artifact
    E. Metal artifact
    *(Answer: D. Streaks between dense objects (like bone) are characteristic of beam hardening.)*

4.  (Dosimetry) A helical CT scan of the chest (scan length = 30 cm) is performed with a displayed $CTDI_{vol}$ of 15 mGy. The Dose Length Product (DLP) for this scan is:
    A. 0.5 mGy·cm
    B. 15 mGy·cm
    C. 45 mGy·cm
    D. 450 mGy·cm
    E. Cannot be determined without pitch
    *(Answer: D. $DLP = CTDI_{vol} \times Scan Length = 15 mGy \times 30 cm = 450 mGy·cm$)*

5.  (Technology) Dual-Energy CT (DECT) allows for material differentiation primarily because different materials exhibit different:
    A. Densities
    B. Changes in attenuation coefficient with energy
    C. Rates of radioactive decay
    D. Magnetic susceptibilities
    E. Acoustic impedances
    *(Answer: B. DECT exploits the energy dependence of the linear attenuation coefficient (μ), particularly the difference in photoelectric absorption vs. Compton scattering dominance at different energies for different materials.)*

6.  (QA) The weighted CTDI ($CTDI_w$) is calculated from measurements in a standard phantom to better represent the average dose within the scanned plane by accounting for:
    A. Helical pitch
    B. Patient size
    C. The non-uniform dose profile (higher dose at periphery)
    D. Scan length
    E. Iterative reconstruction algorithm used
    *(Answer: C. $CTDI_w = (1/3)CTDI_{center} + (2/3)CTDI_{periphery}$ specifically accounts for the higher dose typically found at the periphery of the phantom.)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection comprehensively covers the ABR Part 1 syllabus items related to Computed Tomography within the Diagnostic Medical Physics section. It details CT principles, technology, reconstruction, image quality, artifacts, advanced techniques (MDCT, DECT, CBCT), dosimetry, and QA with significant depth and clinical relevance.

---


#### Subsection 3.3: Ultrasound

**Overview:**
Ultrasound imaging, or sonography, is a widely used diagnostic modality that utilizes high-frequency sound waves (typically 2-18 MHz) to visualize internal body structures. Unlike modalities using ionizing radiation, ultrasound relies on the mechanical properties of tissues. A transducer emits pulses of ultrasound into the body and detects the returning echoes, which are processed to form images. This subsection explores the fundamental physics of ultrasound waves, their interactions with biological tissues, the principles of transducer operation, various imaging modes (including Doppler), factors affecting image quality, common artifacts, safety considerations (bioeffects), and essential quality assurance procedures, all with a strong emphasis on clinical application and interpretation.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Describe the nature of sound waves and define key parameters: frequency, wavelength, propagation speed, acoustic impedance, intensity, and attenuation.
- Explain the mechanisms of ultrasound interaction with tissue: reflection (specular and diffuse/scattering), refraction, absorption, and attenuation.
- Detail the piezoelectric effect and the construction and operation of ultrasound transducers (single element, arrays - linear, curvilinear, phased).
- Explain the pulse-echo principle, including pulse generation, transmission, reception, and the role of backing material and matching layers.
- Describe the formation and characteristics of the ultrasound beam: near field (Fresnel zone), far field (Fraunhofer zone), focal zone, axial resolution, and lateral resolution.
- Differentiate between A-mode, B-mode (grayscale), and M-mode imaging techniques and their clinical applications.
- Explain the Doppler effect and its application in medical ultrasound for blood flow assessment.
- Describe Continuous Wave (CW) Doppler and Pulsed Wave (PW) Doppler principles, including range gating and aliasing.
- Explain Color Doppler and Power (Amplitude) Doppler imaging techniques.
- Analyze factors influencing ultrasound image quality: spatial resolution (axial, lateral, elevational), contrast resolution, temporal resolution, penetration depth, and signal-to-noise ratio.
- Identify common ultrasound artifacts (e.g., reverberation, shadowing, enhancement, mirror image, side lobes, grating lobes, speed displacement), explain their causes, and recognize their appearance.
- Describe the principles of Tissue Harmonic Imaging (THI) and its benefits (improved contrast, reduced artifacts).
- Explain the mechanism and applications of ultrasound contrast agents (microbubbles).
- Discuss the potential biological effects of ultrasound (thermal and mechanical/cavitation) and the safety indices: Thermal Index (TI - TIS, TIB, TIC) and Mechanical Index (MI).
- Outline the key components and procedures of an ultrasound quality assurance (QA) program using tissue-mimicking phantoms.

**Estimated Completion Time:** 500-600 minutes (Increased detail & clinical focus)

**Key Points for Understanding:**
- **Ultrasound is Mechanical Waves:** Imaging relies on sound waves > 20 kHz, typically 2-18 MHz for medical use.
- **Acoustic Impedance Mismatch Causes Echoes:** Echoes are generated at interfaces between tissues with different acoustic impedances ($Z = \rho c$, where $\rho$ is density, $c$ is propagation speed). The greater the difference, the stronger the echo.
- **Transducers are Piezoelectric:** They convert electrical energy to mechanical (sound) energy and vice versa.
- **Resolution Depends on Frequency & Beam:** Axial resolution (along beam direction) is determined by spatial pulse length (SPL/2) and improves with higher frequency. Lateral resolution (perpendicular to beam) is determined by beam width and improves with focusing and higher frequency.
- **Doppler Detects Motion:** The Doppler shift (change in frequency of returning echoes) is used to detect and quantify blood flow velocity and direction.
- **Artifacts are Informative but Can Mislead:** Understanding artifacts is crucial for accurate interpretation (e.g., shadowing behind a stone confirms its presence, but reverberation can mimic structures).
- **Safety is Monitored by TI and MI:** Thermal Index (TI) estimates potential temperature rise. Mechanical Index (MI) estimates likelihood of cavitation. ALARA principles apply.
- **QA is Essential:** Regular testing with phantoms ensures image quality and measurement accuracy.

**3.3.1 Physics of Sound Waves**

*   **Nature of Sound:** Longitudinal mechanical waves requiring a medium for propagation. Particles oscillate parallel to the direction of wave travel, creating compressions and rarefactions.
*   **Key Parameters:**
    *   **Frequency (f):** Number of cycles per second (Hz or MHz). Determines penetration and resolution. Higher f = better resolution, less penetration. Lower f = poorer resolution, better penetration.
    *   **Period (T):** Time for one cycle ($T = 1/f$).
    *   **Wavelength (λ):** Spatial length of one cycle ($\\lambda = c/f$). Crucial for axial resolution.
    *   **Propagation Speed (c):** Speed at which the wave travels through the medium. Determined *only* by the medium\'s properties (stiffness/bulk modulus and density). Average speed in soft tissue ≈ 1540 m/s (used for range calculations). Speed varies: Air << Lung < Fat < Soft Tissue < Muscle < Bone.
    *   **Acoustic Impedance (Z):** Resistance of the medium to sound propagation ($Z = \rho c$). Units: Rayls (kg/m²s). Determines reflection at interfaces.
    *   **Intensity (I):** Power per unit area (W/m² or mW/cm²). Proportional to the square of pressure amplitude ($I \propto P^2$). Describes the strength of the ultrasound beam. Various intensity measures exist (SPTA, SATA, SPTP, SATP - Spatial Peak/Average, Temporal Peak/Average).
    *   **Decibels (dB):** Logarithmic scale used to compare intensities or amplitudes. $dB = 10 \log_{10}(I_2/I_1) = 20 \log_{10}(P_2/P_1)$. A 3 dB change represents a factor of 2 change in intensity. A 10 dB change represents a factor of 10 change in intensity.

**3.3.2 Interaction of Ultrasound with Tissue**

As ultrasound travels through tissue, its intensity decreases (attenuation) due to several processes:

*   **Reflection:** Redirection of the sound beam back towards the source. Occurs at interfaces between media with different acoustic impedances (Z).
    *   **Specular Reflection:** Occurs at large, smooth interfaces (relative to λ). Angle of incidence = angle of reflection. Responsible for visualizing organ boundaries.
    *   **Intensity Reflection Coefficient (IRC):** Fraction of intensity reflected at a perpendicular interface: $IRC = \left( \frac{Z_2 - Z_1}{Z_2 + Z_1} \right)^2$. Large Z mismatch (e.g., tissue-air, tissue-bone) causes strong reflection.
    *   **Diffuse Reflection (Scattering):** Occurs at small or rough interfaces (dimensions ≈ λ). Sound reflects in multiple directions. Responsible for the echotexture of parenchymal organs.
*   **Refraction:** Change in direction of sound beam when crossing an interface obliquely between media with different propagation speeds. Governed by Snell\'s Law: $\frac{\sin \theta_i}{\sin \theta_t} = \frac{c_1}{c_2}$. Can cause misregistration of objects laterally.
*   **Absorption:** Conversion of acoustic energy into heat. Dominant component of attenuation in soft tissues. Increases significantly with frequency.
*   **Attenuation:** Overall decrease in intensity as sound propagates. Combination of absorption, scattering, and reflection. Expressed in dB/cm. Attenuation coefficient (α) is approximately proportional to frequency in soft tissue (α ≈ 0.5 dB/cm/MHz).
    *   Total Attenuation (dB) = α (dB/cm/MHz) × f (MHz) × path length (cm).
    *   **Half-Value Layer (HVL):** Thickness of tissue required to reduce intensity by 50% (3 dB). HVL decreases with increasing frequency.

[ILLUSTRATION: Diagram showing compression/rarefaction of sound wave. Diagram illustrating specular vs. diffuse reflection. Diagram showing refraction according to Snell\'s Law. Graph showing attenuation coefficient vs. frequency for different tissues.]

**3.3.3 Transducers and Beam Formation**

*   **Piezoelectric Effect:** Property of certain materials (e.g., lead zirconate titanate - PZT ceramic) to generate a voltage when mechanically stressed (direct effect) and to deform when a voltage is applied (reverse effect). Ultrasound transducers use the reverse effect to generate sound and the direct effect to detect returning echoes.
*   **Transducer Construction:**
    *   **Piezoelectric Element(s):** Typically PZT crystal(s), cut to a thickness of λ/2 for resonant frequency operation.
    *   **Electrodes:** Thin conductive layers on element faces to apply voltage/detect charge.
    *   **Backing Material (Damping Block):** Attached to the back of the element. Absorbs backward-directed sound and dampens element ringing. Crucial for creating short pulses (improves axial resolution) but reduces sensitivity/efficiency.
    *   **Matching Layer(s):** One or more layers on the front face with intermediate acoustic impedance between the element (high Z) and tissue (low Z). Reduces the large impedance mismatch, improving sound transmission into/out of the patient (increases efficiency/sensitivity).
    *   **Acoustic Lens/Curvature:** Focuses the beam electronically or mechanically.
    *   **Housing & Connector:** Protects components and provides electrical connection.
*   **Transducer Types:**
    *   **Single Element:** Simple disk, rarely used for imaging now.
    *   **Arrays:** Multiple small elements arranged in patterns:
        *   **Linear Array:** Elements arranged in a line. Rectangular image format. Used for vascular, small parts, musculoskeletal imaging.
        *   **Curvilinear (Convex) Array:** Elements arranged along a curve. Blunted sector image format. Wide field of view. Used for abdominal, OB/GYN imaging.
        *   **Phased Array:** Small footprint, elements fired with small time delays (phasing) to steer and focus the beam electronically. Sector image format. Used for cardiac, abdominal imaging (intercostal access).
        *   **Other Arrays:** Annular arrays, 2D arrays (for 3D/4D imaging).
*   **Beam Formation & Focusing:**
    *   **Near Field (Fresnel Zone):** Region close to transducer where beam is relatively collimated. Length $N = D^2 / (4\lambda)$, where D is transducer diameter/aperture.
    *   **Far Field (Fraunhofer Zone):** Region beyond near field where beam diverges. Divergence angle $\sin \theta = 1.22 \lambda / D$.
    *   **Focal Zone:** Region of minimum beam width where resolution is best. Focusing can be achieved with curved elements, lenses, or electronic phasing (transmit and receive focusing).
*   **Resolution:**
    *   **Axial Resolution (LARRD - Longitudinal, Axial, Range, Radial, Depth):** Ability to distinguish two objects along the beam axis. Determined by Spatial Pulse Length (SPL). $Axial Res = SPL / 2 = (n \times \lambda) / 2$, where n is number of cycles per pulse. Improved by higher frequency (shorter λ) and damping (fewer cycles/pulse).
    *   **Lateral Resolution (LATA - Lateral, Angular, Transverse, Azimuthal):** Ability to distinguish two objects perpendicular to the beam axis. Determined by beam width. Best in the focal zone. Improved by focusing, higher frequency (less divergence), and larger aperture.
    *   **Elevational Resolution:** Resolution in the slice thickness dimension (perpendicular to image plane). Determined by transducer element height or lens/curvature in that dimension. Often poorer than lateral resolution.

[ILLUSTRATION: Diagram of transducer construction showing element, backing, matching layer. Diagrams of linear, curvilinear, and phased array transducers and their image formats. Diagram illustrating near field, far field, focal zone, axial resolution, and lateral resolution.]

**3.3.4 Pulse-Echo Principle and Imaging Modes**

*   **Pulse-Echo Principle:** Transducer sends short pulse into tissue, then listens for returning echoes. The time it takes for an echo to return determines the depth of the reflector (assuming constant speed $c=1540$ m/s). $Depth = (c \times RoundTripTime) / 2$. The strength (amplitude) of the echo determines the brightness of the corresponding pixel.
*   **Imaging Modes:**
    *   **A-Mode (Amplitude Modulation):** Displays echo amplitude vs. depth along a single line of sight. Used in ophthalmology for measurements. Rarely used otherwise.
    *   **B-Mode (Brightness Modulation):** Displays echo amplitude as brightness of pixels. By sweeping the beam (mechanically or electronically), a 2D cross-sectional image is formed. The foundation of most diagnostic ultrasound imaging.
    *   **M-Mode (Motion Modulation):** Displays echo depth vs. time along a single line of sight. Used to visualize motion of structures, particularly cardiac valves and walls.

[ILLUSTRATION: Diagram illustrating pulse-echo principle and depth calculation. Examples of A-mode, B-mode, and M-mode displays.]

**3.3.5 Doppler Ultrasound**

Detects motion (primarily blood flow) by analyzing the frequency shift of returning echoes.

*   **Doppler Effect:** Change in observed frequency due to relative motion between source and receiver. $f_D = f_r - f_t = \pm \frac{2 f_t v \cos \theta}{c}$, where $f_D$ is Doppler shift, $f_r$ is received frequency, $f_t$ is transmitted frequency, $v$ is reflector (blood cell) velocity, $c$ is speed of sound in tissue, and $\theta$ is the Doppler angle (angle between beam direction and flow direction).
    *   Positive shift ($f_r > f_t$): Flow towards transducer.
    *   Negative shift ($f_r < f_t$): Flow away from transducer.
    *   No shift if flow is perpendicular to beam ($\\cos 90° = 0$). Doppler angle is critical; ideally < 60° for accurate velocity estimation.
*   **Continuous Wave (CW) Doppler:** One transducer element continuously transmits, another continuously receives. Detects Doppler shifts from anywhere along the beam (range ambiguity). Can measure very high velocities without aliasing. Used in cardiology and peripheral vascular studies (e.g., ankle-brachial index).
*   **Pulsed Wave (PW) Doppler:** Transducer sends short pulses and listens for echoes from a specific depth range (range gating). Allows velocity measurement at a specific location (range resolution). Subject to **aliasing** if the Doppler shift exceeds half the Pulse Repetition Frequency (PRF). $f_{D,max} = PRF / 2$ (Nyquist Limit). Aliasing appears as wrap-around on the spectral display.
    *   *Reducing Aliasing:* Increase PRF (reduces max depth), use lower frequency transducer, increase Doppler angle (less accurate velocity), use CW Doppler.
*   **Doppler Displays:**
    *   **Spectral Doppler (CW & PW):** Displays Doppler shifts (velocities) vs. time. Provides quantitative velocity information and flow characteristics (laminar vs. turbulent).
    *   **Color Doppler:** Superimposes color map onto B-mode image, showing average Doppler shift (velocity and direction) within sampled regions. Typically uses BART convention (Blue Away, Red Towards). Provides spatial map of flow but is angle-dependent and subject to aliasing.
    *   **Power (Amplitude/Color Doppler Energy) Doppler:** Displays amplitude (power) of Doppler signal, not frequency shift. More sensitive to low flow and less angle-dependent than Color Doppler, but provides no directional or velocity information.

[ILLUSTRATION: Diagram explaining Doppler effect and angle dependence. Diagram comparing CW and PW Doppler beam/sampling. Example of aliasing on PW spectral display. Examples of Color Doppler and Power Doppler images.]

**3.3.6 Image Quality**

*   **Spatial Resolution:** (See 3.3.3) Axial (SPL/2), Lateral (beam width). Elevational (slice thickness).
*   **Contrast Resolution:** Ability to differentiate tissues based on echogenicity. Affected by dynamic range, signal processing, noise, and artifacts.
*   **Temporal Resolution:** Ability to accurately display moving structures. Determined by Frame Rate (frames per second). Frame Rate depends on depth, number of focal zones, line density, sector width, and PRF. Trade-off exists: improving spatial resolution often decreases temporal resolution.
*   **Penetration Depth:** Maximum depth from which meaningful echoes can be received. Limited by attenuation. Decreases with increasing frequency.
*   **Signal-to-Noise Ratio (SNR):** Ratio of echo signal strength to background electronic/system noise. Improved by increasing transmit power, focusing, appropriate gain settings, and reducing noise sources.
*   **System Controls Affecting Image Quality:**
    *   **Frequency:** Higher f = better resolution, less penetration. Lower f = worse resolution, better penetration.
    *   **Gain:** Overall amplification of received echoes. Does not improve SNR.
    *   **Time Gain Compensation (TGC):** Depth-dependent amplification to compensate for attenuation. Allows echoes from deeper structures to appear with similar brightness to shallower ones.
    *   **Focusing:** Adjusts focal zone depth to optimize lateral resolution.
    *   **Dynamic Range:** Range of echo amplitudes displayed (compression). Affects image contrast.
    *   **Output Power:** Controls intensity of transmitted pulse. Affects signal strength and patient exposure (TI/MI).

**3.3.7 Artifacts**

Misrepresentations of anatomy or flow.

*   **Propagation Artifacts:**
    *   **Reverberation:** Multiple reflections between strong reflectors or transducer and reflector. Appear as equally spaced echoes deep to the real reflector (e.g., comet tail, ring down).
    *   **Shadowing:** Reduced echo amplitude deep to a strongly attenuating or reflecting structure (e.g., gallstone, bone). Useful diagnostic sign.
    *   **Enhancement (Through Transmission):** Increased echo amplitude deep to a weakly attenuating structure (e.g., cyst). Useful diagnostic sign.
    *   **Mirror Image:** Artifactual structure displayed deep to a strong specular reflector (e.g., diaphragm). Sound reflects off interface to another structure and back.
    *   **Refraction Artifact:** Lateral displacement of structures due to beam bending at oblique interfaces with different speeds.
    *   **Speed Displacement Artifact:** Structures displayed at incorrect depth if actual propagation speed differs significantly from assumed 1540 m/s.
*   **Attenuation Artifacts:** Shadowing, Enhancement.
*   **Beam Characteristic Artifacts:**
    *   **Side Lobes / Grating Lobes:** Energy projected off-axis from the main beam (side lobes for single elements, grating lobes for arrays). Can cause echoes from strong reflectors outside the main beam to appear within the image.
    *   **Slice Thickness (Elevational Resolution) Artifact:** Echoes from structures above/below the thin image plane can be projected into the image, potentially filling in anechoic structures like cysts.
*   **Doppler Artifacts:**
    *   **Aliasing:** (See 3.3.5) Wrap-around of spectral or color display when Doppler shift exceeds Nyquist limit (PRF/2).
    *   **Mirror Image (Doppler):** Duplicate spectral display or color vessel appearing on opposite side of baseline, often due to high gain or near-90° angle.
    *   **Twinkle Artifact:** Color Doppler artifact appearing as rapidly changing color signals behind strongly reflecting, rough surfaces (e.g., stones), likely due to intrinsic noise/phase jitter.

[ILLUSTRATION: Examples of common ultrasound artifacts: Reverberation, Shadowing, Enhancement, Mirror Image, Side Lobe artifact, Aliasing.]

**3.3.8 Harmonic Imaging & Contrast Agents**

*   **Tissue Harmonic Imaging (THI):** Ultrasound beam distorts as it propagates through tissue (non-linear propagation), generating harmonic frequencies (multiples of the fundamental frequency, primarily 2f₀). THI systems transmit at f₀ and selectively receive echoes at 2f₀. 
    *   *Benefits:* Harmonics are generated within the tissue, reducing clutter/haze from superficial layers, improving contrast resolution, narrowing the beam (improving lateral resolution), and reducing some artifacts (e.g., reverberation).
*   **Ultrasound Contrast Agents (UCAs):** Gas-filled microbubbles (typically < 10 μm diameter) encapsulated in a lipid or protein shell, injected intravenously. Microbubbles strongly scatter ultrasound and resonate non-linearly, significantly enhancing Doppler signals and enabling harmonic contrast imaging. Used for lesion characterization, perfusion assessment, echocardiography.

**3.3.9 Bioeffects and Safety**

Ultrasound deposits energy in tissue, potentially causing bioeffects.

*   **Mechanisms:**
    *   **Thermal Effects:** Absorption of ultrasound energy leads to temperature rise. Significant temperature increases (> 1-2°C) can have detrimental effects, especially in sensitive tissues (e.g., fetus, eye).
    *   **Mechanical Effects (Non-thermal):** Primarily **cavitation** - interaction of sound waves with microscopic gas bodies. Can be stable (bubbles oscillate) or inertial/transient (bubbles collapse violently, causing high local pressures/temperatures). Radiation force, acoustic streaming also occur.
*   **Safety Indices (Displayed on Screen):** Based on AIUM/NEMA Output Display Standard (ODS).
    *   **Thermal Index (TI):** Ratio of acoustic power produced by transducer to the power required to raise tissue temperature by 1°C under specific assumptions. Unitless. Provides estimate of *potential* temperature rise.
        *   **TIS:** Soft Tissue TI (used for imaging soft tissue).
        *   **TIB:** Bone TI (used when bone is near focus, e.g., fetal imaging).
        *   **TIC:** Cranial Bone TI (used when beam passes through bone, e.g., transcranial Doppler).
    *   **Mechanical Index (MI):** Estimates the potential for inertial cavitation. $MI = \frac{p_{r.3}}{\sqrt{f}}$, where $p_{r.3}$ is peak rarefactional pressure (MPa) derated by 0.3 dB/cm/MHz, and f is center frequency (MHz). Unitless.
*   **ALARA Principle:** As Low As Reasonably Achievable. Use lowest output power and shortest scan time consistent with obtaining diagnostic information. Prudent use is especially important in obstetric and pediatric imaging.
*   **Regulatory Limits:** FDA sets limits on maximum acoustic output levels (e.g., SPTA intensity) for diagnostic ultrasound equipment.

**3.3.10 Quality Assurance (QA)**

Ensures optimal image quality, accurate measurements, and safe operation.

*   **Phantoms:** Tissue-mimicking phantoms containing targets to test various parameters.
    *   **Tissue Mimicking Material:** Speed ≈ 1540 m/s, attenuation ≈ 0.5-0.7 dB/cm/MHz, defined scattering properties.
    *   **Targets:** Nylon monofilaments (spatial resolution), cystic structures (low-contrast resolution, noise), high-contrast structures, depth markers.
    *   **Doppler Phantoms:** Flowing blood-mimicking fluid or moving strings/belts.
*   **Key QA Tests (Performed routinely, e.g., semi-annually):**
    *   **System Sensitivity / Penetration:** Maximum depth visualized.
    *   **Image Uniformity:** Consistent brightness in uniform regions.
    *   **Axial Resolution:** Measure separation of closely spaced pins along beam axis.
    *   **Lateral Resolution:** Measure width of pin targets at different depths.
    *   **Vertical & Horizontal Distance Accuracy (Calipers):** Measure known distances between targets.
    *   **Dead Zone:** Minimum depth visualized near transducer face.
    *   **Focal Zone:** Verify location of best lateral resolution matches indicator.
    *   **Low-Contrast Resolution:** Detectability of low-contrast targets.
    *   **Gray Scale / Dynamic Range:** Verify display of different echo amplitudes.
    *   **Doppler Accuracy (Velocity & Color):** Using Doppler phantom.
    *   **Preventive Maintenance:** Cleaning, inspection of transducers/cables, electrical safety.

[ILLUSTRATION: Diagram of a typical ultrasound QA phantom showing various targets.]

**Assessment Questions (ABR Style):**

1.  (Physics) The acoustic impedance (Z) of a medium is determined by its:
    A. Frequency (f) and Attenuation (α)
    B. Density (ρ) and Propagation Speed (c)
    C. Wavelength (λ) and Frequency (f)
    D. Intensity (I) and Period (T)
    E. Bulk Modulus (B) and Wavelength (λ)
    *(Answer: B. $Z = \rho c$)*

2.  (Transducers) Which component of an ultrasound transducer is primarily responsible for improving axial resolution by shortening the spatial pulse length?
    A. Matching Layer
    B. Piezoelectric Element Thickness
    C. Backing Material
    D. Acoustic Lens
    E. Electrodes
    *(Answer: C. The backing material damps the ringing of the element, creating shorter pulses.)*

3.  (Image Quality) Increasing the frequency of an ultrasound transducer will generally result in:
    A. Increased penetration depth and improved axial resolution
    B. Decreased penetration depth and improved axial resolution
    C. Increased penetration depth and degraded axial resolution
    D. Decreased penetration depth and degraded axial resolution
    E. No change in penetration depth but improved axial resolution
    *(Answer: B. Higher frequency leads to greater attenuation (less penetration) but shorter wavelength (better axial resolution).)*

4.  (Doppler) In Pulsed Wave (PW) Doppler, aliasing occurs when:
    A. The Doppler angle is exactly 90 degrees
    B. The flow velocity is too low
    C. The Doppler shift frequency exceeds half the Pulse Repetition Frequency (PRF)
    D. Continuous Wave (CW) Doppler is used instead of PW
    E. The vessel is located beyond the focal zone
    *(Answer: C. This is the definition of the Nyquist limit.)*

5.  (Artifacts) An ultrasound image shows increased brightness in the region deep to a fluid-filled cyst. This artifact is known as:
    A. Shadowing
    B. Reverberation
    C. Mirror Image
    D. Enhancement
    E. Side Lobe
    *(Answer: D. Enhancement (or through transmission) occurs because the fluid in the cyst attenuates the beam less than the surrounding tissue.)*

6.  (Safety) The Mechanical Index (MI) displayed on an ultrasound system provides an indication of the potential risk for:
    A. Tissue heating due to absorption
    B. Electrical shock from the transducer
    C. Cavitation effects
    D. Misregistration due to refraction
    E. Aliasing in Doppler measurements
    *(Answer: C. MI is specifically related to the likelihood of non-thermal, mechanical effects, primarily inertial cavitation.)*

**Alignment with CAMPEP/ABR Requirements:**
This subsection comprehensively covers the ABR Part 1 syllabus items related to Ultrasound within the Diagnostic Medical Physics section. It details ultrasound physics, wave interactions, transducer technology, beam properties, imaging modes (A, B, M, Doppler), image quality, artifacts, advanced techniques (harmonics, contrast), bioeffects/safety (TI/MI), and QA with significant depth and clinical relevance.

---

#### Subsection 3.4: Magnetic Resonance (MR)

**Overview:**
Magnetic Resonance Imaging (MRI) is a powerful, non-invasive diagnostic modality that utilizes strong magnetic fields, radiofrequency (RF) pulses, and magnetic field gradients to generate detailed images of internal body structures, particularly soft tissues. Unlike modalities using ionizing radiation, MRI exploits the magnetic properties of atomic nuclei, primarily hydrogen protons (¹H), which are abundant in water and fat. This subsection provides an exceptionally detailed exploration of the fundamental physics of nuclear magnetic resonance (NMR), the complex processes of spatial encoding and image formation, various pulse sequences and contrast mechanisms, MRI hardware components, factors influencing image quality, common artifacts, and critical safety considerations, all interwoven with deep clinical insights and practical applications.

**Learning Objectives:**
Upon completing this subsection, you will be able to:
- Explain the quantum mechanical basis of nuclear spin, magnetic moment, and precession in an external magnetic field ($B_0$).
- Define the Larmor frequency and its dependence on gyromagnetic ratio (γ) and field strength ($B_0$).
- Describe the concept of net magnetization vector (M) and its behavior at equilibrium and following RF excitation (nutation).
- Detail the processes of T1 (spin-lattice) relaxation and T2 (spin-spin) relaxation, including their underlying physical mechanisms and characteristic time constants.
- Explain T2* decay and its relationship to T2 and magnetic field inhomogeneities.
- Describe the principles of spatial encoding using magnetic field gradients: slice selection, phase encoding, and frequency encoding.
- Define k-space (spatial frequency domain) and explain how it is filled using different pulse sequence trajectories.
- Explain the relationship between k-space data and the final image via the Fourier Transform.
- Detail the structure and timing of fundamental pulse sequences: Spin Echo (SE) and Gradient Echo (GRE).
- Explain how T1-weighting, T2-weighting, and Proton Density (PD) weighting are achieved by manipulating sequence parameters (TR, TE, flip angle).
- Describe the principles and applications of Inversion Recovery (IR) sequences, including FLAIR (Fluid Attenuated IR) and STIR (Short Tau IR).
- Explain the concepts behind fast/turbo imaging techniques: Fast Spin Echo (FSE)/Turbo Spin Echo (TSE) and Echo Planar Imaging (EPI).
- Discuss advanced contrast mechanisms: Diffusion Weighted Imaging (DWI - ADC maps), MR Angiography (MRA - TOF, PC), functional MRI (fMRI - BOLD effect), and MR Spectroscopy (MRS).
- Describe the main components of an MRI scanner: main magnet (superconducting, permanent, resistive), gradient coils, RF coils (transmit/receive, surface coils, phased arrays), and shim coils.
- Analyze factors influencing MRI image quality: Signal-to-Noise Ratio (SNR), Contrast-to-Noise Ratio (CNR), spatial resolution, and temporal resolution.
- Identify common MRI artifacts (e.g., chemical shift, magnetic susceptibility, motion, aliasing/wrap-around, zipper, Gibbs ringing, RF interference), explain their physical causes, appearance, and mitigation strategies.
- Discuss the significant safety considerations in the MR environment related to static magnetic fields (projectile effect, device interactions), time-varying gradient fields (peripheral nerve stimulation - PNS), RF fields (Specific Absorption Rate - SAR, tissue heating), acoustic noise, and cryogens.
- Outline essential MR quality assurance (QA) procedures using phantoms.

**Estimated Completion Time:** 750-900 minutes (Extra detail: ~50% increase + additional examples)

**Key Points for Understanding:**
- **MRI Uses Nuclear Magnetism:** Exploits the spin property of atomic nuclei (mainly ¹H protons) in a strong magnetic field.
- **Larmor Frequency is Key:** Protons precess at a frequency proportional to the local magnetic field strength ($\omega_0 = \gamma B_0$).
- **RF Pulses Excite Spins:** RF pulses at the Larmor frequency tip the net magnetization away from equilibrium.
- **Relaxation Provides Contrast:** T1 (longitudinal recovery) and T2 (transverse decay) relaxation times differ between tissues, forming the basis of image contrast.
- **Gradients Encode Space:** Linearly varying magnetic fields (gradients) are superimposed on $B_0$ to make the Larmor frequency spatially dependent, allowing localization of the MR signal.
- **K-space Holds Spatial Frequencies:** Raw MR data is acquired in k-space; a Fourier Transform converts this data into the image.
- **Pulse Sequences Control Contrast & Speed:** Different sequences (SE, GRE, IR, FSE, EPI) manipulate RF pulses and gradients to emphasize specific tissue properties (T1, T2, PD, diffusion, flow) and control acquisition time.
- **Hardware is Complex:** Requires strong, stable magnets, fast-switching gradients, and sensitive RF coils.
- **Safety is Paramount:** Strong magnetic fields, RF energy deposition, acoustic noise, and cryogens pose significant risks requiring strict protocols.

**3.4.1 Fundamentals of Nuclear Magnetic Resonance (NMR)**

*   **Nuclear Spin & Magnetic Moment:** Nuclei with an odd number of protons and/or neutrons possess a quantum mechanical property called spin angular momentum ($\vec{I}$). This spinning charge generates a magnetic dipole moment ($\vec{\mu}$), proportional to the spin: $\vec{\mu} = \gamma \vec{I}$, where $\gamma$ is the gyromagnetic ratio (a constant specific to the nucleus, e.g., 42.58 MHz/T for ¹H). The magnitude of the spin is quantized, characterized by the spin quantum number I (e.g., I=1/2 for ¹H, ¹³C, ³¹P, ¹⁹F).
*   **Behavior in External Field ($B_0$):**
    *   **Alignment & Zeeman Splitting:** In the absence of $B_0$, nuclear magnetic moments are randomly oriented. When placed in a strong external magnetic field ($B_0$, typically along the z-axis), the magnetic moments align in discrete energy states determined by the magnetic quantum number, $m_I$, which ranges from -I to +I in integer steps. For ¹H (I=1/2), $m_I = +1/2$ (parallel, spin-up, lower energy) and $m_I = -1/2$ (anti-parallel, spin-down, higher energy). This splitting of energy levels is called the Zeeman effect. The energy difference is $\Delta E = \gamma \hbar B_0$.
    *   **Net Magnetization (M):** Slightly more spins populate the lower energy state (spin-up) than the higher energy state (spin-down) according to the Boltzmann distribution: $\frac{N_{down}}{N_{up}} = e^{-\Delta E / (kT)} \approx 1 - \frac{\gamma \hbar B_0}{kT}$ (for $kT >> \Delta E$). This small population excess (typically only a few parts per million at clinical field strengths and body temperature) creates a bulk net magnetization vector ($\vec{M}$) aligned with $B_0$ at equilibrium. The magnitude $M_0$ is proportional to $B_0/T$.
    *   **Precession:** Individual magnetic moments do not simply align but precess around the $B_0$ axis due to the torque exerted by $B_0$ on $\vec{\mu}$ ($\vec{\tau} = \vec{\mu} \times \vec{B_0}$). The frequency of this precession is the **Larmor Frequency**: $\omega_0 = \gamma B_0$ (angular frequency, rad/s) or $f_0 = \frac{\gamma}{2\pi} B_0$ (frequency, Hz). For ¹H, $f_0 \approx 42.58 \text{ MHz}$ per Tesla. At 1.5 T, $f_0 \approx 63.9$ MHz; at 3.0 T, $f_0 \approx 127.7$ MHz (in the RF range).
*   **RF Excitation (B₁ Field):**
    *   **Resonance Condition:** To manipulate $\vec{M}$, a second, weaker magnetic field ($B_1$) oscillating at the Larmor frequency is applied perpendicular to $B_0$ (typically in the x-y plane) using an RF transmit coil. This is the resonance condition – energy is efficiently transferred from the $B_1$ field to the spin system only when the $B_1$ frequency matches the Larmor frequency.
    *   **Nutation (Rotating Frame):** It's convenient to analyze the effect of $B_1$ in a reference frame rotating at the Larmor frequency around the z-axis. In this rotating frame, the static $B_0$ effect disappears, and the $B_1$ field appears stationary. $\vec{M}$ then precesses around the stationary $B_1$ field, causing it to tip away from the z-axis towards the x-y plane. This tipping motion is called nutation. The angle of tip (flip angle, α) depends on the strength and duration of the $B_1$ pulse: $\alpha = \gamma B_{1,eff} \tau_{RF}$, where $B_{1,eff}$ is the effective $B_1$ amplitude. Common flip angles are 90° (maximizes transverse signal) and 180° (inverts longitudinal magnetization or refocuses transverse magnetization).
    *   **Phase Coherence & Signal Detection:** The $B_1$ pulse forces the precessing spins into phase coherence, meaning their individual transverse magnetic moment components ($µ_{xy}$) point in the same direction in the rotating frame, resulting in a large macroscopic transverse magnetization ($M_{xy}$). It is this rotating $M_{xy}$ that induces an electromotive force (voltage signal) in the RF receive coil via Faraday's law of induction. This raw signal, decaying over time due to relaxation, is called the Free Induction Decay (FID).
*   **Relaxation Processes:** After the RF pulse is turned off, the spin system returns to thermal equilibrium ($M_z = M_0, M_{xy} = 0$) via two simultaneous, independent relaxation processes:
    *   **T1 Relaxation (Longitudinal or Spin-Lattice):** Recovery of the longitudinal magnetization ($M_z$) back towards its equilibrium value ($M_0$). $M_z(t) = M_0 (1 - (1 - M_z(0)/M_0)e^{-t/T1})$. Following a 90° pulse ($M_z(0)=0$), $M_z(t) = M_0 (1 - e^{-t/T1})$. T1 represents the time for $M_z$ to recover to $1 - 1/e \approx 63\%$ of its total change. It involves energy exchange between the excited spins and the surrounding molecular lattice, mediated by fluctuating magnetic fields caused by molecular motion (tumbling, translation) at or near the Larmor frequency. Efficient T1 relaxation occurs when molecular motion matches the Larmor frequency. T1 times depend strongly on field strength (generally increasing with $B_0$), tissue type (fat has short T1 due to optimal molecular tumbling; water/CSF has long T1), temperature, and the presence of paramagnetic contrast agents (like Gadolinium, which dramatically shortens T1).
    *   **T2 Relaxation (Transverse or Spin-Spin):** Irreversible decay of the transverse magnetization ($M_{xy}$) due to loss of phase coherence among the precessing spins. $M_{xy}(t) = M_{xy}(0) e^{-t/T2}$. T2 represents the time for $M_{xy}$ to decay to $1/e \approx 37\%$ of its initial value. It involves energy-conserving interactions between the magnetic fields of neighboring spins (spin-spin interaction), leading to variations in local magnetic fields and thus variations in precession frequencies, causing spins to dephase. T2 is influenced by molecular structure and mobility but is less dependent on $B_0$ than T1. Liquids (water, CSF) have long T2 due to rapid molecular motion averaging out local field variations, while solids or tissues with large macromolecules (muscle, cartilage) have short T2.
    *   **T2* Decay (T2-star):** The *observed* decay of the FID signal (transverse magnetization) is actually faster than predicted by T2 alone. This faster decay is characterized by T2* and includes dephasing due to both intrinsic, random spin-spin interactions (T2) *and* dephasing due to *static*, macroscopic inhomogeneities in the main magnetic field ($B_0$) across a voxel, as well as magnetic susceptibility differences at tissue interfaces. $\frac{1}{T2^*} = \frac{1}{T2} + \frac{1}{T2_{inhom}} = \frac{1}{T2} + \gamma \Delta B_{0,local}$. T2* effects are reversible with a 180° RF pulse (used in Spin Echo sequences) but are not refocused by gradient reversals (used in Gradient Echo sequences). T2* decay is particularly important for GRE sequences and susceptibility-weighted imaging (SWI).

[ILLUSTRATION: Detailed diagram showing Zeeman splitting for spin-1/2 nucleus, Boltzmann distribution, and net magnetization M. Diagram illustrating the concept of the rotating frame of reference and the effect of B1 on M (nutation). Graphs comparing T1 recovery curves for fat, muscle, and CSF at 1.5T. Graphs comparing T2 decay curves for fat, muscle, and CSF. Graph comparing T2 and T2* decay, highlighting the effect of static field inhomogeneity.]

**3.4.2 Spatial Encoding and K-Space**

To create an image, we need to map the spatial origin of the MR signal. This is achieved by temporarily applying magnetic field gradients ($G_x, G_y, G_z$) – coils designed to produce a linear variation in magnetic field strength along a specific direction, superimposed on the main $B_0$ field.

*   **Gradient Function:** When a gradient $G_z$ is applied, the total field becomes $B(z) = B_0 + G_z z$. Consequently, the Larmor frequency becomes linearly dependent on position: $\omega(z) = \gamma (B_0 + G_z z)$. This frequency-position relationship is the foundation of spatial encoding.
*   **Spatial Encoding Steps (Cartesian Acquisition):**
    1.  **Slice Selection ($G_{ss}$):** A gradient (e.g., $G_z$) is applied *simultaneously* with a frequency-selective RF excitation pulse ($B_1$). The RF pulse has a specific center frequency and bandwidth ($\Delta \omega$). Only spins within a slice where the Larmor frequency matches the RF pulse bandwidth will be excited. Slice thickness ($\Delta z$) is determined by the RF bandwidth and gradient strength: $\Delta z = \frac{\Delta \omega}{\gamma G_{ss}}$. Slice position is determined by the RF pulse's center frequency. Using shaped RF pulses (e.g., sinc) and gradients allows for selective excitation of specific slices.
    2.  **Phase Encoding ($G_{pe}$):** After slice selection but *before* signal readout, a brief gradient (e.g., $G_y$) is applied. This gradient introduces a temporary frequency difference along the y-direction, causing spins at different y-positions to accumulate different amounts of phase shift by the time the gradient ends: $\phi(y) = \gamma G_{pe} y \tau_{pe}$. The *amplitude* (or duration) of this $G_{pe}$ gradient is stepped incrementally from a maximum negative value to a maximum positive value over successive TR periods (e.g., 128, 256, or 512 steps). Each step encodes a different spatial frequency component along the y-direction.
    3.  **Frequency Encoding ($G_{fe}$, Readout):** While the MR signal (echo) is being acquired, a gradient (e.g., $G_x$) is applied. This gradient imposes a linear frequency variation along the x-direction during the readout window: $\omega(x) = \gamma (B_0 + G_{ss} z_{slice} + G_{fe} x)$. The received signal is a complex waveform containing a spectrum of frequencies. A Fourier Transform of this signal separates the contributions from different x-positions based on their unique frequencies. The strength of $G_{fe}$ and the sampling rate determine the Field of View (FOV) and spatial resolution in the frequency-encoding direction.
*   **K-Space (Spatial Frequency Domain):**
    *   **Definition & Coordinates:** K-space is a mathematical construct representing the spatial frequency content of the image. It is *not* the image itself. The coordinates ($k_x, k_y$) are related to the time integrals of the applied gradients: $k_x(t) = \frac{\gamma}{2\pi} \int_0^t G_x(t") dt"$ and $k_y = \frac{\gamma}{2\pi} G_{pe} \tau_{pe}$ (constant during readout for a given TR). The phase encoding gradient step determines the $k_y$ value (vertical line in k-space), and the frequency encoding gradient sweeps across $k_x$ values (horizontal direction) during readout.
    *   **Filling K-space:** In conventional Cartesian imaging (like SE, GRE, FSE), one line of k-space (constant $k_y$) is acquired per TR. The number of phase-encoding steps ($N_y$) determines the number of lines acquired and the resolution in the phase-encoding direction. Total scan time is approximately $TR \times N_y \times NEX$ (Number of Excitations/Averages).
    *   **K-space Properties & Image Information:** The center of k-space (low spatial frequencies) contains information about overall image contrast and signal intensity, while the periphery (high spatial frequencies) contains information about edges and fine details. This property is exploited in various acceleration techniques (e.g., partial Fourier, parallel imaging) and undersampling strategies.
    *   **Fourier Transform:** The final MR image is obtained by applying a 2D Fourier Transform to the k-space data, converting spatial frequency information into spatial position information. The magnitude of the complex data is typically displayed as the final image.

[ILLUSTRATION: Detailed diagram showing the three spatial encoding steps (slice selection, phase encoding, frequency encoding) with gradient waveforms and their effects on spins. Diagram of k-space showing the relationship between k-space location and image features, with examples of how different regions of k-space contribute to the final image. Diagram showing the relationship between gradient waveforms and k-space trajectory for a conventional Cartesian acquisition.]

**Clinical Example: Spatial Encoding in Practice**
When a radiologist prescribes an axial brain MRI, the MR technologist selects the desired slice locations on a localizer image. The scanner software calculates the specific RF frequencies needed to excite each slice based on the slice position and the gradient strength. For a 5mm slice thickness at 1.5T with a slice-select gradient of 10 mT/m, the RF pulse bandwidth would be approximately 2.1 kHz. If the radiologist needs to visualize a small pituitary lesion, the technologist might reduce the slice thickness to 3mm, requiring a proportionally narrower RF bandwidth or stronger gradient. The phase and frequency encoding directions are typically chosen to minimize artifacts (e.g., placing the phase-encode direction anterior-posterior to avoid respiratory motion artifacts in abdominal imaging).

**3.4.3 Pulse Sequences and Contrast Mechanisms**

Pulse sequences are specific combinations of RF pulses and gradient waveforms designed to manipulate the MR signal to highlight different tissue properties. The choice of sequence and its parameters determines the image contrast, acquisition time, and susceptibility to artifacts.

*   **Basic Pulse Sequence Components:**
    *   **RF Pulses:** Excitation pulses (typically 90°) to create transverse magnetization, refocusing pulses (typically 180°) to reverse dephasing, and inversion pulses (180°) to invert longitudinal magnetization.
    *   **Gradients:** Slice-select, phase-encode, and frequency-encode gradients for spatial encoding; additional gradients for motion compensation, flow encoding, or diffusion weighting.
    *   **Timing Parameters:** TR (Repetition Time) - time between successive excitations of the same slice; TE (Echo Time) - time between excitation and signal readout; TI (Inversion Time) - time between inversion pulse and excitation pulse.
*   **Fundamental Pulse Sequences:**
    *   **Spin Echo (SE):** The classic sequence using a 90° excitation pulse followed by a 180° refocusing pulse at TE/2 to form an echo at TE. The 180° pulse reverses the dephasing caused by static field inhomogeneities (T2* effects), making the signal intensity at TE dependent only on true T2 decay. The sequence diagram shows:
        *   90° RF pulse with slice-select gradient
        *   Phase-encode gradient
        *   180° RF pulse with slice-select gradient at TE/2
        *   Readout gradient with signal acquisition at TE
        *   Signal equation: $S \propto N(H) \cdot (1 - e^{-TR/T1}) \cdot e^{-TE/T2}$, where $N(H)$ is the proton density.
    *   **Gradient Echo (GRE):** Uses a single RF pulse (typically with flip angle α < 90° to allow shorter TR) and gradient reversal (instead of a 180° pulse) to form an echo. Since gradient reversal does not compensate for static field inhomogeneities, GRE is sensitive to T2* effects.
        *   α° RF pulse with slice-select gradient
        *   Phase-encode gradient
        *   Frequency-encode gradient with initial dephasing lobe, followed by readout lobe with opposite polarity
        *   Signal equation: $S \propto N(H) \cdot \frac{(1 - e^{-TR/T1})}{(1 - \cos(\alpha) \cdot e^{-TR/T1})} \cdot \sin(\alpha) \cdot e^{-TE/T2^*}$
*   **Contrast Mechanisms & Weighting:**
    *   **T1-Weighted Imaging:** Emphasizes differences in T1 relaxation times between tissues. Fat appears bright; water/CSF appears dark. Achieved with:
        *   SE: Short TR (400-700 ms), Short TE (10-25 ms)
        *   GRE: Short TR (50-200 ms), Short TE (2-10 ms), Moderate flip angle (30-60°)
        *   Clinical applications: Anatomical imaging, post-contrast studies, fat/water distinction, MS plaques (with contrast), subacute hemorrhage.
    *   **T2-Weighted Imaging:** Emphasizes differences in T2 relaxation times. Water/CSF appears bright; fat appears intermediate; muscle appears dark. Achieved with:
        *   SE: Long TR (>2000 ms), Long TE (80-140 ms)
        *   Clinical applications: Pathology detection (edema, inflammation, tumors), acute/chronic infarcts, demyelination, infection.
    *   **Proton Density (PD) Weighted Imaging:** Minimizes T1 and T2 contrast to emphasize differences in proton density. Achieved with:
        *   SE: Long TR (>2000 ms), Short TE (10-25 ms)
        *   Clinical applications: Subtle white/gray matter differentiation, cartilage evaluation, some MS lesions.
    *   **T2*-Weighted Imaging:** Emphasizes magnetic susceptibility differences. Achieved with:
        *   GRE: Moderate-Long TR, Moderate-Long TE (15-50 ms), Low-moderate flip angle
        *   Clinical applications: Hemorrhage detection, iron deposition, calcium, air-tissue interfaces.
*   **Advanced Pulse Sequences:**
    *   **Inversion Recovery (IR):** Adds a 180° inversion pulse before the standard excitation pulse, allowing selective nulling of specific tissues based on their T1 values. The time between inversion and excitation (TI) determines which tissues are suppressed.
        *   **STIR (Short TI Inversion Recovery):** Uses TI ≈ 150-170 ms at 1.5T to null fat signal (appears dark). Useful for fat suppression, especially in musculoskeletal imaging and when fat/water separation is needed.
        *   **FLAIR (Fluid Attenuated Inversion Recovery):** Uses TI ≈ 2000-2500 ms at 1.5T to null CSF signal while maintaining T2 weighting for other tissues. Extremely valuable for detecting periventricular and cortical lesions in neuroimaging.
    *   **Fast/Turbo Spin Echo (FSE/TSE):** Modification of SE that acquires multiple echoes (echo train) after a single excitation by applying a series of 180° refocusing pulses. Each echo is encoded with a different phase-encode step, allowing multiple k-space lines to be filled per TR. The echo train length (ETL) or turbo factor determines the acceleration factor. Effective TE (TEeff) is the TE of the echo used to fill the center of k-space, which primarily determines the image contrast.
        *   Advantages: Dramatically reduced scan time, reduced motion sensitivity
        *   Disadvantages: Increased SAR (due to multiple 180° pulses), potential blurring (T2 decay during echo train), different contrast behavior than conventional SE
        *   Clinical applications: Standard for T2-weighted imaging in most body regions
    *   **Echo Planar Imaging (EPI):** Ultra-fast sequence that acquires all or multiple lines of k-space after a single excitation by rapidly oscillating the readout gradient while incrementing the phase-encode gradient in small steps. Single-shot EPI acquires the entire k-space in one TR (tens of milliseconds).
        *   Advantages: Extremely fast acquisition (useful for functional MRI, diffusion, perfusion)
        *   Disadvantages: Low spatial resolution, high sensitivity to susceptibility artifacts and chemical shift, geometric distortion
        *   Clinical applications: Diffusion-weighted imaging (DWI), functional MRI (fMRI), perfusion imaging, real-time imaging

[ILLUSTRATION: Pulse sequence diagrams for Spin Echo and Gradient Echo sequences showing RF pulses, gradient waveforms, and signal acquisition. Diagram comparing T1, T2, and PD-weighted images of the same brain slice, highlighting how different tissues appear in each. Diagram showing the effect of TI selection in Inversion Recovery sequences, with the magnetization evolution and signal nulling point. Comparison of k-space filling strategies for conventional SE vs. Fast/Turbo SE vs. EPI.]

**Clinical Example: Sequence Selection for Brain Tumor Evaluation**
When evaluating a suspected brain tumor, the radiologist typically requests multiple sequences to characterize the lesion comprehensively:
1. T1-weighted pre-contrast: Provides anatomical reference and shows subacute hemorrhage as hyperintense.
2. T2-weighted: Shows edema (hyperintense) surrounding the tumor and helps differentiate solid tumor from cystic/necrotic components.
3. FLAIR: Suppresses CSF signal to better visualize periventricular and cortical lesions, particularly valuable for detecting infiltrative tumor components.
4. DWI: Assesses cellularity (restricted diffusion appears bright) to help differentiate abscess (restricted) from necrotic tumor (typically not restricted).
5. T1-weighted post-contrast: Shows areas of blood-brain barrier disruption where contrast extravasates, indicating tumor vascularity and viability.
6. Susceptibility-weighted imaging (SWI): Detects microhemorrhages, calcifications, or tumor-related vascular structures.

The radiologist might request thin-slice (1mm) 3D T1-weighted post-contrast images for surgical planning and volumetric analysis. For follow-up during treatment, standardized protocols ensure consistent positioning and parameters for accurate comparison.

**3.4.4 Advanced Contrast Mechanisms and Applications**

*   **Diffusion-Weighted Imaging (DWI):**
    *   **Physical Basis:** Measures the random Brownian motion of water molecules. In tissues with high cellularity or cytotoxic edema, water diffusion is restricted.
    *   **Acquisition:** Typically uses spin-echo EPI with additional strong bipolar diffusion-sensitizing gradients. The degree of diffusion weighting is determined by the b-value ($b = \gamma^2 G^2 \delta^2 (\Delta - \delta/3)$, where G is gradient amplitude, δ is gradient duration, and Δ is time between gradients).
    *   **Apparent Diffusion Coefficient (ADC):** Calculated from images acquired with different b-values (typically b=0 and b=1000 s/mm²). ADC maps show true diffusion without T2 shine-through effect. Low ADC (dark on ADC map) indicates restricted diffusion.
    *   **Clinical Applications:** 
        *   **Acute Stroke:** Gold standard for early detection (within minutes) of acute ischemic stroke, appearing as restricted diffusion (bright on DWI, dark on ADC).
        *   **Tumor Characterization:** Highly cellular tumors (e.g., lymphoma, high-grade gliomas) show restricted diffusion; treatment response often shows increased diffusion as cell density decreases.
        *   **Infection:** Abscesses typically show restricted diffusion due to viscous pus.
        *   **Diffusion Tensor Imaging (DTI):** Extension of DWI that measures diffusion directionality (anisotropy) to map white matter tracts (tractography).
*   **MR Angiography (MRA):**
    *   **Time-of-Flight (TOF):** Uses flow-related enhancement. Stationary tissues are saturated by repeated RF pulses (short TR), while inflowing blood maintains full magnetization, appearing bright. 2D TOF is used for venography; 3D TOF for intracranial arterial imaging.
    *   **Phase Contrast (PC):** Uses the phase shift induced in moving spins by bipolar gradients. The phase shift is proportional to velocity, allowing quantitative flow measurements. Velocity encoding (VENC) parameter must be set appropriately for the expected flow velocities.
    *   **Contrast-Enhanced MRA (CE-MRA):** Uses T1-shortening effect of gadolinium contrast to highlight vessels. Timing is critical to capture the arterial phase before venous enhancement.
    *   **Clinical Applications:** Evaluation of stenosis, aneurysms, vascular malformations, dissection, and post-surgical vascular patency. Quantitative flow assessment for cardiac output, valve regurgitation, or CSF flow studies.
*   **Functional MRI (fMRI):**
    *   **BOLD (Blood Oxygen Level Dependent) Effect:** Deoxyhemoglobin is paramagnetic and creates microscopic field inhomogeneities, reducing T2* signal. During neural activation, increased blood flow delivers more oxyhemoglobin (diamagnetic), reducing deoxyhemoglobin concentration and increasing signal on T2*-weighted images.
    *   **Acquisition:** Typically uses gradient-echo EPI with TE optimized for BOLD contrast (around 30-40 ms at 3T). Temporal resolution of 2-3 seconds is typical.
    *   **Paradigms:** Block design (alternating task/rest periods) or event-related design. Analysis involves statistical comparison of signal during task vs. rest.
    *   **Clinical Applications:** Presurgical mapping of eloquent cortex (motor, language, vision) to guide neurosurgical approach and minimize functional deficits. Research applications in cognitive neuroscience.
*   **MR Spectroscopy (MRS):**
    *   **Physical Basis:** Measures the chemical shift of different metabolites due to their unique electronic environments, which slightly modify the local magnetic field experienced by protons.
    *   **Acquisition:** Single-voxel or multi-voxel (chemical shift imaging). Uses specialized sequences with water suppression (since water signal is ~10,000 times stronger than metabolites).
    *   **Key Metabolites:** N-acetylaspartate (NAA, neuronal marker), choline (cell membrane turnover), creatine (energy metabolism, often used as reference), lactate (anaerobic metabolism), lipids (cell membrane breakdown), myoinositol (glial marker), glutamate/glutamine, and others.
    *   **Clinical Applications:** Tumor characterization (high choline, low NAA in tumors), differentiation of tumor recurrence from radiation necrosis, metabolic disorders, dementia evaluation, and epilepsy.
*   **Perfusion MRI:**
    *   **Dynamic Susceptibility Contrast (DSC):** Uses T2* effects of gadolinium contrast during first pass through brain vasculature. Provides relative cerebral blood volume (rCBV), mean transit time (MTT), and relative cerebral blood flow (rCBF).
    *   **Dynamic Contrast Enhanced (DCE):** Uses T1 effects of gadolinium to assess blood-brain barrier permeability (Ktrans) and extravascular extracellular space (ve).
    *   **Arterial Spin Labeling (ASL):** Non-contrast technique using magnetically labeled arterial blood water as an endogenous tracer.
    *   **Clinical Applications:** Tumor grading (high-grade tumors show increased rCBV), stroke assessment (penumbra evaluation), neurodegenerative disorders.

[ILLUSTRATION: Diagram showing diffusion-weighted imaging principles, with examples of restricted diffusion in acute stroke and abscess. Comparison of different MRA techniques (TOF, PC, CE-MRA) with their advantages and limitations. Diagram of the BOLD effect mechanism in fMRI, showing the relationship between neural activity, blood flow, and MR signal. MR spectroscopy chart showing typical metabolite peaks and their significance in normal brain vs. tumor.]

**Clinical Example: Comprehensive Stroke Protocol**
A comprehensive stroke MRI protocol demonstrates the power of multiparametric assessment:
1. DWI/ADC: Identifies acute infarct core (restricted diffusion)
2. Perfusion imaging (DSC or ASL): Identifies hypoperfused tissue (potential penumbra)
3. FLAIR: Shows established infarcts and helps determine stroke timing (DWI-FLAIR mismatch suggests <4.5 hours)
4. GRE/SWI: Detects hemorrhagic transformation
5. MRA (TOF or CE-MRA): Identifies vascular occlusion or stenosis
6. T1-weighted: Evaluates for underlying structural abnormalities

The "mismatch" between the small DWI lesion (infarct core) and larger perfusion deficit (tissue at risk) helps identify patients who might benefit from late thrombectomy beyond the standard time window. This physiological selection has revolutionized stroke treatment, extending the treatment window to 24 hours in selected patients.

**3.4.5 MRI Hardware Components**

*   **Main Magnet:**
    *   **Types:**
        *   **Superconducting Magnets:** Most common in clinical systems. Use liquid helium-cooled superconducting wire (typically niobium-titanium) to generate strong, stable fields (1.5T, 3.0T, and now 7.0T for clinical use). Advantages: High field strength, excellent homogeneity. Disadvantages: Expensive, requires cryogens, always on (cannot be easily turned off).
        *   **Permanent Magnets:** Use permanent magnetic materials (typically rare-earth magnets). Typically lower field (0.2-0.5T). Advantages: No cryogens, lower cost, open design possible. Disadvantages: Lower field strength, heavy, temperature-sensitive.
        *   **Resistive Magnets:** Use conventional wire with electric current. Typically very low field (<0.5T). Advantages: Low cost, no cryogens, can be turned off. Disadvantages: Low field strength, power consumption, heating.
    *   **Field Strength Considerations:** Higher field provides better SNR (approximately linear with $B_0$), allowing higher spatial resolution or faster scanning. However, higher field also increases susceptibility artifacts, chemical shift, RF power deposition (SAR), and acoustic noise.
    *   **Homogeneity:** Typically specified as parts per million (ppm) over a defined spherical volume (DSV). Clinical magnets achieve ~1 ppm over 40-50 cm DSV. Homogeneity is critical for fat suppression, spectroscopy, and minimizing geometric distortion.
*   **Gradient System:**
    *   **Function:** Produces linear magnetic field variations for spatial encoding and other purposes (diffusion weighting, flow compensation, etc.).
    *   **Performance Metrics:**
        *   **Maximum Amplitude:** Typically 20-80 mT/m for clinical systems. Higher amplitude allows thinner slices, stronger diffusion weighting, and reduced echo spacing in EPI.
        *   **Slew Rate:** Rate of gradient change, typically 100-200 T/m/s. Higher slew rate allows faster sequences but increases risk of peripheral nerve stimulation.
        *   **Rise Time:** Time to reach maximum amplitude, typically 200-300 μs.
        *   **Duty Cycle:** Percentage of time gradients can operate at maximum performance without overheating.
    *   **Eddy Currents:** Rapid gradient switching induces currents in nearby conducting structures, causing image artifacts. Modern systems use active shielding and pre-emphasis correction to minimize these effects.
    *   **Acoustic Noise:** Lorentz forces on gradient coils cause vibration, producing loud noise (up to 120 dB). Mitigation strategies include acoustic insulation, quieter sequence designs, and providing hearing protection.
*   **RF System:**
    *   **Transmit System:** Generates RF pulses at the Larmor frequency to excite spins. Includes RF synthesizer, power amplifier (typically 15-35 kW peak power), and transmit coil(s).
    *   **Receive System:** Detects the weak MR signal (nanovolts to microvolts). Includes receive coil(s), preamplifiers, and signal processing electronics.
    *   **RF Coils:**
        *   **Body Coil:** Built into the scanner bore, used for transmission in most exams and reception for large FOV imaging.
        *   **Surface Coils:** Placed close to the anatomy of interest. Higher SNR but limited depth penetration. Examples include spine arrays, head coils, knee coils, shoulder coils, breast coils, etc.
        *   **Phased Array Coils:** Multiple coil elements with separate receiver channels, combined to maximize SNR and enable parallel imaging.
        *   **Transmit/Receive (T/R) Coils:** Used for both transmission and reception, typically for specialized applications (e.g., knee, wrist, head at 3T+).
    *   **Parallel Imaging:** Uses spatial information from multiple coil elements to reduce the number of phase-encoding steps required, accelerating acquisition. Common implementations include SENSE (SENSitivity Encoding) and GRAPPA (GeneRalized Autocalibrating Partially Parallel Acquisitions).
*   **Shim System:**
    *   **Function:** Improves $B_0$ homogeneity by counteracting field distortions caused by the patient and environment.
    *   **Passive Shimming:** Uses strategically placed ferromagnetic materials during installation to optimize the empty magnet homogeneity.
    *   **Active Shimming:** Uses additional electromagnetic coils to correct patient-specific field inhomogeneities. Includes:
        *   **Zero-order shim:** Adjusts the center frequency.
        *   **First-order shims:** Linear gradients in x, y, z (often integrated with the gradient system).
        *   **Higher-order shims:** More complex spatial patterns for better correction.
    *   **Shimming Procedures:** Global shimming optimizes the entire imaging volume; localized shimming targets a specific region (critical for spectroscopy and EPI).
*   **Computer System:**
    *   **Host Computer:** User interface for protocol selection, patient registration, and image viewing.
    *   **Sequence Controller:** Real-time control of gradient and RF waveforms.
    *   **Image Processor:** Reconstruction of raw data into images, including Fourier transformation, filtering, and other post-processing.
    *   **Image Storage and Networking:** DICOM format, PACS integration.

[ILLUSTRATION: Cross-sectional diagram of a superconducting MRI system showing the main components (magnet, gradient coils, RF coils, patient table). Diagram of gradient coil design showing the wire patterns for x, y, and z gradients. Illustrations of various RF coil types (body coil, head coil, surface coil, phased array) with their sensitivity profiles. Diagram showing the concept of active shimming with different order shim coils.]

**Clinical Example: Hardware Selection for Specific Applications**
Different clinical applications require optimized hardware configurations:
1. **Neuroimaging at 3T:** Uses a dedicated 32-channel head coil to maximize SNR for high-resolution structural imaging (0.8mm isotropic), fMRI, and DTI. Higher-order shimming is essential for reducing susceptibility artifacts in the temporal lobes and near the sinuses.
2. **Musculoskeletal Imaging:** Dedicated extremity coils (knee, ankle, wrist) provide high SNR for detailed cartilage and ligament evaluation. Some centers use specialized 1.5T systems with open bore designs for claustrophobic patients or to accommodate larger patients.
3. **Cardiac MRI:** Uses a combination of anterior and posterior phased array coils, along with ECG gating and respiratory navigation. Gradient performance is critical for fast imaging during brief cardiac rest periods.
4. **Breast MRI:** Dedicated bilateral breast coils with apertures for the breasts to hang pendulously, minimizing motion and optimizing positioning for biopsy access if needed.

**3.4.6 Image Quality and Artifacts**

*   **Image Quality Metrics:**
    *   **Signal-to-Noise Ratio (SNR):** Ratio of signal amplitude to noise amplitude. SNR ∝ $B_0 \cdot \sqrt{N_{acq}} \cdot \sqrt{N_{phase}} \cdot \sqrt{N_{freq}} \cdot \sqrt{NEX} \cdot \text{voxel volume}$, where $N_{acq}$ is the number of signal-producing nuclei per voxel, $N_{phase}$ and $N_{freq}$ are the number of phase and frequency encoding steps, and NEX is the number of excitations (averages).
    *   **Contrast-to-Noise Ratio (CNR):** Difference in SNR between two tissues. CNR = $|SNR_A - SNR_B|$. Determines the ability to distinguish adjacent structures.
    *   **Spatial Resolution:** Ability to distinguish small structures, determined by voxel size (FOV/matrix size) and influenced by factors like point spread function and k-space filtering.
    *   **Temporal Resolution:** Time to acquire a complete image or dataset, critical for dynamic studies (cardiac, perfusion, fMRI).
*   **Factors Affecting Image Quality:**
    *   **Acquisition Parameters:** TR, TE, flip angle, matrix size, FOV, slice thickness, bandwidth, NEX.
    *   **Hardware Performance:** Field strength, gradient capabilities, RF coil design and positioning.
    *   **Patient Factors:** Motion, implants, body habitus, physiological noise (e.g., CSF pulsation, respiratory motion).
    *   **Reconstruction Techniques:** Filtering, interpolation, parallel imaging reconstruction algorithms.
*   **Common Artifacts and Mitigation Strategies:**
    *   **Patient-Related Artifacts:**
        *   **Motion:** Causes ghosting in the phase-encode direction. Mitigation: Immobilization, sedation if necessary, motion-resistant sequences (radial acquisition, PROPELLER/BLADE), motion correction algorithms, cardiac/respiratory gating.
        *   **Flow:** Causes signal loss, ghosting, or misregistration. Mitigation: Flow compensation gradients, saturation bands, cardiac gating, black-blood techniques.
        *   **Metal:** Causes severe signal loss, geometric distortion, and bright areas. Mitigation: Special metal artifact reduction sequences (MARS, SEMAC, MAVRIC) with increased bandwidth and view-angle tilting.
    *   **Physics-Related Artifacts:**
        *   **Chemical Shift:** Misregistration between fat and water due to their different resonance frequencies (~3.5 ppm difference). First-order shift appears as spatial displacement in the frequency-encode direction; second-order shift appears as bright/dark bands at fat-water interfaces. Mitigation: Fat suppression techniques, increased bandwidth, swapping phase/frequency directions.
        *   **Magnetic Susceptibility:** Local field distortions at tissue interfaces with different magnetic susceptibilities (air/tissue, bone/tissue). Causes signal loss and geometric distortion, especially in GRE and EPI sequences. Mitigation: Shorter TE, spin echo instead of gradient echo, increased bandwidth, thinner slices.
        *   **B₀ Inhomogeneity:** Causes geometric distortion, signal intensity variation, and fat suppression failure. Mitigation: Careful shimming, shorter echo trains, reduced FOV.
    *   **System-Related Artifacts:**
        *   **Aliasing/Wrap-around:** Occurs when the anatomy extends beyond the FOV, with signal from outside "wrapping" to the opposite side of the image. Mitigation: Larger FOV, phase oversampling, saturation bands.
        *   **Zipper/RF Interference:** Appears as a line or band of noise across the image due to external RF interference. Mitigation: Ensure proper room shielding, remove sources of interference, use RF-safe equipment.
        *   **Gibbs Ringing/Truncation:** Appears as parallel lines near high-contrast boundaries due to finite k-space sampling. Mitigation: Higher matrix size, post-processing filters.
        *   **Gradient Nonlinearity:** Causes geometric distortion, especially at the periphery of large FOVs. Mitigation: Gradient distortion correction algorithms.
    *   **Sequence-Specific Artifacts:**
        *   **EPI Distortion:** Severe susceptibility effects and chemical shift in the phase-encode direction. Mitigation: Parallel imaging to reduce echo spacing, distortion correction using field maps.
        *   **Stimulated Echoes:** Unwanted signal pathways in multi-echo sequences causing image artifacts. Mitigation: Crusher gradients, optimized refocusing flip angles.
        *   **Magic Angle Effect:** Increased signal in tendons and ligaments oriented at ~55° to $B_0$ due to reduced dipolar coupling. Not truly an artifact but can mimic pathology. Mitigation: Awareness of the effect, comparison with other sequences.

[ILLUSTRATION: Series of images showing common MRI artifacts with explanations of their causes and appearance. Comparison of the same anatomical region with different acquisition parameters to demonstrate the trade-offs between SNR, resolution, and scan time. Diagram showing the relationship between k-space sampling and image resolution/FOV.]

**Clinical Example: Artifact Recognition and Problem-Solving**
A patient with a total hip replacement undergoes an MRI to evaluate for suspected infection. The standard sequences show severe metal artifacts obscuring the periprosthetic tissues. The technologist recognizes the problem and switches to a metal artifact reduction protocol that includes:
1. Increased receiver bandwidth to reduce chemical shift and susceptibility effects
2. View angle tilting to correct in-plane distortions
3. SEMAC or MAVRIC techniques to correct through-plane distortions
4. Optimized TE and readout direction
5. Thinner slices with gap

The resulting images show dramatically reduced artifacts, allowing visualization of a fluid collection consistent with abscess. This example demonstrates how understanding the physical basis of artifacts enables appropriate protocol modifications to overcome technical challenges.

**3.4.7 MRI Safety**

MRI involves multiple potential hazards requiring strict safety protocols. The ACR divides the MR environment into four zones with progressively restricted access.

*   **Static Magnetic Field ($B_0$) Hazards:**
    *   **Projectile Effect:** Ferromagnetic objects experience strong attractive forces (proportional to field strength, field gradient, object mass, and magnetic susceptibility). Objects can become dangerous projectiles, accelerating toward the magnet with potentially lethal force. Incidents have resulted in serious injuries and deaths.
    *   **Implanted Devices:** Interaction with ferromagnetic components in implants can cause movement, dislodgement, or malfunction. Particular concerns include:
        *   **Pacemakers/ICDs:** Modern MR-conditional devices are available, but require specific protocols and monitoring.
        *   **Aneurysm Clips:** Older ferromagnetic clips may dislodge; newer titanium clips are generally safe.
        *   **Cochlear Implants:** May be damaged or dislodged.
        *   **Metallic Foreign Bodies:** Especially concerning in critical locations (eyes, vasculature, CNS).
    *   **Biological Effects:** Vertigo, nausea, metallic taste, or phosphenes (visual light flashes) when moving quickly through the fringe field, due to electromagnetic induction in tissues.
    *   **Mitigation:** Thorough patient screening (written questionnaire and verbal interview), staff education, restricted access to Zone IV, ferromagnetic detection systems, clear marking of MR-safe vs. MR-unsafe equipment.
*   **Time-Varying Gradient Field Hazards:**
    *   **Peripheral Nerve Stimulation (PNS):** Rapidly changing magnetic fields induce electric currents in conductive tissues, potentially causing nerve stimulation, muscle twitching, or pain. The threshold for PNS depends on gradient slew rate, patient size, and orientation.
    *   **Acoustic Noise:** Gradient switching creates loud noise (80-120 dB) that can cause discomfort and potentially hearing damage.
    *   **Implanted Devices:** Gradient switching can induce currents in conductive implants or leads, potentially causing heating or device malfunction.
    *   **Mitigation:** Operating gradients below PNS thresholds when possible, providing hearing protection (earplugs/headphones, minimum 30 dB attenuation), using quieter sequences when appropriate, careful screening of implanted devices.
*   **Radiofrequency (RF) Field Hazards:**
    *   **Tissue Heating:** RF pulses deposit energy in tissues, measured as Specific Absorption Rate (SAR, W/kg). Excessive SAR can cause tissue heating and burns. SAR increases with field strength (∝ $B_0^2$), RF duty cycle, transmit coil type, and patient size.
    *   **Implants and Devices:** Conductive materials can concentrate RF energy, causing localized heating. Particular concerns include:
        *   **Abandoned leads:** Disconnected pacemaker/neurostimulator leads without the device.
        *   **External cables:** ECG leads, pulse oximeters, etc., which can form loops.
        *   **Tattoos:** Especially those with metallic pigments, which can heat and cause burns.
    *   **Mitigation:** SAR monitoring and limits (whole-body: 4 W/kg for short-term exposure, 2 W/kg for normal operation; head: 3.2 W/kg), removing unnecessary conductive materials, avoiding loops in cables, careful positioning to prevent skin-to-skin contact points, using lower SAR sequences when appropriate.
*   **Cryogen Hazards:**
    *   **Quench:** Sudden boil-off of liquid helium, converting to gas (expansion ratio ~1:700) and potentially displacing oxygen in the scan room if venting fails.
    *   **Mitigation:** Proper quench pipe installation and maintenance, oxygen monitors, emergency procedures for quench events.
*   **Contrast Agent Hazards:**
    *   **Nephrogenic Systemic Fibrosis (NSF):** Rare but serious condition linked to gadolinium-based contrast agents (GBCAs) in patients with severe renal impairment. Modern macrocyclic GBCAs have minimal risk.
    *   **Gadolinium Deposition:** Long-term retention of gadolinium in brain and other tissues, clinical significance unclear.
    *   **Allergic Reactions:** Rare but possible, similar to other contrast media.
    *   **Mitigation:** Screening for renal function, using macrocyclic agents, appropriate dosing, and monitoring for reactions.
*   **Pregnancy Considerations:**
    *   No known harmful effects of MRI on the fetus have been documented, but caution is advised, especially in the first trimester.
    *   ACOG and ACR guidelines suggest MRI can be performed if the benefit outweighs the risk, preferably after the first trimester.
    *   Gadolinium contrast crosses the placenta and should be avoided unless absolutely necessary.
*   **Claustrophobia and Anxiety:**
    *   Approximately 5-10% of patients experience significant anxiety or claustrophobia during MRI.
    *   Mitigation strategies include explanation and reassurance, allowing a companion in the room, prism glasses, music/entertainment, shorter protocols, open-bore systems, or sedation if necessary.
*   **MR Safety Screening and Zones:**
    *   **Zone I:** Public access, uncontrolled.
    *   **Zone II:** Interface between public and restricted areas, where patient screening occurs.
    *   **Zone III:** Restricted access, controlled by MR personnel, contains control room.
    *   **Zone IV:** Scanner room, highest risk area, strictest access control.
    *   Thorough screening includes written questionnaire, verbal interview, and sometimes ferromagnetic detection.
    *   MR personnel are classified as Level 1 (basic safety training) or Level 2 (comprehensive training, authorized to make safety decisions).

[ILLUSTRATION: Diagram of the four MR safety zones with access restrictions. Images showing examples of the projectile effect and proper equipment labeling (MR Safe, MR Conditional, MR Unsafe). Diagram illustrating SAR distribution in the human body at different field strengths. Flowchart for screening patients with implanted devices.]

**Clinical Example: Managing a Patient with an Implanted Device**
A patient with a recently implanted MR-conditional pacemaker requires an MRI to evaluate for suspected spinal cord compression. The MR safety officer follows a comprehensive protocol:
1. Obtains complete device information (manufacturer, model, implant date)
2. Confirms the specific device is MR-conditional and identifies the required conditions (field strength limits, SAR limits, excluded body regions)
3. Coordinates with cardiology to program the device to MR mode before the scan
4. Selects appropriate sequences that meet the SAR and gradient limitations
5. Ensures continuous monitoring (ECG, pulse oximetry, verbal communication)
6. Positions the patient to minimize RF exposure to the device
7. Returns the patient to cardiology after the scan to restore normal device settings and confirm proper function

This example demonstrates the multidisciplinary approach required for safe scanning of patients with implanted devices, balancing the diagnostic benefit against potential risks.

**3.4.8 Quality Assurance in MRI**

Regular quality assurance (QA) testing is essential to maintain optimal scanner performance and image quality.

*   **Phantom Types:**
    *   **ACR MRI Phantom:** Standard for accreditation, contains various test structures for comprehensive evaluation.
    *   **Uniform Phantoms:** Spherical or cylindrical containers with uniform solution (typically doped water) for SNR, uniformity, and ghosting measurements.
    *   **Geometric Phantoms:** Contain precise geometric structures for spatial accuracy assessment.
    *   **Specialized Phantoms:** For specific tests like slice profile, eddy currents, or gradient calibration.
*   **Key QA Parameters and Tests:**
    *   **Center Frequency and Transmitter Gain:** Verified daily through auto-prescan procedures.
    *   **Signal-to-Noise Ratio (SNR):** Measured using uniform phantom, comparing signal intensity to background noise. Should remain within ±10% of baseline.
    *   **Image Uniformity:** Assesses $B_0$ and $B_1$ homogeneity. Measured as percentage integral uniformity or coefficient of variation across a uniform region.
    *   **Geometric Accuracy:** Measures dimensions of known structures to verify gradient calibration and absence of distortion.
    *   **Slice Position Accuracy:** Verifies that slices are positioned correctly relative to the prescribed location.
    *   **Slice Thickness Accuracy:** Measures actual slice profile compared to nominal thickness.
    *   **Spatial Resolution:** Assesses ability to resolve small structures, typically using line pair patterns or hole arrays.
    *   **Ghosting/Artifact Analysis:** Quantifies ghosting ratio in phase-encode direction, indicating system stability.
    *   **Gradient Performance:** Tests for eddy currents, linearity, and timing accuracy.
    *   **RF Coil Tests:** Evaluates individual coil element function, isolation between elements, and overall coil performance.
*   **QA Schedule:**
    *   **Daily:** Basic system checks (center frequency, transmitter calibration, SNR quick check).
    *   **Weekly:** SNR, uniformity, artifact analysis.
    *   **Monthly:** Geometric accuracy, slice position/thickness, spatial resolution.
    *   **Quarterly:** Comprehensive testing of all parameters, including specialized coils.
    *   **Annual:** Complete system evaluation, often by service engineer, including gradient calibration, shim system, and hardware performance.
*   **Preventive Maintenance:**
    *   Regular cryogen level monitoring and refills for superconducting systems.
    *   Chiller system maintenance for gradient cooling.
    *   RF room integrity testing (typically annual).
    *   Hardware and software updates as recommended by manufacturer.
*   **Documentation and Trending:**
    *   Maintaining records of all QA tests and results.
    *   Tracking parameters over time to identify gradual drift before clinical impact.
    *   Establishing action limits for each parameter.
*   **Clinical Image Quality Monitoring:**
    *   Regular review of clinical images by radiologists and physicists.
    *   Feedback mechanism for technologists to report quality concerns.
    *   Protocol optimization based on clinical needs and image quality assessment.

[ILLUSTRATION: Images of standard MRI phantoms with annotations showing the structures used for different tests. Example QA test results showing acceptable vs. unacceptable performance for key parameters. Flowchart of the QA process, including testing frequency, documentation, and action thresholds.]

**Clinical Example: Troubleshooting Image Quality Issues**
A radiologist notices subtle horizontal bands across recent brain MRI images. The medical physicist performs targeted QA tests and identifies increased ghosting in the phase-encode direction. Further investigation reveals that the ghosting correlates with the cooling system cycle. Maintenance finds a failing component in the gradient cooling system causing mechanical vibration synchronized with the compressor cycle. After repair, the ghosting artifact resolves, demonstrating the value of systematic QA and troubleshooting processes.

**Assessment Questions:**

1. A 45-year-old patient undergoes a brain MRI at 3T. The T1 relaxation time of white matter at this field strength is approximately 850 ms. If a Spin Echo sequence with TR = 500 ms is used, what percentage of the equilibrium longitudinal magnetization (M₀) will be recovered just before the next excitation pulse?
   A. 44%
   B. 56%
   C. 63%
   D. 75%
   E. 95%

2. A radiologist needs to evaluate a patient with suspected multiple sclerosis. Which of the following pulse sequence parameters would be MOST appropriate for detecting periventricular demyelinating lesions?
   A. T1-weighted: TR = 500 ms, TE = 15 ms
   B. T2-weighted: TR = 4000 ms, TE = 100 ms
   C. Proton Density: TR = 2500 ms, TE = 20 ms
   D. FLAIR: TR = 9000 ms, TE = 125 ms, TI = 2500 ms
   E. T1-weighted post-contrast: TR = 600 ms, TE = 15 ms

3. A medical physicist is measuring the slice profile of a 3 mm slice using a 90° sinc pulse with a time-bandwidth product of 4. The slice-select gradient strength is 10 mT/m. What is the approximate bandwidth of the RF pulse required to excite this slice?
   A. 0.5 kHz
   B. 1.3 kHz
   C. 2.6 kHz
   D. 5.1 kHz
   E. 10.2 kHz

4. During a cardiac MRI, a technologist observes significant ghosting artifacts in the phase-encode direction. Which of the following modifications would be MOST effective in reducing these artifacts?
   A. Increase the receiver bandwidth
   B. Switch the phase and frequency encoding directions
   C. Implement cardiac gating
   D. Increase the number of signal averages (NEX)
   E. Use a smaller field of view

5. A patient with a history of renal failure (eGFR = 25 mL/min/1.73m²) requires an MRI to evaluate a spinal cord lesion. Which of the following approaches regarding contrast administration is most appropriate?
   A. Use a standard dose of any available gadolinium-based contrast agent
   B. Use a half-dose of any available gadolinium-based contrast agent
   C. Use a standard dose of a macrocyclic gadolinium-based contrast agent
   D. Use a standard dose of a macrocyclic gadolinium-based contrast agent with hemodialysis afterward
   E. Avoid gadolinium-based contrast agents and optimize non-contrast sequences

**Answers:**
1. B. Using the T1 recovery equation: $M_z(TR) = M_0 (1 - e^{-TR/T1}) = M_0 (1 - e^{-500/850}) = M_0 \times 0.56$ or 56% of M₀.

2. D. FLAIR (Fluid Attenuated Inversion Recovery) is most sensitive for detecting periventricular MS lesions because it suppresses CSF signal while maintaining T2 weighting, increasing lesion conspicuity at the CSF-parenchyma interface.

3. C. The bandwidth (BW) required for a slice of thickness Δz with gradient strength G is: $BW = \gamma \cdot G \cdot \Delta z = 42.58 \text{ MHz/T} \cdot 10 \text{ mT/m} \cdot 0.003 \text{ m} = 1.28 \text{ kHz}$. With a time-bandwidth product of 4, the required RF bandwidth is $4 \times 1.28 \text{ kHz} = 5.12 \text{ kHz}$, but this is for the full width of the pulse. The half-width (which corresponds to the slice thickness) would be approximately 2.6 kHz.

4. C. The ghosting artifacts in cardiac MRI are primarily due to cardiac motion. Cardiac gating synchronizes data acquisition with the cardiac cycle, significantly reducing motion artifacts.

5. E. For a patient with severe renal impairment (eGFR < 30 mL/min/1.73m²), the safest approach is to avoid gadolinium-based contrast agents due to the risk of Nephrogenic Systemic Fibrosis (NSF). Optimizing non-contrast sequences (e.g., STIR, diffusion-weighted imaging) is the preferred strategy.

**References:**
1. Brown RW, Cheng YN, Haacke EM, Thompson MR, Venkatesan R. Magnetic Resonance Imaging: Physical Principles and Sequence Design. 2nd ed. Wiley-Blackwell; 2014.
2. McRobbie DW, Moore EA, Graves MJ, Prince MR. MRI from Picture to Proton. 3rd ed. Cambridge University Press; 2017.
3. Bernstein MA, King KF, Zhou XJ. Handbook of MRI Pulse Sequences. Academic Press; 2004.
4. ACR Manual on MR Safety. American College of Radiology; 2020.
5. Bushberg JT, Seibert JA, Leidholdt EM, Boone JM. The Essential Physics of Medical Imaging. 3rd ed. Lippincott Williams & Wilkins; 2011.
