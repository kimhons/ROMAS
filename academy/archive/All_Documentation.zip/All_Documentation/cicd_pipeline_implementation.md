# CI/CD Pipeline Implementation for Radiation Oncology Academy

This document outlines the Continuous Integration/Continuous Deployment (CI/CD) pipeline configuration for the Radiation Oncology Academy platform, covering both the iOS and Android mobile applications as well as the web platform.

## Overview

The CI/CD pipeline will automate the build, test, and deployment processes, ensuring consistent quality and streamlining the release workflow. The pipeline will be implemented using GitHub Actions, which provides seamless integration with our GitHub repository.

## Repository Structure

```
radiation-oncology-academy/
├── .github/
│   └── workflows/
│       ├── ios_build.yml
│       ├── android_build.yml
│       ├── web_build.yml
│       ├── ios_deploy.yml
│       ├── android_deploy.yml
│       └── web_deploy.yml
├── ios/
│   └── RadiationOncologyApp/
├── android/
│   └── RadiationOncologyApp/
└── web/
    └── radiation_oncology_academy/
```

## GitHub Actions Workflow Files

### 1. iOS Build Workflow

```yaml
# .github/workflows/ios_build.yml
name: iOS Build

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'ios/**'
      - '.github/workflows/ios_build.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'ios/**'
  workflow_dispatch:

jobs:
  build:
    name: Build iOS App
    runs-on: macos-latest
    
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3
      
      - name: Setup Ruby
        uses: ruby/setup-ruby@v1
        with:
          ruby-version: '3.0'
          bundler-cache: true
      
      - name: Install Dependencies
        run: |
          cd ios/RadiationOncologyApp
          bundle install
          pod install
      
      - name: Setup Xcode
        uses: maxim-lobanov/setup-xcode@v1
        with:
          xcode-version: '14.x'
      
      - name: Build iOS App
        run: |
          cd ios/RadiationOncologyApp
          bundle exec fastlane build
      
      - name: Run Tests
        run: |
          cd ios/RadiationOncologyApp
          bundle exec fastlane test
      
      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v3
        with:
          name: ios-build
          path: ios/RadiationOncologyApp/build
```

### 2. Android Build Workflow

```yaml
# .github/workflows/android_build.yml
name: Android Build

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'android/**'
      - '.github/workflows/android_build.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'android/**'
  workflow_dispatch:

jobs:
  build:
    name: Build Android App
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3
      
      - name: Setup Java
        uses: actions/setup-java@v3
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'
      
      - name: Grant Execute Permission for Gradlew
        run: chmod +x android/RadiationOncologyApp/gradlew
      
      - name: Build Android App
        run: |
          cd android/RadiationOncologyApp
          ./gradlew assembleRelease
      
      - name: Run Tests
        run: |
          cd android/RadiationOncologyApp
          ./gradlew test
      
      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v3
        with:
          name: android-build
          path: android/RadiationOncologyApp/app/build/outputs/apk/release
```

### 3. Web Build Workflow

```yaml
# .github/workflows/web_build.yml
name: Web Build

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'web/**'
      - '.github/workflows/web_build.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'web/**'
  workflow_dispatch:

jobs:
  build:
    name: Build Web Platform
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: web/radiation_oncology_academy/package-lock.json
      
      - name: Install Dependencies
        run: |
          cd web/radiation_oncology_academy
          npm ci
      
      - name: Build Web Platform
        run: |
          cd web/radiation_oncology_academy
          npm run build
      
      - name: Run Tests
        run: |
          cd web/radiation_oncology_academy
          npm test
      
      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v3
        with:
          name: web-build
          path: web/radiation_oncology_academy/build
```

### 4. iOS Deploy Workflow

```yaml
# .github/workflows/ios_deploy.yml
name: iOS Deploy

on:
  workflow_dispatch:
    inputs:
      deploy_type:
        description: 'Deploy Type'
        required: true
        default: 'testflight'
        type: choice
        options:
          - testflight
          - appstore

jobs:
  deploy:
    name: Deploy iOS App
    runs-on: macos-latest
    
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3
      
      - name: Setup Ruby
        uses: ruby/setup-ruby@v1
        with:
          ruby-version: '3.0'
          bundler-cache: true
      
      - name: Install Dependencies
        run: |
          cd ios/RadiationOncologyApp
          bundle install
          pod install
      
      - name: Setup Xcode
        uses: maxim-lobanov/setup-xcode@v1
        with:
          xcode-version: '14.x'
      
      - name: Setup App Store Connect API Key
        env:
          APP_STORE_CONNECT_KEY_ID: ${{ secrets.APP_STORE_CONNECT_KEY_ID }}
          APP_STORE_CONNECT_ISSUER_ID: ${{ secrets.APP_STORE_CONNECT_ISSUER_ID }}
          APP_STORE_CONNECT_KEY_CONTENT: ${{ secrets.APP_STORE_CONNECT_KEY_CONTENT }}
        run: |
          mkdir -p ~/.appstoreconnect/private_keys
          echo "$APP_STORE_CONNECT_KEY_CONTENT" > ~/.appstoreconnect/private_keys/AuthKey_$APP_STORE_CONNECT_KEY_ID.p8
      
      - name: Deploy to TestFlight
        if: ${{ github.event.inputs.deploy_type == 'testflight' }}
        run: |
          cd ios/RadiationOncologyApp
          bundle exec fastlane beta
      
      - name: Deploy to App Store
        if: ${{ github.event.inputs.deploy_type == 'appstore' }}
        run: |
          cd ios/RadiationOncologyApp
          bundle exec fastlane release
      
      - name: Send Notification
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          fields: repo,message,commit,author,action,eventName,ref,workflow
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
        if: always()
```

### 5. Android Deploy Workflow

```yaml
# .github/workflows/android_deploy.yml
name: Android Deploy

on:
  workflow_dispatch:
    inputs:
      deploy_type:
        description: 'Deploy Type'
        required: true
        default: 'internal'
        type: choice
        options:
          - internal
          - alpha
          - beta
          - production

jobs:
  deploy:
    name: Deploy Android App
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3
      
      - name: Setup Java
        uses: actions/setup-java@v3
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'
      
      - name: Grant Execute Permission for Gradlew
        run: chmod +x android/RadiationOncologyApp/gradlew
      
      - name: Decode Service Account Key
        env:
          GOOGLE_PLAY_SERVICE_ACCOUNT_KEY: ${{ secrets.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY }}
        run: |
          echo $GOOGLE_PLAY_SERVICE_ACCOUNT_KEY > android/service-account-key.json
      
      - name: Build Android App Bundle
        run: |
          cd android/RadiationOncologyApp
          ./gradlew bundleRelease
      
      - name: Sign Android App Bundle
        uses: r0adkll/sign-android-release@v1
        with:
          releaseDirectory: android/RadiationOncologyApp/app/build/outputs/bundle/release
          signingKeyBase64: ${{ secrets.ANDROID_SIGNING_KEY }}
          alias: ${{ secrets.ANDROID_SIGNING_KEY_ALIAS }}
          keyStorePassword: ${{ secrets.ANDROID_SIGNING_STORE_PASSWORD }}
          keyPassword: ${{ secrets.ANDROID_SIGNING_KEY_PASSWORD }}
      
      - name: Deploy to Internal Testing
        if: ${{ github.event.inputs.deploy_type == 'internal' }}
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJson: android/service-account-key.json
          packageName: com.radiationoncologyacademy.android
          releaseFiles: android/RadiationOncologyApp/app/build/outputs/bundle/release/app-release.aab
          track: internal
          status: completed
      
      - name: Deploy to Alpha
        if: ${{ github.event.inputs.deploy_type == 'alpha' }}
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJson: android/service-account-key.json
          packageName: com.radiationoncologyacademy.android
          releaseFiles: android/RadiationOncologyApp/app/build/outputs/bundle/release/app-release.aab
          track: alpha
          status: completed
      
      - name: Deploy to Beta
        if: ${{ github.event.inputs.deploy_type == 'beta' }}
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJson: android/service-account-key.json
          packageName: com.radiationoncologyacademy.android
          releaseFiles: android/RadiationOncologyApp/app/build/outputs/bundle/release/app-release.aab
          track: beta
          status: completed
      
      - name: Deploy to Production
        if: ${{ github.event.inputs.deploy_type == 'production' }}
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJson: android/service-account-key.json
          packageName: com.radiationoncologyacademy.android
          releaseFiles: android/RadiationOncologyApp/app/build/outputs/bundle/release/app-release.aab
          track: production
          status: completed
      
      - name: Send Notification
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          fields: repo,message,commit,author,action,eventName,ref,workflow
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
        if: always()
```

### 6. Web Deploy Workflow

```yaml
# .github/workflows/web_deploy.yml
name: Web Deploy

on:
  workflow_dispatch:
    inputs:
      environment:
        description: 'Deployment Environment'
        required: true
        default: 'staging'
        type: choice
        options:
          - staging
          - production

jobs:
  deploy:
    name: Deploy Web Platform
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: web/radiation_oncology_academy/package-lock.json
      
      - name: Install Dependencies
        run: |
          cd web/radiation_oncology_academy
          npm ci
      
      - name: Build Web Platform
        run: |
          cd web/radiation_oncology_academy
          npm run build
      
      - name: Deploy to Staging
        if: ${{ github.event.inputs.environment == 'staging' }}
        uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT_STAGING }}'
          channelId: live
          projectId: radiation-oncology-academy-staging
          entryPoint: './web/radiation_oncology_academy'
      
      - name: Deploy to Production
        if: ${{ github.event.inputs.environment == 'production' }}
        uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT_PRODUCTION }}'
          channelId: live
          projectId: radiation-oncology-academy-production
          entryPoint: './web/radiation_oncology_academy'
      
      - name: Send Notification
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          fields: repo,message,commit,author,action,eventName,ref,workflow
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
        if: always()
```

## Fastlane Configuration

### iOS Fastlane Configuration

Create a `Fastfile` in the `ios/RadiationOncologyApp/fastlane` directory:

```ruby
# ios/RadiationOncologyApp/fastlane/Fastfile
default_platform(:ios)

platform :ios do
  desc "Build the iOS app"
  lane :build do
    cocoapods
    gym(
      scheme: "RadiationOncologyApp",
      workspace: "RadiationOncologyApp.xcworkspace",
      export_method: "development",
      clean: true,
      output_directory: "build"
    )
  end

  desc "Run tests"
  lane :test do
    scan(
      scheme: "RadiationOncologyApp",
      workspace: "RadiationOncologyApp.xcworkspace",
      devices: ["iPhone 13"]
    )
  end

  desc "Deploy to TestFlight"
  lane :beta do
    app_store_connect_api_key(
      key_id: ENV["APP_STORE_CONNECT_KEY_ID"],
      issuer_id: ENV["APP_STORE_CONNECT_ISSUER_ID"],
      key_filepath: "~/.appstoreconnect/private_keys/AuthKey_#{ENV['APP_STORE_CONNECT_KEY_ID']}.p8",
      duration: 1200,
      in_house: false
    )
    
    increment_build_number(
      build_number: latest_testflight_build_number + 1
    )
    
    cocoapods
    
    gym(
      scheme: "RadiationOncologyApp",
      workspace: "RadiationOncologyApp.xcworkspace",
      export_method: "app-store",
      clean: true,
      output_directory: "build"
    )
    
    pilot(
      skip_waiting_for_build_processing: true,
      skip_submission: true,
      distribute_external: false
    )
  end

  desc "Deploy to App Store"
  lane :release do
    app_store_connect_api_key(
      key_id: ENV["APP_STORE_CONNECT_KEY_ID"],
      issuer_id: ENV["APP_STORE_CONNECT_ISSUER_ID"],
      key_filepath: "~/.appstoreconnect/private_keys/AuthKey_#{ENV['APP_STORE_CONNECT_KEY_ID']}.p8",
      duration: 1200,
      in_house: false
    )
    
    increment_build_number(
      build_number: latest_testflight_build_number + 1
    )
    
    cocoapods
    
    gym(
      scheme: "RadiationOncologyApp",
      workspace: "RadiationOncologyApp.xcworkspace",
      export_method: "app-store",
      clean: true,
      output_directory: "build"
    )
    
    deliver(
      submit_for_review: true,
      automatic_release: true,
      force: true,
      skip_metadata: false,
      skip_screenshots: false,
      skip_binary_upload: false
    )
  end
end
```

## Required Secrets

The following secrets need to be configured in the GitHub repository:

### iOS Secrets
- `APP_STORE_CONNECT_KEY_ID`: The key ID for App Store Connect API
- `APP_STORE_CONNECT_ISSUER_ID`: The issuer ID for App Store Connect API
- `APP_STORE_CONNECT_KEY_CONTENT`: The private key content for App Store Connect API

### Android Secrets
- `GOOGLE_PLAY_SERVICE_ACCOUNT_KEY`: The service account key for Google Play Console
- `ANDROID_SIGNING_KEY`: The base64-encoded signing key
- `ANDROID_SIGNING_KEY_ALIAS`: The alias for the signing key
- `ANDROID_SIGNING_STORE_PASSWORD`: The keystore password
- `ANDROID_SIGNING_KEY_PASSWORD`: The key password

### Web Secrets
- `FIREBASE_SERVICE_ACCOUNT_STAGING`: The Firebase service account for staging
- `FIREBASE_SERVICE_ACCOUNT_PRODUCTION`: The Firebase service account for production

### Notification Secrets
- `SLACK_WEBHOOK_URL`: The webhook URL for Slack notifications

## Implementation Steps

1. **Repository Setup**:
   - Create the directory structure as outlined above
   - Add the workflow files to the `.github/workflows` directory

2. **iOS Setup**:
   - Install Fastlane in the iOS project
   - Add the Fastfile to the `fastlane` directory
   - Configure the Xcode project for CI/CD

3. **Android Setup**:
   - Configure the Gradle build for CI/CD
   - Generate a signing key for the app
   - Create a service account in Google Play Console

4. **Web Setup**:
   - Configure Firebase hosting for staging and production
   - Set up build scripts in package.json

5. **Secrets Configuration**:
   - Add all required secrets to the GitHub repository
   - Ensure proper access control for sensitive information

6. **Testing the Pipeline**:
   - Trigger the build workflows manually
   - Verify that builds complete successfully
   - Test the deployment workflows with staging environments

## Monitoring and Notifications

The CI/CD pipeline includes Slack notifications for build and deployment status. These notifications will be sent to the configured Slack channel for:

- Build successes and failures
- Deployment successes and failures
- Test results

## Maintenance and Updates

The CI/CD pipeline should be regularly maintained to ensure it continues to function correctly:

1. **Regular Updates**:
   - Update GitHub Actions versions
   - Update Fastlane and other dependencies
   - Review and update workflow configurations

2. **Security Audits**:
   - Regularly rotate secrets
   - Review access permissions
   - Audit workflow configurations for security issues

3. **Performance Optimization**:
   - Monitor build times
   - Optimize build scripts
   - Implement caching strategies

## Conclusion

This CI/CD pipeline implementation provides a comprehensive automation solution for building, testing, and deploying the Radiation Oncology Academy platform across iOS, Android, and web platforms. By following the implementation steps and maintaining the pipeline, we can ensure consistent quality and streamline the release process.
