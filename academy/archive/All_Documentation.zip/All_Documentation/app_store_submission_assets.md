# App Store Submission Assets for Radiation Oncology Academy

## App Icons
- App Icon (1024x1024px)
- Spotlight Icon (120x120px)
- Settings Icon (58x58px)
- Notification Icon (20x20px)
- App Store Icon (1024x1024px)

## Screenshots
- iPhone 13 Pro Max (1284x2778px)
- iPhone 8 Plus (1242x2208px)
- iPad Pro (2048x2732px)
- iPad (1668x2224px)

## App Preview Videos
- 15-30 second preview video showing key features
- Format: H.264, 30fps
- iPhone 13 Pro Max resolution (1284x2778px)
- iPad Pro resolution (2048x2732px)

## App Information
- App Name: Radiation Oncology Academy
- Subtitle: Professional Education Platform
- Category: Medical, Education
- Secondary Category: Reference
- Keywords: radiation oncology, medical education, oncology training, radiation therapy, cancer treatment, medical podcasts
- Description: [Full app description with formatting]
- What's New: Initial release
- Support URL: https://radiationoncologyacademy.com/support
- Marketing URL: https://radiationoncologyacademy.com
- Privacy Policy URL: https://radiationoncologyacademy.com/privacy

## App Store Connect Information
- SKU: ROA-iOS-2025
- Bundle ID: com.radiationoncologyacademy.ios
- App Version: 1.0.0
- Build Number: 1
- Copyright: © 2025 Radiation Oncology Academy
- Trade Representative Contact Information
- App Review Information (Contact, Notes, Login credentials)
- Content Rights Declaration

## Age Rating Information
- Made for Kids: No
- Age Rating: 17+
- Content Descriptions: Medical/Treatment Information

## App Store Territory Availability
- Pricing: Free with In-App Purchases
- Available territories: All territories
- Availability date: Immediate after approval

## In-App Purchases
- Monthly Subscription: $19.99
- Annual Subscription: $199.99
- Institutional Subscription: $999.99

## Build Submission Checklist
- Archive build in Xcode
- Validate App
- Upload to App Store Connect
- TestFlight Internal Testing
- TestFlight External Testing (Optional)
- Submit for Review

## App Review Guidelines Compliance
- 2.1 Performance: App is fully functional and tested
- 2.3 Accurate Metadata: All descriptions and screenshots are accurate
- 3.1 Payments: In-app purchases properly implemented
- 5.1 Privacy: Privacy policy is comprehensive and accurate
- 5.1.1 Data Collection: Only necessary data is collected
- 5.1.2 Data Use: Clear explanation of how data is used
