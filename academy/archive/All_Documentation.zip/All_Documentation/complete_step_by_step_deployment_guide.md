1. Click "Network Access" in the left sidebar
2. Click the "Add IP Address" button
3. In the "Add IP Address" form:
   - Click "Allow Access from Anywhere" (for simplicity during setup)
4. Click "Confirm"
5. Wait for the status to change from "Pending" to "Active"

## Step 9: Get MongoDB Connection String
1. Click "Database" in the left sidebar
2. Wait for your cluster to finish deploying if it hasn't already
3. Click the "Connect" button for your cluster
4. Select "Connect your application"
5. In the connection string, copy the entire string that looks like:
   `mongodb+srv://roa_admin:<password>@cluster0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`
6. Paste this into your notepad
7. Replace `<password>` with the password you copied earlier
8. Replace `myFirstDatabase` with `radiationOncologyAcademy`

---

# PART 5: CONFIGURATION

## Step 1: Create Environment Variables File
1. Go back to your GoDaddy cPanel File Manager tab
2. Navigate to the radiation_oncology_academy folder if you're not already there
3. In the top menu, click "New File"
4. In the "New File Name" field, type ".env" (including the dot)
5. Click "Create New File"
6. In the file editor that opens, paste the following:

```
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=radiation_oncology_academy_secret_key_2025
OPENAI_API_KEY=your_openai_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
STRIPE_SECRET_KEY=sk_test_51NxSample1234567890abcdefghijklmnopqrstuvwxyz
STRIPE_PUBLISHABLE_KEY=pk_test_51NxSample1234567890abcdefghijklmnopqrstuvwxyz
NODE_ENV=production
PORT=8080
GOOGLE_APPLICATION_CREDENTIALS=/home/username/public_html/radiation_oncology_academy/config/your-service-account-key-filename.json
```

7. Replace the following values:
   - `your_mongodb_connection_string` with the MongoDB connection string from your notepad
   - `your_openai_api_key` with your OpenAI API key
   - `your_elevenlabs_api_key` with your ElevenLabs API key
   - `your-service-account-key-filename.json` with the actual filename of your Google Cloud service account key
8. Click "Save Changes" in the top-right

## Step 2: Update Frontend Configuration
1. In the File Manager, navigate to:
   `/public_html/radiation_oncology_academy/frontend`
2. Look for the file "next.config.js" and click on it
3. In the file editor, find the line that contains:
   `API_URL: process.env.API_URL || 'http://localhost:8080/api'`
4. Change it to:
   `API_URL: process.env.API_URL || 'https://radiationoncologyacademy.com/api'`
5. Click "Save Changes" in the top-right

## Step 3: Install Dependencies
1. Go back to your GoDaddy cPanel tab
2. In the cPanel dashboard, scroll to the "Software" section
3. Click on "Setup Node.js App"
4. Find your application in the list and click on it
5. Click the "Run NPM Install" button
6. Wait for the installation to complete (this may take 5-10 minutes)
7. You'll see a success message when it's done

## Step 4: Start Your Application
1. After the NPM install completes, click the "Run JS Script" button
2. Wait for the application to start
3. You'll see a success message when it's running

## Step 5: Set Up Domain Pointing
1. In cPanel, go back to the main dashboard
2. Scroll to the "Domains" section
3. Click on "Domains"
4. Find your domain (radiationoncologyacademy.com) in the list
5. Make sure it's pointing to your hosting account
6. If not, click "Manage" and then "Change" next to "Points to"
7. Select your hosting account from the dropdown
8. Click "Save"

---

# PART 6: TESTING

## Step 1: Access Your Website
1. Open a new browser tab
2. Type "radiationoncologyacademy.com" in the address bar and press Enter
3. You should see the Radiation Oncology Academy homepage
4. If the site doesn't load, wait 5-10 minutes for DNS propagation and try again

## Step 2: Test User Registration
1. On the homepage, click the "Register" button in the top-right
2. Fill in the registration form:
   - Full Name: Your name
   - Email: Your email address
   - Password: Create a password
   - Confirm Password: Repeat the same password