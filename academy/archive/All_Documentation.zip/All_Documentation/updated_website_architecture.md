# Updated Website Architecture for Radiation Oncology Academy

## Overview

This document outlines the updated architecture for the Radiation Oncology Academy website, incorporating the new profession-specific organization structure, enhanced AI integration, and Google Cloud services. This architecture serves as the foundation for rebuilding the website to better serve the educational needs of Medical Physicists, Radiation Oncologists, Dosimetrists, and Radiation Therapists.

## System Architecture

### 1. Frontend Architecture

```
radiation_oncology_academy/
├── frontend/
│   ├── app/
│   │   ├── (auth)/
│   │   │   ├── login/
│   │   │   └── register/
│   │   ├── about/
│   │   ├── blog/
│   │   ├── contact/
│   │   ├── dashboard/
│   │   ├── podcast/
│   │   ├── webinars/
│   │   ├── membership/
│   │   │   ├── checkout/
│   │   │   └── success/
│   │   ├── medical-physicist/
│   │   │   ├── education/
│   │   │   ├── clinical-practice/
│   │   │   ├── research/
│   │   │   └── professional-development/
│   │   ├── radiation-oncologist/
│   │   │   ├── education/
│   │   │   ├── clinical-practice/
│   │   │   ├── research/
│   │   │   └── professional-development/
│   │   ├── dosimetrist/
│   │   │   ├── education/
│   │   │   ├── clinical-practice/
│   │   │   ├── technical-skills/
│   │   │   └── professional-development/
│   │   ├── radiation-therapist/
│   │   │   ├── education/
│   │   │   ├── clinical-practice/
│   │   │   ├── technical-skills/
│   │   │   └── professional-development/
│   │   └── cross-disciplinary/
│   │       ├── board-exams/
│   │       ├── clinical-resources/
│   │       ├── research/
│   │       └── professional-development/
│   ├── components/
│   │   ├── common/
│   │   ├── layout/
│   │   ├── dashboard/
│   │   ├── courses/
│   │   ├── blog/
│   │   ├── podcast/
│   │   ├── membership/
│   │   ├── medical-physicist/
│   │   ├── radiation-oncologist/
│   │   ├── dosimetrist/
│   │   ├── radiation-therapist/
│   │   └── ai/
│   │       ├── RecommendationEngine.tsx
│   │       ├── AdaptiveLearning.tsx
│   │       ├── ContentGenerator.tsx
│   │       └── SmartSearch.tsx
│   └── lib/
│       ├── utils.ts
│       ├── api.ts
│       ├── auth.ts
│       └── ai-services.ts
```

### 2. Backend Architecture

```
radiation_oncology_academy/
├── backend/
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── user.controller.js
│   │   ├── course.controller.js
│   │   ├── blog.controller.js
│   │   ├── podcast.controller.js
│   │   ├── webinar.controller.js
│   │   ├── membership.controller.js
│   │   ├── payment.controller.js
│   │   ├── openai.controller.js
│   │   ├── elevenlabs.controller.js
│   │   ├── gcloud-storage.controller.js
│   │   ├── gcloud-speech.controller.js
│   │   ├── firebase.controller.js
│   │   ├── medical-physicist.controller.js
│   │   ├── radiation-oncologist.controller.js
│   │   ├── dosimetrist.controller.js
│   │   └── radiation-therapist.controller.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Membership.js
│   │   ├── Course.js
│   │   ├── Module.js
│   │   ├── Quiz.js
│   │   ├── BlogPost.js
│   │   ├── PodcastEpisode.js
│   │   ├── Webinar.js
│   │   ├── Payment.js
│   │   ├── UserProgress.js
│   │   ├── ProfessionalRole.js
│   │   ├── ContentAccess.js
│   │   └── AIRecommendation.js
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── user.routes.js
│   │   ├── course.routes.js
│   │   ├── blog.routes.js
│   │   ├── podcast.routes.js
│   │   ├── webinar.routes.js
│   │   ├── membership.routes.js
│   │   ├── payment.routes.js
│   │   ├── openai.routes.js
│   │   ├── elevenlabs.routes.js
│   │   ├── gcloud.routes.js
│   │   ├── firebase.routes.js
│   │   ├── medical-physicist.routes.js
│   │   ├── radiation-oncologist.routes.js
│   │   ├── dosimetrist.routes.js
│   │   └── radiation-therapist.routes.js
│   ├── middleware/
│   │   ├── auth.js
│   │   ├── role.js
│   │   ├── membership.js
│   │   └── ai.js
│   ├── config/
│   │   ├── db.js
│   │   ├── auth.js
│   │   ├── openai.js
│   │   ├── elevenlabs.js
│   │   ├── gcloud-storage.js
│   │   ├── gcloud-speech.js
│   │   └── firebase.js
│   ├── utils/
│   │   ├── ai-helpers.js
│   │   ├── content-generator.js
│   │   ├── recommendation-engine.js
│   │   └── analytics.js
│   └── server.js
```

### 3. Database Schema Updates

```
// User Schema with Professional Role
{
  _id: ObjectId,
  email: String,
  password: String,
  firstName: String,
  lastName: String,
  professionalRole: {
    type: String,
    enum: ['medical-physicist', 'radiation-oncologist', 'dosimetrist', 'radiation-therapist', 'other']
  },
  specialization: String,
  experienceLevel: {
    type: String,
    enum: ['student', 'resident', 'early-career', 'experienced', 'senior']
  },
  membershipTier: {
    type: String,
    enum: ['basic', 'standard', 'premium', 'enterprise']
  },
  membershipStartDate: Date,
  membershipEndDate: Date,
  freeTrialEndDate: Date,
  createdAt: Date,
  updatedAt: Date
}

// Content Access Schema
{
  _id: ObjectId,
  contentType: {
    type: String,
    enum: ['course', 'module', 'quiz', 'blog', 'podcast', 'webinar', 'resource']
  },
  contentId: ObjectId,
  professionalRoles: [String], // Which roles can access this content
  membershipTiers: [String],   // Which tiers can access this content
  isPublic: Boolean,           // Whether content is publicly accessible
  createdAt: Date,
  updatedAt: Date
}

// AI Recommendation Schema
{
  _id: ObjectId,
  userId: ObjectId,
  contentType: String,
  contentId: ObjectId,
  recommendationScore: Number,
  reasonCodes: [String],
  viewed: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

## Integration Architecture

### 1. Google Cloud Integration

#### 1.1 Google Cloud Storage

```
// Storage Buckets
- roa-private-source-materials (Private access)
- roa-member-content (Restricted access)
- roa-public-content (Public access)

// Folder Structure for Each Bucket
/medical-physicist/
  /education/
  /clinical-practice/
  /research/
  /professional-development/
/radiation-oncologist/
  /education/
  /clinical-practice/
  /research/
  /professional-development/
/dosimetrist/
  /education/
  /clinical-practice/
  /technical-skills/
  /professional-development/
/radiation-therapist/
  /education/
  /clinical-practice/
  /technical-skills/
  /professional-development/
/cross-disciplinary/
  /board-exams/
  /clinical-resources/
  /research/
  /professional-development/
```

#### 1.2 Google Speech-to-Text

```javascript
// Integration with Podcast and Webinar Content
const speechToTextService = {
  transcribeAudio: async (audioFile, options) => {
    // Configure Speech-to-Text with medical terminology
    const config = {
      languageCode: 'en-US',
      model: 'medical_conversation',
      enableAutomaticPunctuation: true,
      enableWordTimeOffsets: true,
      useEnhanced: true
    };
    
    // Process audio file
    const [response] = await speechClient.recognize({
      config,
      audio: { content: audioFile }
    });
    
    // Return transcript with timestamps
    return response.results.map(result => result.alternatives[0]);
  }
};
```

#### 1.3 Firebase Integration

```javascript
// Firebase Configuration
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: "radiationoncologyacademy.firebaseapp.com",
  projectId: "radiationoncologyacademy",
  storageBucket: "radiationoncologyacademy.appspot.com",
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID,
  measurementId: process.env.FIREBASE_MEASUREMENT_ID
};

// Firebase Services
const firebaseServices = {
  auth: firebase.auth(),
  db: firebase.firestore(),
  realtime: firebase.database(),
  storage: firebase.storage(),
  analytics: firebase.analytics()
};
```

### 2. AI Integration

#### 2.1 OpenAI Integration

```javascript
// Content Generation Service
const contentGenerationService = {
  generateBlogPost: async (topic, professionalRole, experienceLevel) => {
    const prompt = `Write a comprehensive blog post about ${topic} for ${professionalRole}s with ${experienceLevel} experience level. Include relevant clinical examples, references to recent research, and practical applications.`;
    
    const response = await openai.createCompletion({
      model: "gpt-4",
      prompt: prompt,
      max_tokens: 2000,
      temperature: 0.7
    });
    
    return response.choices[0].text;
  },
  
  generateQuizQuestions: async (topic, professionalRole, difficulty) => {
    const prompt = `Create 10 multiple-choice questions about ${topic} for ${professionalRole}s at ${difficulty} difficulty level. Each question should have 4 options with one correct answer. Format as JSON.`;
    
    const response = await openai.createCompletion({
      model: "gpt-4",
      prompt: prompt,
      max_tokens: 2000,
      temperature: 0.7
    });
    
    return JSON.parse(response.choices[0].text);
  }
};
```

#### 2.2 ElevenLabs Integration

```javascript
// Voice Generation Service
const voiceGenerationService = {
  generatePodcastAudio: async (script, voiceId) => {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': process.env.ELEVENLABS_API_KEY
      },
      body: JSON.stringify({
        text: script,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      })
    });
    
    const audioBuffer = await response.arrayBuffer();
    return Buffer.from(audioBuffer);
  }
};
```

#### 2.3 Recommendation Engine

```javascript
// AI Recommendation Service
const recommendationService = {
  generateRecommendations: async (userId) => {
    // Get user data
    const user = await User.findById(userId);
    
    // Get user's learning history
    const progress = await UserProgress.find({ userId });
    
    // Get content appropriate for user's role and membership tier
    const accessibleContent = await ContentAccess.find({
      professionalRoles: user.professionalRole,
      membershipTiers: user.membershipTier
    });
    
    // Generate recommendations using ML model
    const recommendations = await recommendationModel.predict({
      user,
      progress,
      accessibleContent
    });
    
    // Save recommendations to database
    await AIRecommendation.insertMany(
      recommendations.map(rec => ({
        userId,
        contentType: rec.contentType,
        contentId: rec.contentId,
        recommendationScore: rec.score,
        reasonCodes: rec.reasons,
        viewed: false,
        createdAt: new Date()
      }))
    );
    
    return recommendations;
  }
};
```

## Membership System Updates

### 1. 60-Day Free Trial Implementation

```javascript
// Membership Controller Update
const createMembership = async (req, res) => {
  try {
    const { userId, membershipTier, paymentMethod } = req.body;
    
    // Set membership dates
    const startDate = new Date();
    
    // For basic tier, set 60-day free trial
    let endDate;
    let freeTrialEndDate = null;
    
    if (membershipTier === 'basic') {
      freeTrialEndDate = new Date();
      freeTrialEndDate.setDate(freeTrialEndDate.getDate() + 60); // 60-day free trial
      endDate = new Date();
      endDate.setFullYear(endDate.getFullYear() + 1); // 1 year subscription after trial
    } else {
      endDate = new Date();
      endDate.setFullYear(endDate.getFullYear() + 1); // 1 year subscription
    }
    
    // Create membership record
    const membership = await Membership.create({
      userId,
      membershipTier,
      startDate,
      endDate,
      freeTrialEndDate,
      paymentMethod,
      status: 'active'
    });
    
    // Update user record
    await User.findByIdAndUpdate(userId, {
      membershipTier,
      membershipStartDate: startDate,
      membershipEndDate: endDate,
      freeTrialEndDate
    });
    
    return res.status(201).json({
      success: true,
      data: membership
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message
    });
  }
};
```

## Role-Based Navigation

### 1. User Onboarding Flow

```javascript
// Professional Role Selection Component
const ProfessionalRoleSelection = () => {
  const [selectedRole, setSelectedRole] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('');
  
  const handleSubmit = async () => {
    // Update user profile with professional role information
    await updateUserProfile({
      professionalRole: selectedRole,
      specialization,
      experienceLevel
    });
    
    // Redirect to personalized dashboard
    router.push('/dashboard');
  };
  
  return (
    <div className="role-selection-container">
      <h2>Tell us about your professional role</h2>
      
      <div className="role-options">
        <RoleCard
          title="Medical Physicist"
          description="For professionals working in radiation physics, treatment planning, and quality assurance."
          selected={selectedRole === 'medical-physicist'}
          onClick={() => setSelectedRole('medical-physicist')}
        />
        
        <RoleCard
          title="Radiation Oncologist"
          description="For physicians specializing in the treatment of cancer with radiation therapy."
          selected={selectedRole === 'radiation-oncologist'}
          onClick={() => setSelectedRole('radiation-oncologist')}
        />
        
        <RoleCard
          title="Medical Dosimetrist"
          description="For professionals who create treatment plans and calculate radiation doses."
          selected={selectedRole === 'dosimetrist'}
          onClick={() => setSelectedRole('dosimetrist')}
        />
        
        <RoleCard
          title="Radiation Therapist"
          description="For professionals who administer radiation treatments to patients."
          selected={selectedRole === 'radiation-therapist'}
          onClick={() => setSelectedRole('radiation-therapist')}
        />
      </div>
      
      {/* Specialization and Experience Level inputs */}
      
      <Button onClick={handleSubmit}>Continue to your personalized dashboard</Button>
    </div>
  );
};
```

### 2. Personalized Dashboard

```javascript
// Personalized Dashboard Component
const Dashboard = ({ user, recommendations, progress }) => {
  const { professionalRole } = user;
  
  // Get role-specific content
  const roleSpecificContent = useRoleSpecificContent(professionalRole);
  
  return (
    <div className="dashboard-container">
      <WelcomeSection user={user} />
      
      <section className="recommendations">
        <h2>Recommended for You</h2>
        <div className="recommendation-cards">
          {recommendations.map(rec => (
            <RecommendationCard key={rec.id} recommendation={rec} />
          ))}
        </div>
      </section>
      
      <section className="role-specific-content">
        <h2>{getRoleName(professionalRole)} Resources</h2>
        <div className="content-categories">
          <ContentCategoryCard
            title="Education & Certification"
            description="Exam preparation, continuing education, and certification resources."
            link={`/${professionalRole}/education`}
          />
          
          <ContentCategoryCard
            title="Clinical Practice"
            description="Guidelines, protocols, and practical resources for clinical work."
            link={`/${professionalRole}/clinical-practice`}
          />
          
          {(professionalRole === 'dosimetrist' || professionalRole === 'radiation-therapist') && (
            <ContentCategoryCard
              title="Technical Skills"
              description="Tutorials, guides, and resources for technical procedures."
              link={`/${professionalRole}/technical-skills`}
            />
          )}
          
          {(professionalRole === 'medical-physicist' || professionalRole === 'radiation-oncologist') && (
            <ContentCategoryCard
              title="Research & Development"
              description="Latest research, methodologies, and innovation in the field."
              link={`/${professionalRole}/research`}
            />
          )}
          
          <ContentCategoryCard
            title="Professional Development"
            description="Career resources, leadership skills, and professional growth."
            link={`/${professionalRole}/professional-development`}
          />
        </div>
      </section>
      
      <section className="learning-progress">
        <h2>Your Learning Progress</h2>
        <ProgressTracker progress={progress} />
      </section>
      
      <section className="latest-content">
        <h2>Latest Content</h2>
        <Tabs>
          <TabPanel title="Blog">
            <BlogPostList posts={roleSpecificContent.blogPosts} />
          </TabPanel>
          <TabPanel title="Podcast">
            <PodcastEpisodeList episodes={roleSpecificContent.podcastEpisodes} />
          </TabPanel>
          <TabPanel title="Webinars">
            <WebinarList webinars={roleSpecificContent.webinars} />
          </TabPanel>
        </Tabs>
      </section>
    </div>
  );
};
```

## Conclusion

This updated architecture provides a comprehensive foundation for rebuilding the Radiation Oncology Academy website with the new profession-specific organization structure. The architecture incorporates:

1. Role-based content organization for Medical Physicists, Radiation Oncologists, Dosimetrists, and Radiation Therapists
2. Enhanced AI integration using OpenAI and ElevenLabs
3. Google Cloud services integration (Storage, Speech-to-Text, Firebase)
4. Updated membership system with 60-day free trial for the basic tier
5. Personalized user experience with role-based navigation

This architecture will guide the implementation of the rebuilt website, ensuring all requirements are met while maintaining a scalable and maintainable codebase.
