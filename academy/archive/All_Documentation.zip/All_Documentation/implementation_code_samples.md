# Implementation Plan for Radiation Oncology Academy Website

## Project Setup

### Frontend Setup
```bash
# Create Next.js project with TypeScript
npx create-next-app@latest radiation-oncology-academy-frontend --typescript
cd radiation-oncology-academy-frontend

# Install necessary dependencies
npm install axios tailwindcss @headlessui/react @heroicons/react react-query framer-motion chart.js react-chartjs-2 formik yup
npm install @tailwindcss/forms @tailwindcss/typography

# Set up Tailwind CSS
npx tailwindcss init -p
```

### Backend Setup
```bash
# Create backend directory
mkdir radiation-oncology-academy-backend
cd radiation-oncology-academy-backend

# Initialize Node.js project
npm init -y

# Install necessary dependencies
npm install express mongoose dotenv cors helmet jsonwebtoken bcrypt morgan winston multer openai axios stripe

# Create basic directory structure
mkdir -p src/{controllers,models,routes,middleware,utils,services,config}
```

## Database Schema Implementation

I'll create MongoDB schemas based on our content structure:

### Content Schema
```javascript
const ContentSchema = new mongoose.Schema({
  title: { type: String, required: true },
  type: { type: String, enum: ['article', 'video', 'quiz', 'simulation', 'reference'], required: true },
  category: { type: String, required: true },
  subcategory: { type: String, required: true },
  difficulty: { type: String, enum: ['beginner', 'intermediate', 'advanced'], required: true },
  roles: [{ type: String, enum: ['physicist', 'oncologist', 'dosimetrist', 'therapist'] }],
  tags: [{ type: String }],
  content: { type: String, required: true },
  equations: [{ 
    id: String, 
    latex: String, 
    description: String 
  }],
  media: [{
    type: { type: String, enum: ['image', 'video', 'animation', '3d-model'] },
    url: String,
    caption: String
  }],
  references: [{
    text: String,
    url: String
  }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  aiGenerated: { type: Boolean, default: false },
  reviewStatus: { type: String, enum: ['pending', 'reviewed', 'approved'], default: 'pending' }
});
```

### User Schema
```javascript
const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  role: { type: String, enum: ['admin', 'editor', 'user'], default: 'user' },
  profession: { type: String, enum: ['physicist', 'oncologist', 'dosimetrist', 'therapist', 'student', 'other'] },
  specialization: { type: String },
  experience: { type: String, enum: ['student', '0-2', '3-5', '6-10', '10+'] },
  membershipTier: { type: String, enum: ['free', 'basic', 'premium', 'professional'], default: 'free' },
  membershipExpiry: { type: Date },
  createdAt: { type: Date, default: Date.now },
  lastLogin: { type: Date },
  progress: {
    completedContent: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Content' }],
    quizScores: [{
      quizId: { type: mongoose.Schema.Types.ObjectId, ref: 'Quiz' },
      score: Number,
      maxScore: Number,
      completedAt: Date
    }]
  },
  preferences: {
    contentDifficulty: { type: String, enum: ['beginner', 'intermediate', 'advanced'], default: 'intermediate' },
    emailNotifications: { type: Boolean, default: true },
    theme: { type: String, enum: ['light', 'dark', 'system'], default: 'system' }
  }
});
```

### Quiz Schema
```javascript
const QuestionSchema = new mongoose.Schema({
  text: { type: String, required: true },
  type: { type: String, enum: ['multiple-choice', 'true-false', 'calculation', 'matching'], required: true },
  options: [{ 
    id: String,
    text: String,
    isCorrect: Boolean
  }],
  explanation: { type: String },
  difficulty: { type: String, enum: ['beginner', 'intermediate', 'advanced'], required: true },
  tags: [{ type: String }],
  aiGenerated: { type: Boolean, default: false }
});

const QuizSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  category: { type: String, required: true },
  subcategory: { type: String },
  examType: { type: String, enum: ['practice', 'mock-exam', 'self-assessment', 'certification'] },
  questions: [QuestionSchema],
  timeLimit: { type: Number }, // in minutes
  passingScore: { type: Number }, // percentage
  difficulty: { type: String, enum: ['beginner', 'intermediate', 'advanced'], required: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});
```

## AI Integration Implementation

### OpenAI API Integration
```javascript
// src/services/openai.service.js
const { Configuration, OpenAIApi } = require('openai');
const config = require('../config');

const configuration = new Configuration({
  apiKey: config.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

async function generateContent(topic, contentType, difficulty, role) {
  try {
    const prompt = `Create educational content about ${topic} in radiation oncology for a ${role} at ${difficulty} level. The content should be in ${contentType} format.`;
    
    const response = await openai.createCompletion({
      model: "gpt-4",
      prompt: prompt,
      max_tokens: 2000,
      temperature: 0.7,
    });
    
    return {
      content: response.data.choices[0].text.trim(),
      aiGenerated: true,
      reviewStatus: 'pending'
    };
  } catch (error) {
    console.error('Error generating content with OpenAI:', error);
    throw error;
  }
}

async function generateQuizQuestions(topic, difficulty, numberOfQuestions) {
  try {
    const prompt = `Create ${numberOfQuestions} multiple-choice questions about ${topic} in radiation oncology at ${difficulty} level. For each question, provide 4 options with one correct answer and an explanation.`;
    
    const response = await openai.createCompletion({
      model: "gpt-4",
      prompt: prompt,
      max_tokens: 2000,
      temperature: 0.7,
    });
    
    // Process the response to extract structured questions
    // This would require parsing the text response into our question format
    
    return {
      questions: processedQuestions,
      aiGenerated: true,
      reviewStatus: 'pending'
    };
  } catch (error) {
    console.error('Error generating quiz questions with OpenAI:', error);
    throw error;
  }
}

module.exports = {
  generateContent,
  generateQuizQuestions
};
```

## Content Processing Pipeline

```javascript
// src/services/content-processor.service.js
const fs = require('fs');
const path = require('path');
const { GoogleDriveService } = require('./google-drive.service');
const { ContentModel } = require('../models/content.model');
const openaiService = require('./openai.service');

class ContentProcessorService {
  constructor() {
    this.googleDriveService = new GoogleDriveService();
  }
  
  async processGoogleDriveFolder(folderId, category) {
    try {
      // Get files from Google Drive folder
      const files = await this.googleDriveService.listFilesInFolder(folderId);
      
      for (const file of files) {
        // Download file content
        const content = await this.googleDriveService.downloadFile(file.id);
        
        // Process content based on file type
        if (file.mimeType.includes('pdf')) {
          await this.processPdfContent(content, file.name, category);
        } else if (file.mimeType.includes('text')) {
          await this.processTextContent(content, file.name, category);
        } else if (file.mimeType.includes('image')) {
          await this.processImageContent(file.id, file.name, category);
        }
      }
      
      return { success: true, message: `Processed ${files.length} files from folder` };
    } catch (error) {
      console.error('Error processing Google Drive folder:', error);
      throw error;
    }
  }
  
  async processPdfContent(pdfBuffer, fileName, category) {
    // Extract text from PDF
    // Analyze content and categorize
    // Store in database with appropriate metadata
  }
  
  async processTextContent(textContent, fileName, category) {
    // Analyze text content
    // Extract key concepts, equations, etc.
    // Store in database with appropriate metadata
  }
  
  async processImageContent(fileId, fileName, category) {
    // Store image reference
    // Generate caption or description using AI
    // Link to relevant content
  }
  
  async enhanceContentWithAI(contentId) {
    try {
      // Get existing content
      const content = await ContentModel.findById(contentId);
      
      if (!content) {
        throw new Error('Content not found');
      }
      
      // Generate enhanced content with AI
      const enhancedContent = await openaiService.generateContent(
        content.title,
        content.type,
        content.difficulty,
        content.roles[0]
      );
      
      // Update content with AI enhancements
      content.content = enhancedContent.content;
      content.aiEnhanced = true;
      content.reviewStatus = 'pending';
      
      await content.save();
      
      return { success: true, message: 'Content enhanced with AI' };
    } catch (error) {
      console.error('Error enhancing content with AI:', error);
      throw error;
    }
  }
}

module.exports = new ContentProcessorService();
```

## Frontend Components Implementation

### Main Layout Component
```jsx
// components/layout/MainLayout.tsx
import React from 'react';
import Head from 'next/head';
import Navbar from './Navbar';
import Footer from './Footer';
import Sidebar from './Sidebar';

interface MainLayoutProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  showSidebar?: boolean;
}

const MainLayout: React.FC<MainLayoutProps> = ({
  children,
  title = 'Radiation Oncology Academy',
  description = 'Educational platform for radiation oncology professionals',
  showSidebar = true,
}) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <Navbar />
      
      <div className="flex">
        {showSidebar && <Sidebar />}
        
        <main className={`flex-1 p-6 ${showSidebar ? 'ml-64' : ''}`}>
          {children}
        </main>
      </div>
      
      <Footer />
    </div>
  );
};

export default MainLayout;
```

### Dashboard Page
```jsx
// pages/dashboard.tsx
import { useEffect, useState } from 'react';
import MainLayout from '../components/layout/MainLayout';
import RecommendationCard from '../components/dashboard/RecommendationCard';
import ProgressTracker from '../components/dashboard/ProgressTracker';
import ContentCategoryCard from '../components/common/ContentCategoryCard';
import { useUser } from '../hooks/useUser';
import { useRecommendations } from '../hooks/useRecommendations';
import { useProgress } from '../hooks/useProgress';

const Dashboard = () => {
  const { user, isLoading: userLoading } = useUser();
  const { recommendations, isLoading: recommendationsLoading } = useRecommendations();
  const { progress, isLoading: progressLoading } = useProgress();
  
  if (userLoading || recommendationsLoading || progressLoading) {
    return (
      <MainLayout title="Dashboard | Loading...">
        <div className="flex items-center justify-center h-screen">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout title={`Dashboard | ${user?.firstName}'s Learning Portal`}>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Welcome back, {user?.firstName}!</h1>
        <p className="text-gray-600 mt-2">Continue your learning journey in radiation oncology.</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <ProgressTracker progress={progress} />
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-4">Your Next Certification Steps</h2>
          {/* Certification progress widget */}
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Recommended for You</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recommendations?.map((recommendation) => (
            <RecommendationCard key={recommendation.id} recommendation={recommendation} />
          ))}
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold mb-4">Continue Learning</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ContentCategoryCard 
            title="Radiation Physics" 
            description="Fundamental principles and advanced concepts"
            icon="physics"
            progress={progress?.categories?.radiationPhysics || 0}
            href="/content/radiation-physics"
          />
          <ContentCategoryCard 
            title="Radiation Therapy" 
            description="Treatment techniques and procedures"
            icon="therapy"
            progress={progress?.categories?.radiationTherapy || 0}
            href="/content/radiation-therapy"
          />
          <ContentCategoryCard 
            title="Medical Imaging" 
            description="Imaging modalities and applications"
            icon="imaging"
            progress={progress?.categories?.medicalImaging || 0}
            href="/content/medical-imaging"
          />
          <ContentCategoryCard 
            title="Clinical Applications" 
            description="Disease-specific approaches"
            icon="clinical"
            progress={progress?.categories?.clinicalApplications || 0}
            href="/content/clinical-applications"
          />
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
```

## Next Steps

1. Complete the implementation of core components:
   - Authentication system
   - Content management system
   - User profile and progress tracking
   - Quiz and assessment engine

2. Implement the AI integration features:
   - Content generation and enhancement
   - Personalized recommendations
   - Adaptive learning paths

3. Develop the interactive learning elements:
   - Interactive equations
   - 3D visualizations
   - Simulations
   - Case-based scenarios

4. Create the content processing pipeline:
   - Google Drive integration
   - Content extraction and structuring
   - Metadata tagging and organization

5. Build the admin dashboard:
   - Content management interface
   - User management
   - Analytics and reporting
   - AI content review workflow

I'll continue implementing these components and provide regular updates on progress.
