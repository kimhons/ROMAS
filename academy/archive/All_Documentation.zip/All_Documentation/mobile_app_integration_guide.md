# Mobile App Integration Guide for Radiation Oncology Academy

## Overview

This document outlines the integration strategy for connecting the Radiation Oncology Academy mobile application with the existing web platform. The integration approach ensures data consistency, shared functionality, and seamless user experience across both platforms.

## 1. Integration Architecture

### 1.1 System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                    Radiation Oncology Academy                   │
│                                                                 │
├─────────────────┬─────────────────────────┬───────────────────┤
│                 │                         │                   │
│   Web Platform  │    Shared Backend       │   Mobile App      │
│                 │                         │                   │
├─────────────────┼─────────────────────────┼───────────────────┤
│ - Next.js       │ - Node.js/Express       │ - React Native    │
│ - React         │ - MongoDB               │ - Redux           │
│ - Redux         │ - Authentication        │ - AsyncStorage    │
│ - Tailwind CSS  │ - Content Management    │ - React Navigation│
│ - Web Components│ - User Management       │ - Native Modules  │
│                 │ - AI Services           │                   │
└─────────────────┴─────────────────────────┴───────────────────┘
```

### 1.2 Integration Principles

1. **Shared Backend**: Both web and mobile platforms will use the same backend services and APIs
2. **Consistent Data Models**: Data structures will be consistent across platforms
3. **Platform-Specific Optimizations**: UI and interactions will be optimized for each platform
4. **Synchronized State**: User data and progress will be synchronized across platforms
5. **Graceful Degradation**: Mobile app will function with limited capabilities when offline

## 2. API Integration

### 2.1 API Architecture

The mobile app will integrate with the existing backend API using a RESTful architecture with the following enhancements:

1. **Mobile-Specific Endpoints**: Additional endpoints optimized for mobile use cases
2. **Bandwidth Optimization**: Compressed payloads and partial responses
3. **Batch Operations**: Endpoints for multiple operations in a single request
4. **Background Synchronization**: Support for queued operations during offline use

### 2.2 API Endpoint Mapping

| Functionality | Web Endpoint | Mobile Endpoint | Modifications for Mobile |
|---------------|--------------|-----------------|--------------------------|
| Authentication | `/api/auth/login` | `/api/auth/login` | Additional device registration |
| User Profile | `/api/users/profile` | `/api/users/profile` | Reduced payload size |
| Content Listing | `/api/content` | `/api/mobile/content` | Pagination, reduced metadata |
| Content Detail | `/api/content/:id` | `/api/mobile/content/:id` | Optimized media references |
| Progress Tracking | `/api/progress` | `/api/mobile/progress` | Batch update support |
| Podcast Streaming | `/api/podcasts/stream/:id` | `/api/mobile/podcasts/stream/:id` | Adaptive bitrate options |
| Offline Sync | N/A | `/api/mobile/sync` | Conflict resolution support |

### 2.3 API Client Implementation

```javascript
// src/services/api.js
import axios from 'axios';
import { getAuthToken, refreshToken } from './auth';
import { getNetworkStatus, queueOfflineRequest } from './network';

const API_BASE_URL = 'https://api.radiationoncologyacademy.com';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-Platform': 'mobile'
  }
});

// Request interceptor for auth token
apiClient.interceptors.request.use(
  async config => {
    // Check network status
    const isOnline = await getNetworkStatus();
    
    if (!isOnline) {
      // Queue request for later if it's a write operation
      if (['post', 'put', 'patch', 'delete'].includes(config.method)) {
        await queueOfflineRequest(config);
        throw new Error('OFFLINE_QUEUE');
      }
    }
    
    // Add auth token to request
    const token = await getAuthToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  error => Promise.reject(error)
);

// Response interceptor for token refresh
apiClient.interceptors.response.use(
  response => response,
  async error => {
    const originalRequest = error.config;
    
    // Handle token expiration
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        await refreshToken();
        const token = await getAuthToken();
        originalRequest.headers.Authorization = `Bearer ${token}`;
        return apiClient(originalRequest);
      } catch (refreshError) {
        // Handle refresh failure - usually redirect to login
        return Promise.reject(refreshError);
      }
    }
    
    return Promise.reject(error);
  }
);

export default apiClient;
```

## 3. Authentication Integration

### 3.1 Authentication Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│             │     │             │     │             │
│  Mobile App │────▶│  Auth API   │────▶│  User DB    │
│             │     │             │     │             │
└─────────────┘     └─────────────┘     └─────────────┘
       │                                       │
       │                                       │
       │                                       │
       ▼                                       ▼
┌─────────────┐                        ┌─────────────┐
│             │                        │             │
│  Secure     │                        │  Session    │
│  Storage    │                        │  Management │
│             │                        │             │
└─────────────┘                        └─────────────┘
```

### 3.2 Authentication Implementation

```javascript
// src/services/auth.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Keychain from 'react-native-keychain';
import apiClient from './api';
import { Platform } from 'react-native';
import DeviceInfo from 'react-native-device-info';

// Storage keys
const AUTH_TOKEN_KEY = 'auth_token';
const REFRESH_TOKEN_KEY = 'refresh_token';
const USER_DATA_KEY = 'user_data';

// Get device information for authentication
const getDeviceInfo = async () => {
  return {
    deviceId: await DeviceInfo.getUniqueId(),
    deviceModel: DeviceInfo.getModel(),
    deviceOS: Platform.OS,
    deviceOSVersion: Platform.Version,
    appVersion: DeviceInfo.getVersion(),
    appBuild: DeviceInfo.getBuildNumber(),
  };
};

// Login user
export const loginUser = async (email, password) => {
  try {
    const deviceInfo = await getDeviceInfo();
    
    const response = await apiClient.post('/api/auth/login', {
      email,
      password,
      deviceInfo
    });
    
    const { token, refreshToken, user } = response.data;
    
    // Store tokens securely
    await Keychain.setGenericPassword(AUTH_TOKEN_KEY, token);
    await Keychain.setInternetCredentials(
      'radiationoncologyacademy.com',
      REFRESH_TOKEN_KEY,
      refreshToken
    );
    
    // Store user data
    await AsyncStorage.setItem(USER_DATA_KEY, JSON.stringify(user));
    
    return user;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

// Get stored auth token
export const getAuthToken = async () => {
  try {
    const credentials = await Keychain.getGenericPassword();
    if (credentials) {
      return credentials.password;
    }
    return null;
  } catch (error) {
    console.error('Error getting auth token:', error);
    return null;
  }
};

// Refresh token
export const refreshToken = async () => {
  try {
    const credentials = await Keychain.getInternetCredentials('radiationoncologyacademy.com');
    
    if (!credentials) {
      throw new Error('No refresh token available');
    }
    
    const response = await apiClient.post('/api/auth/refresh', {
      refreshToken: credentials.password
    });
    
    const { token, refreshToken: newRefreshToken } = response.data;
    
    // Update stored tokens
    await Keychain.setGenericPassword(AUTH_TOKEN_KEY, token);
    await Keychain.setInternetCredentials(
      'radiationoncologyacademy.com',
      REFRESH_TOKEN_KEY,
      newRefreshToken
    );
    
    return token;
  } catch (error) {
    console.error('Token refresh error:', error);
    throw error;
  }
};

// Logout user
export const logoutUser = async () => {
  try {
    // Call logout API to invalidate tokens on server
    const token = await getAuthToken();
    if (token) {
      await apiClient.post('/api/auth/logout');
    }
    
    // Clear stored tokens and data
    await Keychain.resetGenericPassword();
    await Keychain.resetInternetCredentials('radiationoncologyacademy.com');
    await AsyncStorage.removeItem(USER_DATA_KEY);
    
    return true;
  } catch (error) {
    console.error('Logout error:', error);
    
    // Still clear local data even if API call fails
    await Keychain.resetGenericPassword();
    await Keychain.resetInternetCredentials('radiationoncologyacademy.com');
    await AsyncStorage.removeItem(USER_DATA_KEY);
    
    return true;
  }
};
```

### 3.3 Backend Authentication Modifications

The existing backend authentication system will need the following modifications:

1. **Device Registration**: Store and manage device information for each user
2. **Multiple Active Sessions**: Support simultaneous sessions across web and mobile
3. **Platform-Specific Tokens**: Issue tokens with appropriate expiration for each platform
4. **Secure Token Revocation**: Ability to revoke tokens for specific devices

## 4. Data Synchronization

### 4.1 Synchronization Strategy

The mobile app will use a multi-layered synchronization strategy:

1. **Real-time Sync**: Immediate synchronization when online
2. **Background Sync**: Periodic synchronization of changes when app is in background
3. **On-demand Sync**: User-initiated synchronization
4. **Conflict Resolution**: Strategies for handling conflicting changes

### 4.2 Offline Data Management

```javascript
// src/services/syncManager.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import apiClient from './api';

// Storage keys
const SYNC_QUEUE_KEY = 'sync_queue';
const LAST_SYNC_KEY = 'last_sync_timestamp';

// Initialize sync manager
export const initSyncManager = () => {
  // Set up network change listeners
  NetInfo.addEventListener(state => {
    if (state.isConnected && state.isInternetReachable) {
      processSyncQueue();
    }
  });
  
  // Set up periodic background sync
  setInterval(() => {
    NetInfo.fetch().then(state => {
      if (state.isConnected && state.isInternetReachable) {
        processSyncQueue();
      }
    });
  }, 15 * 60 * 1000); // Check every 15 minutes
};

// Add item to sync queue
export const queueForSync = async (operation) => {
  try {
    const queue = await getSyncQueue();
    queue.push({
      ...operation,
      timestamp: Date.now(),
      attempts: 0
    });
    await AsyncStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(queue));
    return true;
  } catch (error) {
    console.error('Error queuing item for sync:', error);
    return false;
  }
};

// Get current sync queue
export const getSyncQueue = async () => {
  try {
    const queue = await AsyncStorage.getItem(SYNC_QUEUE_KEY);
    return queue ? JSON.parse(queue) : [];
  } catch (error) {
    console.error('Error getting sync queue:', error);
    return [];
  }
};

// Process sync queue
export const processSyncQueue = async () => {
  try {
    const queue = await getSyncQueue();
    if (queue.length === 0) return;
    
    let updatedQueue = [...queue];
    
    // Process each item in queue
    for (let i = 0; i < updatedQueue.length; i++) {
      const item = updatedQueue[i];
      
      try {
        // Attempt to sync the item
        await syncItem(item);
        
        // Remove from queue if successful
        updatedQueue = updatedQueue.filter((_, index) => index !== i);
        i--; // Adjust index after removal
      } catch (error) {
        // Increment attempt count
        updatedQueue[i] = {
          ...item,
          attempts: item.attempts + 1,
          lastAttempt: Date.now(),
          lastError: error.message
        };
        
        // Remove from queue if too many attempts
        if (updatedQueue[i].attempts >= 5) {
          updatedQueue = updatedQueue.filter((_, index) => index !== i);
          i--; // Adjust index after removal
        }
      }
    }
    
    // Update queue in storage
    await AsyncStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(updatedQueue));
    
    // Update last sync timestamp
    await AsyncStorage.setItem(LAST_SYNC_KEY, Date.now().toString());
    
    return true;
  } catch (error) {
    console.error('Error processing sync queue:', error);
    return false;
  }
};

// Sync a single item
const syncItem = async (item) => {
  const { endpoint, method, data, id } = item;
  
  // Perform API request
  await apiClient({
    url: endpoint,
    method,
    data
  });
  
  // If this was a progress update, update local cache
  if (endpoint.includes('/progress') && method !== 'GET') {
    await updateLocalProgress(data);
  }
};

// Force sync now
export const forceSyncNow = async () => {
  const netInfo = await NetInfo.fetch();
  if (netInfo.isConnected && netInfo.isInternetReachable) {
    return processSyncQueue();
  }
  return false;
};

// Get last sync time
export const getLastSyncTime = async () => {
  try {
    const timestamp = await AsyncStorage.getItem(LAST_SYNC_KEY);
    return timestamp ? parseInt(timestamp, 10) : null;
  } catch (error) {
    console.error('Error getting last sync time:', error);
    return null;
  }
};
```

### 4.3 Content Synchronization

```javascript
// src/services/contentSync.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import RNFS from 'react-native-fs';
import apiClient from './api';

// Storage keys
const CONTENT_MANIFEST_KEY = 'content_manifest';
const CONTENT_BASE_DIR = `${RNFS.DocumentDirectoryPath}/content`;

// Initialize content directories
export const initContentStorage = async () => {
  try {
    const exists = await RNFS.exists(CONTENT_BASE_DIR);
    if (!exists) {
      await RNFS.mkdir(CONTENT_BASE_DIR);
    }
    return true;
  } catch (error) {
    console.error('Error initializing content storage:', error);
    return false;
  }
};

// Sync content manifest
export const syncContentManifest = async () => {
  try {
    // Get current manifest
    const currentManifest = await getContentManifest();
    const lastUpdate = currentManifest?.lastUpdate || 0;
    
    // Get updated manifest from server
    const response = await apiClient.get('/api/mobile/content/manifest', {
      params: { since: lastUpdate }
    });
    
    const { manifest, updates } = response.data;
    
    // Update local manifest
    await AsyncStorage.setItem(CONTENT_MANIFEST_KEY, JSON.stringify({
      ...manifest,
      lastUpdate: Date.now()
    }));
    
    // Return updates that need to be applied
    return updates;
  } catch (error) {
    console.error('Error syncing content manifest:', error);
    throw error;
  }
};

// Get local content manifest
export const getContentManifest = async () => {
  try {
    const manifest = await AsyncStorage.getItem(CONTENT_MANIFEST_KEY);
    return manifest ? JSON.parse(manifest) : null;
  } catch (error) {
    console.error('Error getting content manifest:', error);
    return null;
  }
};

// Download content item
export const downloadContentItem = async (contentId) => {
  try {
    // Get content metadata
    const response = await apiClient.get(`/api/mobile/content/${contentId}/download-info`);
    const { metadata, resources } = response.data;
    
    // Create content directory
    const contentDir = `${CONTENT_BASE_DIR}/${contentId}`;
    await RNFS.mkdir(contentDir);
    
    // Download content file
    await RNFS.downloadFile({
      fromUrl: metadata.contentUrl,
      toFile: `${contentDir}/content.json`,
      background: true,
      discretionary: true,
      progressDivider: 10
    }).promise;
    
    // Download resources
    const downloadPromises = resources.map(resource => {
      return RNFS.downloadFile({
        fromUrl: resource.url,
        toFile: `${contentDir}/${resource.filename}`,
        background: true,
        discretionary: true
      }).promise;
    });
    
    await Promise.all(downloadPromises);
    
    // Update local manifest to mark as downloaded
    const manifest = await getContentManifest();
    if (manifest && manifest.items) {
      manifest.items = manifest.items.map(item => {
        if (item.id === contentId) {
          return {
            ...item,
            downloaded: true,
            downloadDate: Date.now()
          };
        }
        return item;
      });
      
      await AsyncStorage.setItem(CONTENT_MANIFEST_KEY, JSON.stringify(manifest));
    }
    
    return true;
  } catch (error) {
    console.error(`Error downloading content item ${contentId}:`, error);
    throw error;
  }
};

// Get downloaded content
export const getDownloadedContent = async (contentId) => {
  try {
    const contentPath = `${CONTENT_BASE_DIR}/${contentId}/content.json`;
    const exists = await RNFS.exists(contentPath);
    
    if (!exists) {
      throw new Error('Content not downloaded');
    }
    
    const contentJson = await RNFS.readFile(contentPath, 'utf8');
    return JSON.parse(contentJson);
  } catch (error) {
    console.error(`Error getting downloaded content ${contentId}:`, error);
    throw error;
  }
};

// Delete downloaded content
export const deleteDownloadedContent = async (contentId) => {
  try {
    const contentDir = `${CONTENT_BASE_DIR}/${contentId}`;
    const exists = await RNFS.exists(contentDir);
    
    if (exists) {
      await RNFS.unlink(contentDir);
    }
    
    // Update local manifest
    const manifest = await getContentManifest();
    if (manifest && manifest.items) {
      manifest.items = manifest.items.map(item => {
        if (item.id === contentId) {
          const { downloaded, downloadDate, ...rest } = item;
          return rest;
        }
        return item;
      });
      
      await AsyncStorage.setItem(CONTENT_MANIFEST_KEY, JSON.stringify(manifest));
    }
    
    return true;
  } catch (error) {
    console.error(`Error deleting downloaded content ${contentId}:`, error);
    throw error;
  }
};
```

## 5. Media Handling Integration

### 5.1 Podcast Integration

```javascript
// src/services/podcastService.js
import RNFS from 'react-native-fs';
import TrackPlayer from 'react-native-track-player';
import apiClient from './api';
import { queueForSync } from './syncManager';

// Storage paths
const PODCAST_BASE_DIR = `${RNFS.DocumentDirectoryPath}/podcasts`;

// Initialize podcast player
export const initPodcastPlayer = async () => {
  try {
    await TrackPlayer.setupPlayer({
      maxCacheSize: 1024 * 5 // 5 MB
    });
    
    await TrackPlayer.updateOptions({
      stopWithApp: false,
      capabilities: [
        TrackPlayer.CAPABILITY_PLAY,
        TrackPlayer.CAPABILITY_PAUSE,
        TrackPlayer.CAPABILITY_STOP,
        TrackPlayer.CAPABILITY_SKIP_TO_NEXT,
        TrackPlayer.CAPABILITY_SKIP_TO_PREVIOUS,
        TrackPlayer.CAPABILITY_SEEK_TO
      ],
      compactCapabilities: [
        TrackPlayer.CAPABILITY_PLAY,
        TrackPlayer.CAPABILITY_PAUSE,
        TrackPlayer.CAPABILITY_SEEK_TO
      ]
    });
    
    // Create podcast directory if it doesn't exist
    const exists = await RNFS.exists(PODCAST_BASE_DIR);
    if (!exists) {
      await RNFS.mkdir(PODCAST_BASE_DIR);
    }
    
    return true;
  } catch (error) {
    console.error('Error initializing podcast player:', error);
    throw error;
  }
};

// Download podcast episode
export const downloadPodcastEpisode = async (episodeId) => {
  try {
    // Get episode details
    const response = await apiClient.get(`/api/podcasts/episodes/${episodeId}`);
    const episode = response.data;
    
    // Create episode directory
    const episodeDir = `${PODCAST_BASE_DIR}/${episodeId}`;
    await RNFS.mkdir(episodeDir);
    
    // Download audio file
    const audioFilePath = `${episodeDir}/audio.mp3`;
    await RNFS.downloadFile({
      fromUrl: episode.audioUrl,
      toFile: audioFilePath,
      background: true,
      discretionary: true,
      progressDivider: 10
    }).promise;
    
    // Download thumbnail if available
    let thumbnailPath = null;
    if (episode.thumbnailUrl) {
      thumbnailPath = `${episodeDir}/thumbnail.jpg`;
      await RNFS.downloadFile({
        fromUrl: episode.thumbnailUrl,
        toFile: thumbnailPath,
        background: true
      }).promise;
    }
    
    // Save episode metadata
    const metadata = {
      id: episode.id,
      title: episode.title,
      description: episode.description,
      duration: episode.duration,
      publishDate: episode.publishDate,
      audioPath: audioFilePath,
      thumbnailPath: thumbnailPath,
      downloadDate: Date.now()
    };
    
    await RNFS.writeFile(
      `${episodeDir}/metadata.json`,
      JSON.stringify(metadata),
      'utf8'
    );
    
    return metadata;
  } catch (error) {
    console.error(`Error downloading podcast episode ${episodeId}:`, error);
    throw error;
  }
};

// Get downloaded episodes
export const getDownloadedEpisodes = async () => {
  try {
    const items = await RNFS.readDir(PODCAST_BASE_DIR);
    const episodes = [];
    
    for (const item of items) {
      if (item.isDirectory()) {
        const metadataPath = `${item.path}/metadata.json`;
        const exists = await RNFS.exists(metadataPath);
        
        if (exists) {
          const metadataJson = await RNFS.readFile(metadataPath, 'utf8');
          episodes.push(JSON.parse(metadataJson));
        }
      }
    }
    
    return episodes;
  } catch (error) {
    console.error('Error getting downloaded episodes:', error);
    return [];
  }
};

// Play podcast episode
export const playPodcastEpisode = async (episodeId, isDownloaded = false) => {
  try {
    let episode;
    let audioUrl;
    
    if (isDownloaded) {
      // Get local episode data
      const episodeDir = `${PODCAST_BASE_DIR}/${episodeId}`;
      const metadataPath = `${episodeDir}/metadata.json`;
      const metadataJson = await RNFS.readFile(metadataPath, 'utf8');
      episode = JSON.parse(metadataJson);
      audioUrl = `file://${episode.audioPath}`;
    } else {
      // Get episode from API
      const response = await apiClient.get(`/api/podcasts/episodes/${episodeId}`);
      episode = response.data;
      audioUrl = episode.audioUrl;
      
      // Record listen on server
      recordPodcastListen(episodeId);
    }
    
    // Clear current queue
    await TrackPlayer.reset();
    
    // Add episode to queue
    await TrackPlayer.add({
      id: episode.id,
      url: audioUrl,
      title: episode.title,
      artist: 'Radiation Oncology Academy',
      artwork: episode.thumbnailPath ? `file://${episode.thumbnailPath}` : episode.thumbnailUrl,
      duration: episode.duration
    });
    
    // Start playback
    await TrackPlayer.play();
    
    return true;
  } catch (error) {
    console.error(`Error playing podcast episode ${episodeId}:`, error);
    throw error;
  }
};

// Record podcast listen
export const recordPodcastListen = async (episodeId) => {
  try {
    await apiClient.post(`/api/podcasts/episodes/${episodeId}/listen`);
    return true;
  } catch (error) {
    // Queue for later if offline
    await queueForSync({
      endpoint: `/api/podcasts/episodes/${episodeId}/listen`,
      method: 'POST',
      data: {}
    });
    return false;
  }
};
```

### 5.2 Media Optimization for Mobile

The backend will need to implement the following optimizations for mobile media delivery:

1. **Adaptive Bitrate Streaming**: Multiple quality levels for audio and video
2. **Image Resizing**: Server-side image resizing based on device capabilities
3. **Progressive Loading**: Chunked content delivery for large media files
4. **Compression**: Optimized compression for mobile networks
5. **CDN Integration**: Content delivery network for faster global access

## 6. Progress Tracking Integration

### 6.1 Progress Synchronization

```javascript
// src/services/progressService.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient from './api';
import { queueForSync } from './syncManager';

// Storage keys
const PROGRESS_DATA_KEY = 'user_progress';
const PROGRESS_SYNC_QUEUE_KEY = 'progress_sync_queue';

// Get user progress
export const getUserProgress = async () => {
  try {
    const progressData = await AsyncStorage.getItem(PROGRESS_DATA_KEY);
    return progressData ? JSON.parse(progressData) : null;
  } catch (error) {
    console.error('Error getting user progress:', error);
    return null;
  }
};

// Sync progress from server
export const syncProgressFromServer = async () => {
  try {
    const response = await apiClient.get('/api/mobile/progress');
    const progressData = response.data;
    
    await AsyncStorage.setItem(PROGRESS_DATA_KEY, JSON.stringify(progressData));
    
    return progressData;
  } catch (error) {
    console.error('Error syncing progress from server:', error);
    throw error;
  }
};

// Update content progress
export const updateContentProgress = async (contentId, progress) => {
  try {
    // Update local progress
    const progressData = await getUserProgress() || { content: {} };
    
    progressData.content[contentId] = {
      ...progressData.content[contentId],
      ...progress,
      lastUpdated: Date.now()
    };
    
    await AsyncStorage.setItem(PROGRESS_DATA_KEY, JSON.stringify(progressData));
    
    // Try to update server
    try {
      await apiClient.post('/api/mobile/progress/content', {
        contentId,
        progress
      });
    } catch (error) {
      // Queue for later if offline
      await queueForSync({
        endpoint: '/api/mobile/progress/content',
        method: 'POST',
        data: { contentId, progress }
      });
    }
    
    return true;
  } catch (error) {
    console.error(`Error updating content progress for ${contentId}:`, error);
    return false;
  }
};

// Update quiz progress
export const updateQuizProgress = async (quizId, results) => {
  try {
    // Update local progress
    const progressData = await getUserProgress() || { quizzes: {} };
    
    progressData.quizzes[quizId] = {
      ...progressData.quizzes[quizId],
      ...results,
      lastUpdated: Date.now()
    };
    
    await AsyncStorage.setItem(PROGRESS_DATA_KEY, JSON.stringify(progressData));
    
    // Try to update server
    try {
      await apiClient.post('/api/mobile/progress/quiz', {
        quizId,
        results
      });
    } catch (error) {
      // Queue for later if offline
      await queueForSync({
        endpoint: '/api/mobile/progress/quiz',
        method: 'POST',
        data: { quizId, results }
      });
    }
    
    return true;
  } catch (error) {
    console.error(`Error updating quiz progress for ${quizId}:`, error);
    return false;
  }
};

// Update course progress
export const updateCourseProgress = async (courseId, moduleId, progress) => {
  try {
    // Update local progress
    const progressData = await getUserProgress() || { courses: {} };
    
    if (!progressData.courses[courseId]) {
      progressData.courses[courseId] = { modules: {} };
    }
    
    progressData.courses[courseId].modules[moduleId] = {
      ...progressData.courses[courseId].modules[moduleId],
      ...progress,
      lastUpdated: Date.now()
    };
    
    // Calculate overall course progress
    const moduleCount = Object.keys(progressData.courses[courseId].modules).length;
    const completedModules = Object.values(progressData.courses[courseId].modules)
      .filter(module => module.completed).length;
    
    progressData.courses[courseId].overallProgress = moduleCount > 0 
      ? (completedModules / moduleCount) * 100 
      : 0;
    
    await AsyncStorage.setItem(PROGRESS_DATA_KEY, JSON.stringify(progressData));
    
    // Try to update server
    try {
      await apiClient.post('/api/mobile/progress/course', {
        courseId,
        moduleId,
        progress
      });
    } catch (error) {
      // Queue for later if offline
      await queueForSync({
        endpoint: '/api/mobile/progress/course',
        method: 'POST',
        data: { courseId, moduleId, progress }
      });
    }
    
    return true;
  } catch (error) {
    console.error(`Error updating course progress for ${courseId}/${moduleId}:`, error);
    return false;
  }
};
```

### 6.2 Backend Progress API Modifications

The existing progress tracking system will need the following modifications:

1. **Conflict Resolution**: Logic for handling conflicting progress updates
2. **Batch Updates**: Support for processing multiple progress updates in a single request
3. **Timestamp-Based Synchronization**: Use timestamps to determine the most recent updates
4. **Progress Aggregation**: Efficient calculation of overall progress metrics
5. **Cross-Platform Progress Views**: Consistent progress representation across platforms

## 7. Notification Integration

### 7.1 Push Notification Setup

```javascript
// src/services/notificationService.js
import messaging from '@react-native-firebase/messaging';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PushNotification from 'react-native-push-notification';
import apiClient from './api';

// Storage keys
const NOTIFICATION_TOKEN_KEY = 'fcm_token';
const NOTIFICATION_SETTINGS_KEY = 'notification_settings';

// Initialize notifications
export const initNotifications = async () => {
  try {
    // Configure local notifications
    PushNotification.configure({
      onNotification: function (notification) {
        console.log('LOCAL NOTIFICATION:', notification);
      },
      popInitialNotification: true,
      requestPermissions: false
    });
    
    // Create notification channels for Android
    PushNotification.createChannel(
      {
        channelId: 'content-updates',
        channelName: 'Content Updates',
        channelDescription: 'Notifications about new content and updates',
        importance: 4,
        vibrate: true
      },
      (created) => console.log(`Channel 'content-updates' created: ${created}`)
    );
    
    PushNotification.createChannel(
      {
        channelId: 'learning-reminders',
        channelName: 'Learning Reminders',
        channelDescription: 'Reminders about your learning goals and progress',
        importance: 3,
        vibrate: true
      },
      (created) => console.log(`Channel 'learning-reminders' created: ${created}`)
    );
    
    // Request permission for iOS
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
    
    if (enabled) {
      // Get FCM token
      const token = await messaging().getToken();
      await registerNotificationToken(token);
      
      // Listen for token refresh
      messaging().onTokenRefresh(token => {
        registerNotificationToken(token);
      });
      
      // Set up message handlers
      messaging().onMessage(async remoteMessage => {
        console.log('Foreground message received:', remoteMessage);
        
        // Display local notification for foreground messages
        PushNotification.localNotification({
          channelId: remoteMessage.data.channel || 'content-updates',
          title: remoteMessage.notification.title,
          message: remoteMessage.notification.body,
          data: remoteMessage.data
        });
      });
      
      // Handle background/quit state messages
      messaging().setBackgroundMessageHandler(async remoteMessage => {
        console.log('Background message received:', remoteMessage);
        return Promise.resolve();
      });
    }
    
    return enabled;
  } catch (error) {
    console.error('Error initializing notifications:', error);
    return false;
  }
};

// Register notification token with server
export const registerNotificationToken = async (token) => {
  try {
    // Save token locally
    await AsyncStorage.setItem(NOTIFICATION_TOKEN_KEY, token);
    
    // Register with server
    await apiClient.post('/api/mobile/notifications/register', { token });
    
    return true;
  } catch (error) {
    console.error('Error registering notification token:', error);
    return false;
  }
};

// Update notification settings
export const updateNotificationSettings = async (settings) => {
  try {
    // Get current settings
    const currentSettings = await getNotificationSettings();
    
    // Merge with new settings
    const updatedSettings = {
      ...currentSettings,
      ...settings
    };
    
    // Save locally
    await AsyncStorage.setItem(
      NOTIFICATION_SETTINGS_KEY,
      JSON.stringify(updatedSettings)
    );
    
    // Update on server
    await apiClient.post('/api/mobile/notifications/settings', updatedSettings);
    
    return updatedSettings;
  } catch (error) {
    console.error('Error updating notification settings:', error);
    throw error;
  }
};

// Get notification settings
export const getNotificationSettings = async () => {
  try {
    const settings = await AsyncStorage.getItem(NOTIFICATION_SETTINGS_KEY);
    
    // Default settings if none exist
    if (!settings) {
      return {
        contentUpdates: true,
        learningReminders: true,
        progressMilestones: true,
        newFeatures: true,
        marketingMessages: false,
        quietHoursEnabled: false,
        quietHoursStart: '22:00',
        quietHoursEnd: '08:00'
      };
    }
    
    return JSON.parse(settings);
  } catch (error) {
    console.error('Error getting notification settings:', error);
    return null;
  }
};
```

### 7.2 Backend Notification System Modifications

The existing notification system will need the following modifications:

1. **Device Registration**: Store and manage device tokens for each user
2. **Platform-Specific Formatting**: Optimize notification format for mobile
3. **Notification Preferences**: User-configurable notification settings
4. **Notification Categories**: Structured notification types for different purposes
5. **Delivery Scheduling**: Time zone aware notification delivery

## 8. AI Integration

### 8.1 Mobile AI Service Integration

```javascript
// src/services/aiService.js
import apiClient from './api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getNetworkStatus } from './network';

// Storage keys
const AI_CACHE_KEY_PREFIX = 'ai_cache_';
const AI_CACHE_EXPIRY = 7 * 24 * 60 * 60 * 1000; // 7 days

// Get content recommendations
export const getContentRecommendations = async (count = 5) => {
  try {
    // Check cache first
    const cacheKey = `${AI_CACHE_KEY_PREFIX}recommendations_${count}`;
    const cachedData = await AsyncStorage.getItem(cacheKey);
    
    if (cachedData) {
      const { data, timestamp } = JSON.parse(cachedData);
      
      // Use cache if less than expiry time and offline
      const isOnline = await getNetworkStatus();
      if (!isOnline || Date.now() - timestamp < AI_CACHE_EXPIRY) {
        return data;
      }
    }
    
    // Get fresh recommendations from API
    const response = await apiClient.get('/api/mobile/ai/recommendations', {
      params: { count }
    });
    
    // Cache the results
    await AsyncStorage.setItem(cacheKey, JSON.stringify({
      data: response.data,
      timestamp: Date.now()
    }));
    
    return response.data;
  } catch (error) {
    console.error('Error getting content recommendations:', error);
    
    // Fall back to cache if available
    const cacheKey = `${AI_CACHE_KEY_PREFIX}recommendations_${count}`;
    const cachedData = await AsyncStorage.getItem(cacheKey);
    
    if (cachedData) {
      const { data } = JSON.parse(cachedData);
      return data;
    }
    
    throw error;
  }
};

// Get concept explanation
export const getConceptExplanation = async (concept, difficulty = 'intermediate') => {
  try {
    // Check cache first
    const cacheKey = `${AI_CACHE_KEY_PREFIX}concept_${concept}_${difficulty}`;
    const cachedData = await AsyncStorage.getItem(cacheKey);
    
    if (cachedData) {
      const { data, timestamp } = JSON.parse(cachedData);
      
      // Use cache if less than expiry time and offline
      const isOnline = await getNetworkStatus();
      if (!isOnline || Date.now() - timestamp < AI_CACHE_EXPIRY) {
        return data;
      }
    }
    
    // Get explanation from API
    const response = await apiClient.post('/api/mobile/ai/explain', {
      concept,
      difficulty
    });
    
    // Cache the results
    await AsyncStorage.setItem(cacheKey, JSON.stringify({
      data: response.data,
      timestamp: Date.now()
    }));
    
    return response.data;
  } catch (error) {
    console.error(`Error getting explanation for concept "${concept}":`, error);
    
    // Fall back to cache if available
    const cacheKey = `${AI_CACHE_KEY_PREFIX}concept_${concept}_${difficulty}`;
    const cachedData = await AsyncStorage.getItem(cacheKey);
    
    if (cachedData) {
      const { data } = JSON.parse(cachedData);
      return data;
    }
    
    throw error;
  }
};

// Generate practice questions
export const generatePracticeQuestions = async (topic, count = 5, difficulty = 'intermediate') => {
  try {
    // This is less likely to be cached as it's more dynamic
    const response = await apiClient.post('/api/mobile/ai/generate-questions', {
      topic,
      count,
      difficulty
    });
    
    return response.data;
  } catch (error) {
    console.error(`Error generating practice questions for "${topic}":`, error);
    throw error;
  }
};

// Get learning path recommendation
export const getLearningPathRecommendation = async () => {
  try {
    // Check cache first
    const cacheKey = `${AI_CACHE_KEY_PREFIX}learning_path`;
    const cachedData = await AsyncStorage.getItem(cacheKey);
    
    if (cachedData) {
      const { data, timestamp } = JSON.parse(cachedData);
      
      // Use cache if less than expiry time and offline
      const isOnline = await getNetworkStatus();
      if (!isOnline || Date.now() - timestamp < AI_CACHE_EXPIRY) {
        return data;
      }
    }
    
    // Get learning path from API
    const response = await apiClient.get('/api/mobile/ai/learning-path');
    
    // Cache the results
    await AsyncStorage.setItem(cacheKey, JSON.stringify({
      data: response.data,
      timestamp: Date.now()
    }));
    
    return response.data;
  } catch (error) {
    console.error('Error getting learning path recommendation:', error);
    
    // Fall back to cache if available
    const cacheKey = `${AI_CACHE_KEY_PREFIX}learning_path`;
    const cachedData = await AsyncStorage.getItem(cacheKey);
    
    if (cachedData) {
      const { data } = JSON.parse(cachedData);
      return data;
    }
    
    throw error;
  }
};
```

### 8.2 Backend AI Service Modifications

The existing AI services will need the following modifications:

1. **Mobile-Optimized Responses**: Smaller payload sizes for mobile consumption
2. **Offline Support**: Cacheable responses for common AI requests
3. **Reduced Computation**: Simplified models for mobile-friendly performance
4. **Context-Aware Recommendations**: Location and time-aware suggestions
5. **Bandwidth-Efficient Updates**: Incremental model updates for mobile

## 9. Backend API Modifications

### 9.1 Required API Endpoints for Mobile

| Endpoint | Method | Purpose | Mobile-Specific Optimizations |
|----------|--------|---------|------------------------------|
| `/api/mobile/auth/login` | POST | Authenticate user with device info | Device registration, longer token expiry |
| `/api/mobile/auth/refresh` | POST | Refresh authentication token | Background token refresh |
| `/api/mobile/content/manifest` | GET | Get content manifest with updates | Incremental updates, compression |
| `/api/mobile/content/:id/download-info` | GET | Get content download information | Resource bundling, prioritization |
| `/api/mobile/progress` | GET | Get user progress | Compressed response, essential data only |
| `/api/mobile/progress/content` | POST | Update content progress | Batch update support, conflict resolution |
| `/api/mobile/progress/quiz` | POST | Update quiz progress | Result summarization, offline support |
| `/api/mobile/progress/course` | POST | Update course progress | Module-level updates, efficient sync |
| `/api/mobile/sync` | POST | Synchronize offline changes | Batch processing, conflict resolution |
| `/api/mobile/notifications/register` | POST | Register device for notifications | Platform-specific registration |
| `/api/mobile/notifications/settings` | POST | Update notification preferences | User-specific settings |
| `/api/mobile/ai/recommendations` | GET | Get personalized recommendations | Mobile-optimized response size |
| `/api/mobile/ai/explain` | POST | Get concept explanations | Cacheable responses |
| `/api/mobile/ai/generate-questions` | POST | Generate practice questions | Simplified question formats |
| `/api/mobile/ai/learning-path` | GET | Get personalized learning path | Mobile-optimized path structure |

### 9.2 API Response Optimization

The backend API responses should be optimized for mobile with:

1. **Reduced Payload Size**: Only essential fields in responses
2. **Pagination**: Smaller page sizes for mobile
3. **Compression**: GZIP/Brotli compression for all responses
4. **Caching Headers**: Proper cache control headers
5. **Partial Responses**: Support for requesting only needed fields

## 10. Implementation Considerations

### 10.1 Development Approach

1. **API-First Development**: Define and implement mobile-specific API endpoints before client development
2. **Shared Code**: Identify and refactor shared logic between web and mobile
3. **Feature Parity Planning**: Ensure core features work consistently across platforms
4. **Progressive Enhancement**: Implement basic functionality first, then add advanced features
5. **Continuous Integration**: Automated testing for cross-platform compatibility

### 10.2 Testing Strategy

1. **API Integration Testing**: Verify mobile API endpoints work as expected
2. **Offline Testing**: Validate functionality during connectivity loss
3. **Synchronization Testing**: Ensure data consistency across platforms
4. **Performance Testing**: Validate response times and resource usage
5. **Cross-Device Testing**: Test on various iOS and Android devices

### 10.3 Deployment Coordination

1. **Version Compatibility**: Ensure mobile app works with current backend version
2. **API Versioning**: Implement versioned APIs for backward compatibility
3. **Feature Flags**: Use feature flags to control feature availability
4. **Phased Rollout**: Coordinate backend and mobile app updates
5. **Rollback Plan**: Strategy for handling failed deployments

## 11. Conclusion

This integration guide provides a comprehensive approach for connecting the Radiation Oncology Academy mobile app with the existing web platform. By following these integration patterns, the mobile app will provide a seamless extension of the web experience while optimizing for mobile-specific considerations.

The implementation focuses on:
- Shared backend services with mobile-specific optimizations
- Robust authentication and data synchronization
- Efficient media handling for mobile networks
- Offline functionality with background synchronization
- Cross-platform progress tracking
- Mobile-optimized AI services

This approach ensures a consistent user experience across platforms while leveraging the unique capabilities of mobile devices for learning on the go.
