# Firebase Implementation Guide for Radiation Oncology Academy

This guide provides step-by-step instructions for implementing Firebase to enhance user engagement for the Radiation Oncology Academy platform. It's designed specifically for non-technical users to follow easily.

## Table of Contents

1. [Setting Up Firebase Account](#setting-up-firebase-account)
2. [Implementing Firebase Authentication](#implementing-firebase-authentication)
3. [Setting Up Realtime Database](#setting-up-realtime-database)
4. [Implementing User Progress Tracking](#implementing-user-progress-tracking)
5. [Adding Interactive Features](#adding-interactive-features)
6. [Setting Up Push Notifications](#setting-up-push-notifications)
7. [Testing and Troubleshooting](#testing-and-troubleshooting)
8. [Best Practices and Maintenance](#best-practices-and-maintenance)

## Setting Up Firebase Account

### Step 1: Create a Firebase Account

1. Go to [firebase.google.com](https://firebase.google.com/)
2. Click "Get started" or "Sign in" if you already have a Google account
3. You'll be taken to the Firebase console

### Step 2: Create a New Project

1. In the Firebase console, click "Add project"
2. Name your project "Radiation Oncology Academy"
3. Choose whether to enable Google Analytics (recommended)
4. Accept the terms and click "Create project"
5. Wait for your project to be set up, then click "Continue"

### Step 3: Register Your Web App

1. In the Firebase console, click the web icon (</>) to add a web app
2. Name your app "Radiation Oncology Academy Web"
3. Check the box for "Also set up Firebase Hosting" if you want to use Firebase for hosting
4. Click "Register app"
5. You'll see a code snippet with your Firebase configuration - save this information
6. Click "Continue to console"

## Implementing Firebase Authentication

### Step 1: Enable Authentication Methods

1. In the Firebase console, click "Authentication" in the left sidebar
2. Click "Get started"
3. Select "Email/Password" as the sign-in method
4. Toggle the "Enable" switch to on
5. Click "Save"
6. Repeat for any other authentication methods you want to enable (Google, Facebook, etc.)

### Step 2: Update Your Website Configuration

1. Upload the following file to `/home/ubuntu/radiation_oncology_academy/frontend/config/firebase-config.js`:

```javascript
// Firebase configuration
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};

export default firebaseConfig;
```

2. Replace all the placeholder values with your actual Firebase configuration values from Step 3 of "Setting Up Firebase Account"

### Step 3: Update Environment Variables

Add these lines to your `.env` file in the backend directory:

```
FIREBASE_API_KEY=your-api-key
FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
FIREBASE_MESSAGING_SENDER_ID=your-messaging-sender-id
FIREBASE_APP_ID=your-app-id
FIREBASE_MEASUREMENT_ID=your-measurement-id
```

Replace all placeholder values with your actual Firebase configuration.

## Setting Up Realtime Database

### Step 1: Create a Realtime Database

1. In the Firebase console, click "Realtime Database" in the left sidebar
2. Click "Create database"
3. Choose "Start in test mode" for now (we'll secure it later)
4. Click "Enable"

### Step 2: Set Up Database Rules

1. In the Realtime Database section, click the "Rules" tab
2. Replace the default rules with the following:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "courses": {
      ".read": "auth != null",
      ".write": "auth != null && root.child('users').child(auth.uid).child('role').val() === 'admin'"
    },
    "progress": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "discussions": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}
```

3. Click "Publish"

### Step 3: Set Up Initial Data Structure

1. In the Realtime Database section, click the "Data" tab
2. Click the "+" button to add a new node
3. Create the following structure:
   - Key: "courses", Value: (leave empty)
   - Key: "users", Value: (leave empty)
   - Key: "progress", Value: (leave empty)
   - Key: "discussions", Value: (leave empty)
4. Click "Add" for each node

## Implementing User Progress Tracking

### Step 1: Enable Progress Tracking in Admin Panel

1. Log in to your website's admin panel
2. Go to "Settings" > "Learning Features"
3. Find the "Progress Tracking" section
4. Toggle "Enable Firebase Progress Tracking" to "On"
5. Save your changes

### Step 2: Configure Progress Tracking Settings

1. Still in the admin panel, go to "Settings" > "Learning Features"
2. Configure the following options:
   - Track Course Completion: Enable
   - Track Quiz Attempts: Enable
   - Track Video Watching: Enable
   - Track Reading Time: Enable
3. Save your changes

### Step 3: Test Progress Tracking

1. Log in as a test user
2. Start a course and complete some activities
3. Check the Firebase Realtime Database to verify that progress data is being recorded
4. The data should appear under `progress/[user-id]/[course-id]`

## Adding Interactive Features

### Step 1: Enable Discussion Forums

1. In the admin panel, go to "Settings" > "Community Features"
2. Toggle "Enable Discussion Forums" to "On"
3. Configure the following options:
   - Allow File Attachments: Enable
   - Allow Image Uploads: Enable
   - Enable Notifications: Enable
4. Save your changes

### Step 2: Set Up Forum Categories

1. Go to "Community" > "Forum Categories"
2. Click "Add Category"
3. Create categories relevant to your content, such as:
   - General Discussion
   - Clinical Practice
   - Board Exam Preparation
   - Research Topics
4. Click "Create" for each category

### Step 3: Enable Real-time Chat

1. In the admin panel, go to "Settings" > "Community Features"
2. Toggle "Enable Real-time Chat" to "On"
3. Configure the following options:
   - Allow Private Messages: Enable
   - Allow Group Chats: Enable
   - Message History Limit: 100
4. Save your changes

## Setting Up Push Notifications

### Step 1: Configure Firebase Cloud Messaging

1. In the Firebase console, click "Cloud Messaging" in the left sidebar
2. Click "Set up Firebase Cloud Messaging"
3. Follow the prompts to enable Cloud Messaging

### Step 2: Generate a Server Key

1. In the Firebase console, go to "Project settings" (gear icon)
2. Click the "Cloud Messaging" tab
3. Under "Project credentials", find your "Server key"
4. Copy this key for the next step

### Step 3: Update Your Website Configuration

1. In your website's admin panel, go to "Settings" > "Notifications"
2. Find the "Push Notifications" section
3. Enter your Firebase Server Key
4. Toggle "Enable Push Notifications" to "On"
5. Save your changes

### Step 4: Configure Notification Types

1. Still in the "Notifications" section
2. Configure which events should trigger notifications:
   - New Course Available: Enable
   - New Blog Post: Enable
   - New Podcast Episode: Enable
   - Forum Replies: Enable
   - Course Completion: Enable
3. Save your changes

## Testing and Troubleshooting

### Testing Authentication

1. Log out of your website
2. Try to log in with a test account
3. Verify that you can successfully log in
4. Check the Firebase Authentication console to confirm the user appears there

### Testing Realtime Features

1. Open two browser windows side by side
2. Log in as different users in each window
3. Have one user post a comment in a discussion forum
4. Verify that the comment appears in the other window without refreshing

### Troubleshooting Common Issues

#### Issue: Authentication not working

Solution:
1. Check that you've correctly copied your Firebase configuration
2. Verify that the authentication method is enabled in Firebase
3. Check the browser console for any error messages

#### Issue: Realtime updates not working

Solution:
1. Check your database rules to ensure they allow reading/writing
2. Verify your internet connection
3. Check the browser console for any error messages

#### Issue: Push notifications not working

Solution:
1. Ensure the user has granted notification permissions in their browser
2. Verify that your Firebase Server Key is correct
3. Check that the service worker is properly registered

## Best Practices and Maintenance

### Regular Backups

1. In the Firebase console, go to "Realtime Database"
2. Click the "Export JSON" button to download a backup of your data
3. Store this backup securely
4. Set up a regular schedule for backups (weekly recommended)

### Monitoring Usage

1. In the Firebase console, go to "Usage and billing"
2. Monitor your usage to ensure you stay within free tier limits or your budget
3. Set up billing alerts if needed

### Security Best Practices

1. Regularly review and update your database rules
2. Use the principle of least privilege - only grant necessary access
3. Consider implementing additional authentication factors for admin users
4. Regularly audit user accounts and remove unused ones

## Conclusion

You've now set up Firebase for your Radiation Oncology Academy platform. This integration enables:

1. Secure user authentication
2. Real-time progress tracking
3. Interactive discussion forums
4. Push notifications for engagement

These features will significantly enhance user engagement and provide a more interactive learning experience for your users.

For any questions or issues, refer to the [Firebase documentation](https://firebase.google.com/docs) or contact your website administrator.
