# Regular Backup System Implementation for Radiation Oncology Academy

## Overview

This document outlines the implementation of an automated backup system for the Radiation Oncology Academy website hosted on GoDaddy. The backup system will ensure that both website files and database content are regularly backed up, easily restorable, and properly monitored.

## Backup Components

The backup system will cover:
1. Website files (frontend and backend code)
2. MongoDB database (user data, content, and configurations)
3. Google Cloud Storage content (educational materials and resources)
4. Configuration files and environment variables

## Automated Backup Workflow

### Website Files Backup

```bash
#!/bin/bash
# File: /home/username/backup_scripts/website_backup.sh

# Set variables
BACKUP_DIR="/home/username/backups/website"
WEBSITE_DIR="/home/username/public_html/radiation_oncology_academy"
DATE=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_FILENAME="roa_website_backup_$DATE.tar.gz"
RETENTION_DAYS=30

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Create compressed backup of website files
tar -czf $BACKUP_DIR/$BACKUP_FILENAME $WEBSITE_DIR

# Upload to Google Cloud Storage for offsite backup
gsutil cp $BACKUP_DIR/$BACKUP_FILENAME gs://roa-private-source-materials/backups/website/

# Remove backups older than retention period
find $BACKUP_DIR -name "roa_website_backup_*" -type f -mtime +$RETENTION_DAYS -delete

# Log backup completion
echo "Website backup completed: $BACKUP_FILENAME" >> $BACKUP_DIR/backup_log.txt
```

### MongoDB Database Backup

```bash
#!/bin/bash
# File: /home/username/backup_scripts/database_backup.sh

# Set variables
BACKUP_DIR="/home/username/backups/database"
DATE=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_FILENAME="roa_database_backup_$DATE"
MONGODB_URI="your_mongodb_connection_string"
RETENTION_DAYS=30

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Create MongoDB database backup
mongodump --uri="$MONGODB_URI" --out=$BACKUP_DIR/$BACKUP_FILENAME

# Compress the backup
tar -czf $BACKUP_DIR/$BACKUP_FILENAME.tar.gz $BACKUP_DIR/$BACKUP_FILENAME
rm -rf $BACKUP_DIR/$BACKUP_FILENAME

# Upload to Google Cloud Storage for offsite backup
gsutil cp $BACKUP_DIR/$BACKUP_FILENAME.tar.gz gs://roa-private-source-materials/backups/database/

# Remove backups older than retention period
find $BACKUP_DIR -name "roa_database_backup_*" -type f -mtime +$RETENTION_DAYS -delete

# Log backup completion
echo "Database backup completed: $BACKUP_FILENAME.tar.gz" >> $BACKUP_DIR/backup_log.txt
```

## Backup Schedule

The backup system will run on the following schedule:

| Component | Frequency | Retention Period | Storage Location |
|-----------|-----------|------------------|------------------|
| Website Files | Daily (2 AM) | 30 days | Local + Google Cloud Storage |
| Database | Daily (3 AM) | 30 days | Local + Google Cloud Storage |
| Full System | Weekly (Sunday 4 AM) | 90 days | Local + Google Cloud Storage |
| Configuration | After any change | Indefinite | Google Cloud Storage |

## Cron Job Configuration

Add the following to the server's crontab to automate the backup process:

```
# Daily website backup at 2 AM
0 2 * * * /home/username/backup_scripts/website_backup.sh

# Daily database backup at 3 AM
0 3 * * * /home/username/backup_scripts/database_backup.sh

# Weekly full system backup at 4 AM on Sundays
0 4 * * 0 /home/username/backup_scripts/full_system_backup.sh

# Backup monitoring check every hour
0 * * * * /home/username/backup_scripts/check_backup_status.sh
```

## Backup Monitoring and Notification

```bash
#!/bin/bash
# File: /home/username/backup_scripts/check_backup_status.sh

# Set variables
BACKUP_LOG_DIR="/home/username/backups"
EMAIL="your_email@example.com"
CURRENT_DATE=$(date +"%Y-%m-%d")

# Check website backup
LATEST_WEBSITE_BACKUP=$(ls -t $BACKUP_LOG_DIR/website/roa_website_backup_* 2>/dev/null | head -n1)
if [ -z "$LATEST_WEBSITE_BACKUP" ] || [ $(date -r "$LATEST_WEBSITE_BACKUP" +%Y-%m-%d) != "$CURRENT_DATE" ]; then
    echo "WARNING: No website backup found for today ($CURRENT_DATE)" | mail -s "Radiation Oncology Academy Backup Alert" $EMAIL
fi

# Check database backup
LATEST_DB_BACKUP=$(ls -t $BACKUP_LOG_DIR/database/roa_database_backup_* 2>/dev/null | head -n1)
if [ -z "$LATEST_DB_BACKUP" ] || [ $(date -r "$LATEST_DB_BACKUP" +%Y-%m-%d) != "$CURRENT_DATE" ]; then
    echo "WARNING: No database backup found for today ($CURRENT_DATE)" | mail -s "Radiation Oncology Academy Backup Alert" $EMAIL
fi
```

## Backup Restoration Procedure

### Website Files Restoration

1. Access the backup directory or Google Cloud Storage bucket
2. Select the appropriate backup file based on the date needed
3. Extract the backup to a temporary directory:
   ```bash
   mkdir -p /home/username/restore_temp
   tar -xzf /home/username/backups/website/roa_website_backup_YYYY-MM-DD_HH-MM-SS.tar.gz -C /home/username/restore_temp
   ```
4. Copy the files to the website directory:
   ```bash
   cp -r /home/username/restore_temp/home/username/public_html/radiation_oncology_academy/* /home/username/public_html/radiation_oncology_academy/
   ```
5. Set proper permissions:
   ```bash
   chmod -R 755 /home/username/public_html/radiation_oncology_academy
   ```
6. Restart the Node.js application:
   ```bash
   # Through cPanel Node.js interface or command line
   pm2 restart radiation_oncology_academy
   ```

### MongoDB Database Restoration

1. Access the backup directory or Google Cloud Storage bucket
2. Select the appropriate backup file based on the date needed
3. Extract the backup to a temporary directory:
   ```bash
   mkdir -p /home/username/restore_temp
   tar -xzf /home/username/backups/database/roa_database_backup_YYYY-MM-DD_HH-MM-SS.tar.gz -C /home/username/restore_temp
   ```
4. Restore the database:
   ```bash
   mongorestore --uri="your_mongodb_connection_string" --drop /home/username/restore_temp/roa_database_backup_YYYY-MM-DD_HH-MM-SS/radiationOncologyAcademy
   ```

## GoDaddy-Specific Implementation

Since GoDaddy shared hosting has some limitations, the following adjustments are necessary:

1. Use GoDaddy's cPanel Backup feature as an additional layer of protection
2. Configure the backup scripts to work within GoDaddy's environment:
   - Use relative paths compatible with GoDaddy's directory structure
   - Ensure scripts have proper execution permissions
   - Work within GoDaddy's resource limitations

3. For GoDaddy cPanel, access the backup feature:
   - Log in to GoDaddy cPanel
   - Navigate to "Backup" under the "Files" section
   - Configure daily backups of the home directory
   - Download these backups regularly to a local computer as an additional safeguard

## Implementation Steps

1. Create the backup directory structure:
   ```bash
   mkdir -p /home/username/backups/website
   mkdir -p /home/username/backups/database
   mkdir -p /home/username/backup_scripts
   ```

2. Create the backup scripts as outlined above

3. Make the scripts executable:
   ```bash
   chmod +x /home/username/backup_scripts/*.sh
   ```

4. Set up cron jobs through GoDaddy cPanel:
   - Access cPanel > Advanced > Cron Jobs
   - Add each cron job as specified in the schedule

5. Test each backup script manually to ensure it works correctly

6. Verify the first automated backups and check notification system

7. Document the backup system in the admin guide

## Conclusion

This backup system provides comprehensive protection for the Radiation Oncology Academy website with:
- Regular automated backups of all critical components
- Offsite storage in Google Cloud for disaster recovery
- Monitoring and notification system for backup failures
- Clear restoration procedures for quick recovery
- Retention policies to manage storage efficiently

The system is designed to be low-maintenance while providing robust protection against data loss.
