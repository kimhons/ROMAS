# Implementation Plan for Podcast, News, and Advanced Courses

## Overview

This document outlines the implementation strategy for adding podcast functionality, news section, and advanced short courses to the Radiation Oncology Academy website. These features will enhance the educational value of the platform and provide users with diverse learning options.

## 1. Podcast Implementation

### Database Schema

```javascript
// models/PodcastEpisode.js
const mongoose = require('mongoose');

const PodcastEpisodeSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  audioUrl: { type: String, required: true },
  duration: { type: Number, required: true }, // in seconds
  thumbnailUrl: { type: String },
  publishDate: { type: Date, default: Date.now },
  categories: [{ type: String }],
  tags: [{ type: String }],
  transcript: { type: String },
  hosts: [{ 
    name: String, 
    title: String, 
    bio: String, 
    imageUrl: String 
  }],
  guests: [{ 
    name: String, 
    title: String, 
    bio: String, 
    imageUrl: String 
  }],
  relatedResources: [{
    title: String,
    url: String,
    type: { type: String, enum: ['article', 'video', 'course', 'reference'] }
  }],
  aiGenerated: { type: Boolean, default: false },
  downloadable: { type: Boolean, default: true },
  featured: { type: Boolean, default: false },
  listens: { type: Number, default: 0 },
  ratings: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rating: { type: Number, min: 1, max: 5 },
    comment: String,
    date: { type: Date, default: Date.now }
  }]
});

module.exports = mongoose.model('PodcastEpisode', PodcastEpisodeSchema);
```

### API Endpoints

```javascript
// routes/podcast.routes.js
const express = require('express');
const router = express.Router();
const podcastController = require('../controllers/podcast.controller');
const authMiddleware = require('../middleware/auth');

// Public routes
router.get('/episodes', podcastController.getAllEpisodes);
router.get('/episodes/:id', podcastController.getEpisodeById);
router.get('/episodes/category/:category', podcastController.getEpisodesByCategory);
router.get('/episodes/featured', podcastController.getFeaturedEpisodes);
router.get('/episodes/latest', podcastController.getLatestEpisodes);

// Protected routes
router.post('/episodes', authMiddleware.verifyToken, authMiddleware.isAdmin, podcastController.createEpisode);
router.put('/episodes/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, podcastController.updateEpisode);
router.delete('/episodes/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, podcastController.deleteEpisode);
router.post('/episodes/:id/listen', authMiddleware.verifyToken, podcastController.recordListen);
router.post('/episodes/:id/rate', authMiddleware.verifyToken, podcastController.rateEpisode);

// AI generation routes
router.post('/generate', authMiddleware.verifyToken, authMiddleware.isAdmin, podcastController.generatePodcast);
router.post('/generate-transcript', authMiddleware.verifyToken, authMiddleware.isAdmin, podcastController.generateTranscript);

module.exports = router;
```

### Controller Implementation

```javascript
// controllers/podcast.controller.js
const PodcastEpisode = require('../models/PodcastEpisode');
const openaiService = require('../services/openai.service');
const elevenlabsService = require('../services/elevenlabs.service');
const cloudStorageService = require('../services/cloud-storage.service');

// Get all podcast episodes with pagination
exports.getAllEpisodes = async (req, res) => {
  try {
    const { page = 1, limit = 10, sort = '-publishDate' } = req.query;
    
    const episodes = await PodcastEpisode.find()
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
      
    const count = await PodcastEpisode.countDocuments();
    
    res.json({
      episodes,
      totalPages: Math.ceil(count / limit),
      currentPage: page
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get episode by ID
exports.getEpisodeById = async (req, res) => {
  try {
    const episode = await PodcastEpisode.findById(req.params.id);
    if (!episode) {
      return res.status(404).json({ message: 'Episode not found' });
    }
    res.json(episode);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get episodes by category
exports.getEpisodesByCategory = async (req, res) => {
  try {
    const { page = 1, limit = 10, sort = '-publishDate' } = req.query;
    
    const episodes = await PodcastEpisode.find({ categories: req.params.category })
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
      
    const count = await PodcastEpisode.countDocuments({ categories: req.params.category });
    
    res.json({
      episodes,
      totalPages: Math.ceil(count / limit),
      currentPage: page
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create new episode
exports.createEpisode = async (req, res) => {
  try {
    const newEpisode = new PodcastEpisode(req.body);
    const savedEpisode = await newEpisode.save();
    res.status(201).json(savedEpisode);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Generate podcast using AI
exports.generatePodcast = async (req, res) => {
  try {
    const { topic, duration, voiceType, style } = req.body;
    
    // Generate podcast script using OpenAI
    const script = await openaiService.generatePodcastScript(topic, duration, style);
    
    // Convert script to audio using ElevenLabs
    const audioFile = await elevenlabsService.textToSpeech(script.content, voiceType);
    
    // Upload audio to cloud storage
    const audioUrl = await cloudStorageService.uploadAudio(audioFile, `podcasts/${Date.now()}.mp3`);
    
    // Create new podcast episode
    const newEpisode = new PodcastEpisode({
      title: script.title,
      description: script.description,
      audioUrl: audioUrl,
      duration: duration * 60, // convert minutes to seconds
      transcript: script.content,
      categories: script.categories,
      tags: script.tags,
      aiGenerated: true,
      publishDate: new Date()
    });
    
    const savedEpisode = await newEpisode.save();
    res.status(201).json(savedEpisode);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Additional controller methods...
```

### Frontend Components

```jsx
// components/podcast/PodcastPlayer.tsx
import React, { useState, useRef, useEffect } from 'react';
import { formatTime } from '../../lib/utils';

interface PodcastPlayerProps {
  episode: {
    id: string;
    title: string;
    audioUrl: string;
    duration: number;
    thumbnailUrl?: string;
  };
  onComplete?: () => void;
}

const PodcastPlayer: React.FC<PodcastPlayerProps> = ({ episode, onComplete }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [playbackRate, setPlaybackRate] = useState(1);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  
  useEffect(() => {
    // Record listen when playback reaches 10%
    const handleTimeUpdate = () => {
      if (audioRef.current) {
        setCurrentTime(audioRef.current.currentTime);
        
        // Record listen when 10% of podcast is played
        if (audioRef.current.currentTime > episode.duration * 0.1 && !listenRecorded) {
          recordListen(episode.id);
          setListenRecorded(true);
        }
      }
    };
    
    const handleEnded = () => {
      setIsPlaying(false);
      if (onComplete) onComplete();
    };
    
    const audioElement = audioRef.current;
    if (audioElement) {
      audioElement.addEventListener('timeupdate', handleTimeUpdate);
      audioElement.addEventListener('ended', handleEnded);
    }
    
    return () => {
      if (audioElement) {
        audioElement.removeEventListener('timeupdate', handleTimeUpdate);
        audioElement.removeEventListener('ended', handleEnded);
      }
    };
  }, [episode.id, episode.duration, onComplete]);
  
  const [listenRecorded, setListenRecorded] = useState(false);
  
  const recordListen = async (episodeId: string) => {
    try {
      await fetch(`/api/podcast/episodes/${episodeId}/listen`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
    } catch (error) {
      console.error('Error recording listen:', error);
    }
  };
  
  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };
  
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };
  
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const seekTime = parseFloat(e.target.value);
    setCurrentTime(seekTime);
    if (audioRef.current) {
      audioRef.current.currentTime = seekTime;
    }
  };
  
  const handlePlaybackRateChange = (rate: number) => {
    setPlaybackRate(rate);
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4 w-full">
      <audio ref={audioRef} src={episode.audioUrl} preload="metadata" />
      
      <div className="flex items-center mb-4">
        {episode.thumbnailUrl && (
          <img 
            src={episode.thumbnailUrl} 
            alt={episode.title} 
            className="w-16 h-16 rounded mr-4"
          />
        )}
        <div>
          <h3 className="text-lg font-semibold">{episode.title}</h3>
          <div className="text-gray-500 text-sm">
            {formatTime(currentTime)} / {formatTime(episode.duration)}
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <input
          type="range"
          min="0"
          max={episode.duration}
          value={currentTime}
          onChange={handleSeek}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => {
              if (audioRef.current) {
                audioRef.current.currentTime = Math.max(0, currentTime - 15);
              }
            }}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200"
            aria-label="Rewind 15 seconds"
          >
            -15s
          </button>
          
          <button
            onClick={togglePlayPause}
            className="p-3 rounded-full bg-blue-600 text-white hover:bg-blue-700"
            aria-label={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? "⏸️" : "▶️"}
          </button>
          
          <button
            onClick={() => {
              if (audioRef.current) {
                audioRef.current.currentTime = Math.min(episode.duration, currentTime + 15);
              }
            }}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200"
            aria-label="Forward 15 seconds"
          >
            +15s
          </button>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => handlePlaybackRateChange(playbackRate === 2 ? 1 : playbackRate + 0.25)}
            className="px-2 py-1 text-sm rounded bg-gray-100 hover:bg-gray-200"
          >
            {playbackRate}x
          </button>
          
          <div className="flex items-center">
            <span className="mr-2">🔊</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={handleVolumeChange}
              className="w-20 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PodcastPlayer;
```

```jsx
// pages/podcast/index.tsx
import { useState, useEffect } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PodcastEpisodeCard from '../../components/podcast/PodcastEpisodeCard';
import PodcastPlayer from '../../components/podcast/PodcastPlayer';
import { usePodcastEpisodes } from '../../hooks/usePodcastEpisodes';

const PodcastPage = () => {
  const { episodes, isLoading, error } = usePodcastEpisodes();
  const [selectedEpisode, setSelectedEpisode] = useState(null);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  useEffect(() => {
    if (episodes) {
      // Extract unique categories from episodes
      const allCategories = episodes.flatMap(episode => episode.categories);
      const uniqueCategories = [...new Set(allCategories)];
      setCategories(uniqueCategories);
    }
  }, [episodes]);
  
  const filteredEpisodes = selectedCategory === 'all'
    ? episodes
    : episodes?.filter(episode => episode.categories.includes(selectedCategory));
  
  if (isLoading) {
    return (
      <MainLayout title="Podcasts | Loading...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </MainLayout>
    );
  }
  
  if (error) {
    return (
      <MainLayout title="Podcasts | Error">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <p>Error loading podcast episodes. Please try again later.</p>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout title="Radiation Oncology Podcasts">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Radiation Oncology Podcasts</h1>
        <p className="text-gray-600 mt-2">
          Listen to expert discussions on the latest developments in radiation oncology.
        </p>
      </div>
      
      {selectedEpisode && (
        <div className="mb-8">
          <PodcastPlayer 
            episode={selectedEpisode} 
            onComplete={() => console.log('Podcast completed')}
          />
        </div>
      )}
      
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-full text-sm font-medium ${
              selectedCategory === 'all' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
          >
            All Episodes
          </button>
          
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                selectedCategory === category 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEpisodes?.map(episode => (
          <PodcastEpisodeCard 
            key={episode.id} 
            episode={episode}
            onClick={() => setSelectedEpisode(episode)}
          />
        ))}
      </div>
    </MainLayout>
  );
};

export default PodcastPage;
```

### AI Integration for Podcast Generation

```javascript
// services/openai.service.js
// Add podcast generation methods

exports.generatePodcastScript = async (topic, duration, style) => {
  try {
    const prompt = `Create a podcast script about ${topic} in radiation oncology. 
    The podcast should be approximately ${duration} minutes long when read aloud at a normal pace.
    Style: ${style}
    
    Include the following:
    1. An engaging title
    2. A brief description for the episode
    3. An introduction that hooks the listener
    4. Main content with clear sections
    5. A conclusion with key takeaways
    6. Suggested categories and tags
    
    Format the response as a JSON object with the following structure:
    {
      "title": "Episode title",
      "description": "Brief episode description",
      "content": "Full podcast script",
      "categories": ["category1", "category2"],
      "tags": ["tag1", "tag2", "tag3"]
    }`;
    
    const response = await openai.createCompletion({
      model: "gpt-4",
      prompt: prompt,
      max_tokens: 4000,
      temperature: 0.7,
    });
    
    return JSON.parse(response.data.choices[0].text.trim());
  } catch (error) {
    console.error('Error generating podcast script with OpenAI:', error);
    throw error;
  }
};
```

```javascript
// services/elevenlabs.service.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const config = require('../config');

class ElevenLabsService {
  constructor() {
    this.apiKey = config.ELEVENLABS_API_KEY;
    this.baseUrl = 'https://api.elevenlabs.io/v1';
  }
  
  async textToSpeech(text, voiceId = 'ErXwobaYiN019PkySvjV') {
    try {
      const response = await axios({
        method: 'post',
        url: `${this.baseUrl}/text-to-speech/${voiceId}`,
        data: {
          text: text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5
          }
        },
        headers: {
          'Accept': 'audio/mpeg',
          'xi-api-key': this.apiKey,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      });
      
      // Save audio file temporarily
      const tempFilePath = path.join(__dirname, '../temp', `${Date.now()}.mp3`);
      fs.writeFileSync(tempFilePath, response.data);
      
      return tempFilePath;
    } catch (error) {
      console.error('Error in ElevenLabs text-to-speech:', error);
      throw error;
    }
  }
  
  async getVoices() {
    try {
      const response = await axios({
        method: 'get',
        url: `${this.baseUrl}/voices`,
        headers: {
          'xi-api-key': this.apiKey
        }
      });
      
      return response.data.voices;
    } catch (error) {
      console.error('Error getting ElevenLabs voices:', error);
      throw error;
    }
  }
}

module.exports = new ElevenLabsService();
```

## 2. News Section Implementation

### Database Schema

```javascript
// models/NewsArticle.js
const mongoose = require('mongoose');

const NewsArticleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  summary: { type: String, required: true },
  content: { type: String, required: true },
  source: { 
    name: { type: String, required: true },
    url: { type: String, required: true }
  },
  publishDate: { type: Date, required: true },
  importDate: { type: Date, default: Date.now },
  categories: [{ type: String }],
  tags: [{ type: String }],
  imageUrl: { type: String },
  author: { type: String },
  aiProcessed: { type: Boolean, default: false },
  aiSummary: { type: String },
  relevanceScore: { type: Number, default: 0 }, // 0-100 scale
  featured: { type: Boolean, default: false },
  views: { type: Number, default: 0 },
  bookmarks: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  relatedContent: [{
    contentId: { type: mongoose.Schema.Types.ObjectId, refPath: 'relatedContentType' },
    contentType: { type: String, enum: ['Content', 'PodcastEpisode', 'Course'] },
    title: String,
    relevanceScore: Number
  }]
});

// Add text index for search functionality
NewsArticleSchema.index({ 
  title: 'text', 
  summary: 'text', 
  content: 'text',
  'source.name': 'text',
  author: 'text',
  categories: 'text',
  tags: 'text'
});

module.exports = mongoose.model('NewsArticle', NewsArticleSchema);
```

### API Endpoints

```javascript
// routes/news.routes.js
const express = require('express');
const router = express.Router();
const newsController = require('../controllers/news.controller');
const authMiddleware = require('../middleware/auth');

// Public routes
router.get('/articles', newsController.getAllArticles);
router.get('/articles/:id', newsController.getArticleById);
router.get('/articles/category/:category', newsController.getArticlesByCategory);
router.get('/articles/featured', newsController.getFeaturedArticles);
router.get('/articles/latest', newsController.getLatestArticles);
router.get('/articles/search', newsController.searchArticles);

// Protected routes
router.post('/articles', authMiddleware.verifyToken, authMiddleware.isAdmin, newsController.createArticle);
router.put('/articles/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, newsController.updateArticle);
router.delete('/articles/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, newsController.deleteArticle);
router.post('/articles/:id/view', authMiddleware.verifyToken, newsController.recordView);
router.post('/articles/:id/bookmark', authMiddleware.verifyToken, newsController.bookmarkArticle);
router.delete('/articles/:id/bookmark', authMiddleware.verifyToken, newsController.removeBookmark);

// AI processing routes
router.post('/fetch-external', authMiddleware.verifyToken, authMiddleware.isAdmin, newsController.fetchExternalNews);
router.post('/process-article', authMiddleware.verifyToken, authMiddleware.isAdmin, newsController.processArticleWithAI);
router.post('/generate-related', authMiddleware.verifyToken, authMiddleware.isAdmin, newsController.generateRelatedContent);

module.exports = router;
```

### Controller Implementation

```javascript
// controllers/news.controller.js
const NewsArticle = require('../models/NewsArticle');
const openaiService = require('../services/openai.service');
const newsAggregatorService = require('../services/news-aggregator.service');
const cloudStorageService = require('../services/cloud-storage.service');

// Get all news articles with pagination and filtering
exports.getAllArticles = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 10, 
      sort = '-publishDate',
      category,
      tag,
      startDate,
      endDate
    } = req.query;
    
    // Build filter object
    const filter = {};
    if (category) filter.categories = category;
    if (tag) filter.tags = tag;
    
    // Date range filter
    if (startDate || endDate) {
      filter.publishDate = {};
      if (startDate) filter.publishDate.$gte = new Date(startDate);
      if (endDate) filter.publishDate.$lte = new Date(endDate);
    }
    
    const articles = await NewsArticle.find(filter)
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
      
    const count = await NewsArticle.countDocuments(filter);
    
    res.json({
      articles,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      totalArticles: count
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get article by ID
exports.getArticleById = async (req, res) => {
  try {
    const article = await NewsArticle.findById(req.params.id);
    if (!article) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json(article);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Search articles
exports.searchArticles = async (req, res) => {
  try {
    const { q, page = 1, limit = 10 } = req.query;
    
    if (!q) {
      return res.status(400).json({ message: 'Search query is required' });
    }
    
    const articles = await NewsArticle.find(
      { $text: { $search: q } },
      { score: { $meta: 'textScore' } }
    )
      .sort({ score: { $meta: 'textScore' } })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
      
    const count = await NewsArticle.countDocuments({ $text: { $search: q } });
    
    res.json({
      articles,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      totalArticles: count
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Fetch external news
exports.fetchExternalNews = async (req, res) => {
  try {
    const { sources, categories, limit = 10 } = req.body;
    
    // Fetch news from external sources
    const newsArticles = await newsAggregatorService.fetchNews(sources, categories, limit);
    
    // Process and save each article
    const savedArticles = [];
    for (const article of newsArticles) {
      // Check if article already exists by URL
      const existingArticle = await NewsArticle.findOne({ 'source.url': article.sourceUrl });
      
      if (!existingArticle) {
        // Process article with AI
        const processedArticle = await openaiService.processNewsArticle(
          article.title,
          article.content,
          article.source,
          categories
        );
        
        // Save image if exists
        let imageUrl = article.imageUrl;
        if (imageUrl) {
          imageUrl = await cloudStorageService.uploadImageFromUrl(
            imageUrl, 
            `news/${Date.now()}-${article.title.replace(/[^a-z0-9]/gi, '-').toLowerCase()}.jpg`
          );
        }
        
        // Create new article
        const newArticle = new NewsArticle({
          title: article.title,
          summary: processedArticle.summary,
          content: article.content,
          source: {
            name: article.sourceName,
            url: article.sourceUrl
          },
          publishDate: article.publishDate || new Date(),
          categories: processedArticle.categories,
          tags: processedArticle.tags,
          imageUrl: imageUrl,
          author: article.author,
          aiProcessed: true,
          aiSummary: processedArticle.summary,
          relevanceScore: processedArticle.relevanceScore
        });
        
        const savedArticle = await newArticle.save();
        savedArticles.push(savedArticle);
      }
    }
    
    res.status(201).json({
      message: `Fetched and processed ${savedArticles.length} new articles`,
      articles: savedArticles
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Additional controller methods...
```

### News Aggregator Service

```javascript
// services/news-aggregator.service.js
const axios = require('axios');
const cheerio = require('cheerio');
const config = require('../config');

class NewsAggregatorService {
  constructor() {
    this.sources = {
      'aapm': {
        url: 'https://www.aapm.org/news/',
        parser: this.parseAAPMNews
      },
      'astro': {
        url: 'https://www.astro.org/News-and-Publications/News-and-Media-Center/News-Releases',
        parser: this.parseASTRONews
      },
      'medicalphysicsweb': {
        url: 'https://medicalphysicsweb.org/news/',
        parser: this.parseMedicalPhysicsWebNews
      },
      // Add more sources as needed
    };
  }
  
  async fetchNews(sources = [], categories = [], limit = 10) {
    try {
      let allArticles = [];
      
      // If no sources specified, use all available sources
      const sourcesToFetch = sources.length > 0 ? sources : Object.keys(this.sources);
      
      // Fetch from each source
      for (const source of sourcesToFetch) {
        if (this.sources[source]) {
          const sourceArticles = await this.fetchFromSource(source, categories);
          allArticles = [...allArticles, ...sourceArticles];
        }
      }
      
      // Sort by publish date (newest first) and limit results
      allArticles.sort((a, b) => new Date(b.publishDate) - new Date(a.publishDate));
      return allArticles.slice(0, limit);
    } catch (error) {
      console.error('Error fetching news:', error);
      throw error;
    }
  }
  
  async fetchFromSource(source, categories = []) {
    try {
      const sourceConfig = this.sources[source];
      if (!sourceConfig) {
        throw new Error(`Source ${source} not configured`);
      }
      
      const response = await axios.get(sourceConfig.url);
      const articles = await sourceConfig.parser(response.data, categories);
      
      return articles.map(article => ({
        ...article,
        sourceName: source
      }));
    } catch (error) {
      console.error(`Error fetching from source ${source}:`, error);
      return [];
    }
  }
  
  // Example parser for AAPM news
  async parseAAPMNews(html, categories = []) {
    try {
      const $ = cheerio.load(html);
      const articles = [];
      
      $('.news-item').each((i, element) => {
        const title = $(element).find('.news-title').text().trim();
        const summary = $(element).find('.news-summary').text().trim();
        const url = $(element).find('.news-title a').attr('href');
        const publishDate = $(element).find('.news-date').text().trim();
        const imageUrl = $(element).find('img').attr('src');
        
        articles.push({
          title,
          content: summary,
          sourceUrl: url,
          publishDate: new Date(publishDate),
          imageUrl
        });
      });
      
      return articles;
    } catch (error) {
      console.error('Error parsing AAPM news:', error);
      return [];
    }
  }
  
  // Additional parsers for other sources...
}

module.exports = new NewsAggregatorService();
```

### Frontend Components

```jsx
// pages/news/index.tsx
import { useState, useEffect } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import NewsArticleCard from '../../components/news/NewsArticleCard';
import NewsFilter from '../../components/news/NewsFilter';
import NewsSearch from '../../components/news/NewsSearch';
import Pagination from '../../components/common/Pagination';
import { useNewsArticles } from '../../hooks/useNewsArticles';

const NewsPage = () => {
  const [page, setPage] = useState(1);
  const [category, setCategory] = useState('');
  const [tag, setTag] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  
  const { 
    articles, 
    isLoading, 
    error, 
    totalPages, 
    totalArticles 
  } = useNewsArticles({ 
    page, 
    category, 
    tag, 
    searchQuery,
    startDate: dateRange.start,
    endDate: dateRange.end
  });
  
  const handleSearch = (query) => {
    setSearchQuery(query);
    setPage(1);
  };
  
  const handleFilterChange = (filters) => {
    setCategory(filters.category || '');
    setTag(filters.tag || '');
    setDateRange({
      start: filters.startDate || '',
      end: filters.endDate || ''
    });
    setPage(1);
  };
  
  const handlePageChange = (newPage) => {
    setPage(newPage);
    window.scrollTo(0, 0);
  };
  
  if (isLoading && page === 1) {
    return (
      <MainLayout title="News | Loading...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </MainLayout>
    );
  }
  
  if (error) {
    return (
      <MainLayout title="News | Error">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <p>Error loading news articles. Please try again later.</p>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout title="Radiation Oncology News">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Radiation Oncology News</h1>
        <p className="text-gray-600 mt-2">
          Stay updated with the latest developments in radiation oncology.
        </p>
      </div>
      
      <div className="mb-8 flex flex-col md:flex-row gap-4">
        <div className="md:w-1/3">
          <NewsSearch onSearch={handleSearch} />
        </div>
        <div className="md:w-2/3">
          <NewsFilter onFilterChange={handleFilterChange} />
        </div>
      </div>
      
      {articles?.length === 0 ? (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded">
          <p>No articles found matching your criteria. Try adjusting your filters or search query.</p>
        </div>
      ) : (
        <>
          <div className="mb-4">
            <p className="text-gray-600">
              Showing {articles?.length} of {totalArticles} articles
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {articles?.map(article => (
              <NewsArticleCard key={article.id} article={article} />
            ))}
          </div>
          
          <Pagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </>
      )}
    </MainLayout>
  );
};

export default NewsPage;
```

```jsx
// components/news/NewsArticleCard.tsx
import React from 'react';
import Link from 'next/link';
import { formatDate } from '../../lib/utils';

interface NewsArticleCardProps {
  article: {
    id: string;
    title: string;
    summary: string;
    source: {
      name: string;
      url: string;
    };
    publishDate: string;
    imageUrl?: string;
    categories: string[];
  };
}

const NewsArticleCard: React.FC<NewsArticleCardProps> = ({ article }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      {article.imageUrl && (
        <div className="h-48 overflow-hidden">
          <img 
            src={article.imageUrl} 
            alt={article.title}
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </div>
      )}
      
      <div className="p-4">
        <div className="flex items-center mb-2">
          <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded">
            {article.source.name}
          </span>
          <span className="text-xs text-gray-500 ml-2">
            {formatDate(article.publishDate)}
          </span>
        </div>
        
        <h3 className="text-lg font-semibold mb-2 line-clamp-2">
          <Link href={`/news/${article.id}`}>
            <a className="text-gray-800 hover:text-blue-600">{article.title}</a>
          </Link>
        </h3>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-3">
          {article.summary}
        </p>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {article.categories.slice(0, 3).map(category => (
            <Link 
              key={category} 
              href={`/news?category=${encodeURIComponent(category)}`}
            >
              <a className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded hover:bg-gray-200">
                {category}
              </a>
            </Link>
          ))}
        </div>
        
        <Link href={`/news/${article.id}`}>
          <a className="text-sm font-medium text-blue-600 hover:text-blue-800">
            Read more →
          </a>
        </Link>
      </div>
    </div>
  );
};

export default NewsArticleCard;
```

## 3. Advanced Short Courses Implementation

### Database Schema

```javascript
// models/ShortCourse.js
const mongoose = require('mongoose');

const ModuleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  content: { type: String, required: true },
  videoUrl: { type: String },
  duration: { type: Number }, // in minutes
  order: { type: Number, required: true },
  resources: [{
    title: String,
    description: String,
    url: String,
    type: { type: String, enum: ['pdf', 'video', 'link', 'image'] }
  }]
});

const AssessmentSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  questions: [{
    text: { type: String, required: true },
    type: { type: String, enum: ['multiple-choice', 'true-false', 'matching', 'calculation'], required: true },
    options: [{
      text: String,
      isCorrect: Boolean
    }],
    explanation: String,
    points: { type: Number, default: 1 }
  }],
  passingScore: { type: Number, default: 70 }, // percentage
  timeLimit: { type: Number }, // in minutes
  attempts: { type: Number, default: -1 } // -1 for unlimited
});

const ShortCourseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  objectives: [{ type: String }],
  level: { type: String, enum: ['beginner', 'intermediate', 'advanced'], required: true },
  categories: [{ type: String }],
  tags: [{ type: String }],
  thumbnailUrl: { type: String },
  duration: { type: Number }, // total duration in minutes
  modules: [ModuleSchema],
  assessment: AssessmentSchema,
  prerequisites: [{
    courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'ShortCourse' },
    title: String
  }],
  instructors: [{
    name: String,
    title: String,
    bio: String,
    imageUrl: String
  }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  published: { type: Boolean, default: false },
  featured: { type: Boolean, default: false },
  enrollments: { type: Number, default: 0 },
  completions: { type: Number, default: 0 },
  averageRating: { type: Number, default: 0 },
  ratings: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rating: { type: Number, min: 1, max: 5 },
    review: String,
    date: { type: Date, default: Date.now }
  }],
  certificateTemplate: { type: String, default: 'default' }
});

module.exports = mongoose.model('ShortCourse', ShortCourseSchema);
```

```javascript
// models/CourseProgress.js
const mongoose = require('mongoose');

const ModuleProgressSchema = new mongoose.Schema({
  moduleId: { type: mongoose.Schema.Types.ObjectId, required: true },
  completed: { type: Boolean, default: false },
  startedAt: { type: Date },
  completedAt: { type: Date },
  timeSpent: { type: Number, default: 0 } // in seconds
});

const AssessmentAttemptSchema = new mongoose.Schema({
  attemptedAt: { type: Date, default: Date.now },
  score: { type: Number, required: true }, // percentage
  passed: { type: Boolean, required: true },
  timeSpent: { type: Number }, // in seconds
  answers: [{
    questionId: mongoose.Schema.Types.ObjectId,
    selectedOptions: [mongoose.Schema.Types.ObjectId],
    isCorrect: Boolean,
    points: Number
  }]
});

const CourseProgressSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'ShortCourse', required: true },
  enrolledAt: { type: Date, default: Date.now },
  lastAccessedAt: { type: Date, default: Date.now },
  completed: { type: Boolean, default: false },
  completedAt: { type: Date },
  moduleProgress: [ModuleProgressSchema],
  assessmentAttempts: [AssessmentAttemptSchema],
  certificateIssued: { type: Boolean, default: false },
  certificateUrl: { type: String },
  certificateIssuedAt: { type: Date },
  overallProgress: { type: Number, default: 0 } // percentage
});

// Compound index to ensure one progress record per user per course
CourseProgressSchema.index({ userId: 1, courseId: 1 }, { unique: true });

module.exports = mongoose.model('CourseProgress', CourseProgressSchema);
```

### API Endpoints

```javascript
// routes/short-course.routes.js
const express = require('express');
const router = express.Router();
const shortCourseController = require('../controllers/short-course.controller');
const authMiddleware = require('../middleware/auth');

// Public routes
router.get('/courses', shortCourseController.getAllCourses);
router.get('/courses/:id', shortCourseController.getCourseById);
router.get('/courses/category/:category', shortCourseController.getCoursesByCategory);
router.get('/courses/level/:level', shortCourseController.getCoursesByLevel);
router.get('/courses/featured', shortCourseController.getFeaturedCourses);

// Protected routes
router.post('/courses', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.createCourse);
router.put('/courses/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.updateCourse);
router.delete('/courses/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.deleteCourse);
router.post('/courses/:id/publish', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.publishCourse);
router.post('/courses/:id/unpublish', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.unpublishCourse);

// Enrollment and progress routes
router.post('/courses/:id/enroll', authMiddleware.verifyToken, shortCourseController.enrollInCourse);
router.get('/courses/:id/progress', authMiddleware.verifyToken, shortCourseController.getCourseProgress);
router.post('/courses/:id/modules/:moduleId/complete', authMiddleware.verifyToken, shortCourseController.completeModule);
router.post('/courses/:id/assessment/submit', authMiddleware.verifyToken, shortCourseController.submitAssessment);
router.get('/courses/:id/certificate', authMiddleware.verifyToken, shortCourseController.generateCertificate);

// Rating and review routes
router.post('/courses/:id/rate', authMiddleware.verifyToken, shortCourseController.rateCourse);
router.get('/courses/:id/ratings', shortCourseController.getCourseRatings);

// AI generation routes
router.post('/generate', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.generateCourse);
router.post('/generate-assessment', authMiddleware.verifyToken, authMiddleware.isAdmin, shortCourseController.generateAssessment);

module.exports = router;
```

### Controller Implementation

```javascript
// controllers/short-course.controller.js
const ShortCourse = require('../models/ShortCourse');
const CourseProgress = require('../models/CourseProgress');
const User = require('../models/User');
const openaiService = require('../services/openai.service');
const certificateService = require('../services/certificate.service');
const cloudStorageService = require('../services/cloud-storage.service');

// Get all courses with filtering and pagination
exports.getAllCourses = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 10, 
      sort = '-createdAt',
      level,
      category,
      tag,
      search
    } = req.query;
    
    // Build filter object
    const filter = { published: true };
    if (level) filter.level = level;
    if (category) filter.categories = category;
    if (tag) filter.tags = tag;
    
    // Add text search if provided
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { objectives: { $regex: search, $options: 'i' } },
        { categories: { $regex: search, $options: 'i' } },
        { tags: { $regex: search, $options: 'i' } }
      ];
    }
    
    const courses = await ShortCourse.find(filter)
      .select('-modules.content -assessment.questions') // Exclude large content fields
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
      
    const count = await ShortCourse.countDocuments(filter);
    
    res.json({
      courses,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      totalCourses: count
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get course by ID
exports.getCourseById = async (req, res) => {
  try {
    const course = await ShortCourse.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    
    // If user is logged in, check enrollment status
    let enrollmentStatus = null;
    if (req.user) {
      const progress = await CourseProgress.findOne({
        userId: req.user.id,
        courseId: course._id
      });
      
      if (progress) {
        enrollmentStatus = {
          enrolled: true,
          enrolledAt: progress.enrolledAt,
          completed: progress.completed,
          completedAt: progress.completedAt,
          overallProgress: progress.overallProgress
        };
      } else {
        enrollmentStatus = { enrolled: false };
      }
    }
    
    res.json({
      course,
      enrollmentStatus
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Enroll in course
exports.enrollInCourse = async (req, res) => {
  try {
    const course = await ShortCourse.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    
    // Check if user is already enrolled
    const existingProgress = await CourseProgress.findOne({
      userId: req.user.id,
      courseId: course._id
    });
    
    if (existingProgress) {
      return res.status(400).json({ message: 'Already enrolled in this course' });
    }
    
    // Create module progress entries for each module
    const moduleProgress = course.modules.map(module => ({
      moduleId: module._id,
      completed: false
    }));
    
    // Create new progress record
    const newProgress = new CourseProgress({
      userId: req.user.id,
      courseId: course._id,
      moduleProgress,
      overallProgress: 0
    });
    
    await newProgress.save();
    
    // Increment course enrollment count
    course.enrollments += 1;
    await course.save();
    
    res.status(201).json({
      message: 'Successfully enrolled in course',
      progress: newProgress
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Generate course with AI
exports.generateCourse = async (req, res) => {
  try {
    const { 
      topic, 
      level, 
      moduleCount, 
      includeAssessment = true,
      categories = [],
      tags = []
    } = req.body;
    
    // Generate course structure using OpenAI
    const courseStructure = await openaiService.generateShortCourse(
      topic, 
      level, 
      moduleCount, 
      includeAssessment
    );
    
    // Create modules
    const modules = courseStructure.modules.map((module, index) => ({
      title: module.title,
      description: module.description,
      content: module.content,
      order: index,
      resources: module.resources.map(resource => ({
        title: resource.title,
        description: resource.description,
        url: resource.url,
        type: resource.type
      }))
    }));
    
    // Create assessment if requested
    let assessment = null;
    if (includeAssessment && courseStructure.assessment) {
      assessment = {
        title: courseStructure.assessment.title,
        description: courseStructure.assessment.description,
        questions: courseStructure.assessment.questions.map(question => ({
          text: question.text,
          type: question.type,
          options: question.options,
          explanation: question.explanation,
          points: question.points || 1
        })),
        passingScore: courseStructure.assessment.passingScore || 70
      };
    }
    
    // Calculate total duration
    const totalDuration = modules.reduce((sum, module) => sum + (module.duration || 0), 0);
    
    // Create new course
    const newCourse = new ShortCourse({
      title: courseStructure.title,
      description: courseStructure.description,
      objectives: courseStructure.objectives,
      level,
      categories: [...categories, ...courseStructure.categories],
      tags: [...tags, ...courseStructure.tags],
      duration: totalDuration,
      modules,
      assessment,
      createdBy: req.user.id,
      published: false
    });
    
    const savedCourse = await newCourse.save();
    
    res.status(201).json({
      message: 'Course generated successfully',
      course: savedCourse
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Additional controller methods...
```

### AI Integration for Course Generation

```javascript
// services/openai.service.js
// Add course generation methods

exports.generateShortCourse = async (topic, level, moduleCount, includeAssessment) => {
  try {
    const prompt = `Create a short course about ${topic} in radiation oncology at ${level} level with ${moduleCount} modules.
    
    Include the following:
    1. A descriptive title for the course
    2. A comprehensive course description
    3. 3-5 learning objectives
    4. ${moduleCount} modules, each with:
       - Title
       - Brief description
       - Detailed content (with proper formatting, equations if relevant)
       - Estimated duration in minutes
       - 2-3 resources (articles, videos, etc.)
    ${includeAssessment ? '5. An assessment with 5-10 questions (multiple choice, true/false, etc.)' : ''}
    6. Suggested categories and tags
    
    Format the response as a JSON object with the following structure:
    {
      "title": "Course title",
      "description": "Course description",
      "objectives": ["objective1", "objective2", "objective3"],
      "modules": [
        {
          "title": "Module title",
          "description": "Module description",
          "content": "Detailed module content",
          "duration": 30,
          "resources": [
            {
              "title": "Resource title",
              "description": "Resource description",
              "url": "",
              "type": "pdf|video|link|image"
            }
          ]
        }
      ],
      ${includeAssessment ? `"assessment": {
        "title": "Assessment title",
        "description": "Assessment description",
        "questions": [
          {
            "text": "Question text",
            "type": "multiple-choice|true-false|matching|calculation",
            "options": [
              {
                "text": "Option text",
                "isCorrect": true|false
              }
            ],
            "explanation": "Explanation for the correct answer",
            "points": 1
          }
        ],
        "passingScore": 70
      },` : ''}
      "categories": ["category1", "category2"],
      "tags": ["tag1", "tag2", "tag3"]
    }`;
    
    const response = await openai.createCompletion({
      model: "gpt-4",
      prompt: prompt,
      max_tokens: 4000,
      temperature: 0.7,
    });
    
    return JSON.parse(response.data.choices[0].text.trim());
  } catch (error) {
    console.error('Error generating short course with OpenAI:', error);
    throw error;
  }
};
```

### Frontend Components

```jsx
// pages/courses/short-courses/index.tsx
import { useState } from 'react';
import MainLayout from '../../../components/layout/MainLayout';
import ShortCourseCard from '../../../components/courses/ShortCourseCard';
import CourseFilter from '../../../components/courses/CourseFilter';
import Pagination from '../../../components/common/Pagination';
import { useShortCourses } from '../../../hooks/useShortCourses';

const ShortCoursesPage = () => {
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState({
    level: '',
    category: '',
    tag: '',
    search: ''
  });
  
  const { 
    courses, 
    isLoading, 
    error, 
    totalPages, 
    totalCourses 
  } = useShortCourses({ 
    page, 
    ...filters
  });
  
  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
    setPage(1);
  };
  
  const handlePageChange = (newPage) => {
    setPage(newPage);
    window.scrollTo(0, 0);
  };
  
  if (isLoading && page === 1) {
    return (
      <MainLayout title="Short Courses | Loading...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </MainLayout>
    );
  }
  
  if (error) {
    return (
      <MainLayout title="Short Courses | Error">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <p>Error loading courses. Please try again later.</p>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout title="Advanced Short Courses">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Advanced Short Courses</h1>
        <p className="text-gray-600 mt-2">
          Focused learning modules on specialized topics in radiation oncology.
        </p>
      </div>
      
      <div className="mb-8">
        <CourseFilter onFilterChange={handleFilterChange} />
      </div>
      
      {courses?.length === 0 ? (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded">
          <p>No courses found matching your criteria. Try adjusting your filters.</p>
        </div>
      ) : (
        <>
          <div className="mb-4">
            <p className="text-gray-600">
              Showing {courses?.length} of {totalCourses} courses
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {courses?.map(course => (
              <ShortCourseCard key={course.id} course={course} />
            ))}
          </div>
          
          <Pagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </>
      )}
    </MainLayout>
  );
};

export default ShortCoursesPage;
```

```jsx
// components/courses/ShortCourseCard.tsx
import React from 'react';
import Link from 'next/link';
import { formatDuration } from '../../lib/utils';

interface ShortCourseCardProps {
  course: {
    id: string;
    title: string;
    description: string;
    level: 'beginner' | 'intermediate' | 'advanced';
    duration: number;
    modules: { title: string }[];
    thumbnailUrl?: string;
    enrollments: number;
    averageRating: number;
    categories: string[];
  };
}

const ShortCourseCard: React.FC<ShortCourseCardProps> = ({ course }) => {
  const getLevelColor = (level) => {
    switch (level) {
      case 'beginner':
        return 'bg-green-100 text-green-800';
      case 'intermediate':
        return 'bg-blue-100 text-blue-800';
      case 'advanced':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="h-48 overflow-hidden bg-gray-200">
        {course.thumbnailUrl ? (
          <img 
            src={course.thumbnailUrl} 
            alt={course.title}
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-blue-500 to-purple-600">
            <h3 className="text-white text-xl font-bold px-4 text-center">
              {course.title}
            </h3>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className={`text-xs font-medium px-2 py-1 rounded ${getLevelColor(course.level)}`}>
            {course.level.charAt(0).toUpperCase() + course.level.slice(1)}
          </span>
          <span className="text-xs text-gray-500">
            {formatDuration(course.duration)}
          </span>
        </div>
        
        <h3 className="text-lg font-semibold mb-2 line-clamp-2">
          <Link href={`/courses/short-courses/${course.id}`}>
            <a className="text-gray-800 hover:text-blue-600">{course.title}</a>
          </Link>
        </h3>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-3">
          {course.description}
        </p>
        
        <div className="flex justify-between items-center mb-3">
          <div className="text-sm text-gray-500">
            {course.modules.length} modules
          </div>
          <div className="flex items-center">
            <span className="text-yellow-500 mr-1">★</span>
            <span className="text-sm text-gray-700">
              {course.averageRating.toFixed(1)}
            </span>
            <span className="text-sm text-gray-500 ml-2">
              ({course.enrollments} enrolled)
            </span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {course.categories.slice(0, 2).map(category => (
            <Link 
              key={category} 
              href={`/courses/short-courses?category=${encodeURIComponent(category)}`}
            >
              <a className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded hover:bg-gray-200">
                {category}
              </a>
            </Link>
          ))}
        </div>
        
        <Link href={`/courses/short-courses/${course.id}`}>
          <a className="block w-full text-center py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
            View Course
          </a>
        </Link>
      </div>
    </div>
  );
};

export default ShortCourseCard;
```

## Integration with Main Website

### Navigation Updates

```jsx
// components/layout/Navbar.tsx
// Add new navigation items

const navigationItems = [
  { name: 'Home', href: '/' },
  { name: 'Courses', href: '/courses' },
  { 
    name: 'Resources', 
    href: '#',
    children: [
      { name: 'Podcasts', href: '/podcast' },
      { name: 'News', href: '/news' },
      { name: 'Short Courses', href: '/courses/short-courses' },
      { name: 'Reference Library', href: '/resources/library' }
    ]
  },
  { name: 'Blog', href: '/blog' },
  { name: 'Membership', href: '/membership' },
  { name: 'About', href: '/about' },
  { name: 'Contact', href: '/contact' }
];
```

### Homepage Updates

```jsx
// pages/index.tsx
// Add new sections to homepage

<section className="py-12 bg-gray-50">
  <div className="container mx-auto px-4">
    <h2 className="text-3xl font-bold text-center mb-8">Latest Resources</h2>
    
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">Latest Podcasts</h3>
        <LatestPodcasts limit={3} />
        <Link href="/podcast">
          <a className="text-blue-600 hover:text-blue-800 font-medium">
            View all podcasts →
          </a>
        </Link>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">Latest News</h3>
        <LatestNews limit={3} />
        <Link href="/news">
          <a className="text-blue-600 hover:text-blue-800 font-medium">
            View all news →
          </a>
        </Link>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">Featured Short Courses</h3>
        <FeaturedShortCourses limit={3} />
        <Link href="/courses/short-courses">
          <a className="text-blue-600 hover:text-blue-800 font-medium">
            View all short courses →
          </a>
        </Link>
      </div>
    </div>
  </div>
</section>
```

### Dashboard Updates

```jsx
// pages/dashboard.tsx
// Add new sections to user dashboard

<div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
  <div className="lg:col-span-2">
    <h2 className="text-xl font-semibold mb-4">Your Learning Journey</h2>
    <div className="bg-white rounded-lg shadow-md p-6">
      <ProgressTracker progress={progress} />
    </div>
  </div>
  
  <div>
    <h2 className="text-xl font-semibold mb-4">Latest Updates</h2>
    <div className="bg-white rounded-lg shadow-md p-6">
      <Tabs>
        <Tab label="News">
          <LatestNews limit={3} />
        </Tab>
        <Tab label="Podcasts">
          <LatestPodcasts limit={3} />
        </Tab>
        <Tab label="Courses">
          <LatestShortCourses limit={3} />
        </Tab>
      </Tabs>
    </div>
  </div>
</div>
```

## Conclusion

This implementation plan provides a comprehensive framework for adding podcast functionality, news section, and advanced short courses to the Radiation Oncology Academy website. These features will significantly enhance the educational value of the platform and provide users with diverse learning options.

The implementation includes:

1. **Podcast Section**:
   - Database schema for podcast episodes
   - API endpoints for podcast management
   - Frontend components for podcast listing and playback
   - AI integration for podcast generation using OpenAI and ElevenLabs

2. **News Section**:
   - Database schema for news articles
   - API endpoints for news management
   - News aggregation service for automated content collection
   - Frontend components for news listing and filtering
   - AI integration for content processing and summarization

3. **Advanced Short Courses**:
   - Database schema for courses, modules, and assessments
   - Progress tracking and certification system
   - API endpoints for course management and enrollment
   - Frontend components for course listing and interaction
   - AI integration for course generation and assessment creation

These features are fully integrated with the main website through updated navigation, homepage sections, and dashboard components. The implementation leverages AI technologies to automate content creation and enhance the learning experience.
