# App Store Screenshots for Radiation Oncology Academy

## iPhone Screenshots (1242x2208px for iPhone 8 Plus)

### Screenshot 1: Home Screen
- Title: "Personalized Dashboard"
- Description: "Access your personalized learning content, progress tracking, and recommendations all in one place."
- Elements to show:
  - Dashboard with user profile
  - Recent courses section
  - Progress statistics
  - AI recommendations

### Screenshot 2: Educational Content
- Title: "Comprehensive Educational Content"
- Description: "Explore in-depth articles, videos, and interactive modules on radiation oncology topics."
- Elements to show:
  - Content library view
  - Featured article with images
  - Video thumbnail
  - Interactive module preview

### Screenshot 3: Podcast Player
- Title: "Expert Podcasts On-The-Go"
- Description: "Listen to the latest insights from leading radiation oncology experts."
- Elements to show:
  - Podcast player with episode playing
  - Show notes
  - Playback controls
  - Episode list

### Screenshot 4: News Feed
- Title: "Stay Updated with Latest Research"
- Description: "Access the most recent publications and breakthroughs in radiation oncology."
- Elements to show:
  - News article list
  - Featured news with image
  - Publication date and source
  - Bookmark and share options

### Screenshot 5: Interactive Learning
- Title: "Interactive Learning Tools"
- Description: "Enhance your understanding with quizzes, case studies, and interactive diagrams."
- Elements to show:
  - Quiz interface
  - Multiple choice question
  - Progress indicator
  - Explanation panel

## iPad Screenshots (2048x2732px for iPad Pro)

### Screenshot 1: Split View Dashboard
- Title: "Optimized for iPad"
- Description: "Take advantage of the larger screen with our specially designed iPad interface."
- Elements to show:
  - Split view with navigation and content
  - Dashboard with expanded statistics
  - Recommended content grid
  - Recent activity timeline

### Screenshot 2: Enhanced Content Viewer
- Title: "Immersive Learning Experience"
- Description: "Study complex topics with our enhanced content viewer featuring side-by-side resources."
- Elements to show:
  - Article with medical imaging
  - Side panel with related resources
  - Note-taking interface
  - Interactive diagram

### Screenshot 3: Advanced Podcast Experience
- Title: "Enhanced Podcast Experience"
- Description: "Access show notes, references, and related content while listening to podcasts."
- Elements to show:
  - Podcast player with waveform
  - Expanded show notes
  - Referenced studies panel
  - Related episodes

### Screenshot 4: Offline Learning
- Title: "Learn Anywhere, Anytime"
- Description: "Download content for offline access during your commute or when internet isn't available."
- Elements to show:
  - Downloaded content library
  - Download management interface
  - Storage usage statistics
  - Offline indicator

### Screenshot 5: Cross-Platform Synchronization
- Title: "Seamless Cross-Platform Experience"
- Description: "Continue your learning journey across all your devices with perfect synchronization."
- Elements to show:
  - Sync status interface
  - Device management
  - Progress synchronization
  - Recently synced content

## App Preview Video Storyboard (30 seconds)

### Scene 1 (0-5 seconds)
- App logo animation
- Tagline: "Advancing Radiation Oncology Education"
- User logging in

### Scene 2 (5-10 seconds)
- Dashboard overview
- AI recommendations highlighting
- Progress statistics animation

### Scene 3 (10-15 seconds)
- Educational content browsing
- Opening an article
- Interactive diagram demonstration

### Scene 4 (15-20 seconds)
- Podcast player interface
- Adjusting playback speed
- Downloading for offline listening

### Scene 5 (20-25 seconds)
- News browsing
- Saving article for later
- Sharing functionality

### Scene 6 (25-30 seconds)
- Cross-platform synchronization demonstration
- Multiple device usage
- Closing with call-to-action: "Download Now"
