# Final App Store Submission Checklist for Radiation Oncology Academy

This comprehensive checklist consolidates all requirements for both iOS App Store and Google Play Store submissions, ensuring we have all necessary assets and information ready for final submission.

## Common Requirements for Both Platforms

### App Information
- [x] App Name: Radiation Oncology Academy
- [x] App Description: Comprehensive and formatted description
- [x] Privacy Policy URL: https://radiationoncologyacademy.org/privacy
- [x] Support URL: https://radiationoncologyacademy.org/support
- [x] Marketing URL: https://radiationoncologyacademy.org
- [x] Category: Medical (Primary), Education (Secondary)
- [x] Version Number: 1.0.0
- [x] Build Number: 1

### Contact Information
- [x] Support Email: support@radiationoncologyacademy.org
- [x] Developer Name: Radiation Oncology Academy
- [x] Developer Website: https://radiationoncologyacademy.org
- [x] Developer Phone: [CONTACT_PHONE]

### Demo Account (for reviewers)
- [x] Username: [DEMO_USERNAME]
- [x] Password: [DEMO_PASSWORD]
- [x] Notes for reviewers explaining app functionality

## iOS App Store Specific Requirements

### App Icons
- [x] 1024x1024px App Store Icon
- [x] Complete set of app icons for all required sizes:
  - [x] 180x180px (iPhone)
  - [x] 167x167px (iPad Pro)
  - [x] 152x152px (iPad)
  - [x] 120x120px (iPhone)
  - [x] 87x87px (iPhone Spotlight)
  - [x] 80x80px (iPhone Spotlight)
  - [x] 76x76px (iPad)
  - [x] 60x60px (iPhone)
  - [x] 58x58px (Settings)
  - [x] 40x40px (Spotlight)
  - [x] 29x29px (Settings)
  - [x] 20x20px (Notification)

### Screenshots
- [x] iPhone 6.5" Display (1242 x 2688px) - 6 screenshots
- [x] iPhone 5.5" Display (1242 x 2208px) - 6 screenshots
- [x] iPad 12.9" Display (2048 x 2732px) - 6 screenshots
- [x] iPad 11" Display (1668 x 2388px) - 6 screenshots

### App Preview Video
- [x] 15-30 second preview video (H.264, 30fps)
- [x] Appropriate resolution for each device type
- [x] No references to pricing or other platforms
- [x] Shows actual app functionality

### App Store Connect Configuration
- [x] SKU: ROA-IOS-2025
- [x] Bundle ID: org.radiationoncologyacademy.mobile
- [x] App Store Information completed
- [x] Age Rating: 17+ (Medical/Treatment Information)
- [x] App Review Information completed
- [x] Version Release: Automatic after approval

### Technical Requirements
- [x] App binary built for production
- [x] App validated in Xcode
- [x] All app services configured:
  - [x] Push Notifications
  - [x] Background Modes (Audio playback, Background fetch)

## Google Play Store Specific Requirements

### App Icons and Graphics
- [x] 512x512px App Icon (32-bit PNG, no rounded corners)
- [x] 1024x500px Feature Graphic
- [x] High-resolution app icon (adaptive icon format)

### Screenshots
- [x] Phone screenshots (minimum 2, maximum 8)
- [x] 7-inch tablet screenshots (minimum 2, maximum 8)
- [x] 10-inch tablet screenshots (minimum 2, maximum 8)
- [x] All screenshots in 16:9 aspect ratio

### Promo Video
- [x] YouTube URL for promotional video
- [x] Video showcases key app features
- [x] No references to iOS or App Store

### Google Play Store Information
- [x] Short Description (80 characters max)
- [x] Full Description (4000 characters max)
- [x] Tags (5 max): radiation, oncology, medical, education, professional
- [x] Content Rating questionnaire completed
- [x] Target audience defined: 18+

### Technical Requirements
- [x] Android App Bundle (.aab) prepared
- [x] Signing key uploaded to Google Play
- [x] Minimum SDK: API level 23 (Android 6.0)
- [x] Target SDK: API level 33 (Android 13)
- [x] All required permissions declared and justified

## Final Verification Steps

### iOS Submission
- [x] All required metadata complete in App Store Connect
- [x] All screenshots and preview videos uploaded
- [x] App binary uploaded and processing complete
- [x] Build selected for review
- [x] All required questions answered
- [x] Final review of all information before submission

### Android Submission
- [x] All required metadata complete in Google Play Console
- [x] All screenshots and graphics uploaded
- [x] App bundle uploaded and processing complete
- [x] Content rating questionnaire completed
- [x] Pricing & distribution settings configured
- [x] Final review of all information before submission

## Post-Submission Plan

### Monitoring
- [ ] Check App Store Connect daily for iOS review status
- [ ] Check Google Play Console daily for Android review status
- [ ] Be prepared to respond to any reviewer questions within 24 hours

### If Approved
- [ ] Verify app appears correctly on both stores
- [ ] Test download and functionality on real devices
- [ ] Announce launch through marketing channels
- [ ] Monitor analytics and user feedback

### If Rejected
- [ ] Document rejection reasons
- [ ] Address all issues mentioned
- [ ] Test fixes thoroughly
- [ ] Resubmit with notes explaining the fixes

## Submission Timeline

| Task | Deadline | Status |
|------|----------|--------|
| Prepare all iOS assets | April 12, 2025 | Complete |
| Prepare all Android assets | April 12, 2025 | Complete |
| Configure App Store Connect | April 13, 2025 | Complete |
| Configure Google Play Console | April 13, 2025 | Complete |
| Upload iOS build | April 14, 2025 | Complete |
| Upload Android bundle | April 14, 2025 | Complete |
| Submit iOS app for review | April 15, 2025 | Ready |
| Submit Android app for review | April 15, 2025 | Ready |
| Expected review completion | April 18-22, 2025 | Pending |
| Expected public launch | April 25, 2025 | Pending |

This checklist confirms that all required assets and information for both iOS and Android app submissions have been prepared and are ready for final submission. The submission process can now proceed according to the timeline above.
