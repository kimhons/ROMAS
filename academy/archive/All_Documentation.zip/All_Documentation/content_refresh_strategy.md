# Content Refresh Strategy for Radiation Oncology Academy

## Overview

This document outlines a comprehensive content refresh strategy for the Radiation Oncology Academy website. Regular content updates are essential to maintain user engagement, ensure information accuracy, and leverage the latest developments in radiation oncology. This strategy establishes systematic processes for analyzing, refreshing, and optimizing content using AI tools and human expertise.

## Content Types and Refresh Requirements

| Content Type | Refresh Frequency | Priority Level | Responsible Role | AI Assistance |
|--------------|-------------------|----------------|------------------|--------------|
| **AAPM TG Reports Analysis** | When new reports released + Quarterly review | High | Medical Physicist | Content generation, summarization |
| **ASTRO Guidelines** | When updated + Quarterly review | High | Radiation Oncologist | Content generation, summarization |
| **Clinical Practice Resources** | Monthly | Medium | Role-specific expert | Content suggestions, updates |
| **Board Exam Preparation** | Bi-annually | High | Medical Physicist | Question generation, content updates |
| **Educational Courses** | Quarterly | Medium | Role-specific expert | Content suggestions, module creation |
| **Blog Posts** | Weekly | Medium | Content Manager | Topic generation, draft creation |
| **Podcast Episodes** | Bi-weekly | Medium | Content Manager | Script generation, voice synthesis |
| **News Updates** | Daily/Weekly | Low | Content Manager | Automated news collection, summarization |
| **User Guides & Documentation** | Quarterly | Low | Technical Writer | Update suggestions |
| **Research Highlights** | Monthly | Medium | Medical Physicist | Paper summarization, key findings |

## AI-Powered Content Refresh Workflow

### 1. Content Audit and Analysis System

```javascript
// File: /home/username/content_scripts/content_audit.js
const fs = require('fs');
const path = require('path');
const { MongoClient } = require('mongodb');
const { Configuration, OpenAIApi } = require('openai');
const { sendAlert, SEVERITY } = require('../monitoring_scripts/alert_manager');

// MongoDB connection
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

// OpenAI configuration
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

// Content types to analyze
const contentTypes = [
  { collection: 'blogposts', refreshFrequency: 90, name: 'Blog Posts' },
  { collection: 'courses', refreshFrequency: 90, name: 'Courses' },
  { collection: 'podcastepisodes', refreshFrequency: 45, name: 'Podcast Episodes' },
  { collection: 'quizzes', refreshFrequency: 180, name: 'Quizzes' }
];

// Analyze content freshness
async function analyzeContentFreshness() {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    
    const results = {
      needsRefresh: [],
      totalContent: 0,
      outdatedContent: 0
    };
    
    // Current date for comparison
    const currentDate = new Date();
    
    // Check each content type
    for (const contentType of contentTypes) {
      const collection = database.collection(contentType.collection);
      
      // Get all content of this type
      const allContent = await collection.find({}).toArray();
      results.totalContent += allContent.length;
      
      // Filter for content that needs refresh
      const outdatedContent = allContent.filter(item => {
        const lastUpdated = item.updatedAt ? new Date(item.updatedAt) : new Date(item.createdAt);
        const daysSinceUpdate = Math.floor((currentDate - lastUpdated) / (1000 * 60 * 60 * 24));
        return daysSinceUpdate > contentType.refreshFrequency;
      });
      
      results.outdatedContent += outdatedContent.length;
      
      // Add to needs refresh list
      if (outdatedContent.length > 0) {
        results.needsRefresh.push({
          type: contentType.name,
          count: outdatedContent.length,
          items: outdatedContent.map(item => ({
            id: item._id,
            title: item.title,
            lastUpdated: item.updatedAt || item.createdAt,
            daysSinceUpdate: Math.floor((currentDate - (item.updatedAt ? new Date(item.updatedAt) : new Date(item.createdAt))) / (1000 * 60 * 60 * 24))
          }))
        });
      }
    }
    
    // Generate audit report
    const reportDir = path.join(__dirname, '../content_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(reportDir, `content_audit_${new Date().toISOString().split('T')[0]}.json`);
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
    
    // Send alert if significant content needs refresh
    if (results.outdatedContent > 0) {
      const percentOutdated = (results.outdatedContent / results.totalContent) * 100;
      
      if (percentOutdated > 20) {
        sendAlert(
          'Significant content needs refreshing',
          `${results.outdatedContent} items (${percentOutdated.toFixed(1)}%) need to be updated`,
          SEVERITY.WARNING,
          { reportPath }
        );
      } else {
        sendAlert(
          'Content refresh needed',
          `${results.outdatedContent} items need to be updated`,
          SEVERITY.INFO,
          { reportPath }
        );
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error analyzing content freshness:', error);
    sendAlert(
      'Error in content audit',
      `Failed to complete content audit: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  } finally {
    await client.close();
  }
}

// Analyze content relevance and quality
async function analyzeContentQuality(contentId, contentType, content) {
  try {
    // Use OpenAI to analyze content quality
    const prompt = `
    Analyze the following ${contentType} content for quality, relevance, and accuracy in the field of radiation oncology. 
    Consider:
    1. Scientific accuracy
    2. Relevance to current practice
    3. Clarity and educational value
    4. Areas that need updating
    
    Content: ${content}
    
    Provide a structured analysis with:
    - Overall quality score (1-10)
    - Key strengths
    - Areas needing improvement
    - Specific update recommendations
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 1000,
      temperature: 0.3,
    });
    
    const analysis = response.data.choices[0].text.trim();
    
    // Save analysis
    const reportDir = path.join(__dirname, '../content_reports/quality');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(reportDir, `quality_analysis_${contentId}.txt`);
    fs.writeFileSync(reportPath, analysis);
    
    return {
      contentId,
      contentType,
      analysis,
      reportPath
    };
  } catch (error) {
    console.error(`Error analyzing content quality for ${contentId}:`, error);
    return {
      contentId,
      contentType,
      error: error.message
    };
  }
}

// Run content audit
async function runContentAudit() {
  try {
    console.log('Starting content audit...');
    const freshnessResults = await analyzeContentFreshness();
    
    // Analyze quality for a sample of outdated content
    const qualityAnalyses = [];
    
    for (const typeResult of freshnessResults.needsRefresh) {
      // Analyze up to 3 items per content type
      const itemsToAnalyze = typeResult.items.slice(0, 3);
      
      for (const item of itemsToAnalyze) {
        // Retrieve full content
        await client.connect();
        const database = client.db('radiationOncologyAcademy');
        const collection = database.collection(typeResult.type.toLowerCase().replace(' ', ''));
        
        const fullItem = await collection.findOne({ _id: item.id });
        await client.close();
        
        if (fullItem) {
          // Extract content based on content type
          let contentText = '';
          if (fullItem.content) {
            contentText = fullItem.content;
          } else if (fullItem.description) {
            contentText = fullItem.description;
          } else if (fullItem.transcript) {
            contentText = fullItem.transcript;
          }
          
          // Analyze content quality
          if (contentText) {
            const qualityResult = await analyzeContentQuality(
              item.id.toString(),
              typeResult.type,
              contentText.substring(0, 4000) // Limit to 4000 chars for API
            );
            
            qualityAnalyses.push(qualityResult);
          }
        }
      }
    }
    
    // Generate comprehensive report
    const reportPath = path.join(
      __dirname, 
      '../content_reports', 
      `comprehensive_audit_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify({
      freshnessResults,
      qualityAnalyses,
      timestamp: new Date().toISOString(),
      summary: `${freshnessResults.outdatedContent} of ${freshnessResults.totalContent} content items need refreshing`
    }, null, 2));
    
    console.log(`Content audit completed. Report saved to ${reportPath}`);
    return reportPath;
  } catch (error) {
    console.error('Error running content audit:', error);
    sendAlert(
      'Error in comprehensive content audit',
      `Failed to complete comprehensive audit: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
  }
}

// Check if this script is being run directly
if (require.main === module) {
  runContentAudit();
}

module.exports = {
  runContentAudit,
  analyzeContentFreshness,
  analyzeContentQuality
};
```

### 2. AI-Powered Content Generation System

```javascript
// File: /home/username/content_scripts/content_generator.js
const fs = require('fs');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');
const { Configuration, OpenAIApi } = require('openai');
const axios = require('axios');
const { sendAlert, SEVERITY } = require('../monitoring_scripts/alert_manager');

// MongoDB connection
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

// OpenAI configuration
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

// ElevenLabs configuration
const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY;
const ELEVENLABS_VOICE_ID = 'EXAVITQu4vr4xnSDxMaL'; // Default voice ID

// Generate blog post content
async function generateBlogPost(topic, targetRole) {
  try {
    const prompt = `
    Write a comprehensive, educational blog post for radiation oncology professionals, specifically for ${targetRole}.
    
    Topic: ${topic}
    
    The blog post should:
    1. Begin with an engaging introduction that explains the importance of this topic
    2. Include scientifically accurate information with proper terminology
    3. Discuss clinical implications and practical applications
    4. Reference relevant AAPM TG reports or ASTRO guidelines where applicable
    5. Include a conclusion with key takeaways
    6. Be written in a professional but accessible tone
    7. Be structured with clear headings and subheadings
    
    Format the blog post with markdown formatting.
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 2500,
      temperature: 0.7,
    });
    
    const blogContent = response.data.choices[0].text.trim();
    
    // Generate a title
    const titleResponse = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: `Create an engaging, professional title for a blog post about: ${topic}. The audience is ${targetRole} in radiation oncology.`,
      max_tokens: 50,
      temperature: 0.7,
    });
    
    const title = titleResponse.data.choices[0].text.trim();
    
    return {
      title,
      content: blogContent,
      topic,
      targetRole
    };
  } catch (error) {
    console.error('Error generating blog post:', error);
    throw error;
  }
}

// Generate podcast script
async function generatePodcastScript(topic, targetRole) {
  try {
    const prompt = `
    Write a script for a 10-minute educational podcast episode for radiation oncology professionals, specifically for ${targetRole}.
    
    Topic: ${topic}
    
    The podcast script should:
    1. Start with a brief introduction and greeting
    2. Explain why this topic is important for radiation oncology professionals
    3. Present key information in a conversational, engaging style
    4. Include practical insights and clinical applications
    5. End with key takeaways and a sign-off
    
    Format the script as a monologue with clear paragraph breaks. Use natural, conversational language suitable for speaking aloud.
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 2000,
      temperature: 0.7,
    });
    
    const podcastScript = response.data.choices[0].text.trim();
    
    // Generate a title
    const titleResponse = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: `Create an engaging, professional title for a podcast episode about: ${topic}. The audience is ${targetRole} in radiation oncology.`,
      max_tokens: 50,
      temperature: 0.7,
    });
    
    const title = titleResponse.data.choices[0].text.trim();
    
    return {
      title,
      script: podcastScript,
      topic,
      targetRole
    };
  } catch (error) {
    console.error('Error generating podcast script:', error);
    throw error;
  }
}

// Generate audio from podcast script using ElevenLabs
async function generatePodcastAudio(script, title) {
  try {
    const response = await axios({
      method: 'post',
      url: `https://api.elevenlabs.io/v1/text-to-speech/${ELEVENLABS_VOICE_ID}`,
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': ELEVENLABS_API_KEY
      },
      data: {
        text: script,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5
        }
      },
      responseType: 'arraybuffer'
    });
    
    // Save audio file
    const audioDir = path.join(__dirname, '../generated_content/audio');
    if (!fs.existsSync(audioDir)) {
      fs.mkdirSync(audioDir, { recursive: true });
    }
    
    const safeTitle = title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    const audioPath = path.join(audioDir, `${safeTitle}_${Date.now()}.mp3`);
    fs.writeFileSync(audioPath, response.data);
    
    return audioPath;
  } catch (error) {
    console.error('Error generating podcast audio:', error);
    throw error;
  }
}

// Generate quiz questions
async function generateQuizQuestions(topic, targetRole, difficulty, count = 5) {
  try {
    const prompt = `
    Create ${count} multiple-choice quiz questions about ${topic} for ${targetRole} in radiation oncology.
    
    Difficulty level: ${difficulty} (1=basic, 5=advanced)
    
    For each question:
    1. Write a clear, concise question
    2. Provide 4 possible answers (A, B, C, D)
    3. Indicate the correct answer
    4. Include a brief explanation of why the answer is correct
    
    Format as JSON with this structure:
    [
      {
        "question": "Question text",
        "options": ["Option A", "Option B", "Option C", "Option D"],
        "correctAnswer": 0,
        "explanation": "Explanation text"
      }
    ]
    
    Ensure all questions are scientifically accurate and relevant to clinical practice.
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 2000,
      temperature: 0.7,
    });
    
    // Parse the JSON response
    const responseText = response.data.choices[0].text.trim();
    let quizQuestions;
    
    try {
      quizQuestions = JSON.parse(responseText);
    } catch (error) {
      // If JSON parsing fails, try to extract JSON portion
      const jsonMatch = responseText.match(/\[\s*\{.*\}\s*\]/s);
      if (jsonMatch) {
        quizQuestions = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('Failed to parse quiz questions JSON');
      }
    }
    
    return {
      topic,
      targetRole,
      difficulty,
      questions: quizQuestions
    };
  } catch (error) {
    console.error('Error generating quiz questions:', error);
    throw error;
  }
}

// Update existing content
async function updateExistingContent(contentId, contentType, originalContent) {
  try {
    let prompt;
    
    switch (contentType.toLowerCase()) {
      case 'blogposts':
        prompt = `
        Update and improve the following blog post for radiation oncology professionals.
        Make it more current, accurate, and engaging while maintaining its core topic.
        
        Original content:
        ${originalContent.substring(0, 3000)}
        
        Please:
        1. Update any outdated information
        2. Add recent developments in this area
        3. Improve clarity and educational value
        4. Maintain the original structure but enhance content quality
        5. Keep a professional but accessible tone
        
        Return the complete updated blog post with markdown formatting.
        `;
        break;
        
      case 'podcastepisodes':
        prompt = `
        Update and improve the following podcast script for radiation oncology professionals.
        Make it more current, accurate, and engaging while maintaining its core topic.
        
        Original script:
        ${originalContent.substring(0, 3000)}
        
        Please:
        1. Update any outdated information
        2. Add recent developments in this area
        3. Improve clarity and conversational flow
        4. Maintain the original structure but enhance content quality
        5. Keep a professional but conversational tone suitable for speaking
        
        Return the complete updated podcast script.
        `;
        break;
        
      default:
        prompt = `
        Update and improve the following content for radiation oncology professionals.
        Make it more current, accurate, and engaging while maintaining its core topic.
        
        Original content:
        ${originalContent.substring(0, 3000)}
        
        Please:
        1. Update any outdated information
        2. Add recent developments in this area
        3. Improve clarity and educational value
        4. Maintain the original structure but enhance content quality
        5. Keep a professional but accessible tone
        
        Return the complete updated content.
        `;
    }
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 2500,
      temperature: 0.7,
    });
    
    const updatedContent = response.data.choices[0].text.trim();
    
    return {
      contentId,
      contentType,
      updatedContent
    };
  } catch (error) {
    console.error(`Error updating ${contentType} content:`, error);
    throw error;
  }
}

// Save generated content to database
async function saveContentToDatabase(content, contentType) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection(contentType);
    
    // Prepare document based on content type
    let document;
    
    switch (contentType) {
      case 'blogposts':
        document = {
          title: content.title,
          content: content.content,
          targetRole: content.targetRole,
          topic: content.topic,
          createdAt: new Date(),
          updatedAt: new Date(),
          isPublished: false, // Requires review before publishing
          author: 'AI Content Generator',
          tags: [content.topic, content.targetRole, 'AI Generated']
        };
        break;
        
      case 'podcastepisodes':
        document = {
          title: content.title,
          script: content.script,
          audioFile: content.audioPath || null,
          targetRole: content.targetRole,
          topic: content.topic,
          createdAt: new Date(),
          updatedAt: new Date(),
          isPublished: false, // Requires review before publishing
          host: 'AI Content Generator',
          duration: content.duration || '10:00', // Estimated duration
          tags: [content.topic, content.targetRole, 'AI Generated']
        };
        break;
        
      case 'quizzes':
        document = {
          topic: content.topic,
          targetRole: content.targetRole,
          difficulty: content.difficulty,
          questions: content.questions,
          createdAt: new Date(),
          updatedAt: new Date(),
          isPublished: false, // Requires review before publishing
          author: 'AI Content Generator',
          tags: [content.topic, content.targetRole, `Difficulty: ${content.difficulty}`, 'AI Generated']
        };
        break;
        
      default:
        document = {
          ...content,
          createdAt: new Date(),
          updatedAt: new Date(),
          isPublished: false,
          author: 'AI Content Generator'
        };
    }
    
    const result = await collection.insertOne(document);
    
    return {
      contentId: result.insertedId,
      contentType,
      status: 'success'
    };
  } catch (error) {
    console.error(`Error saving ${contentType} to database:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Update existing content in database
async function updateContentInDatabase(contentId, contentType, updatedContent) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection(contentType);
    
    // Prepare update based on content type
    let updateDoc;
    
    switch (contentType) {
      case 'blogposts':
        updateDoc = {
          $set: {
            content: updatedContent,
            updatedAt: new Date(),
            isPublished: false, // Reset to unpublished for review
            lastUpdatedBy: 'AI Content Refresher'
          }
        };
        break;
        
      case 'podcastepisodes':
        updateDoc = {
          $set: {
            script: updatedContent,
            updatedAt: new Date(),
            isPublished: false, // Reset to unpublished for review
            lastUpdatedBy: 'AI Content Refresher'
          }
        };
        break;
        
      default:
        updateDoc = {
          $set: {
            content: updatedContent,
            updatedAt: new Date(),
            isPublished: false, // Reset to unpublished for review
            lastUpdatedBy: 'AI Content Refresher'
          }
        };
    }
    
    const result = await collection.updateOne(
      { _id: new ObjectId(contentId) },
      updateDoc
    );
    
    return {
      contentId,
      contentType,
      status: result.modifiedCount > 0 ? 'success' : 'no changes',
      modifiedCount: result.modifiedCount
    };
  } catch (error) {
    console.error(`Error updating ${contentType} in database:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Generate content based on audit results
async function generateContentFromAudit(auditReportPath) {
  try {
    // Read audit report
    const auditReport = JSON.parse(fs.readFileSync(auditReportPath, 'utf8'));
    
    // Track results
    const results = {
      generated: [],
      updated: [],
      errors: []
    };
    
    // Process each content type that needs refresh
    for (const typeResult of auditReport.freshnessResults.needsRefresh) {
      const contentType = typeResult.type.toLowerCase().replace(' ', '');
      
      // Process up to 3 items per content type
      const itemsToProcess = typeResult.items.slice(0, 3);
      
      for (const item of itemsToProcess) {
        try {
          // Retrieve full content
          await client.connect();
          const database = client.db('radiationOncologyAcademy');
          const collection = database.collection(contentType);
          
          const fullItem = await collection.findOne({ _id: new ObjectId(item.id) });
          await client.close();
          
          if (fullItem) {
            // Extract content based on content type
            let contentText = '';
            let targetRole = fullItem.targetRole || 'Medical Physicist';
            let topic = fullItem.topic || fullItem.title || 'Radiation Oncology';
            
            if (fullItem.content) {
              contentText = fullItem.content;
            } else if (fullItem.script) {
              contentText = fullItem.script;
            } else if (fullItem.description) {
              contentText = fullItem.description;
            }
            
            // Update the content
            if (contentText) {
              const updateResult = await updateExistingContent(
                item.id.toString(),
                contentType,
                contentText
              );
              
              // Save updated content to database
              const dbResult = await updateContentInDatabase(
                item.id.toString(),
                contentType,
                updateResult.updatedContent
              );
              
              results.updated.push({
                contentId: item.id.toString(),
                contentType,
                title: fullItem.title || topic,
                status: dbResult.status
              });
            }
          }
        } catch (error) {
          console.error(`Error processing ${item.id}:`, error);
          results.errors.push({
            contentId: item.id.toString(),
            contentType,
            error: error.message
          });
        }
      }
      
      // Generate one new content item for each content type
      try {
        let newContent;
        let saveResult;
        
        // Generate content based on type
        switch (contentType) {
          case 'blogposts':
            // Generate a topic if needed
            const blogTopic = await generateContentTopic('blog post', 'Medical Physicist');
            newContent = await generateBlogPost(blogTopic, 'Medical Physicist');
            saveResult = await saveContentToDatabase(newContent, 'blogposts');
            break;
            
          case 'podcastepisodes':
            // Generate a topic if needed
            const podcastTopic = await generateContentTopic('podcast', 'Radiation Oncologist');
            newContent = await generatePodcastScript(podcastTopic, 'Radiation Oncologist');
            
            // Generate audio
            const audioPath = await generatePodcastAudio(newContent.script, newContent.title);
            newContent.audioPath = audioPath;
            
            saveResult = await saveContentToDatabase(newContent, 'podcastepisodes');
            break;
            
          case 'quizzes':
            // Generate a topic if needed
            const quizTopic = await generateContentTopic('quiz', 'Medical Physicist');
            newContent = await generateQuizQuestions(quizTopic, 'Medical Physicist', 3, 10);
            saveResult = await saveContentToDatabase(newContent, 'quizzes');
            break;
        }
        
        if (newContent && saveResult) {
          results.generated.push({
            contentType,
            title: newContent.title || newContent.topic,
            contentId: saveResult.contentId.toString(),
            status: 'success'
          });
        }
      } catch (error) {
        console.error(`Error generating new ${contentType}:`, error);
        results.errors.push({
          contentType,
          error: error.message,
          phase: 'generation'
        });
      }
    }
    
    // Generate report
    const reportDir = path.join(__dirname, '../content_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(
      reportDir, 
      `content_generation_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify({
      results,
      timestamp: new Date().toISOString(),
      summary: `Generated ${results.generated.length} new items, updated ${results.updated.length} existing items, encountered ${results.errors.length} errors`
    }, null, 2));
    
    // Send alert
    sendAlert(
      'Content refresh completed',
      `Generated ${results.generated.length} new items, updated ${results.updated.length} existing items`,
      results.errors.length > 0 ? SEVERITY.WARNING : SEVERITY.INFO,
      { reportPath, errorCount: results.errors.length }
    );
    
    return reportPath;
  } catch (error) {
    console.error('Error generating content from audit:', error);
    sendAlert(
      'Error in content generation',
      `Failed to generate content: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  }
}

// Generate content topic
async function generateContentTopic(contentType, targetRole) {
  try {
    const prompt = `
    Suggest a current, relevant topic for a ${contentType} about radiation oncology for ${targetRole}.
    The topic should be specific, educational, and valuable for professionals in this field.
    Provide just the topic name without any additional text.
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 50,
      temperature: 0.8,
    });
    
    return response.data.choices[0].text.trim();
  } catch (error) {
    console.error('Error generating content topic:', error);
    return 'Recent Advances in Radiation Oncology'; // Fallback topic
  }
}

// Run content generation
async function runContentGeneration() {
  try {
    // First run an audit
    console.log('Running content audit...');
    const auditReportPath = await runContentAudit();
    
    // Generate content based on audit
    console.log('Generating content based on audit...');
    const generationReportPath = await generateContentFromAudit(auditReportPath);
    
    console.log(`Content generation completed. Report saved to ${generationReportPath}`);
    return generationReportPath;
  } catch (error) {
    console.error('Error running content generation:', error);
    sendAlert(
      'Error in content generation workflow',
      `Failed to complete content generation: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
  }
}

// Check if this script is being run directly
if (require.main === module) {
  runContentGeneration();
}

module.exports = {
  runContentGeneration,
  generateBlogPost,
  generatePodcastScript,
  generatePodcastAudio,
  generateQuizQuestions,
  updateExistingContent
};
```

### 3. Content Quality Assessment System

```javascript
// File: /home/username/content_scripts/content_quality.js
const fs = require('fs');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');
const { Configuration, OpenAIApi } = require('openai');
const { sendAlert, SEVERITY } = require('../monitoring_scripts/alert_manager');

// MongoDB connection
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

// OpenAI configuration
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

// Quality assessment criteria
const qualityCriteria = {
  scientific_accuracy: {
    weight: 0.25,
    description: "Scientific and medical accuracy of the content"
  },
  relevance: {
    weight: 0.20,
    description: "Relevance to current practice and target audience"
  },
  educational_value: {
    weight: 0.20,
    description: "Educational value and depth of information"
  },
  clarity: {
    weight: 0.15,
    description: "Clarity of explanation and organization"
  },
  engagement: {
    weight: 0.10,
    description: "Engagement and interest level"
  },
  actionability: {
    weight: 0.10,
    description: "Practical applicability and actionable insights"
  }
};

// Assess content quality
async function assessContentQuality(contentId, contentType, content) {
  try {
    // Use OpenAI to assess content quality
    const prompt = `
    Evaluate the following ${contentType} content for quality in radiation oncology education.
    
    Content: ${content.substring(0, 4000)}
    
    Rate each criterion on a scale of 1-10:
    
    1. Scientific Accuracy (weight: 25%): Accuracy of medical and scientific information
    2. Relevance (weight: 20%): Relevance to current practice and target audience
    3. Educational Value (weight: 20%): Depth and value of educational content
    4. Clarity (weight: 15%): Clarity of explanation and organization
    5. Engagement (weight: 10%): How engaging and interesting the content is
    6. Actionability (weight: 10%): Practical applicability and actionable insights
    
    For each criterion, provide:
    - Score (1-10)
    - Brief justification
    - Improvement suggestion
    
    Then calculate a weighted overall score.
    
    Format your response as JSON:
    {
      "criteria": {
        "scientific_accuracy": {"score": X, "justification": "...", "improvement": "..."},
        "relevance": {"score": X, "justification": "...", "improvement": "..."},
        "educational_value": {"score": X, "justification": "...", "improvement": "..."},
        "clarity": {"score": X, "justification": "...", "improvement": "..."},
        "engagement": {"score": X, "justification": "...", "improvement": "..."},
        "actionability": {"score": X, "justification": "...", "improvement": "..."}
      },
      "overall_score": X.X,
      "summary": "Overall assessment summary",
      "primary_strengths": ["Strength 1", "Strength 2"],
      "primary_weaknesses": ["Weakness 1", "Weakness 2"],
      "improvement_priority": "Which aspect should be improved first"
    }
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 1500,
      temperature: 0.3,
    });
    
    // Parse the JSON response
    const responseText = response.data.choices[0].text.trim();
    let assessment;
    
    try {
      assessment = JSON.parse(responseText);
    } catch (error) {
      // If JSON parsing fails, try to extract JSON portion
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        assessment = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('Failed to parse quality assessment JSON');
      }
    }
    
    // Save assessment
    const reportDir = path.join(__dirname, '../content_reports/quality');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(reportDir, `quality_assessment_${contentId}_${new Date().toISOString().split('T')[0]}.json`);
    fs.writeFileSync(reportPath, JSON.stringify(assessment, null, 2));
    
    return {
      contentId,
      contentType,
      assessment,
      reportPath
    };
  } catch (error) {
    console.error(`Error assessing content quality for ${contentId}:`, error);
    return {
      contentId,
      contentType,
      error: error.message
    };
  }
}

// Update content quality score in database
async function updateQualityScore(contentId, contentType, assessment) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection(contentType);
    
    const updateResult = await collection.updateOne(
      { _id: new ObjectId(contentId) },
      {
        $set: {
          qualityScore: assessment.overall_score,
          qualityAssessment: assessment,
          lastQualityCheck: new Date()
        }
      }
    );
    
    return {
      contentId,
      contentType,
      updated: updateResult.modifiedCount > 0
    };
  } catch (error) {
    console.error(`Error updating quality score for ${contentId}:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Run quality assessment for a batch of content
async function runQualityAssessment(contentType, limit = 5) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection(contentType);
    
    // Find content that hasn't been quality checked or was checked long ago
    const contentItems = await collection.find({
      $or: [
        { lastQualityCheck: { $exists: false } },
        { lastQualityCheck: { $lt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) } } // Older than 90 days
      ]
    })
    .limit(limit)
    .toArray();
    
    const results = {
      assessed: [],
      errors: [],
      contentType,
      timestamp: new Date().toISOString()
    };
    
    for (const item of contentItems) {
      try {
        // Extract content based on content type
        let contentText = '';
        
        if (item.content) {
          contentText = item.content;
        } else if (item.script) {
          contentText = item.script;
        } else if (item.description) {
          contentText = item.description;
        } else if (item.questions) {
          // For quizzes, format questions into text
          contentText = item.questions.map((q, i) => 
            `Question ${i+1}: ${q.question}\n` +
            `Options: ${q.options.join(', ')}\n` +
            `Correct Answer: ${q.options[q.correctAnswer]}\n` +
            `Explanation: ${q.explanation}\n`
          ).join('\n');
        }
        
        if (contentText) {
          // Assess quality
          const assessment = await assessContentQuality(
            item._id.toString(),
            contentType,
            contentText
          );
          
          // Update quality score in database
          if (!assessment.error) {
            await updateQualityScore(
              item._id.toString(),
              contentType,
              assessment.assessment
            );
            
            results.assessed.push({
              contentId: item._id.toString(),
              title: item.title || 'Untitled',
              score: assessment.assessment.overall_score,
              reportPath: assessment.reportPath
            });
          } else {
            results.errors.push({
              contentId: item._id.toString(),
              title: item.title || 'Untitled',
              error: assessment.error
            });
          }
        }
      } catch (error) {
        console.error(`Error processing ${item._id}:`, error);
        results.errors.push({
          contentId: item._id.toString(),
          title: item.title || 'Untitled',
          error: error.message
        });
      }
    }
    
    // Generate report
    const reportDir = path.join(__dirname, '../content_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(
      reportDir, 
      `quality_batch_${contentType}_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
    
    // Send alert if there are low-quality items
    const lowQualityItems = results.assessed.filter(item => item.score < 7.0);
    if (lowQualityItems.length > 0) {
      sendAlert(
        'Low quality content detected',
        `${lowQualityItems.length} ${contentType} items have quality scores below 7.0`,
        SEVERITY.WARNING,
        { lowQualityItems, reportPath }
      );
    }
    
    return reportPath;
  } catch (error) {
    console.error(`Error running quality assessment for ${contentType}:`, error);
    sendAlert(
      'Error in content quality assessment',
      `Failed to assess ${contentType} quality: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  } finally {
    await client.close();
  }
}

// Run quality assessment for all content types
async function runAllQualityAssessments() {
  const contentTypes = ['blogposts', 'podcastepisodes', 'courses', 'quizzes'];
  const reports = [];
  
  for (const contentType of contentTypes) {
    try {
      console.log(`Running quality assessment for ${contentType}...`);
      const reportPath = await runQualityAssessment(contentType, 3);
      reports.push({ contentType, reportPath });
    } catch (error) {
      console.error(`Error assessing ${contentType}:`, error);
    }
  }
  
  // Generate summary report
  const summaryReport = {
    timestamp: new Date().toISOString(),
    reports,
    summary: `Completed quality assessment for ${reports.length} content types`
  };
  
  const summaryPath = path.join(
    __dirname, 
    '../content_reports', 
    `quality_summary_${new Date().toISOString().split('T')[0]}.json`
  );
  
  fs.writeFileSync(summaryPath, JSON.stringify(summaryReport, null, 2));
  
  console.log(`Quality assessment completed. Summary saved to ${summaryPath}`);
  return summaryPath;
}

// Check if this script is being run directly
if (require.main === module) {
  runAllQualityAssessments();
}

module.exports = {
  runAllQualityAssessments,
  runQualityAssessment,
  assessContentQuality
};
```

### 4. Content Scheduling System

```javascript
// File: /home/username/content_scripts/content_scheduler.js
const fs = require('fs');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');
const { sendAlert, SEVERITY } = require('../monitoring_scripts/alert_manager');

// MongoDB connection
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

// Content publishing schedule
const publishingSchedule = {
  blogposts: {
    frequency: 'weekly',
    dayOfWeek: 2, // Tuesday (0 = Sunday)
    timeOfDay: '09:00',
    minQualityScore: 7.5
  },
  podcastepisodes: {
    frequency: 'biweekly',
    dayOfWeek: 4, // Thursday
    timeOfDay: '12:00',
    minQualityScore: 8.0
  },
  courses: {
    frequency: 'monthly',
    dayOfMonth: 15,
    timeOfDay: '10:00',
    minQualityScore: 8.5
  },
  quizzes: {
    frequency: 'weekly',
    dayOfWeek: 3, // Wednesday
    timeOfDay: '14:00',
    minQualityScore: 7.0
  }
};

// Get content items ready for publishing
async function getContentForPublishing(contentType) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection(contentType);
    
    // Get schedule for this content type
    const schedule = publishingSchedule[contentType];
    
    // Find unpublished content with sufficient quality
    const contentItems = await collection.find({
      isPublished: false,
      qualityScore: { $gte: schedule.minQualityScore }
    })
    .sort({ qualityScore: -1 }) // Highest quality first
    .limit(1) // Just get one item to publish
    .toArray();
    
    return contentItems;
  } catch (error) {
    console.error(`Error getting ${contentType} for publishing:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Publish content
async function publishContent(contentId, contentType) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection(contentType);
    
    // Update content to published status
    const updateResult = await collection.updateOne(
      { _id: new ObjectId(contentId) },
      {
        $set: {
          isPublished: true,
          publishedAt: new Date(),
          publishedBy: 'Content Scheduler'
        }
      }
    );
    
    return {
      contentId,
      contentType,
      published: updateResult.modifiedCount > 0
    };
  } catch (error) {
    console.error(`Error publishing ${contentId}:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Check if content should be published today
function shouldPublishToday(schedule) {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const dayOfMonth = now.getDate();
  
  switch (schedule.frequency) {
    case 'daily':
      return true;
      
    case 'weekly':
      return dayOfWeek === schedule.dayOfWeek;
      
    case 'biweekly':
      // Publish every other week on the specified day
      const weekNumber = Math.floor(now.getTime() / (7 * 24 * 60 * 60 * 1000));
      return dayOfWeek === schedule.dayOfWeek && weekNumber % 2 === 0;
      
    case 'monthly':
      return dayOfMonth === schedule.dayOfMonth;
      
    default:
      return false;
  }
}

// Run content publishing
async function runContentPublishing() {
  try {
    const results = {
      published: [],
      skipped: [],
      errors: [],
      timestamp: new Date().toISOString()
    };
    
    // Check each content type
    for (const [contentType, schedule] of Object.entries(publishingSchedule)) {
      try {
        // Check if we should publish this content type today
        if (shouldPublishToday(schedule)) {
          console.log(`Checking ${contentType} for publishing...`);
          
          // Get content ready for publishing
          const contentItems = await getContentForPublishing(contentType);
          
          if (contentItems.length > 0) {
            // Publish the first item
            const item = contentItems[0];
            const publishResult = await publishContent(item._id.toString(), contentType);
            
            if (publishResult.published) {
              results.published.push({
                contentId: item._id.toString(),
                contentType,
                title: item.title || 'Untitled',
                qualityScore: item.qualityScore
              });
              
              // Send alert
              sendAlert(
                `New ${contentType} published`,
                `Published: ${item.title || 'Untitled'} (Quality: ${item.qualityScore.toFixed(1)}/10)`,
                SEVERITY.INFO,
                { contentId: item._id.toString(), contentType }
              );
            }
          } else {
            results.skipped.push({
              contentType,
              reason: 'No content ready for publishing'
            });
          }
        } else {
          results.skipped.push({
            contentType,
            reason: 'Not scheduled for today'
          });
        }
      } catch (error) {
        console.error(`Error processing ${contentType}:`, error);
        results.errors.push({
          contentType,
          error: error.message
        });
      }
    }
    
    // Generate report
    const reportDir = path.join(__dirname, '../content_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(
      reportDir, 
      `publishing_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
    
    console.log(`Content publishing completed. Report saved to ${reportPath}`);
    return reportPath;
  } catch (error) {
    console.error('Error running content publishing:', error);
    sendAlert(
      'Error in content publishing',
      `Failed to run content publishing: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  }
}

// Check if this script is being run directly
if (require.main === module) {
  runContentPublishing();
}

module.exports = {
  runContentPublishing,
  getContentForPublishing,
  publishContent
};
```

## Content Refresh Schedule

The following schedule establishes a regular cadence for content refresh activities:

### Daily Tasks

1. **News Updates**
   - Automated collection of radiation oncology news
   - AI-powered summarization and categorization
   - Publication to news section of website

2. **Content Publishing**
   - Run `content_scheduler.js` daily to check if content should be published
   - Automatically publish content that meets quality thresholds

### Weekly Tasks

1. **Blog Post Generation**
   - Schedule: Every Tuesday
   - Process:
     - Run `content_generator.js` with focus on blog posts
     - Human review and approval before publishing
     - Publish on schedule via content scheduler

2. **Quiz Updates**
   - Schedule: Every Wednesday
   - Process:
     - Generate new quiz questions for high-traffic topics
     - Update existing quizzes with new questions
     - Publish on schedule via content scheduler

3. **Content Quality Assessment**
   - Schedule: Every Friday
   - Process:
     - Run `content_quality.js` to assess recently created content
     - Prioritize content for improvement based on scores
     - Schedule updates for low-scoring content

### Bi-Weekly Tasks

1. **Podcast Episode Creation**
   - Schedule: Every other Thursday
   - Process:
     - Generate podcast script via AI
     - Create audio using ElevenLabs
     - Human review and approval
     - Publish on schedule via content scheduler

2. **Content Audit**
   - Schedule: Every other Monday
   - Process:
     - Run `content_audit.js` to identify outdated content
     - Prioritize content for refresh based on age and traffic
     - Schedule content updates

### Monthly Tasks

1. **Course Content Updates**
   - Schedule: 15th of each month
   - Process:
     - Review and update one major course module
     - Add new resources and references
     - Update practice questions

2. **AAPM TG Reports & ASTRO Guidelines Review**
   - Schedule: First Monday of each month
   - Process:
     - Check for new or updated reports/guidelines
     - Generate content analyzing new publications
     - Update existing content referencing these sources

3. **Content Performance Analysis**
   - Schedule: Last day of each month
   - Process:
     - Analyze user engagement with content
     - Identify high and low-performing content
     - Adjust content strategy based on findings

### Quarterly Tasks

1. **Comprehensive Content Audit**
   - Schedule: First week of each quarter
   - Process:
     - Run full content audit across all content types
     - Generate report on content freshness and quality
     - Create quarterly content refresh plan

2. **Board Exam Content Update**
   - Schedule: January, April, July, October
   - Process:
     - Review and update all board exam preparation materials
     - Add new practice questions
     - Update content based on recent exam feedback

3. **Role-Based Content Review**
   - Schedule: Rotating quarterly (one role per quarter)
   - Process:
     - Deep review of content for one professional role
     - Update all materials for that role
     - Add new content based on recent developments

## Cron Job Configuration

Add the following to the server's crontab to automate the content refresh process:

```
# Daily content publishing check (8 AM)
0 8 * * * /usr/bin/node /home/username/content_scripts/content_scheduler.js >> /home/username/logs/content_publishing.log 2>&1

# Weekly blog post generation (Monday at 10 AM)
0 10 * * 1 /usr/bin/node /home/username/content_scripts/content_generator.js --type=blogposts >> /home/username/logs/blog_generation.log 2>&1

# Weekly quiz updates (Tuesday at 10 AM)
0 10 * * 2 /usr/bin/node /home/username/content_scripts/content_generator.js --type=quizzes >> /home/username/logs/quiz_generation.log 2>&1

# Weekly content quality assessment (Friday at 10 AM)
0 10 * * 5 /usr/bin/node /home/username/content_scripts/content_quality.js >> /home/username/logs/quality_assessment.log 2>&1

# Bi-weekly podcast generation (Every other Thursday at 10 AM)
0 10 * * 4 [ $(expr $(date +\%s) / 604800 \% 2) -eq 0 ] && /usr/bin/node /home/username/content_scripts/content_generator.js --type=podcastepisodes >> /home/username/logs/podcast_generation.log 2>&1

# Bi-weekly content audit (Every other Monday at 2 AM)
0 2 * * 1 [ $(expr $(date +\%s) / 604800 \% 2) -eq 1 ] && /usr/bin/node /home/username/content_scripts/content_audit.js >> /home/username/logs/content_audit.log 2>&1

# Monthly course updates (15th of each month at 2 AM)
0 2 15 * * /usr/bin/node /home/username/content_scripts/content_generator.js --type=courses >> /home/username/logs/course_updates.log 2>&1
```

## GoDaddy-Specific Implementation

Since GoDaddy shared hosting has some limitations, the following adjustments are necessary:

1. Use GoDaddy's cPanel for cron job setup:
   - Access cPanel > Advanced > Cron Jobs
   - Add each cron job as specified in the schedule
   - Ensure proper paths to Node.js executable

2. Configure scripts to work within GoDaddy's environment:
   - Use relative paths compatible with GoDaddy's directory structure
   - Ensure scripts have proper execution permissions
   - Work within GoDaddy's resource limitations

3. For resource-intensive operations:
   - Schedule during off-peak hours
   - Split large operations into smaller batches
   - Implement timeouts and retry mechanisms

## Implementation Steps

1. Create the content scripts directory structure:
   ```bash
   mkdir -p /home/username/content_scripts
   mkdir -p /home/username/content_reports
   mkdir -p /home/username/content_reports/quality
   mkdir -p /home/username/generated_content/audio
   mkdir -p /home/username/logs
   ```

2. Create the content scripts as outlined above

3. Make the scripts executable:
   ```bash
   chmod +x /home/username/content_scripts/*.js
   ```

4. Install required packages:
   ```bash
   cd /home/username/public_html/radiation_oncology_academy
   npm install axios mongodb openai --save
   ```

5. Set up cron jobs through GoDaddy cPanel:
   - Access cPanel > Advanced > Cron Jobs
   - Add each cron job as specified in the schedule

6. Test each content script manually to ensure it works correctly

7. Document the content refresh system in the admin guide

## Content Performance Analytics

To measure the effectiveness of the content refresh strategy, implement the following analytics:

1. **Engagement Metrics**
   - Page views per content item
   - Average time spent on content
   - Completion rate for courses and quizzes
   - Social shares and comments

2. **Quality Metrics**
   - AI-generated quality scores
   - User ratings and feedback
   - Expert review scores

3. **Freshness Metrics**
   - Content age
   - Time since last update
   - Update frequency

4. **Impact Metrics**
   - User learning outcomes
   - Quiz performance improvements
   - Return visitor rate
   - Membership conversions

## Conclusion

This content refresh strategy provides a comprehensive approach to maintaining fresh, high-quality content on the Radiation Oncology Academy website with:
- Systematic content auditing and quality assessment
- AI-powered content generation and updating
- Structured publishing schedule for different content types
- Performance analytics to measure effectiveness

The system is designed to be compatible with GoDaddy hosting while providing a robust content management approach that leverages AI tools to maintain engaging, accurate, and up-to-date educational materials for radiation oncology professionals.
