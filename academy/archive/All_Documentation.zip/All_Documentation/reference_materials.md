# Radiation Protection and Safety Reference Materials

This document provides essential reference materials for radiation protection in radiation oncology. These resources are designed for quick access to critical information during clinical practice and educational activities.

## 1. Radiation Protection Quantities and Units

### Physical Quantities

| Quantity | Symbol | Unit | Definition |
|----------|--------|------|------------|
| Fluence | Φ | m⁻² | Number of particles incident on a sphere of cross-sectional area, divided by that area |
| Energy Fluence | Ψ | J·m⁻² | Sum of energies of all particles incident on a sphere of cross-sectional area, divided by that area |
| Kerma | K | Gy (J·kg⁻¹) | Sum of initial kinetic energies of all charged particles liberated by uncharged ionizing radiation in a material, divided by the mass |
| Absorbed Dose | D | Gy (J·kg⁻¹) | Energy imparted by ionizing radiation to matter per unit mass |
| Linear Energy Transfer | LET | keV·μm⁻¹ | Energy transferred to the medium per unit length of particle track |

### Protection Quantities

| Quantity | Symbol | Unit | Definition |
|----------|--------|------|------------|
| Radiation Weighting Factor | w<sub>R</sub> | dimensionless | Factor representing the relative biological effectiveness of different radiation types |
| Tissue Weighting Factor | w<sub>T</sub> | dimensionless | Factor representing the relative contribution of a tissue/organ to overall detriment from uniform whole-body irradiation |
| Equivalent Dose | H<sub>T</sub> | Sv | Sum of absorbed doses in a tissue/organ multiplied by radiation weighting factors |
| Effective Dose | E | Sv | Sum of equivalent doses to tissues/organs multiplied by tissue weighting factors |
| Committed Equivalent Dose | H<sub>T</sub>(τ) | Sv | Time integral of equivalent dose rate in tissue/organ following intake of radioactive material |
| Committed Effective Dose | E(τ) | Sv | Sum of committed equivalent doses multiplied by tissue weighting factors |

### Operational Quantities

| Quantity | Symbol | Unit | Definition |
|----------|--------|------|------------|
| Ambient Dose Equivalent | H*(d) | Sv | Dose equivalent at a point in a radiation field that would be produced in the ICRU sphere at depth d on the radius opposing the direction of the aligned field |
| Directional Dose Equivalent | H'(d,Ω) | Sv | Dose equivalent at a point in a radiation field that would be produced in the ICRU sphere at depth d on a radius in a specified direction Ω |
| Personal Dose Equivalent | H<sub>p</sub>(d) | Sv | Dose equivalent in soft tissue at an appropriate depth d below a specified point on the body |

### Radiation Weighting Factors (ICRP 103)

| Radiation Type | Energy Range | w<sub>R</sub> |
|----------------|--------------|---------------|
| Photons | All energies | 1 |
| Electrons and muons | All energies | 1 |
| Protons and charged pions | All energies | 2 |
| Alpha particles, fission fragments, heavy ions | All energies | 20 |
| Neutrons | < 1 MeV | 2.5 + 18.2e<sup>-[ln(E)]²/6</sup> |
| | 1 MeV - 50 MeV | 5.0 + 17.0e<sup>-[ln(2E)]²/6</sup> |
| | > 50 MeV | 2.5 + 3.25e<sup>-[ln(0.04E)]²/6</sup> |

### Tissue Weighting Factors (ICRP 103)

| Tissue/Organ | w<sub>T</sub> | Sum |
|--------------|---------------|-----|
| Bone marrow (red), Colon, Lung, Stomach, Breast, Remainder tissues* | 0.12 | 0.72 |
| Gonads | 0.08 | 0.08 |
| Bladder, Esophagus, Liver, Thyroid | 0.04 | 0.16 |
| Bone surface, Brain, Salivary glands, Skin | 0.01 | 0.04 |
| **Total** | | **1.00** |

*Remainder tissues: Adrenals, Extrathoracic region, Gall bladder, Heart, Kidneys, Lymphatic nodes, Muscle, Oral mucosa, Pancreas, Prostate, Small intestine, Spleen, Thymus, Uterus/cervix

## 2. Dose Limits and Constraints

### Occupational Dose Limits (ICRP 103)

| Application | Dose Limit | Period |
|-------------|------------|--------|
| Effective Dose | 20 mSv | Averaged over 5 years, not to exceed 50 mSv in any single year |
| Lens of Eye | 20 mSv | Per year, averaged over 5 years, not to exceed 50 mSv in any single year |
| Skin | 500 mSv | Per year, averaged over 1 cm² area of skin |
| Hands and Feet | 500 mSv | Per year |

### Public Dose Limits (ICRP 103)

| Application | Dose Limit | Period |
|-------------|------------|--------|
| Effective Dose | 1 mSv | Per year |
| Lens of Eye | 15 mSv | Per year |
| Skin | 50 mSv | Per year |

### Dose Constraints for Medical Exposure (ICRP 103)

| Application | Constraint | Notes |
|-------------|------------|-------|
| Comforters and carers | 5 mSv | Per episode |
| Volunteers in biomedical research | 1-10 mSv | Based on societal benefit |
| Public from patient release | 1 mSv | Per year |

### Typical Dose Constraints for Radiation Oncology Facility Design

| Area Classification | Constraint | Period | Notes |
|---------------------|------------|--------|-------|
| Controlled Area | 6 mSv | Per year | Areas requiring control of normal exposures |
| Supervised Area | 1 mSv | Per year | Areas requiring review of exposure conditions |
| Public Area | 0.3 mSv | Per year | Design goal for areas with continuous occupancy |
| Adjacent Radiotherapy Room | 0.1 mSv | Per week | Design goal for adjacent treatment areas |

### Investigation Levels for Occupational Exposure in Radiation Oncology

| Application | Level | Period | Action |
|-------------|-------|--------|--------|
| Effective Dose | 0.5 mSv | Per month | Review of working practices |
| Effective Dose | 1 mSv | Per month | Formal investigation and corrective actions |
| Extremity Dose | 15 mSv | Per month | Investigation and corrective actions |
| Lens of Eye | 1.5 mSv | Per month | Investigation and corrective actions |

## 3. Shielding Data and Calculations

### Primary Barrier Calculation

The primary barrier thickness (t) can be calculated using:

$$t = TVL_1 + (n-1) \times TVL_e$$

Where:
- TVL₁ = First tenth-value layer
- TVLₑ = Equilibrium tenth-value layer
- n = Number of TVLs required = log₁₀(K·B·P·d²/(W·U·T))

Parameters:
- K = Beam calibration factor (typically 1 for photons)
- B = Transmission factor
- P = Shielding design goal (Sv/week)
- d = Distance from source to calculation point (m)
- W = Workload (Gy/week at 1m)
- U = Use factor
- T = Occupancy factor

### Secondary Barrier Calculation

For leakage radiation:

$$t_L = TVL_1 + (n_L-1) \times TVL_e$$

Where:
- n<sub>L</sub> = log₁₀(0.001·W·T·L/(P·d<sub>L</sub>²))
- L = Leakage ratio (typically 0.001 for modern linacs)
- d<sub>L</sub> = Distance from source to calculation point for leakage (m)

For scatter radiation:

$$t_S = TVL_1 + (n_S-1) \times TVL_e$$

Where:
- n<sub>S</sub> = log₁₀(α·W·T·F·a/(P·d<sub>sca</sub>²·d<sub>sec</sub>²))
- α = Scatter fraction at the specified angle
- F = Field area at 1m from source (cm²)
- a = Scatter fraction (typically 0.1% for 90° scatter)
- d<sub>sca</sub> = Distance from source to scattering surface (m)
- d<sub>sec</sub> = Distance from scattering surface to calculation point (m)

### Tenth-Value Layers (TVLs) for Common Shielding Materials

| Energy | Material | First TVL (cm) | Equilibrium TVL (cm) |
|--------|----------|----------------|----------------------|
| 6 MV | Concrete (2.35 g/cm³) | 37 | 33 |
| 6 MV | Lead | 5.7 | 5.7 |
| 6 MV | Steel | 15.1 | 14.8 |
| 10 MV | Concrete (2.35 g/cm³) | 41 | 37 |
| 10 MV | Lead | 6.1 | 5.9 |
| 10 MV | Steel | 16.8 | 16.3 |
| 18 MV | Concrete (2.35 g/cm³) | 44 | 41 |
| 18 MV | Lead | 6.5 | 6.2 |
| 18 MV | Steel | 17.9 | 17.3 |

### Neutron Shielding for High-Energy Accelerators (>10 MV)

| Material | TVL for Neutrons (cm) |
|----------|------------------------|
| Concrete (2.35 g/cm³) | 21 |
| Borated Polyethylene (5% boron) | 6.5 |
| Water | 22 |
| Paraffin | 12 |

### Typical Occupancy Factors (T)

| Area Type | Occupancy Factor |
|-----------|------------------|
| Administrative or clerical offices, treatment planning areas, nurse stations, attended waiting rooms | 1 |
| Corridors, patient rooms, staff lounges, staff work areas | 1/4 |
| Corridors used by staff only, unattended waiting rooms, storage areas, outdoor areas with seating | 1/8 |
| Outdoor areas with only transient pedestrian or vehicular traffic, unattended parking lots, stairways, unattended elevators, janitor's closets | 1/20 |

### Typical Use Factors (U)

| Barrier Type | Use Factor |
|--------------|------------|
| Primary barriers for fixed orientation units | 1/4 |
| Primary barriers for dedicated stereotactic units | 1/8 |
| Secondary barriers | 1 |

### Typical Workloads (W)

| Equipment | Typical Workload (Gy/week at 1m) |
|-----------|----------------------------------|
| Linear Accelerator (General Purpose) | 500-1000 |
| Linear Accelerator (IMRT/VMAT) | 1000-1500 |
| Linear Accelerator (SRS/SBRT) | 200-400 |
| Cobalt-60 Unit | 200-300 |
| Superficial/Orthovoltage Unit | 100-200 |
| HDR Brachytherapy (Ir-192) | 10-20 |

## 4. Radiation Survey and Monitoring

### Survey Instrument Selection Guide

| Radiation Type | Energy Range | Recommended Detector | Limitations |
|----------------|--------------|----------------------|-------------|
| Photons (γ, X) | 5 keV - 50 keV | Thin-window GM, Scintillation | Energy dependence |
| Photons (γ, X) | 50 keV - 2 MeV | Ionization Chamber | Low sensitivity |
| Photons (γ, X) | 2 MeV - 25 MeV | Ionization Chamber | Needs build-up cap |
| Beta | < 200 keV | Thin-window GM, Scintillation | Energy dependence |
| Beta | > 200 keV | Thin-window GM, Ionization Chamber | Window thickness critical |
| Neutrons | Thermal | BF₃, ³He proportional counters | Gamma discrimination |
| Neutrons | Fast | Moderated BF₃, ³He, Scintillation | Energy dependence |

### Radiation Survey Protocol

#### Area Survey Frequency

| Area Type | Minimum Survey Frequency |
|-----------|--------------------------|
| Treatment Rooms | Monthly |
| Simulator/CT Rooms | Monthly |
| HDR Treatment Rooms | Before each source exchange |
| Source Storage Areas | Monthly |
| Department Boundaries | Quarterly |
| Public Areas | Quarterly |
| Areas with Potential Activation | After high-energy operation |

#### Survey Measurement Points

| Location | Measurement Height | Notes |
|----------|-------------------|-------|
| General Areas | 100 cm | Representative of whole body exposure |
| Operator Positions | 150 cm | Eye level for seated operator |
| Leakage Evaluation | 50 cm from surface | For equipment leakage |
| Door Seams | At seam height | Check for streaming radiation |
| Penetrations | At penetration | Check for inadequate shielding |
| Adjacent Areas | 100 cm | Check in occupied locations |

### Personnel Monitoring Requirements

| Personnel Category | Dosimeter Type | Exchange Frequency | Additional Monitoring |
|-------------------|----------------|-------------------|----------------------|
| Radiation Oncologists | Whole-body badge | Monthly | Ring badge for brachytherapy |
| Medical Physicists | Whole-body badge | Monthly | Ring badge, electronic dosimeter for HDR |
| Radiation Therapists | Whole-body badge | Monthly | None |
| Nurses (Brachytherapy) | Whole-body badge | Monthly | None |
| Dosimetrists | Whole-body badge | Monthly | None |
| Engineering/Maintenance | Whole-body badge | Monthly | Electronic dosimeter for service |
| Housekeeping | Whole-body badge | Monthly | None |

### Action Levels for Survey Results

| Measurement Type | Action Level | Required Response |
|------------------|--------------|-------------------|
| Area Dose Rate (Controlled) | > 25 μSv/h | Restrict access, investigate |
| Area Dose Rate (Supervised) | > 7.5 μSv/h | Post warning, investigate |
| Area Dose Rate (Public) | > 0.5 μSv/h | Restrict access, investigate |
| Leakage Radiation | > 0.1% of useful beam | Service notification, investigation |
| Neutron Dose Rate | > 10 μSv/h | Restrict access, investigate |
| Contamination (Sealed Source) | Any detectable | Secure area, implement emergency procedures |

## 5. Radiation Protection for Specific Modalities

### External Beam Radiotherapy

#### Linear Accelerator Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Primary barriers (concrete 1.5-2.5m)<br>• Secondary barriers (concrete 0.5-1.5m)<br>• Neutron shielding for >10MV (borated polyethylene)<br>• Maze design with 2-3 turns<br>• Shielded doors (lead-lined or neutron doors) |
| Operational Controls | • Two independent interlocks on entrance<br>• Emergency shut-off switches inside room<br>• Audio/visual communication with patient<br>• Radiation warning lights and signs<br>• Key control for operation<br>• Daily safety system checks |
| Monitoring Requirements | • Area monitors at entrance and console<br>• Personal dosimetry for all staff<br>• Quarterly comprehensive area surveys<br>• Annual shielding verification<br>• Patient-specific IGRT dose tracking |
| Emergency Procedures | • Power failure protocol<br>• Stuck beam emergency response<br>• Patient medical emergency protocol<br>• Fire emergency procedure<br>• Radiation incident reporting procedure |

#### Tomotherapy Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Primary barriers (concrete 1.5-2.0m)<br>• Secondary barriers (concrete 0.5-1.0m)<br>• Maze design with 1-2 turns<br>• Standard door (no neutron concerns) |
| Operational Controls | • Two independent interlocks on entrance<br>• Emergency shut-off switches inside room<br>• Audio/visual communication with patient<br>• Radiation warning lights and signs<br>• Key control for operation<br>• Daily safety system checks |
| Monitoring Requirements | • Area monitors at entrance and console<br>• Personal dosimetry for all staff<br>• Quarterly comprehensive area surveys<br>• Annual shielding verification<br>• Patient-specific MVCT dose tracking |
| Emergency Procedures | • Power failure protocol<br>• Gantry rotation failure response<br>• Patient medical emergency protocol<br>• Fire emergency procedure<br>• Radiation incident reporting procedure |

#### Proton Therapy Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Primary barriers (concrete 3.0-4.0m)<br>• Secondary barriers (concrete 2.0-3.0m)<br>• Neutron shielding (borated concrete)<br>• Maze design with multiple turns<br>• Heavy shielded doors |
| Operational Controls | • Multiple interlock systems<br>• Emergency shut-off switches throughout facility<br>• Audio/visual communication with patient<br>• Radiation warning lights and signs<br>• Access control system<br>• Daily safety system checks |
| Monitoring Requirements | • Area monitors throughout facility<br>• Neutron monitors at key locations<br>• Personal dosimetry for all staff<br>• Activation monitoring program<br>• Comprehensive area surveys<br>• Environmental monitoring |
| Emergency Procedures | • Beam control system failure protocol<br>• Magnet quench response procedure<br>• Patient medical emergency protocol<br>• Fire emergency procedure<br>• Activation management procedure |

### Brachytherapy

#### HDR Brachytherapy Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Treatment room (concrete 0.5-1.0m)<br>• Control console shielding<br>• Source storage shielding<br>• Viewing window (lead glass) |
| Operational Controls | • Two independent interlocks on entrance<br>• Emergency shut-off switches<br>• Audio/visual communication with patient<br>• Radiation warning lights and signs<br>• Source position verification<br>• Emergency source retraction system |
| Monitoring Requirements | • Area radiation monitor in treatment room<br>• Source position verification system<br>• Personal dosimetry for all staff<br>• Electronic dosimeters during procedures<br>• Source inventory and tracking system |
| Emergency Procedures | • Source stuck emergency procedure<br>• Source retraction failure protocol<br>• Patient medical emergency protocol<br>• Power failure procedure<br>• Source recovery equipment |

#### LDR Brachytherapy Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Source preparation laboratory shielding<br>• Patient room shielding or portable shields<br>• Source storage container shielding |
| Operational Controls | • Source handling tools and containers<br>• Source inventory and tracking system<br>• Time, distance, shielding optimization<br>• Radiation warning signs<br>• Patient isolation procedures |
| Monitoring Requirements | • Area surveys of patient rooms<br>• Source assay before implantation<br>• Personal dosimetry for all staff<br>• Extremity monitoring for source handlers<br>• Patient release surveys |
| Emergency Procedures | • Lost source search procedure<br>• Contamination control procedure<br>• Patient medical emergency protocol<br>• Source recovery equipment<br>• Regulatory reporting procedure |

### Special Procedures

#### Total Body Irradiation (TBI) Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Standard treatment vault shielding<br>• Additional portable shielding if needed<br>• Extended SSD considerations |
| Operational Controls | • Specialized treatment setup protocol<br>• In-vivo dosimetry requirements<br>• Staff positioning guidance<br>• Extended treatment time considerations |
| Monitoring Requirements | • In-room monitoring during setup<br>• Electronic dosimeters for in-room staff<br>• Area monitoring at control console<br>• Patient monitoring systems |
| Emergency Procedures | • Patient medical emergency protocol<br>• Equipment failure procedure<br>• Extended treatment interruption protocol |

#### Total Skin Electron Therapy (TSET) Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Standard treatment vault shielding<br>• Consideration of scatter radiation patterns<br>• Extended SSD considerations |
| Operational Controls | • Specialized treatment setup protocol<br>• Staff positioning during patient positioning<br>• Rotation of staff for multiple positions<br>• Treatment time optimization |
| Monitoring Requirements | • In-room monitoring during setup<br>• Electronic dosimeters for in-room staff<br>• Area monitoring at control console<br>• Patient monitoring systems |
| Emergency Procedures | • Patient medical emergency protocol<br>• Equipment failure procedure<br>• Position change emergency protocol |

#### Stereotactic Radiosurgery (SRS) Protection Measures

| Protection Aspect | Key Measures |
|-------------------|--------------|
| Structural Shielding | • Standard treatment vault shielding<br>• Consideration of non-coplanar beams |
| Operational Controls | • Specialized immobilization protocol<br>• Image guidance procedures<br>• Staff positioning during setup<br>• Treatment verification requirements |
| Monitoring Requirements | • In-room monitoring during setup<br>• Electronic dosimeters for in-room staff<br>• Area monitoring at control console<br>• Patient monitoring systems |
| Emergency Procedures | • Patient medical emergency protocol<br>• Equipment failure procedure<br>• Image guidance failure protocol |

## 6. Radiation Emergency Response

### Emergency Classification and Response

| Emergency Type | Classification | Immediate Actions | Secondary Actions |
|----------------|----------------|-------------------|-------------------|
| **HDR Source Stuck** | Major | • Notify all personnel in area<br>• Remove patient if possible<br>• Secure area<br>• Activate emergency response team | • Assess situation with survey meter<br>• Implement source recovery procedure<br>• Document incident<br>• Report to regulatory authority |
| **Lost Radioactive Source** | Major | • Secure immediate area<br>• Prevent personnel from leaving<br>• Notify RSO immediately<br>• Begin contamination surveys | • Implement source search procedure<br>• Document all actions<br>• Report to regulatory authority<br>• Prepare public notification if needed |
| **Accelerator Stuck Beam** | Major | • Press emergency stop button<br>• Turn key to off position<br>• Remove patient from room<br>• Secure area | • Contact service engineer<br>• Document incident<br>• Report to regulatory authority<br>• Verify safety systems before restart |
| **Radiation Area Monitor Alarm** | Minor/Major | • Verify alarm with survey meter<br>• Secure area if confirmed<br>• Identify source of radiation<br>• Notify RSO | • Implement appropriate emergency procedure<br>• Document incident<br>• Investigate cause<br>• Implement corrective actions |
| **Contamination Event** | Minor/Major | • Contain spread of contamination<br>• Notify RSO<br>• Isolate affected individuals<br>• Begin decontamination | • Survey affected areas<br>• Document contamination levels<br>• Implement decontamination procedures<br>• Report if regulatory thresholds exceeded |
| **Medical Emergency in Radiation Area** | Major | • For HDR: Emergency retract source<br>• For linac: Emergency beam off<br>• Attend to medical emergency<br>• Monitor radiation levels | • Document radiation status before entry<br>• Brief medical personnel on radiation status<br>• Monitor all emergency responders<br>• Document incident |
| **Fire in Radiation Area** | Major | • Activate fire alarm<br>• For HDR: Emergency retract source<br>• For linac: Emergency beam off<br>• Evacuate area | • Inform fire department of radiation hazards<br>• Monitor all emergency responders<br>• Conduct radiation survey after fire<br>• Document incident and report |
| **Power Failure** | Minor/Major | • For HDR: Verify source retraction<br>• For linac: Verify beam termination<br>• Implement backup power procedures<br>• Secure radiation sources | • Document radiation status<br>• Implement patient care procedures<br>• Verify all systems before restart<br>• Test safety systems after power restoration |

### Emergency Equipment Requirements

| Location | Required Equipment |
|----------|-------------------|
| **Treatment Console** | • Emergency procedures manual<br>• Emergency contact list<br>• Emergency stop controls<br>• Communication system<br>• Backup power connection |
| **Treatment Room** | • Emergency stop buttons<br>• Radiation survey meter<br>• Emergency lighting<br>• First aid kit<br>• Fire extinguisher<br>• Communication system |
| **HDR Treatment Room** | • Emergency source container<br>• Long-handled forceps<br>• Lead bricks and sheets<br>• Radiation survey meter with speaker<br>• Source handling tools<br>• Emergency procedure posters |
| **Source Storage Area** | • Emergency source containers<br>• Decontamination kit<br>• Radiation survey meter<br>• Long-handled tools<br>• Lead sheets and containers<br>• Emergency procedure posters |
| **Department Entrance** | • Emergency procedure summary<br>• Radiation warning signs<br>• Emergency contact list<br>• Department layout with radiation areas marked |

### Emergency Response Team Composition

| Team Member | Primary Responsibilities |
|-------------|--------------------------|
| **Radiation Safety Officer** | • Overall emergency coordination<br>• Regulatory authority communication<br>• Exposure assessment<br>• Documentation oversight<br>• Recovery operations direction |
| **Medical Physicist** | • Technical assessment of situation<br>• Radiation measurements<br>• Source recovery operations<br>• Dose calculations<br>• Equipment safety evaluation |
| **Radiation Oncologist** | • Patient medical management<br>• Staff medical assessment<br>• Exposure consequence evaluation<br>• Communication with patient/family<br>• Medical follow-up coordination |
| **Radiation Therapist** | • Equipment operation during emergency<br>• Patient care during emergency<br>• Execution of technical procedures<br>• Documentation of equipment status<br>• Control area management |
| **Nursing Staff** | • Patient care coordination<br>• Medical monitoring of affected individuals<br>• Decontamination assistance<br>• Documentation of medical aspects<br>• Patient/family communication support |
| **Security Personnel** | • Area security maintenance<br>• Access control implementation<br>• Emergency services coordination<br>• Traffic control<br>• Public protection measures |

### Regulatory Reporting Requirements

| Incident Type | Reporting Timeframe | Documentation Requirements |
|---------------|---------------------|----------------------------|
| **Source Lost or Stolen** | Immediate (within 1 hour) | • Description of source<br>• Activity and radionuclide<br>• Location and time of loss<br>• Actions taken to recover<br>• Potential hazard assessment |
| **Overexposure (>Limits)** | 24 hours | • Exposed individual information<br>• Dose estimate<br>• Cause of exposure<br>• Corrective actions<br>• Medical evaluation results |
| **Equipment Failure with Potential Exposure** | 24 hours | • Equipment description<br>• Nature of failure<br>• Potential exposure assessment<br>• Corrective actions<br>• Patient impact assessment |
| **Leaking Sealed Source** | 24-48 hours | • Source description<br>• Leak test results<br>• Contamination assessment<br>• Corrective actions<br>• Exposure assessment |
| **Treatment Misadministration** | 24 hours - 15 days (varies by jurisdiction) | • Patient information<br>• Prescribed vs. delivered dose<br>• Cause of misadministration<br>• Effect on patient<br>• Corrective actions |
| **Minor Incidents** | Annual report | • Brief description<br>• Corrective actions<br>• Preventive measures<br>• Trending analysis |

## 7. Radiation Safety Program Elements

### Radiation Safety Committee Structure

| Position | Qualifications | Responsibilities |
|----------|----------------|------------------|
| **Chairperson** | • Senior physician (typically)<br>• Radiation safety training<br>• Management experience | • Conduct meetings<br>• Ensure regulatory compliance<br>• Review program effectiveness<br>• Approve policy changes<br>• Interface with administration |
| **Radiation Safety Officer** | • Board certification in medical physics or health physics<br>• Regulatory required training<br>• Experience in radiation protection | • Day-to-day program management<br>• Regulatory compliance oversight<br>• Monitoring program implementation<br>• Incident investigation<br>• Committee recommendations implementation |
| **Radiation Oncologist** | • Board certified<br>• Clinical experience | • Clinical perspective on safety<br>• Patient protection issues<br>• Risk-benefit assessments<br>• Protocol review<br>• Incident review |
| **Medical Physicist** | • Board certification<br>• Clinical experience | • Technical expertise<br>• Shielding design review<br>• Equipment safety evaluation<br>• Dosimetry program oversight<br>• Quality assurance integration |
| **Radiation Therapist** | • Certification<br>• Senior level experience | • Operational perspective<br>• Workflow safety integration<br>• Staff training needs<br>• Practical implementation feedback<br>• Procedure development input |
| **Nursing Representative** | • Oncology nursing experience<br>• Radiation safety training | • Patient care perspective<br>• Nursing procedure development<br>• Staff training needs<br>• Patient education input |
| **Administration Representative** | • Management position<br>• Resource authority | • Resource allocation<br>• Institutional policy integration<br>• Regulatory compliance support<br>• Risk management integration |

### ALARA Program Implementation

| Program Element | Implementation Approach | Performance Indicators |
|-----------------|-------------------------|------------------------|
| **Investigation Levels** | • Level I: 10% of limits (review)<br>• Level II: 30% of limits (investigation) | • Number of Level I/II investigations<br>• Trend in exposure levels<br>• Corrective actions implemented |
| **Dose Reduction Initiatives** | • Annual ALARA goals establishment<br>• Quarterly review of progress<br>• Staff suggestions program<br>• Technology assessment for dose reduction | • Collective dose trends<br>• Individual dose trends<br>• Successful initiatives implemented<br>• Staff participation rate |
| **Training and Awareness** | • Annual radiation safety training<br>• Monthly radiation safety tips<br>• Dose reports to individuals<br>• Department dose dashboard | • Training completion rate<br>• Knowledge assessment scores<br>• Staff awareness survey results<br>• Behavioral observation results |
| **Program Review** | • Quarterly ALARA committee meetings<br>• Annual program review<br>• External review every 3 years<br>• Continuous improvement process | • Meeting attendance<br>• Action item completion rate<br>• Improvement recommendations<br>• Implementation effectiveness |

### Radiation Safety Audits

| Audit Type | Frequency | Key Elements | Documentation |
|------------|-----------|--------------|---------------|
| **Routine Safety Audit** | Monthly | • Posting and labeling<br>• Survey instrument calibration<br>• Dosimeter use<br>• Security of sources<br>• Record keeping | • Checklist completion<br>• Non-compliance documentation<br>• Corrective action tracking<br>• Trend analysis |
| **Comprehensive Program Audit** | Annual | • Policy and procedure review<br>• Training program assessment<br>• Monitoring program evaluation<br>• Incident response assessment<br>• ALARA program effectiveness | • Detailed report<br>• Non-compliance documentation<br>• Corrective action plan<br>• Implementation timeline |
| **Focused Audits** | As needed | • New equipment/procedure<br>• Post-incident<br>• Regulatory change implementation<br>• High-dose procedure review | • Specific audit protocol<br>• Findings documentation<br>• Recommendations<br>• Implementation verification |
| **External Audit** | Every 2-3 years | • Independent assessment<br>• Regulatory compliance<br>• Best practice comparison<br>• Program effectiveness | • Formal report<br>• Findings classification<br>• Response document<br>• Improvement plan |

### Training Requirements

| Personnel Category | Initial Training | Refresher Training | Competency Verification |
|-------------------|------------------|-------------------|-------------------------|
| **Radiation Oncologists** | • 4-8 hours radiation safety<br>• Emergency procedures<br>• Regulatory requirements<br>• Modality-specific training | • Annual (1-2 hours)<br>• After significant changes<br>• Post-incident as needed | • Written examination<br>• Procedure demonstration<br>• Emergency response drill<br>• Documentation review |
| **Medical Physicists** | • 8-16 hours radiation safety<br>• Emergency procedures<br>• Regulatory requirements<br>• Modality-specific training | • Annual (2-4 hours)<br>• After significant changes<br>• Post-incident as needed | • Written examination<br>• Procedure demonstration<br>• Emergency response drill<br>• Documentation review |
| **Radiation Therapists** | • 4-8 hours radiation safety<br>• Emergency procedures<br>• Regulatory requirements<br>• Modality-specific training | • Annual (1-2 hours)<br>• After significant changes<br>• Post-incident as needed | • Written examination<br>• Procedure demonstration<br>• Emergency response drill<br>• Documentation review |
| **Nursing Staff** | • 2-4 hours radiation safety<br>• Emergency procedures<br>• Patient care procedures<br>• Modality-specific training | • Annual (1-2 hours)<br>• After significant changes<br>• Post-incident as needed | • Written examination<br>• Procedure demonstration<br>• Emergency response drill |
| **Ancillary Personnel** | • 1-2 hours radiation safety<br>• Emergency procedures<br>• Area access rules | • Annual (1 hour)<br>• After significant changes | • Written examination<br>• Behavioral observation |

## 8. Radiation Protection During Pregnancy

### Occupational Exposure Management

| Stage | Management Approach | Dose Limits |
|-------|---------------------|------------|
| **Declaration of Pregnancy** | • Voluntary written declaration<br>• Counseling by RSO<br>• Review of work assignments<br>• Additional monitoring as needed | • 1 mSv to embryo/fetus for remainder of pregnancy<br>• Recommended monthly limit of 0.1 mSv |
| **First Trimester** | • Highest radiosensitivity period<br>• Consider temporary reassignment from high-exposure areas<br>• No brachytherapy source handling<br>• No emergency response team participation | • Monthly monitoring with immediate reading<br>• Investigation level at 0.1 mSv/month |
| **Second Trimester** | • Moderate radiosensitivity<br>• Continue modified duties<br>• Maintain distance from radiation sources<br>• Use additional shielding when appropriate | • Monthly monitoring with immediate reading<br>• Investigation level at 0.1 mSv/month |
| **Third Trimester** | • Lower radiosensitivity<br>• Continue modified duties<br>• Ergonomic considerations with shielding<br>• Prepare for maternity leave transition | • Monthly monitoring with immediate reading<br>• Investigation level at 0.1 mSv/month |

### Recommended Work Restrictions

| Work Area/Procedure | Recommendation | Alternative Duties |
|---------------------|----------------|-------------------|
| **HDR Brachytherapy** | Avoid source exchange and emergency response | Treatment planning, quality assurance, patient education |
| **LDR Source Preparation** | Avoid direct handling of sources | Treatment planning, documentation, remote oversight |
| **Seed Implant Procedures** | Avoid direct participation | Treatment planning, equipment preparation, documentation |
| **Fluoroscopic Procedures** | Avoid direct participation | Patient preparation, equipment setup, documentation |
| **High-Energy Linac (>10MV)** | Limit time for patient setup | Treatment planning, lower-energy treatments, documentation |
| **Proton Therapy (Activation Areas)** | Avoid activated areas | Treatment planning, quality assurance, patient education |
| **Emergency Response Team** | Temporary removal from team | Procedure development, training, documentation |

### Monitoring Program for Pregnant Workers

| Monitoring Type | Approach | Action Levels |
|-----------------|----------|---------------|
| **Personal Dosimetry** | • Additional badge at waist level under apron<br>• Monthly exchange frequency<br>• Immediate reading upon receipt<br>• Separate dose tracking | • Investigation at 0.1 mSv/month<br>• Work restriction consideration at 0.25 mSv/month<br>• Reassignment consideration at 0.5 mSv/month |
| **Area Monitoring** | • Workplace evaluation for pregnant worker<br>• Identification of low-exposure areas<br>• Verification of shielding adequacy<br>• Monitoring of workload in area | • Area reassignment if rates exceed 1 μSv/h<br>• Additional shielding if rates exceed 0.5 μSv/h |
| **Bioassay (if applicable)** | • Baseline upon declaration<br>• Monthly during pregnancy<br>• Special monitoring after potential intake | • Investigation at detection limit<br>• Work restriction at 1% ALI |

### Patient Management During Pregnancy

| Patient Scenario | Management Approach | Fetal Dose Consideration |
|------------------|---------------------|--------------------------|
| **Pregnant Patient Needing Radiotherapy** | • Multidisciplinary consultation<br>• Detailed risk assessment<br>• Treatment modification if possible<br>• Enhanced shielding<br>• Detailed documentation | • Detailed fetal dose calculation<br>• Consider treatment delay if possible<br>• Technique optimization<br>• In-vivo dosimetry<br>• Fetal monitoring coordination |
| **Patient Who Becomes Pregnant During Treatment** | • Immediate treatment pause<br>• Multidisciplinary consultation<br>• Reassessment of risk-benefit<br>• Treatment modification if possible<br>• Enhanced documentation | • Estimation of dose already received<br>• Projection of remaining treatment dose<br>• Technique modification<br>• Enhanced monitoring<br>• Detailed documentation |
| **Recently Treated Patient Who Becomes Pregnant** | • Dose estimation to conceptus<br>• Risk assessment<br>• Patient counseling<br>• Coordination with obstetrics<br>• Documentation | • Retrospective dose calculation<br>• Risk communication<br>• Monitoring recommendations<br>• Support resources |

## 9. Non-Ionizing Radiation Safety in Radiation Oncology

### MRI Safety in Radiation Oncology

| Zone | Description | Access Control | Safety Requirements |
|------|-------------|----------------|---------------------|
| **Zone I** | Public access areas | • General public access<br>• No special restrictions | • MRI safety education materials<br>• Directional signs to other zones |
| **Zone II** | Unscreened patient interface | • Patient and visitor access<br>• Supervision required | • Screening forms available<br>• Preliminary screening conducted<br>• Waiting areas for patients/visitors |
| **Zone III** | Screened access, controlled | • Access limited to screened individuals<br>• Key card or key lock entry<br>• Continuous supervision of unscreened persons | • Comprehensive screening before entry<br>• Ferromagnetic detection systems<br>• Warning signs<br>• Emergency procedures posted |
| **Zone IV** | MRI scanner room | • Highly restricted access<br>• Direct supervision by MR personnel<br>• Physical barriers to entry | • "Magnet On" warning signs<br>• Gauss line markings on floor<br>• Emergency shutdown procedures<br>• Quench vent and monitoring<br>• Ferromagnetic material detectors |

#### MRI Screening Categories

| Category | Description | Management |
|----------|-------------|------------|
| **MR Safe** | Items that pose no known hazards in all MRI environments | • Can be taken into Zone IV<br>• No special precautions needed |
| **MR Conditional** | Items that pose no known hazards in a specified MRI environment with specified conditions of use | • Verify conditions match scanner specifications<br>• Implement required conditions<br>• Document verification |
| **MR Unsafe** | Items that pose hazards in all MRI environments | • Prohibited in Zone III and IV<br>• Must be clearly labeled<br>• Secured storage outside restricted zones |

#### MRI Emergency Procedures

| Emergency | Immediate Actions | Secondary Actions |
|-----------|-------------------|-------------------|
| **Medical Emergency** | • Assess if patient can be removed from scanner<br>• Call for medical emergency team<br>• Remove patient if possible<br>• If not possible, follow MR medical emergency protocol | • Document incident<br>• Review response effectiveness<br>• Implement improvements<br>• Return scanner to service |
| **Fire** | • Remove patient from scanner<br>• Activate fire alarm<br>• Use MR-compatible fire extinguisher if safe<br>• Evacuate Zone III and IV | • Do not re-enter until cleared<br>• Document incident<br>• Implement corrective actions<br>• Verify system integrity before use |
| **Quench** | • Remove patient from scanner<br>• Evacuate room if oxygen levels dropping<br>• Ensure vent pipe integrity<br>• Activate emergency ventilation | • Secure area until system evaluated<br>• Contact service engineer<br>• Document incident<br>• Verify system integrity before use |
| **Projectile Incident** | • Ensure patient safety first<br>• Do not attempt to remove projectile during scan<br>• If safe, discontinue scan<br>• Assess injury and damage | • Document incident<br>• Investigate cause<br>• Implement preventive measures<br>• Verify system integrity before use |

### Laser Safety in Radiation Oncology

| Laser Class | Hazard Level | Control Measures |
|-------------|--------------|------------------|
| **Class 1** | Safe under reasonably foreseeable conditions | • No special controls required<br>• Standard operating procedures |
| **Class 1M** | Safe for naked eye, may be hazardous with optical instruments | • Prevent use of optical instruments<br>• Controlled access during service |
| **Class 2** | Low power visible lasers (≤1 mW) | • Caution signs<br>• Avoid prolonged staring<br>• Basic training |
| **Class 2M** | Low power, may be hazardous with optical instruments | • Prevent use of optical instruments<br>• Caution signs<br>• Basic training |
| **Class 3R** | Medium power (1-5 mW) | • Restricted area access<br>• Beam termination<br>• Training required<br>• Warning signs |
| **Class 3B** | Medium-high power (5-500 mW) | • Controlled access<br>• Beam enclosures<br>• Training required<br>• Protective eyewear<br>• Warning signs/lights |
| **Class 4** | High power (>500 mW) | • Strict controlled access<br>• Interlocked room entry<br>• Key control<br>• Protective eyewear<br>• Warning signs/lights<br>• Fire precautions |

#### Laser Safety Program Elements

| Program Element | Requirements |
|-----------------|--------------|
| **Laser Safety Officer** | • Designated individual with appropriate training<br>• Authority to monitor and enforce safety procedures<br>• Responsible for hazard evaluation and control measures |
| **Hazard Evaluation** | • Classification verification<br>• Nominal Hazard Zone determination<br>• Control measure adequacy assessment |
| **Engineering Controls** | • Protective housings<br>• Access panels and interlocks<br>• Key controls<br>• Beam stops and attenuators<br>• Warning systems |
| **Administrative Controls** | • Standard operating procedures<br>• Alignment procedures<br>• Authorized user designation<br>• Training requirements |
| **Personal Protective Equipment** | • Appropriate eyewear based on wavelength and power<br>• Proper fit and condition verification<br>• Availability at room entrance |
| **Medical Surveillance** | • Baseline eye examination<br>• Periodic examinations based on risk<br>• Post-exposure examination protocol |

### Ultrasound Safety

| Bioeffect Mechanism | Potential Effects | Safety Measures |
|---------------------|-------------------|----------------|
| **Thermal Effects** | • Tissue heating<br>• Protein denaturation<br>• Cellular damage | • Monitor thermal index (TI)<br>• Limit exposure time<br>• Use lowest power needed<br>• Allow cooling periods |
| **Mechanical Effects** | • Cavitation<br>• Microstreaming<br>• Radiation pressure | • Monitor mechanical index (MI)<br>• Use lowest power needed<br>• Limit exposure time |
| **Operator Effects** | • Repetitive strain injury<br>• Musculoskeletal disorders | • Ergonomic equipment design<br>• Proper positioning<br>• Work breaks<br>• Technique optimization |

#### Ultrasound Safety Guidelines

| Application | Guidelines |
|-------------|------------|
| **Diagnostic Ultrasound** | • ALARA principle application<br>• TI < 1.0 for most applications<br>• MI < 0.7 to minimize cavitation<br>• Minimize exposure time<br>• Use lowest output power needed |
| **Therapeutic Ultrasound** | • Treatment plan review<br>• Output verification<br>• Treatment area verification<br>• Patient feedback monitoring<br>• Documentation of parameters |

## 10. Regulatory Framework and Guidelines

### International Organizations

| Organization | Role | Key Publications |
|--------------|------|------------------|
| **International Commission on Radiological Protection (ICRP)** | • Develops recommendations for radiation protection<br>• Provides framework for radiological protection standards<br>• Recommends dose limits and constraints | • ICRP Publication 103 (2007): Recommendations<br>• ICRP Publication 105: Medical Exposure<br>• ICRP Publication 113: Education and Training<br>• ICRP Publication 127: Radiological Protection in Ion Beam Radiotherapy |
| **International Atomic Energy Agency (IAEA)** | • Promotes safe use of nuclear technology<br>• Develops safety standards<br>• Provides technical assistance<br>• Verifies compliance through inspections | • IAEA Safety Standards Series No. GSR Part 3<br>• IAEA Safety Reports Series No. 47: Radiation Protection in Radiotherapy<br>• IAEA Human Health Series No. 31: Accuracy Requirements in Radiotherapy |
| **International Commission on Radiation Units and Measurements (ICRU)** | • Develops internationally accepted recommendations on radiation quantities and units<br>• Provides measurement procedures<br>• Develops reporting guidance | • ICRU Report 85: Fundamental Quantities and Units<br>• ICRU Report 91: Prescribing, Recording, and Reporting Proton Therapy<br>• ICRU Report 93: Prescribing, Recording, and Reporting Light Ion Therapy |

### United States Regulatory Framework

| Agency | Jurisdiction | Key Regulations |
|--------|--------------|----------------|
| **Nuclear Regulatory Commission (NRC)** | • Byproduct material<br>• Source material<br>• Special nuclear material<br>• Agreement State program oversight | • 10 CFR Part 20: Standards for Protection Against Radiation<br>• 10 CFR Part 35: Medical Use of Byproduct Material<br>• 10 CFR Part 19: Notices, Instructions and Reports to Workers |
| **Agreement States** | • Regulation of byproduct, source, and small quantities of special nuclear material within state boundaries | • State regulations compatible with NRC requirements<br>• State-specific licensing and inspection programs<br>• State-specific training requirements |
| **Food and Drug Administration (FDA)** | • Electronic product radiation control<br>• Medical device approval<br>• Radiopharmaceutical approval | • 21 CFR 1000-1050: Radiological Health<br>• 21 CFR 807: Medical Device Registration<br>• 21 CFR 812: Investigational Device Exemptions |
| **Occupational Safety and Health Administration (OSHA)** | • Workplace safety<br>• Non-ionizing radiation protection<br>• Hazard communication | • 29 CFR 1910.1096: Ionizing Radiation<br>• 29 CFR 1910.97: Non-ionizing Radiation<br>• 29 CFR 1910.1200: Hazard Communication |
| **Environmental Protection Agency (EPA)** | • Environmental radiation protection<br>• Air emissions<br>• Drinking water standards | • 40 CFR Part 190: Environmental Radiation Protection<br>• 40 CFR Part 61: National Emission Standards for Hazardous Air Pollutants<br>• 40 CFR Part 141: National Primary Drinking Water Regulations |

### European Regulatory Framework

| Entity | Jurisdiction | Key Regulations |
|--------|--------------|----------------|
| **European Union** | • Framework for member states<br>• Harmonization of protection standards<br>• Cross-border aspects | • Euratom Directive 2013/59: Basic Safety Standards<br>• Directive 97/43: Medical Exposures<br>• Directive 90/641: Outside Workers |
| **National Regulatory Authorities** | • Implementation of EU directives<br>• National licensing and inspection<br>• Enforcement actions | • National legislation implementing EU directives<br>• National dose limits and constraints<br>• National licensing requirements |

### Professional Organizations and Guidelines

| Organization | Role | Key Guidelines |
|--------------|------|----------------|
| **American Association of Physicists in Medicine (AAPM)** | • Professional guidance for medical physicists<br>• Technical standards development<br>• Education and training guidance | • AAPM TG-142: QA of Medical Accelerators<br>• AAPM TG-56: Radiation Protection for Radiotherapy Facilities<br>• AAPM TG-100: Risk Assessment for Radiotherapy |
| **American Society for Radiation Oncology (ASTRO)** | • Professional guidance for radiation oncologists<br>• Safety and quality initiatives<br>• Accreditation programs | • Safety is No Accident: Framework for Quality Radiation Oncology<br>• Accreditation Program for Excellence (APEx)<br>• Target Safely Initiative |
| **National Council on Radiation Protection and Measurements (NCRP)** | • Radiation protection guidance<br>• Scientific reviews<br>• Recommendations | • NCRP Report No. 151: Structural Shielding Design<br>• NCRP Report No. 147: Structural Shielding Design for Medical Imaging<br>• NCRP Report No. 170: Second Primary Cancers and Cardiovascular Disease After Radiation Therapy |

## 11. Glossary of Radiation Protection Terms

| Term | Definition |
|------|------------|
| **ALARA** | As Low As Reasonably Achievable - A principle of radiation protection that requires all radiation exposures to be kept as low as reasonably achievable, taking into account economic and social factors. |
| **Absorbed Dose** | The energy imparted by ionizing radiation per unit mass of irradiated material. The unit is the gray (Gy), which equals 1 J/kg. |
| **Ambient Dose Equivalent** | The dose equivalent at a point in a radiation field that would be produced by the corresponding expanded and aligned field in the ICRU sphere at a depth of 10 mm on the radius opposing the direction of the aligned field. |
| **Brachytherapy** | A method of treatment in which sealed sources are used to deliver radiation at a short distance by interstitial, intracavitary, or surface application. |
| **Controlled Area** | A defined area in which specific protection measures and safety provisions are or could be required for controlling normal exposures or preventing the spread of contamination during normal working conditions. |
| **Deterministic Effect** | A health effect of radiation for which a threshold level of dose exists above which the severity of the effect is greater for a higher dose. Examples include erythema, cataract formation, and sterility. |
| **Effective Dose** | The sum of the weighted equivalent doses in all specified tissues and organs of the body. The unit is the sievert (Sv). |
| **Equivalent Dose** | The absorbed dose in a tissue or organ multiplied by the appropriate radiation weighting factor. The unit is the sievert (Sv). |
| **External Beam Radiotherapy** | Treatment with ionizing radiation delivered by a device external to the patient. |
| **Half-Value Layer (HVL)** | The thickness of a specified material that attenuates the beam of radiation to an extent that the exposure rate is reduced to one-half of its original value. |
| **ICRP** | International Commission on Radiological Protection - An independent international organization that provides recommendations and guidance on radiation protection. |
| **Kerma** | Kinetic Energy Released per unit Mass - The sum of the initial kinetic energies of all charged particles liberated by uncharged ionizing radiation in a material of unit mass. |
| **Linear Energy Transfer (LET)** | The average energy locally imparted to a medium by a charged particle of specified energy per unit distance traversed. |
| **Linear No-Threshold Model (LNT)** | A dose-response model that assumes a linear relationship between dose and effect without a threshold, used for radiation protection purposes. |
| **Occupational Exposure** | Exposure of workers incurred in the course of their work. |
| **Personal Dose Equivalent** | The dose equivalent in soft tissue at an appropriate depth below a specified point on the body. |
| **Radiation Weighting Factor** | A dimensionless factor used to derive equivalent dose from absorbed dose, taking into account the relative biological effectiveness of different radiation types. |
| **Radioactive Source** | Radioactive material that is permanently sealed in a capsule or closely bonded in a solid form. |
| **Scattered Radiation** | Radiation that has been deviated in direction during passage through matter. |
| **Stochastic Effect** | A health effect of radiation for which the probability of occurrence increases with dose, but the severity does not depend on dose. Cancer and hereditary effects are stochastic. |
| **Supervised Area** | A defined area not designated as a controlled area but for which occupational exposure conditions are kept under review. |
| **Tenth-Value Layer (TVL)** | The thickness of a specified material that attenuates the beam of radiation to an extent that the exposure rate is reduced to one-tenth of its original value. |
| **Tissue Weighting Factor** | A dimensionless factor used to derive effective dose from equivalent dose, representing the relative contribution of that tissue to the total health detriment. |
| **Use Factor (U)** | The fraction of the workload during which the useful beam is directed toward a particular barrier. |
| **Workload (W)** | The time integral of the radiation output of a source over a defined time period, often expressed as absorbed dose delivered at the calibration point in a specified time. |

## 12. References and Resources

### Key Reference Documents

| Category | Reference | Description |
|----------|-----------|-------------|
| **International Recommendations** | ICRP Publication 103 (2007) | The 2007 Recommendations of the International Commission on Radiological Protection |
| | ICRP Publication 105 (2007) | Radiological Protection in Medicine |
| | ICRP Publication 127 (2014) | Radiological Protection in Ion Beam Radiotherapy |
| | IAEA Safety Standards Series No. GSR Part 3 | Radiation Protection and Safety of Radiation Sources: International Basic Safety Standards |
| **Facility Design** | NCRP Report No. 151 (2005) | Structural Shielding Design and Evaluation for Megavoltage X- and Gamma-Ray Radiotherapy Facilities |
| | IPEM Report 75 (1997) | Design of Radiotherapy Treatment Room Facilities |
| | IAEA Safety Reports Series No. 47 (2006) | Radiation Protection in the Design of Radiotherapy Facilities |
| **Operational Radiation Protection** | AAPM TG-56 Report (1998) | Medical Accelerator Safety Considerations |
| | IAEA Safety Reports Series No. 38 (2006) | Applying Radiation Safety Standards in Radiotherapy |
| | ASTRO Safety is No Accident (2019) | A Framework for Quality Radiation Oncology Care |
| **Brachytherapy** | IAEA Safety Reports Series No. 68 (2012) | Radiation Protection in Brachytherapy |
| | AAPM TG-40 Report (1994) | Comprehensive QA for Radiation Oncology |
| | AAPM TG-56 Report (2005) | Code of Practice for Brachytherapy Physics |
| **Special Procedures** | AAPM TG-29 Report (1987) | The physical aspects of total and half body photon irradiation |
| | AAPM TG-30 Report (1988) | Total Skin Electron Therapy: Technique and Dosimetry |
| | IAEA TECDOC-1040 (1998) | Design and implementation of radiotherapy programmes: Clinical, medical physics, radiation protection and safety aspects |
| **Emergency Preparedness** | IAEA Safety Standards Series No. GS-G-2.1 | Arrangements for Preparedness for a Nuclear or Radiological Emergency |
| | NCRP Report No. 138 (2001) | Management of Terrorist Events Involving Radioactive Material |
| | IAEA EPR-Medical (2005) | Generic procedures for medical response during a nuclear or radiological emergency |

### Online Resources

| Resource | URL | Description |
|----------|-----|-------------|
| **ICRP Website** | [www.icrp.org](http://www.icrp.org) | Access to ICRP publications, recommendations, and educational resources |
| **IAEA Radiation Protection of Patients** | [rpop.iaea.org](https://rpop.iaea.org) | Comprehensive resource for radiation protection in medical applications |
| **NRC Medical Uses Licensee Toolkit** | [www.nrc.gov/materials/miau/med-use-toolkit.html](https://www.nrc.gov/materials/miau/med-use-toolkit.html) | Regulatory guidance and tools for medical use of radioactive materials |
| **AAPM Website** | [www.aapm.org](https://www.aapm.org) | Professional resources for medical physicists including radiation protection |
| **Health Physics Society** | [hps.org](https://hps.org) | Professional society for radiation protection specialists |
| **Radiation Emergency Medical Management** | [www.remm.nlm.gov](https://www.remm.nlm.gov) | Guidance for health care providers on radiation emergencies |
| **Radiation Emergency Assistance Center** | [orise.orau.gov/reacts](https://orise.orau.gov/reacts) | 24/7 consultation on radiation accidents and incidents |

### Professional Organizations

| Organization | Focus | Resources Provided |
|--------------|-------|-------------------|
| **American Association of Physicists in Medicine (AAPM)** | Medical physics practice | • Task group reports<br>• Professional guidelines<br>• Educational resources<br>• Annual meeting |
| **Health Physics Society (HPS)** | Radiation protection | • Position statements<br>• Professional standards<br>• Educational resources<br>• Certification preparation |
| **American Society for Radiation Oncology (ASTRO)** | Radiation oncology practice | • Safety initiatives<br>• Quality programs<br>• Practice guidelines<br>• Patient resources |
| **Society of Nuclear Medicine and Molecular Imaging (SNMMI)** | Nuclear medicine practice | • Procedure standards<br>• Dose reduction resources<br>• Patient information<br>• Professional guidelines |
| **American College of Radiology (ACR)** | Radiological practice | • Accreditation programs<br>• Practice parameters<br>• Quality and safety resources<br>• Dose index registry |
| **International Radiation Protection Association (IRPA)** | International radiation protection | • International standards<br>• Educational resources<br>• Professional guidance<br>• International congress |

### Educational Resources

| Resource Type | Examples | Description |
|---------------|----------|-------------|
| **Online Courses** | • IAEA Radiation Protection in Radiotherapy<br>• Health Physics Society Professional Development<br>• AAPM Virtual Library | Self-paced learning on radiation protection topics with certificates of completion |
| **Webinars** | • ASTRO Safety Webinar Series<br>• AAPM Radiation Safety Series<br>• IAEA Webinars | Expert presentations on specific radiation protection topics |
| **Workshops** | • AAPM Summer School<br>• IAEA Regional Training Courses<br>• Health Physics Society Professional Development School | Hands-on training and in-depth education on radiation protection |
| **Certification Programs** | • American Board of Health Physics<br>• American Board of Medical Physics<br>• American Board of Radiology | Professional certification in radiation protection and medical physics |
| **Simulation Tools** | • IAEA Smart Card/SmartRad<br>• NCRP Dose Calculation Tools<br>• Monte Carlo Simulation Packages | Tools for dose calculation, shielding design, and radiation protection training |

This comprehensive reference material provides essential information for radiation protection in radiation oncology, covering all aspects from basic quantities and units to regulatory frameworks and educational resources. The material is designed for quick access during clinical practice and educational activities.
