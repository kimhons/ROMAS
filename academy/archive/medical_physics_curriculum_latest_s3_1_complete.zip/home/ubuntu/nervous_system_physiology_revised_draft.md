# Section 3.1: Nervous System Physiology

## Learning Objectives

Upon completion of this section, the learner should be able to:

*   Describe the fundamental structure of a neuron and the specific functions of its key components (soma, dendrites, axon, myelin sheath, axon terminal).
*   Identify the major types of glial cells in the CNS and PNS and describe their primary functions.
*   Explain the ionic mechanisms responsible for establishing and maintaining the resting membrane potential, referencing the Nernst and Goldman-Hodgkin-Katz equations conceptually.
*   Detail the sequence of events and ionic fluxes underlying the generation and propagation of an action potential, including depolarization, repolarization, and hyperpolarization.
*   Describe the process of chemical synaptic transmission, encompassing neurotransmitter release, diffusion, receptor binding, postsynaptic potential generation (EPSPs and IPSPs), and signal termination.
*   Outline the major anatomical and functional divisions of the central nervous system (CNS) and peripheral nervous system (PNS), including the somatic and autonomic nervous systems.
*   Summarize the basic physiological principles of key sensory systems (e.g., vision, hearing) and the pathways involved in motor control.
*   Relate fundamental principles of nervous system physiology to specific applications and interpretations in medical physics, such as MRI, fMRI (BOLD contrast), PET, and the consideration of neurological structures in radiation therapy planning.

## Introduction

The nervous system serves as the body's primary control and communication network, orchestrating actions and transmitting signals between different parts of the body. A thorough understanding of its physiology, covering fundamental principles aligned with the foundational knowledge expected by CAMPEP and ABR, is indispensable in medical physics. This is particularly true in the context of diagnostic imaging modalities like Magnetic Resonance Imaging (MRI), functional MRI (fMRI), and Positron Emission Tomography (PET), as well as in radiation therapy, where nervous system tissues are frequently targeted or constitute critical organs at risk. This section provides a detailed exploration of the fundamental physiological processes governing the nervous system, encompassing neuronal signaling, synaptic communication, the structural and functional organization of the central and peripheral nervous systems, sensory perception, motor control, and the physiological underpinnings of neurological functions pertinent to medical imaging and therapeutic interventions.

## Cellular Components and Neuronal Signaling

The nervous system's operations are rooted in the activity of its specialized cells: neurons and glial cells.

### Neurons
Neurons are the primary signaling units, structurally adapted for information transmission. Key components include:
*   **Soma (Cell Body):** Contains the nucleus and metabolic machinery; integrates incoming signals.
*   **Dendrites:** Branched extensions that receive signals from other neurons at synapses.
*   **Axon:** A long projection that transmits electrical signals (action potentials) away from the soma.
*   **Axon Terminal:** The distal end of the axon, where neurotransmitters are released.

```
[Image: /home/ubuntu/curriculum/images/section_3_1/neuron_structure_detailed.svg]
Caption: Figure 3.1.1: Detailed structure of a typical neuron, illustrating the soma, dendrites, axon (with myelin sheath and Nodes of Ranvier), and axon terminal. (Source: Wikimedia Commons, CC BY-SA 4.0)
```

### Glial Cells (Neuroglia)
Glial cells are non-neuronal cells that outnumber neurons and provide essential structural, metabolic, and protective support. Major types include:
*   **Astrocytes (CNS):** Star-shaped cells; provide structural support, regulate the extracellular ionic environment, contribute to the blood-brain barrier, uptake neurotransmitters, and modulate synaptic activity.
*   **Oligodendrocytes (CNS):** Form the myelin sheath around axons in the CNS, insulating them and increasing conduction speed.
*   **Microglia (CNS):** Immune cells of the CNS; act as phagocytes, removing debris and pathogens.
*   **Ependymal Cells (CNS):** Line the ventricles of the brain and central canal of the spinal cord; produce cerebrospinal fluid (CSF).
*   **Schwann Cells (PNS):** Form the myelin sheath around axons in the PNS. Each Schwann cell myelinates a single axon segment.
*   **Satellite Cells (PNS):** Surround neuron cell bodies in ganglia; regulate the microenvironment.

Myelination by oligodendrocytes and Schwann cells is crucial for rapid signal propagation. The myelin sheath acts as an electrical insulator, forcing the action potential to regenerate only at the gaps in the myelin, called Nodes of Ranvier.

### Resting Membrane Potential
In the absence of signaling, a neuron maintains a stable electrical potential difference across its plasma membrane, known as the resting membrane potential (typically around -70 millivolts, mV, with the inside negative relative to the outside). This potential arises from:
1.  **Differential Ion Concentrations:** Maintained primarily by the Na+/K+ pump, resulting in higher [Na+] and [Cl-] outside, and higher [K+] and [A-] (large anions) inside.
2.  **Selective Membrane Permeability:** At rest, the membrane is significantly more permeable to K+ than to Na+, due to the presence of K+ leak channels.
3.  **Na+/K+ Pump (ATPase):** Actively transports 3 Na+ out for every 2 K+ in, maintaining the concentration gradients and contributing slightly to the negative potential.

The **Nernst equation** can be used to calculate the equilibrium potential for a single ion species (the membrane potential at which there is no net movement of that ion across the membrane), based on its concentration gradient. The **Goldman-Hodgkin-Katz (GHK) equation** extends this concept to calculate the overall resting membrane potential by considering the concentration gradients and relative permeabilities of multiple key ions (primarily K+, Na+, and Cl-). Conceptually, the resting potential is close to the Nernst potential for K+ because the membrane is most permeable to K+ at rest.

### Action Potential
An action potential is a rapid, transient, and self-propagating reversal of the membrane potential used for long-distance signaling along the axon. It operates on an "all-or-none" principle: if the stimulus reaches the threshold potential (typically around -55 mV) at the axon hillock, an action potential of a fixed amplitude and duration is generated; if the threshold is not reached, no action potential occurs.

The phases are driven by voltage-gated ion channels:
1.  **Threshold:** Summation of excitatory inputs depolarizes the membrane to the threshold.
2.  **Depolarization:** Rapid opening of voltage-gated Na+ channels causes a massive influx of Na+, driving the membrane potential towards positive values (e.g., +30 mV).
3.  **Repolarization:** Voltage-gated Na+ channels inactivate, and slower-opening voltage-gated K+ channels allow K+ efflux, bringing the potential back towards negative values.
4.  **Hyperpolarization (Undershoot):** Voltage-gated K+ channels close slowly, causing a brief period where the membrane potential is more negative than the resting potential.
5.  **Return to Rest:** Ion gradients are restored by the Na+/K+ pump and leak channel activity.

```
[Image: /home/ubuntu/curriculum/images/section_3_1/action_potential_shape.png]
Caption: Figure 3.1.2: The characteristic shape of an action potential, showing the phases of depolarization, repolarization, and hyperpolarization relative to the resting membrane potential and threshold. (Source: Wikimedia Commons, CC BY-SA 3.0)
```

Action potentials propagate along the axon. In unmyelinated axons, propagation occurs continuously. In myelinated axons, **saltatory conduction** occurs as the action potential "jumps" between Nodes of Ranvier, which is significantly faster and more energy-efficient.

*Practical Example:* The speed of action potential propagation (conduction velocity) varies depending on axon diameter and myelination. This principle is utilized in nerve conduction studies (NCS), an electrodiagnostic test used to evaluate peripheral nerve function by measuring the speed at which electrical impulses travel along a nerve.

### Synaptic Transmission
Neurons communicate with each other and with target cells (muscles, glands) at specialized junctions called synapses. Most synapses in the human nervous system are chemical synapses.

The sequence of events at a chemical synapse:
1.  **Arrival of Action Potential:** An action potential reaches the presynaptic axon terminal.
2.  **Calcium Influx:** Depolarization opens voltage-gated Ca2+ channels in the terminal membrane, allowing Ca2+ ions to enter the terminal.
3.  **Neurotransmitter Release:** The influx of Ca2+ triggers the fusion of synaptic vesicles (containing neurotransmitters) with the presynaptic membrane, releasing neurotransmitters into the synaptic cleft via exocytosis.
4.  **Diffusion and Binding:** Neurotransmitters diffuse across the synaptic cleft and bind to specific receptors on the postsynaptic membrane.
5.  **Postsynaptic Potential Generation:** Binding of neurotransmitters opens or closes ligand-gated ion channels, causing a change in the postsynaptic membrane potential:
    *   **Excitatory Postsynaptic Potential (EPSP):** Depolarization caused by influx of positive ions (e.g., Na+ via glutamate receptors). If EPSPs summate to reach threshold, they can trigger an action potential in the postsynaptic neuron.
    *   **Inhibitory Postsynaptic Potential (IPSP):** Hyperpolarization caused by influx of negative ions (e.g., Cl- via GABA receptors) or efflux of positive ions (K+), making it harder for the postsynaptic neuron to reach threshold.
6.  **Signal Termination:** Neurotransmitter effects are terminated by:
    *   **Reuptake:** Transport back into the presynaptic terminal or glial cells.
    *   **Enzymatic Degradation:** Breakdown by enzymes in the synaptic cleft (e.g., acetylcholine esterase).
    *   **Diffusion:** Drifting away from the synapse.

```
[Image: /home/ubuntu/curriculum/images/section_3_1/chemical_synapse_transmission.png]
Caption: Figure 3.1.3: Overview of chemical synaptic transmission, showing neurotransmitter release from the presynaptic terminal and binding to receptors on the postsynaptic membrane. (Source: Khan Academy, adapted)
```

Common neurotransmitters include acetylcholine (neuromuscular junction, autonomic ganglia), glutamate (primary excitatory in CNS), GABA (primary inhibitory in CNS), glycine (inhibitory in spinal cord), dopamine, serotonin, and norepinephrine (involved in mood, movement, attention).

*Practical Example:* PET imaging can utilize radiolabeled ligands that bind specifically to neurotransmitter receptors (e.g., dopamine D2 receptors in Parkinson's disease research) or transporters (e.g., dopamine transporter imaging with [123I]ioflupane SPECT for diagnosing Parkinsonian syndromes), providing insights into synaptic function and dysfunction in neurological disorders.

## Organization of the Nervous System

The nervous system is structurally and functionally divided into the Central Nervous System (CNS) and the Peripheral Nervous System (PNS).

### Central Nervous System (CNS)
The CNS, comprising the brain and spinal cord, acts as the body's integration and command center.
*   **Brain:** Housed within the skull, it is responsible for processing sensory input, initiating motor responses, regulating bodily functions, and enabling higher cognitive processes. Key structures include:
    *   **Cerebrum:** The largest part, divided into two hemispheres connected by the corpus callosum. The outer layer, the cerebral cortex, is responsible for conscious thought, language, memory, and voluntary movement control. It is organized into four main lobes: frontal, parietal, temporal, and occipital.
    *   **Cerebellum:** Located beneath the occipital lobe, it coordinates movement, balance, and posture.
    *   **Brainstem:** Connects the cerebrum and cerebellum to the spinal cord; includes the midbrain, pons, and medulla oblongata. It controls essential autonomic functions (breathing, heart rate) and relays signals.
    *   **Diencephalon:** Includes the thalamus (sensory relay station) and hypothalamus (homeostasis, endocrine control).
*   **Spinal Cord:** Extends from the brainstem down the vertebral canal. It serves as a conduit for signals between the brain and the body and mediates reflexes.

The CNS is protected by bone (skull, vertebrae), meninges (three membranes: dura, arachnoid, pia mater), and cerebrospinal fluid (CSF), which provides cushioning and chemical stability.

*Practical Example:* In radiation therapy planning for brain tumors, critical CNS structures like the brainstem, optic chiasm, optic nerves, hippocampus, and spinal cord are delineated as organs at risk (OARs). Understanding their location and function is crucial for minimizing radiation dose to these structures to prevent severe neurological deficits.

### Peripheral Nervous System (PNS)
The PNS includes all neural tissue outside the CNS – nerves and ganglia. It connects the CNS to the rest of the body.
*   **Somatic Nervous System:** Controls voluntary muscle movements and transmits sensory information (touch, pain, temperature, proprioception) from the body to the CNS.
*   **Autonomic Nervous System (ANS):** Regulates involuntary functions of internal organs (e.g., heart rate, digestion, respiration, blood pressure). It has two main divisions:
    *   **Sympathetic Division:** Mediates the "fight-or-flight" response, mobilizing the body for action.
    *   **Parasympathetic Division:** Promotes "rest-and-digest" functions, conserving energy.
    These divisions typically exert opposing effects on target organs to maintain homeostasis.

## Sensory Systems
Sensory systems detect various forms of energy (stimuli) from the environment and convert them into neural signals (transduction) that are processed by the CNS.

### General Senses
Receptors are distributed throughout the body (skin, muscles, joints, organs) and detect touch, pressure, vibration, temperature, pain (nociception), and body position (proprioception).

### Special Senses
Receptors are localized in specific sense organs:
*   **Vision:** Photoreceptors (rods for dim light, cones for color) in the retina detect light. Signals are processed by retinal neurons and transmitted via the optic nerve to the thalamus and then to the visual cortex (occipital lobe).
*   **Hearing:** Sound waves cause vibrations transduced by hair cells in the cochlea into electrical signals, sent via the auditory nerve to the auditory cortex (temporal lobe).
*   **Balance:** Hair cells in the vestibular system (semicircular canals, utricle, saccule) detect head movement and orientation.
*   **Smell (Olfaction):** Olfactory receptors in the nasal cavity detect airborne chemicals.
*   **Taste (Gustation):** Taste receptors on the tongue detect dissolved chemicals.

*Practical Example:* Functional MRI (fMRI) often uses sensory stimuli (e.g., visual patterns, auditory tones) to map brain activity. Understanding the pathways and processing areas for different senses (e.g., visual cortex in the occipital lobe, auditory cortex in the temporal lobe) is essential for designing experiments and interpreting the resulting activation maps.

## Motor Systems
Motor systems execute movements by controlling the contraction of muscles.

### Voluntary Movement
Complex movements are planned and initiated by cortical areas (primary motor cortex, premotor cortex, supplementary motor area). Commands descend via motor pathways (e.g., corticospinal tract) to lower motor neurons in the spinal cord, which directly innervate skeletal muscles. The cerebellum and basal ganglia are critical for coordinating, smoothing, and learning movements.

### Reflexes
Simple, involuntary, stereotyped responses to stimuli (e.g., knee-jerk reflex, withdrawal reflex) are often mediated at the spinal cord or brainstem level.

*Practical Example:* Techniques like Transcranial Magnetic Stimulation (TMS) can be used non-invasively to stimulate the motor cortex and map its functional organization or assess the integrity of motor pathways.

## Higher Brain Functions
These encompass complex cognitive processes like learning, memory, language, attention, emotion, and consciousness, involving intricate interactions between multiple brain regions, primarily within the cerebral cortex.
*   **Language:** Typically lateralized to the left hemisphere, involving areas like Broca's (production) and Wernicke's (comprehension).
*   **Memory:** Different types of memory involve distinct structures (e.g., hippocampus for episodic memory, amygdala for emotional memory).
*   **Emotion:** Processed by the limbic system (amygdala, hippocampus, hypothalamus, etc.).

## Physiological Basis in Medical Physics
Understanding nervous system physiology is fundamental to several medical physics domains:
*   **MRI/fMRI:** MRI provides detailed anatomical images. fMRI detects changes in blood oxygenation (Blood-Oxygen-Level-Dependent or BOLD contrast) associated with neural activity, allowing non-invasive mapping of brain function during specific tasks or in response to stimuli. Interpreting BOLD signals requires knowledge of neurovascular coupling.
*   **PET:** Uses radioactive tracers to measure physiological processes like glucose metabolism (e.g., [18F]FDG PET for tumor detection or assessing brain activity), blood flow, or neurotransmitter receptor density, providing functional and molecular information.
*   **Radiation Therapy:** The CNS exhibits varying radiosensitivity. Critical structures like the spinal cord, brainstem, optic nerves, and functional cortical areas have specific radiation tolerance limits. Accurate delineation and dose constraints based on physiological understanding are essential to minimize the risk of radiation-induced neurological damage (e.g., myelopathy, necrosis, cognitive decline).
*   **Electroencephalography (EEG) & Magnetoencephalography (MEG):** These techniques measure electrical and magnetic fields generated by neuronal activity, respectively, offering high temporal resolution insights into brain dynamics.

## Key Points

*   Neurons use electrical signals (resting potential, action potential) and chemical signals (neurotransmitters at synapses) for communication. Glial cells provide essential support.
*   The resting membrane potential is maintained by ion gradients (Na+/K+ pump) and selective permeability (primarily to K+), conceptually described by the Nernst and GHK equations.
*   Action potentials are all-or-none events triggered by threshold depolarization, involving voltage-gated Na+ and K+ channels.
*   Synaptic transmission involves Ca2+-dependent neurotransmitter release and postsynaptic receptor activation, leading to EPSPs or IPSPs.
*   The CNS (brain, spinal cord) integrates information and controls responses; the PNS (somatic, autonomic) connects the CNS to the body.
*   Sensory systems transduce environmental stimuli into neural signals; motor systems control muscle contraction.
*   Medical physics techniques like fMRI (BOLD), PET (metabolism, receptors), and radiation therapy planning rely heavily on understanding nervous system anatomy and physiology.

## Assessment Questions

1.  **Which glial cell type is primarily responsible for forming the myelin sheath around axons in the Peripheral Nervous System (PNS)?**
    (A) Astrocyte
    (B) Oligodendrocyte
    (C) Microglia
    (D) Schwann cell

2.  **The Goldman-Hodgkin-Katz (GHK) equation is used to calculate the resting membrane potential by considering which factors?**
    (A) Only the concentration gradient of K+ ions
    (B) The concentration gradients and relative permeabilities of multiple key ions (Na+, K+, Cl-)
    (C) Only the activity of the Na+/K+ pump
    (D) The capacitance of the neuronal membrane

3.  **During the repolarization phase of an action potential, the primary event is:**
    (A) Rapid influx of Na+ ions
    (B) Inactivation of voltage-gated K+ channels
    (C) Efflux of K+ ions through voltage-gated channels
    (D) Influx of Ca2+ ions at the axon terminal

4.  **Describe the sequence of events occurring at a chemical synapse after an action potential arrives at the presynaptic terminal, leading to a postsynaptic potential.**

5.  **Explain the physiological basis of the BOLD signal detected in fMRI.**

### Solutions

1.  **(D) Schwann cell.** Oligodendrocytes (B) myelinate axons in the CNS.
2.  **(B) The concentration gradients and relative permeabilities of multiple key ions (Na+, K+, Cl-).** The GHK equation provides a more accurate prediction of membrane potential than the Nernst equation (for a single ion) by incorporating the contributions of multiple permeable ions.
3.  **(C) Efflux of K+ ions through voltage-gated channels.** Following Na+ channel inactivation, the opening of voltage-gated K+ channels allows K+ to leave the cell, driving the membrane potential back towards negative values.
4.  **Answer:** Arrival of action potential -> Depolarization of presynaptic terminal -> Opening of voltage-gated Ca2+ channels -> Influx of Ca2+ -> Fusion of synaptic vesicles with presynaptic membrane -> Release of neurotransmitter into synaptic cleft -> Diffusion of neurotransmitter across cleft -> Binding of neurotransmitter to postsynaptic receptors -> Opening or closing of ligand-gated ion channels -> Change in postsynaptic membrane potential (EPSP or IPSP).
5.  **Answer:** The BOLD (Blood-Oxygen-Level-Dependent) signal is based on the difference in magnetic properties between oxygenated hemoglobin (diamagnetic) and deoxygenated hemoglobin (paramagnetic). When neurons become active, local blood flow increases more than oxygen consumption, leading to a higher ratio of oxygenated to deoxygenated hemoglobin in that area. This decrease in paramagnetic deoxygenated hemoglobin reduces local magnetic field distortions, resulting in a slightly stronger MR signal detected by fMRI.

## Conclusion

The intricate physiology of the nervous system, spanning from ionic fluxes across neuronal membranes to the complex interplay within large-scale brain networks, forms the bedrock of sensation, movement, cognition, and behavior. A robust understanding of these physiological principles, aligned with the foundational knowledge expected in medical physics training programs (e.g., CAMPEP, ABR), is fundamentally important for medical physicists. It enables the sophisticated application and accurate interpretation of advanced neuroimaging modalities like MRI, fMRI, and PET, and informs the safe and effective planning and delivery of radiation therapy involving the central or peripheral nervous system, ultimately contributing to improved diagnosis and treatment of neurological conditions.

## References

*   Kandel, E. R., Schwartz, J. H., Jessell, T. M., Siegelbaum, S. A., & Hudspeth, A. J. (2013). *Principles of Neural Science* (5th ed.). McGraw-Hill.
*   Purves, D., Augustine, G. J., Fitzpatrick, D., Hall, W. C., LaMantia, A. S., McNamara, J. O., & White, L. E. (Eds.). (2018). *Neuroscience* (6th ed.). Sinauer Associates.
*   Hall, J. E., & Hall, M. E. (2020). *Guyton and Hall Textbook of Medical Physiology* (14th ed.). Elsevier.
