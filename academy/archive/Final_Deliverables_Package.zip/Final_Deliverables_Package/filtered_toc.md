# Combined Table of Contents for Learning Documents

This TOC lists the documents found in the Learning Content Collection, along with an estimated completion level to help prioritize review.

| Estimated Completion | Title | Size (KB) | Filename |
|---|---|---|---|
| Final/Reference | Android Deployment Guide for Radiation Oncology Academy Mobile App | 12.0 | `android_deployment_guide.md` |
| Final/Reference | Content Migration Guide for Radiation Oncology Academy | 4.0 | `content_migration_guide.md` |
| Final/Reference | Dose Constraint Guide for Radiation Therapy | 12.1 | `dose_constraint_reference_guide.md` |
| Final/Reference | Final Implementation Plan for Radiation Oncology Academy | 8.0 | `final_implementation_plan.md` |
| Final/Reference | Final Testing Plan for Radiation Oncology Academy Mobile App | 11.9 | `final_testing_plan.md` |
| Final/Reference | Google Cloud Speech-to-Text Implementation Guide for Radiation Oncology Academy | 8.4 | `speech_to_text_implementation_guide.md` |
| Final/Reference | Google Cloud Storage Implementation Guide for Radiation Oncology Academy | 8.5 | `gcs_implementation_guide.md` |
| Final/Reference | Google Play Store Submission Guide for Radiation Oncology Academy Android App | 8.0 | `google_play_submission_guide.md` |
| Final/Reference | Graduate Program Features Specification | 7.3 | `graduate_program_features_specification.md` |
| Final/Reference | Manual Content Upload System Specification | 9.5 | `manual_content_upload_specification.md` |
| Final/Reference | Nested Final V2 Contents | 6.6 | `nested_final_v2_contents.txt` |
| Final/Reference | PART 5: CONFIGURATION | 4.0 | `complete_step_by_step_deployment_guide.md` |
| Final/Reference | Production Deployment Guide for Radiation Oncology Academy | 3.6 | `production_deployment_guide.md` |
| Final/Reference | Radiation Guide 1 Contents | 2.6 | `radiation_guide_1_contents.txt` |
| Final/Reference | Radiation Guide Contents | 3.4 | `radiation_guide_contents.txt` |
| Final/Reference | Radiation Guide X Contents | 3.9 | `radiation_guide_x_contents.txt` |
| Final/Reference | Radiation Oncology Academy - Admin Guide | 9.7 | `admin_guide.md` |
| Final/Reference | Radiation Oncology Academy - Beta Testing Protocol Guide | 9.1 | `uat_testing_protocol_guide.md` |
| Final/Reference | Radiation Oncology Academy - Final Project Status Report | 14.6 | `final_project_status_report.md` |
| Final/Reference | Radiation Oncology Academy - GoDaddy Installation Guide | 9.9 | `installation_guide.md` |
| Final/Reference | Radiation Oncology Academy - User Guide | 7.5 | `user_guide.md` |
| Final/Reference | Radiation Oncology Academy Database Schema | 11.9 | `database_schema.md` |
| Final/Reference | Radiation Oncology Academy Mobile App - Final Progress Report | 7.8 | `final_progress_report.md` |
| Final/Reference | Reference Materials Management Guide | 9.8 | `reference_materials_guide.md` |
| Final/Reference | iOS Deployment Guide for Radiation Oncology Academy Mobile App | 9.1 | `ios_deployment_guide.md` |
| Near Complete | ABR Board Preparation Content | 2.0 | `abr_equipment.md` |
| Near Complete | AI Integration Strategy for Radiation Oncology Academy | 11.5 | `ai_integration_strategy.md` |
| Near Complete | Assessment and Quiz System for Radiation Oncology Academy | 19.7 | `assessment_and_quiz_system.md` |
| Near Complete | Calibration, QC, and QA Content | 2.1 | `abr_calibration_qc_qa.md` |
| Near Complete | Chat Memory Management Strategy | 9.3 | `chat_memory_management_strategy.md` |
| Near Complete | Clinical Correlations and Knowledge Check Integration for Oxygen Effect and Radiosensitivity | 31.6 | `subsection_2_5_clinical_integration.md` |
| Near Complete | Coming Soon Indicators and Content Roadmap Implementation Plan | 15.7 | `coming_soon_content_roadmap_implementation_plan.md` |
| Near Complete | Comprehensive Content Inventory | 15.0 | `comprehensive_content_inventory.md` |
| Near Complete | Comprehensive Enhancements Documentation for Radiation Oncology Academy | 15.0 | `comprehensive_enhancements_documentation.md` |
| Near Complete | Comprehensive Platform Launch Strategy | 13.3 | `platform_launch_strategy.md` |
| Near Complete | Content Authoring Workflow for Radiation Oncology Academy | 17.5 | `content_authoring_workflow.md` |
| Near Complete | Content Creation Templates for Radiation Oncology Academy | 62.6 | `content_creation_templates.md` |
| Near Complete | Content Management Interface for Radiation Oncology Academy | 28.4 | `content_management_interface.md` |
| Near Complete | Content Migration Strategy for Radiation Oncology Academy | 43.9 | `content_migration_strategy.md` |
| Near Complete | Content Organization by Module Type and Target Audience | 14.0 | `content_organization_by_type_and_audience.md` |
| Near Complete | Content Refresh Strategy for Radiation Oncology Academy | 54.4 | `content_refresh_strategy.md` |
| Near Complete | Content Review Process for Radiation Oncology Academy | 24.8 | `content_review_process.md` |
| Near Complete | Content Structure and Organization Analysis | 11.2 | `content_structure_analysis.md` |
| Near Complete | Development Plan: Section 2 - Cell Survival Kinetics | 10.7 | `section_2_development_plan.md` |
| Near Complete | Diagram Design: Chromosomal Aberrations and Cellular Effects | 6.0 | `subsection_1_4_diagram_designs.md` |
| Near Complete | Diagram Design: Radiation-Induced Cell Death Mechanisms | 27.8 | `subsection_1_5_diagram_designs.md` |
| Near Complete | Diagram Designs: Cell Survival Curves | 21.9 | `subsection_2_1_diagram_designs.md` |
| Near Complete | Diagram Designs: Cell and Tissue Radiosensitivity | 21.6 | `subsection_2_6_diagram_designs.md` |
| Near Complete | Diagram Designs: Dose-Rate Effects | 16.7 | `subsection_2_3_diagram_designs.md` |
| Near Complete | Diagram Designs: Linear-Quadratic Model | 18.8 | `subsection_2_2_diagram_designs.md` |
| Near Complete | Diagram Designs: Oxygen Effect and Radiosensitivity | 18.7 | `subsection_2_5_diagram_designs.md` |
| Near Complete | Diagram Designs: Relative Biological Effectiveness | 16.0 | `subsection_2_4_diagram_designs.md` |
| Near Complete | Documentation Templates for Cross-Chat Knowledge Transfer | 14.9 | `documentation_templates.md` |
| Near Complete | Educational Content Catalog: Beyond Radiation Biology | 7.5 | `educational_content_beyond_radiation_biology.md` |
| Near Complete | Enhanced Diagram Design: Chromosomal Aberrations and Cellular Effects | 31.1 | `subsection_1_4_enhanced_diagram_designs.md` |
| Near Complete | Fundamentals of Radiation Protection | 28.4 | `lesson1_fundamentals.md` |
| Near Complete | Image Acquisition, Processing, and Display Content | 2.4 | `abr_imaging.md` |
| Near Complete | Implementation Plan for Podcast, News, and Advanced Courses | 61.0 | `podcast_news_courses_implementation.md` |
| Near Complete | Implementation Plan for Radiation Oncology Academy Website | 14.8 | `implementation_code_samples.md` |
| Near Complete | Implementation Strategy for Memory Management | 14.9 | `memory_management_implementation_strategy.md` |
| Near Complete | Interactive Diagrams Implementation Plan | 15.7 | `interactive_diagrams_implementation.md` |
| Near Complete | Interactive Diagrams Implementation Plan for Radiation Biology Module | 15.7 | `interactive_diagrams_implementation_plan.md` |
| Near Complete | Interactive Elements for Radiation Protection and Safety Module | 14.7 | `interactive_elements_design.md` |
| Near Complete | Launch Preparation and Monitoring Plan | 13.0 | `launch_preparation_and_monitoring_plan.md` |
| Near Complete | Marketing Strategy and Materials for Radiation Oncology Academy | 44.8 | `marketing_strategy_and_materials.md` |
| Near Complete | Monitoring System Implementation for Radiation Oncology Academy | 17.3 | `monitoring_system_implementation.md` |
| Near Complete | Monitoring and Analytics System for Radiation Oncology Academy | 30.3 | `monitoring_and_analytics_system.md` |
| Near Complete | Patient Related Measurements Content | 2.2 | `abr_patient_measurements.md` |
| Near Complete | Performance Optimization Report for Radiation Oncology Academy Mobile App | 4.9 | `performance_optimization_report.md` |
| Near Complete | Progress Tracking System for Radiation Oncology Academy | 15.0 | `progress_tracking_system.md` |
| Near Complete | QA Process Integration with Memory Management Strategy | 12.0 | `qa_memory_management_integration.md` |
| Near Complete | Quality Review: Subsection 1.5 - Radiation-Induced Cell Death Mechanisms | 7.1 | `subsection_1_5_quality_review.md` |
| Near Complete | Quality Review: Subsection 2.1 - Cell Survival Curves | 9.1 | `subsection_2_1_quality_review.md` |
| Near Complete | Quality Review: Subsection 2.2 - Linear-Quadratic Model | 9.5 | `subsection_2_2_quality_review.md` |
| Near Complete | Quality Review: Subsection 2.3 - Dose-Rate Effects | 9.4 | `subsection_2_3_quality_review.md` |
| Near Complete | Quality Review: Subsection 2.4 - Relative Biological Effectiveness | 9.6 | `subsection_2_4_quality_review.md` |
| Near Complete | Quality Review: Subsection 2.5 - Oxygen Effect and Radiosensitivity | 9.7 | `subsection_2_5_quality_review.md` |
| Near Complete | Quality Review: Subsection 2.6 - Cell and Tissue Radiosensitivity | 10.4 | `subsection_2_6_quality_review.md` |
| Near Complete | Radiation Biology Module - App Store Submission Documentation Index | 8.9 | `documentation_index.md` |
| Near Complete | Radiation Biology Module Content Analysis for Mobile App Development | 7.6 | `content_analysis.md` |
| Near Complete | Radiation Biology Module Integration Analysis | 10.7 | `radiation_biology_module_integration_analysis.md` |
| Near Complete | Radiation Biology Module Mobile Content Integration Plan | 12.3 | `mobile_content_integration_plan.md` |
| Near Complete | Radiation Detection and Measurement for Protection | 43.4 | `lesson3_radiation_detection.md` |
| Near Complete | Radiation Dosimetry Module | 12.9 | `radiation_dosimetry_module.md` |
| Near Complete | Radiation Incidents and Emergency Response | 47.9 | `lesson7_incidents_emergency_response.md` |
| Near Complete | Radiation Interaction with Matter | 10.7 | `radiation_interaction_lesson.md` |
| Near Complete | Radiation Oncology Academy - Comprehensive Project Timeline | 14.8 | `project_timeline.md` |
| Near Complete | Radiation Oncology Academy - Content Development and App Launch Strategy | 4.5 | `content_development_and_launch_strategy.md` |
| Near Complete | Radiation Oncology Academy - Content Organization Plan | 11.2 | `radiation_oncology_academy_content_plan.md` |
| Near Complete | Radiation Oncology Academy - Content Structure | 11.6 | `content_structure.md` |
| Near Complete | Radiation Oncology Academy - Email Campaign for Existing Users | 15.7 | `email_campaign_existing_users.md` |
| Near Complete | Radiation Oncology Academy - Post-Launch Strategy | 15.7 | `post_launch_strategy.md` |
| Near Complete | Radiation Oncology Academy - Press Release Templates | 15.7 | `press_release_templates.md` |
| Near Complete | Radiation Oncology Academy - Project Status Report | 12.6 | `project_status_report.md` |
| Near Complete | Radiation Oncology Academy - QA Testing Report | 5.4 | `qa_testing_report.md` |
| Near Complete | Radiation Oncology Academy - Remaining Development Tasks | 14.3 | `remaining_development_tasks.md` |
| Near Complete | Radiation Oncology Academy - Web Platform Tutorial Video Script | 9.4 | `web_platform_tutorial_video_script.md` |
| Near Complete | Radiation Oncology Academy Content Creation Priorities | 11.9 | `content_creation_priorities.md` |
| Near Complete | Radiation Oncology Academy Content Development Progress Report | 20.0 | `content_development_progress_report.md` |
| Near Complete | Radiation Oncology Academy Content Structure | 12.9 | `radiation_oncology_academy_content_structure.md` |
| Near Complete | Radiation Oncology Academy Mobile App - Progress Tracking | 2.5 | `progress_tracking.md` |
| Near Complete | Radiation Oncology Academy Mobile App Test Plan | 6.6 | `test_plan.md` |
| Near Complete | Radiation Oncology Academy Platform Components Review | 10.0 | `platform_components_review.md` |
| Near Complete | Radiation Oncology Academy Platform Deployment Progress Report | 17.8 | `deployment_progress_report.md` |
| Near Complete | Radiation Protection and Patient Safety Content | 2.5 | `abr_radiation_protection.md` |
| Near Complete | Radiation Protection and Safety Module Outline | 8.6 | `module_outline.md` |
| Near Complete | Radiation Protection and Safety Reference Materials | 58.5 | `reference_materials.md` |
| Near Complete | Radiation Protection for Special Procedures | 45.5 | `lesson9_special_procedures.md` |
| Near Complete | Radiation Protection in Brachytherapy | 46.5 | `lesson6_brachytherapy_protection.md` |
| Near Complete | Radiation Protection in External Beam Radiotherapy | 42.2 | `lesson5_external_beam_protection.md` |
| Near Complete | Radiation Safety Program Management | 51.0 | `lesson8_safety_program_management.md` |
| Near Complete | Regular Backup System Implementation for Radiation Oncology Academy | 7.7 | `backup_system_implementation.md` |
| Near Complete | Regulatory Framework and Guidelines | 33.2 | `lesson2_regulatory_framework.md` |
| Near Complete | Section 1: Fundamentals of Radiation Biology - Summary and Integration | 10.2 | `section_1_summary_and_integration.md` |
| Near Complete | Section 2 Summary: Cell Survival Kinetics | 13.0 | `section_2_summary.md` |
| Near Complete | Security Updates Schedule for Radiation Oncology Academy | 31.0 | `security_updates_schedule.md` |
| Near Complete | Shielding Design and Evaluation | 41.4 | `lesson4_shielding_design.md` |
| Near Complete | Special Topics in Radiation Protection | 63.5 | `lesson10_special_topics.md` |
| Near Complete | Subsection 1 4 Chromosomal Aberrations | 15.4 | `subsection_1_4_chromosomal_aberrations.md` |
| Near Complete | Subsection 1 5 Cell Death Mechanisms | 22.2 | `subsection_1_5_cell_death_mechanisms.md` |
| Near Complete | Subsection 2 1 Cell Survival Curves | 21.8 | `subsection_2_1_cell_survival_curves.md` |
| Near Complete | Subsection 2 2 Linear Quadratic Model | 29.9 | `subsection_2_2_linear_quadratic_model.md` |
| Near Complete | Subsection 2 3 Dose Rate Effects | 25.8 | `subsection_2_3_dose_rate_effects.md` |
| Near Complete | Subsection 2 4 Relative Biological Effectiveness | 29.6 | `subsection_2_4_relative_biological_effectiveness.md` |
| Near Complete | Subsection 2 5 Oxygen Effect Radiosensitivity | 27.3 | `subsection_2_5_oxygen_effect_radiosensitivity.md` |
| Near Complete | Subsection 2 6 Cell Tissue Radiosensitivity | 28.5 | `subsection_2_6_cell_tissue_radiosensitivity.md` |
| Near Complete | Transition to Section 3: Tumor Radiobiology | 7.1 | `section_3_transition.md` |
| Near Complete | Updated Website Architecture for Radiation Oncology Academy | 19.0 | `updated_website_architecture.md` |
| Near Complete | User Acceptance Testing Implementation for Radiation Oncology Academy | 15.7 | `user_acceptance_testing_implementation.md` |
| Near Complete | User Acceptance Testing Plan for Radiation Oncology Academy | 18.7 | `user_acceptance_testing_plan.md` |
| Near Complete | User Feedback System Implementation for Radiation Oncology Academy | 79.7 | `user_feedback_system_implementation.md` |
| Near Complete | User Onboarding Experience Update Plan | 15.7 | `user_onboarding_update_plan.md` |
| Near Complete | Website Deployment Status Analysis | 5.1 | `website_deployment_status_analysis.md` |
| Near Complete | Website and Mobile App Coordination Analysis | 13.5 | `website_mobile_coordination_analysis.md` |
| Substantial | CNS Tumors Practice Test | 15.7 | `cns_tumors_practice_test.md` |
| Substantial | Clinical Correlations and Knowledge Check Integration for Cell Survival Curves | 15.2 | `subsection_2_1_clinical_integration.md` |
| Substantial | Clinical Correlations and Knowledge Check Integration for Cell and Tissue Radiosensitivity | 31.7 | `subsection_2_6_clinical_integration.md` |
| Substantial | Clinical Correlations and Knowledge Check Integration for Dose-Rate Effects | 23.8 | `subsection_2_3_clinical_integration.md` |
| Substantial | Clinical Correlations and Knowledge Check Integration for Linear-Quadratic Model | 18.1 | `subsection_2_2_clinical_integration.md` |
| Substantial | Clinical Correlations and Knowledge Check Integration for Relative Biological Effectiveness | 26.7 | `subsection_2_4_clinical_integration.md` |
| Substantial | Nested Academy Contents | 5.1 | `nested_academy_contents.txt` |
| Substantial | Radiation Oncology Academy - Beta Tester Registration Form | 5.5 | `uat_tester_registration_form.md` |
| Substantial | Radiation Oncology Academy - Beta Testing Feedback Forms | 14.3 | `uat_feedback_forms.md` |
| Substantial | Radiation Oncology Academy - Documentation | 5.2 | `documentation.md` |
| Substantial | Radiation Oncology Academy - Final Implementation | 2.1 | `README.md` |
| Substantial | Radiation Oncology Academy - Social Media Announcement Templates | 12.5 | `social_media_announcement_templates.md` |
| Substantial | Radiation Oncology Academy - UAT Tester Recruitment Email Templates | 15.5 | `uat_tester_recruitment_email_templates.md` |
| Substantial | Radiation Oncology Academy Project Progress Tracking | 3.4 | `project_progress_tracking.md` |
| Substantial | Special Topics in Radiation Protection | 15.7 | `lesson10_special_topics_expanded.md` |
| Partial | Important Info | 1.0 | `important info.txt` |
| Partial | Nested Enhanced Website Contents | 1.2 | `nested_enhanced_website_contents.txt` |
| Partial | Pasted Content | 2.1 | `pasted_content.txt` |
| Outline/Draft | ABR Medical Physics Certification Exam Structure | 6.8 | `abr_exam_structure.md` |
| Outline/Draft | Google Play Store Promotional Video Script | 4.7 | `google_play_promotional_video_script.md` |
| Outline/Draft | Radiation Oncology Academy - Additional Recommendations Implementation | 1.8 | `todo.md` |
| Outline/Draft | Radiation Oncology Academy - Project Setup | 7.5 | `project_setup.md` |
| Outline/Draft | Radiation Oncology Academy - Website Architecture | 9.6 | `website_architecture.md` |
| Outline/Draft | Radiation Oncology Academy Website Structure | 4.5 | `website_structure.md` |
| Outline/Draft | Section 2 Development Plan Review | 4.4 | `section_2_development_plan_review.md` |
