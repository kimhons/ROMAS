# Section 3.2: Musculoskeletal System Physiology

## Learning Objectives

Upon completion of this section, the learner should be able to:

*   Describe the cellular and molecular processes involved in bone formation (osteogenesis) and remodeling, including the roles of osteoblasts, osteoclasts, and osteocytes.
*   Differentiate between the structure and function of cortical (compact) and trabecular (spongy) bone.
*   Outline the hierarchical structure of skeletal muscle, from the whole muscle down to the sarcomere, identifying key protein components (actin, myosin, troponin, tropomyosin).
*   Explain the sliding filament theory of muscle contraction, detailing the sequence of events from neuromuscular junction activation to cross-bridge cycling.
*   Describe the process of excitation-contraction coupling in skeletal muscle, linking the action potential to calcium release and muscle fiber contraction.
*   Distinguish between the three main types of muscle tissue (skeletal, smooth, cardiac) based on structure, function, and control mechanisms.
*   Classify the major types of joints (fibrous, cartilaginous, synovial) and describe their characteristic structure and range of motion.
*   Relate the physiology of the musculoskeletal system to medical physics applications, including imaging techniques (X-ray, CT, MRI, DEXA) and considerations in radiation therapy (bone marrow sparing, radiation-induced fibrosis, osteoradionecrosis).

## Introduction

The musculoskeletal system provides the structural framework, enables movement, protects internal organs, and plays vital roles in mineral homeostasis and hematopoiesis. It comprises bones, cartilage, ligaments, tendons, and muscles. Understanding the physiology of this system is crucial for medical physicists involved in various diagnostic imaging modalities that visualize musculoskeletal structures (e.g., X-ray, CT, MRI, DEXA) and in radiation therapy, where bone and muscle tissues are often included in treatment fields or represent critical dose-limiting structures. This section delves into the physiological principles governing bone formation and remodeling, muscle contraction mechanisms, and joint function, highlighting their relevance within the medical physics context, consistent with foundational knowledge expectations (CAMPEP/ABR).

## Bone Physiology

Bone is a dynamic connective tissue constantly undergoing formation and resorption.

### Bone Composition and Structure
Bone tissue consists of:
*   **Cells:** Osteoblasts (bone-forming cells), osteoclasts (bone-resorbing cells), osteocytes (mature bone cells embedded in matrix, involved in sensing mechanical stress), and osteoprogenitor cells (stem cells).
*   **Extracellular Matrix:** Composed of organic components (primarily Type I collagen, providing tensile strength) and inorganic components (hydroxyapatite crystals [Ca10(PO4)6(OH)2], providing compressive strength and hardness).

Macroscopically, bone exists in two forms:
*   **Cortical (Compact) Bone:** Dense outer layer, providing strength and protection. Organized into functional units called osteons (Haversian systems).
*   **Trabecular (Spongy or Cancellous) Bone:** Inner network of bone struts (trabeculae) separated by spaces often filled with bone marrow. Provides strength with less weight and has a higher surface area, making it metabolically more active.

`[Illustration: Diagram comparing the structure of cortical bone (showing osteons) and trabecular bone (showing trabeculae)]`

### Bone Formation (Osteogenesis)
Bone develops through two main processes:
1.  **Intramembranous Ossification:** Direct formation of bone within mesenchymal connective tissue (e.g., flat bones of the skull).
2.  **Endochondral Ossification:** Replacement of a pre-existing hyaline cartilage model with bone (e.g., long bones).

In both processes, osteoblasts secrete osteoid (unmineralized organic matrix), which subsequently mineralizes with hydroxyapatite deposition.

### Bone Remodeling
Bone is continuously remodeled throughout life via the coupled action of osteoclasts and osteoblasts. This process repairs microdamage, adapts bone structure to mechanical stress (Wolff's Law), and maintains calcium and phosphate homeostasis.
The remodeling cycle involves:
1.  **Activation:** Pre-osteoclasts are recruited to the remodeling site.
2.  **Resorption:** Mature osteoclasts dissolve bone mineral and degrade the organic matrix, creating a resorption cavity.
3.  **Reversal:** Osteoclasts undergo apoptosis or depart; mononuclear cells prepare the surface.
4.  **Formation:** Osteoblasts are recruited, secrete new osteoid to fill the cavity, and eventually become embedded as osteocytes or remain as lining cells.
5.  **Mineralization:** The newly deposited osteoid mineralizes.

This process is tightly regulated by hormones (e.g., parathyroid hormone, calcitonin, estrogen, vitamin D) and local factors (e.g., cytokines, growth factors).

*Practical Example:* Dual-energy X-ray absorptiometry (DEXA) is a key medical physics technique used to measure bone mineral density (BMD). Low BMD is indicative of osteoporosis, a condition characterized by excessive bone resorption relative to formation, leading to increased fracture risk. Understanding bone physiology helps interpret DEXA results and assess treatment efficacy.

*Practical Example:* In radiation therapy, bone (especially trabecular bone containing active bone marrow) is an important organ at risk. High radiation doses can damage hematopoietic stem cells in the marrow, leading to myelosuppression. Techniques like intensity-modulated radiation therapy (IMRT) aim to spare bone marrow, particularly in pelvic irradiations. High doses can also impair bone remodeling, potentially leading to osteoradionecrosis (bone death) years after treatment.

## Muscle Physiology

Muscle tissue is specialized for contraction, enabling movement, maintaining posture, and generating heat.

### Types of Muscle Tissue
1.  **Skeletal Muscle:** Attached to bones; responsible for voluntary movements. Cells are long, cylindrical, multinucleated, and striated (striped appearance due to sarcomere organization).
2.  **Smooth Muscle:** Found in the walls of internal organs and blood vessels; responsible for involuntary movements (e.g., peristalsis, vasoconstriction). Cells are spindle-shaped, uninucleated, and non-striated.
3.  **Cardiac Muscle:** Found only in the heart wall; responsible for pumping blood. Cells are branched, typically uninucleated, striated, and interconnected by intercalated discs containing gap junctions for rapid signal propagation.

This section focuses primarily on skeletal muscle physiology.

### Skeletal Muscle Structure
Skeletal muscle exhibits a hierarchical organization:
*   **Whole Muscle:** An organ composed of muscle tissue, connective tissue, nerves, and blood vessels.
*   **Fascicle:** A bundle of muscle fibers wrapped in connective tissue (perimysium).
*   **Muscle Fiber (Cell):** An elongated, multinucleated cell containing numerous myofibrils, wrapped in endomysium.
*   **Myofibril:** A cylindrical structure extending the length of the muscle fiber, composed of repeating contractile units.
*   **Sarcomere:** The fundamental contractile unit of a myofibril, extending between two Z-discs. Contains overlapping thick and thin myofilaments.
    *   **Thick Filaments:** Primarily composed of the protein myosin.
    *   **Thin Filaments:** Primarily composed of the protein actin, along with regulatory proteins troponin and tropomyosin.

`[Illustration: Diagram showing the hierarchical structure of skeletal muscle, from whole muscle down to fascicle, fiber, myofibril, and sarcomere, including connective tissue layers (epimysium, perimysium, endomysium)]`

The arrangement of thick and thin filaments creates the characteristic striated pattern (A-bands, I-bands, H-zone, M-line, Z-discs).

`[Illustration: Detailed diagram of a sarcomere, labeling Z-disc, thin (actin) filaments, thick (myosin) filaments, A-band, I-band, H-zone, and M-line]`

### Sliding Filament Theory of Contraction
Muscle contraction occurs when thin filaments slide past thick filaments, shortening the sarcomere without the filaments themselves changing length. This is driven by the interaction between myosin heads (on thick filaments) and actin (on thin filaments).
The cycle involves:
1.  **Cross-Bridge Formation:** Energized myosin head (with ADP and Pi bound) attaches to an actin binding site.
2.  **Power Stroke:** Release of ADP and Pi causes the myosin head to pivot, pulling the thin filament towards the center of the sarcomere.
3.  **Cross-Bridge Detachment:** Binding of a new ATP molecule to the myosin head causes it to detach from actin.
4.  **Reactivation of Myosin Head:** ATP is hydrolyzed to ADP and Pi, re-energizing the myosin head and returning it to the cocked position, ready for another cycle.

`[Illustration: Diagram illustrating the steps of the cross-bridge cycle (sliding filament mechanism), showing myosin head attachment, power stroke, detachment, and reactivation]`

This cycle continues as long as Ca2+ ions and ATP are available.

### Excitation-Contraction Coupling
This process links the electrical excitation of the muscle fiber membrane (sarcolemma) to the mechanical contraction.
1.  **Neuromuscular Junction (NMJ) Activation:** An action potential arrives at the motor neuron terminal, releasing acetylcholine (ACh).
2.  **End-Plate Potential:** ACh binds to receptors on the muscle fiber's motor end plate, opening ligand-gated ion channels and causing a depolarization (end-plate potential).
3.  **Muscle Fiber Action Potential:** If the end-plate potential reaches threshold, it triggers an action potential that propagates along the sarcolemma and down transverse tubules (T-tubules).
4.  **Calcium Release:** The action potential traveling down T-tubules triggers the release of Ca2+ ions from the sarcoplasmic reticulum (SR) into the sarcoplasm.
5.  **Contraction Initiation:** Ca2+ binds to troponin on the thin filaments. This causes tropomyosin to shift, exposing the myosin-binding sites on actin.
6.  **Cross-Bridge Cycling:** Myosin heads bind to actin, initiating the sliding filament mechanism and muscle contraction.
7.  **Relaxation:** When neural stimulation ceases, ACh is broken down, the muscle fiber repolarizes, Ca2+ is actively pumped back into the SR, tropomyosin covers the actin binding sites, and the muscle fiber relaxes.

`[Illustration: Diagram showing the components and steps of excitation-contraction coupling, including the neuromuscular junction, T-tubule, sarcoplasmic reticulum, Ca2+ release, and interaction with troponin/tropomyosin]`

*Practical Example:* Magnetic Resonance Imaging (MRI) is widely used to visualize soft tissues, including muscles. It can detect muscle tears, inflammation, atrophy, fatty infiltration, and tumors. Understanding muscle structure and physiology aids in interpreting MR images of muscle pathology.

*Practical Example:* Radiation therapy can cause muscle damage, including inflammation (myositis) in the acute phase and fibrosis (scarring and stiffness) as a late effect. Dose constraints to muscle groups may be considered in specific situations, although muscle is generally more radioresistant than tissues like nerve or bone marrow.

## Joint Physiology

Joints (articulations) are sites where two or more bones meet, allowing varying degrees of movement.

### Joint Classification
Joints are classified structurally and functionally:
*   **Structural Classification (based on connecting material):**
    *   **Fibrous Joints:** Bones connected by dense fibrous connective tissue; typically immovable or slightly movable (e.g., sutures of the skull, syndesmosis between tibia and fibula).
    *   **Cartilaginous Joints:** Bones connected by cartilage; typically slightly movable (e.g., pubic symphysis, intervertebral discs).
    *   **Synovial Joints:** Bones separated by a fluid-filled joint cavity, enclosed by a capsule, and lined with synovial membrane; freely movable. Most common type of joint.
*   **Functional Classification (based on degree of movement):**
    *   **Synarthrosis:** Immovable joint.
    *   **Amphiarthrosis:** Slightly movable joint.
    *   **Diarthrosis:** Freely movable joint (all synovial joints).

`[Illustration: Examples of fibrous (suture), cartilaginous (symphysis), and synovial (e.g., knee or hip) joints]`

### Synovial Joint Structure
Key features include:
*   **Articular Cartilage:** Hyaline cartilage covering the ends of articulating bones, reducing friction and absorbing shock.
*   **Joint (Articular) Cavity:** Space containing synovial fluid.
*   **Articular Capsule:** Two-layered capsule enclosing the cavity (outer fibrous layer, inner synovial membrane).
*   **Synovial Fluid:** Viscous fluid secreted by the synovial membrane; lubricates the joint, nourishes cartilage, and absorbs shock.
*   **Reinforcing Ligaments:** Connect bone to bone, stabilizing the joint.
*   **Nerves and Blood Vessels:** Supply the joint capsule.

Some synovial joints also have accessory structures like menisci (fibrocartilage pads, e.g., in the knee) or bursae (fluid-filled sacs reducing friction).

*Practical Example:* Radiographic imaging (X-ray, CT) is commonly used to evaluate joint integrity, detect fractures involving the joint, assess joint space narrowing (indicative of cartilage loss in osteoarthritis), and identify dislocations.

> ## **Key Points**
> 
> *   **Bone is a dynamic tissue** composed of cells and a mineralized organic matrix, existing as cortical and trabecular types.
> *   **Bone remodeling** involves coupled resorption by osteoclasts and formation by osteoblasts, regulated by hormones and mechanical stress.
> *   **Skeletal muscle contraction** occurs via the sliding filament mechanism, where myosin heads pull actin filaments, powered by ATP and regulated by Ca2+.
> *   **Excitation-contraction coupling** links nerve impulses to Ca2+ release from the sarcoplasmic reticulum, initiating contraction.
> *   **Joints** are classified by structure (fibrous, cartilaginous, synovial) and function (synarthrosis, amphiarthrosis, diarthrosis).
> *   **Synovial joints** allow free movement and possess a joint cavity filled with lubricating synovial fluid.
> *   **Medical physics techniques** (DEXA, X-ray, CT, MRI) are essential for assessing musculoskeletal health, while **radiation therapy planning** must consider dose limits to bone, marrow, and potentially muscle.

## Assessment Questions

1.  **Which cell type is primarily responsible for bone resorption?**
    (A) Osteoblast
    (B) Osteocyte
    (C) Osteoclast
    (D) Osteoprogenitor cell

2.  **According to the sliding filament theory, what happens to the length of the A-band within a sarcomere during muscle contraction?**
    (A) It increases
    (B) It decreases
    (C) It remains unchanged
    (D) It disappears

3.  **The release of calcium ions from which organelle triggers skeletal muscle contraction?**
    (A) Golgi apparatus
    (B) Mitochondria
    (C) Sarcoplasmic reticulum
    (D) Nucleus

4.  **Describe the key structural differences between a fibrous joint and a synovial joint.**

5.  **Explain Wolff's Law and its relevance to bone remodeling.**

### Solutions

1.  **(C) Osteoclast.** Osteoclasts are large, multinucleated cells responsible for breaking down bone matrix.
2.  **(C) It remains unchanged.** The A-band corresponds to the length of the thick (myosin) filaments, which do not change length during contraction. The I-band and H-zone shorten.
3.  **(C) Sarcoplasmic reticulum.** Action potentials traveling down T-tubules trigger Ca2+ release from the SR, the specialized endoplasmic reticulum of muscle cells.
4.  **Answer:** Fibrous joints connect bones with dense fibrous connective tissue, lack a joint cavity, and are typically immovable or slightly movable. Synovial joints feature a fluid-filled joint cavity enclosed by an articular capsule, have articular cartilage covering bone ends, and are freely movable.
5.  **Answer:** Wolff's Law states that bone adapts to the mechanical stresses placed upon it. Increased stress leads to bone formation and increased density/strength in stressed areas, while decreased stress leads to bone resorption. This is a key principle governing bone remodeling, ensuring the skeleton is optimized for its mechanical environment.

## Conclusion

The musculoskeletal system's physiology, encompassing the dynamic nature of bone, the intricate mechanism of muscle contraction, and the structural diversity of joints, is fundamental to human structure and function. For medical physicists, this knowledge is critical for the effective application and interpretation of imaging modalities used to visualize these tissues and for understanding the potential effects and necessary precautions associated with radiation therapy involving bone and muscle. Integrating this physiological understanding enhances the physicist's ability to contribute meaningfully to patient care in both diagnostic and therapeutic settings.

## References

*   Hall, J. E., & Hall, M. E. (2020). *Guyton and Hall Textbook of Medical Physiology* (14th ed.). Elsevier.
*   Saladin, K. S. (2018). *Anatomy & Physiology: The Unity of Form and Function* (8th ed.). McGraw-Hill Education.
*   Relevant CAMPEP Graduate Program Standards for Medical Physics.

