# Radiation Oncology Academy - Web Platform Tutorial Video Script

## Introduction

**[SCENE: Opening with Radiation Oncology Academy logo animation]**

**NARRATOR:** Welcome to the Radiation Oncology Academy web platform tutorial. In this video, we'll guide you through the key features of our comprehensive educational platform designed specifically for radiation oncology professionals.

**[SCENE: Overview of dashboard with callouts to main sections]**

**NARRATOR:** The Radiation Oncology Academy brings together expert-created content, personalized learning paths, and seamless cross-platform integration to enhance your professional development.

## Dashboard Navigation

**[SCENE: Cursor moving through dashboard, highlighting key elements]**

**NARRATOR:** After logging in, you'll arrive at your personalized dashboard. Here you'll find:

**[SCENE: Highlight each section as mentioned]**

1. Your recommended content based on your specialty and interests
2. Recently viewed items so you can quickly resume your learning
3. Your progress tracking across all courses and modules
4. Upcoming live events and new content alerts
5. Quick access to your bookmarked resources

**NARRATOR:** The main navigation menu on the left provides access to all platform sections. Let's explore each one.

## Content Library

**[SCENE: Navigate to Content Library, showing category structure]**

**NARRATOR:** The Content Library is organized into major categories covering all aspects of radiation oncology.

**[SCENE: Demonstrate filtering and search]**

**NARRATOR:** You can filter content by type, difficulty level, or topic. The advanced search function allows you to find exactly what you need using keywords, author names, or specific clinical terms.

**[SCENE: Open an article to demonstrate content viewing]**

**NARRATOR:** When viewing content, you'll notice several helpful features:

**[SCENE: Highlight each feature]**

1. The progress tracker shows how far you've advanced
2. The note-taking tool lets you add personal annotations
3. The bookmark button saves content to your favorites
4. The download button makes content available offline
5. The share button allows you to recommend content to colleagues

**NARRATOR:** All of these actions synchronize automatically with the mobile app, so you can continue your learning on any device.

## Learning Paths

**[SCENE: Navigate to Learning Paths section]**

**NARRATOR:** Learning Paths provide structured educational journeys through related content. These paths are designed by leading experts to build comprehensive knowledge in specific areas.

**[SCENE: Show a learning path structure with modules]**

**NARRATOR:** Each path includes multiple modules with articles, videos, assessments, and interactive elements. Your progress is tracked automatically, and you'll earn certificates upon completion.

**[SCENE: Demonstrate the AI recommendation feature]**

**NARRATOR:** Our AI-powered system will suggest personalized learning paths based on your interests, specialty, and learning history. These recommendations become more tailored as you use the platform.

## Podcast Section

**[SCENE: Navigate to Podcast section]**

**NARRATOR:** Our podcast library features discussions with leading experts on current topics in radiation oncology.

**[SCENE: Demonstrate podcast player features]**

**NARRATOR:** The podcast player includes:
- Variable playback speed
- Bookmarking specific timestamps
- Downloadable transcripts
- Episode notes with references
- Offline listening capabilities

**NARRATOR:** New episodes are released bi-weekly, with notifications when topics matching your interests become available.

## News Section

**[SCENE: Navigate to News section]**

**NARRATOR:** Stay current with the latest developments in radiation oncology through our curated news section.

**[SCENE: Show news filtering and saving]**

**NARRATOR:** Articles are categorized by topic and can be filtered by relevance, date, or source. Save important articles to your personal library or download them for offline reading.

**[SCENE: Demonstrate the "Research Implications" feature]**

**NARRATOR:** Each research summary includes a practical "Clinical Implications" section, helping you understand how new findings might impact your practice.

## Interactive Tools

**[SCENE: Navigate to Interactive Tools section]**

**NARRATOR:** Our interactive tools enhance your learning experience through practical application.

**[SCENE: Demonstrate case study interactive]**

**NARRATOR:** Case studies allow you to work through clinical scenarios, make decisions, and receive expert feedback on your approach.

**[SCENE: Show treatment planning simulation]**

**NARRATOR:** Treatment planning simulations let you practice contouring and plan evaluation in a risk-free environment.

**[SCENE: Demonstrate self-assessment quiz]**

**NARRATOR:** Self-assessment quizzes help identify knowledge gaps and track your progress over time. Results are private and used to refine your personalized recommendations.

## Community Features

**[SCENE: Navigate to Community section]**

**NARRATOR:** Connect with fellow radiation oncology professionals through our community features.

**[SCENE: Show discussion forum]**

**NARRATOR:** Participate in moderated discussions on clinical topics, research developments, and professional challenges.

**[SCENE: Demonstrate virtual tumor board]**

**NARRATOR:** Join monthly virtual tumor boards where challenging cases are presented and discussed by a multidisciplinary panel of experts.

**[SCENE: Show upcoming events calendar]**

**NARRATOR:** The events calendar keeps you informed about upcoming webinars, live Q&A sessions, and other educational opportunities.

## Profile and Settings

**[SCENE: Navigate to Profile section]**

**NARRATOR:** Your profile helps personalize your experience and tracks your educational achievements.

**[SCENE: Show profile customization]**

**NARRATOR:** Customize your profile with your specialty, interests, and learning goals to receive more relevant recommendations.

**[SCENE: Demonstrate certificate management]**

**NARRATOR:** All your earned certificates and CME credits are stored in your profile for easy access and reporting.

**[SCENE: Show notification settings]**

**NARRATOR:** Manage your notification preferences to stay informed about new content, events, and updates relevant to your interests.

## Cross-Platform Synchronization

**[SCENE: Split screen showing web and mobile app simultaneously]**

**NARRATOR:** One of the most powerful features of Radiation Oncology Academy is seamless cross-platform synchronization.

**[SCENE: Demonstrate making a note on web platform]**

**NARRATOR:** Notes, bookmarks, progress, and preferences automatically sync between the web platform and mobile app.

**[SCENE: Show the same note appearing on mobile device]**

**NARRATOR:** Start learning on your desktop at work, continue on your tablet at home, and review on your phone during your commute - picking up exactly where you left off every time.

## Offline Access

**[SCENE: Demonstrate downloading content for offline access]**

**NARRATOR:** Download any content for offline access by clicking the download button. Downloaded content is available in the "Offline Library" section, even without an internet connection.

**[SCENE: Show offline library]**

**NARRATOR:** Your progress and notes are saved locally while offline and will automatically synchronize when you reconnect.

## Help and Support

**[SCENE: Navigate to Help section]**

**NARRATOR:** If you need assistance, our comprehensive help center provides:

**[SCENE: Show each support option]**

1. Searchable FAQ database
2. Video tutorials for all features
3. Live chat support during business hours
4. Email support for technical issues
5. Feedback forms for feature suggestions

## Conclusion

**[SCENE: Return to dashboard with visual summary of key features]**

**NARRATOR:** The Radiation Oncology Academy web platform provides a comprehensive, personalized learning experience designed specifically for radiation oncology professionals.

**[SCENE: Show web and mobile devices side by side]**

**NARRATOR:** Remember to download our mobile app to access all these features on the go, with perfect synchronization across all your devices.

**[SCENE: Call to action with "Start Learning Today" button]**

**NARRATOR:** Thank you for choosing Radiation Oncology Academy. If you have any questions, our support team is always here to help.

**[SCENE: Closing with Radiation Oncology Academy logo and contact information]**

---

# Production Notes

## Visual Style
- Clean, professional interface with blue and white color scheme
- Smooth transitions between sections
- Highlighted cursor movements to draw attention to features
- Split-screen demonstrations for cross-platform features
- Callout boxes for important information

## Audio Requirements
- Professional narrator with clear medical terminology pronunciation
- Background music: subtle, professional, non-distracting
- Sound effects for clicks and transitions should be minimal

## Technical Specifications
- Resolution: 1080p minimum
- Duration: 8-10 minutes
- Format: MP4 with H.264 encoding
- Captions: Include closed captions in English
- Intro and outro: 5 seconds each with logo animation

## Additional Requirements
- Include text overlays for key terms and features
- Highlight cursor movements and clicks
- Use zoom effects for small details
- Include progress bar at bottom of screen
- Add chapter markers for easy navigation
