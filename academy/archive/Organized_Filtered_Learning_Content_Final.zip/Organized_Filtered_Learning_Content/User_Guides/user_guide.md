# Radiation Oncology Academy - User Guide

Welcome to Radiation Oncology Academy, your comprehensive educational platform for radiation oncology and medical physics professionals. This guide will help you navigate the platform and make the most of its features.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Membership Tiers](#membership-tiers)
3. [Educational Content](#educational-content)
4. [Courses and Learning Modules](#courses-and-learning-modules)
5. [Quizzes and Assessments](#quizzes-and-assessments)
6. [Blog and Resources](#blog-and-resources)
7. [Podcast](#podcast)
8. [Account Management](#account-management)
9. [Support and Help](#support-and-help)

## Getting Started

### Registration

1. Visit [radiationoncologyacademy.com](https://radiationoncologyacademy.com)
2. Click on "Register" in the top navigation bar
3. Fill in your details (name, email, password)
4. Verify your email address by clicking the link sent to your inbox
5. Complete your profile with professional information

### Logging In

1. Visit [radiationoncologyacademy.com](https://radiationoncologyacademy.com)
2. Click on "Login" in the top navigation bar
3. Enter your email and password
4. Click "Login"

### Dashboard

After logging in, you'll be directed to your personalized dashboard, which includes:

- Your progress on current courses
- Recommended content based on your interests
- Recent blog posts and podcast episodes
- Quick access to your membership details
- Notifications and announcements

## Membership Tiers

Radiation Oncology Academy offers four membership tiers to suit different needs:

### Basic Tier ($9.99/month or $99.99/year)

- Access to basic educational content
- Limited quiz attempts
- Community forum access
- Monthly newsletter

### Standard Tier ($19.99/month or $199.99/year)

- All Basic features
- Full access to educational content
- Unlimited quiz attempts
- Access to podcast episodes
- Monthly webinars

### Premium Tier ($39.99/month or $399.99/year)

- All Standard features
- Access to advanced modules
- Personalized learning path
- Priority support
- Certificate of completion
- Access to archived webinars

### Enterprise Tier ($99.99/month or $999.99/year)

- All Premium features
- Multi-user accounts (up to 5)
- Custom learning paths
- Dedicated account manager
- Private consultation sessions
- Custom reporting

### Upgrading Your Membership

1. Go to "Membership" in the main navigation
2. Review the available tiers
3. Click "Upgrade" on your desired tier
4. Complete the payment process
5. Your account will be immediately upgraded

## Educational Content

### Content Categories

- **Board Preparation**: Materials specifically designed for ABR certification exams
- **Clinical Practice**: Practical applications and case studies
- **Research**: Latest developments and research methodologies
- **Professional Development**: Career advancement and soft skills
- **Technology**: Equipment, software, and technological innovations
- **Treatment Modalities**: Various treatment approaches and techniques
- **Quality Assurance**: Protocols and best practices for QA

### Learning Paths

Learning paths are curated sequences of courses designed to help you master specific areas:

1. **ABR Certification Path**: Structured preparation for board exams
2. **Clinical Medical Physics Path**: Practical skills for clinical practice
3. **Research and Innovation Path**: Advanced topics for research-focused professionals
4. **Leadership and Management Path**: Skills for those in or aspiring to leadership roles

To select a learning path:
1. Go to "Learning Paths" in the main navigation
2. Browse available paths
3. Click "Enroll" on your chosen path
4. Track your progress through the dashboard

## Courses and Learning Modules

### Browsing Courses

1. Go to "Courses" in the main navigation
2. Use filters to narrow down by category, difficulty level, or topic
3. Click on a course to view details
4. Click "Enroll" to add the course to your learning queue

### Course Structure

Each course consists of:
- Introduction and learning objectives
- Multiple learning modules
- Supplementary resources
- Quizzes and assessments
- Discussion forum

### Tracking Progress

Your progress is automatically tracked as you complete modules and quizzes. You can:
- Resume where you left off from your dashboard
- See completion percentages for each course
- Earn certificates for completed courses (Premium and Enterprise tiers)

## Quizzes and Assessments

### Types of Assessments

- **Module Quizzes**: Short assessments at the end of each module
- **Course Exams**: Comprehensive tests covering entire courses
- **Practice Tests**: Simulated board-style questions
- **Self-Assessment Tools**: Identify knowledge gaps and strengths

### Taking Quizzes

1. Navigate to the quiz within a module or course
2. Read instructions carefully, noting time limits if applicable
3. Answer all questions
4. Submit your answers
5. Review your results and explanations

### Review and Improvement

- Review incorrect answers with detailed explanations
- Access related content to strengthen weak areas
- Retake quizzes to reinforce learning (unlimited for Standard tier and above)

## Blog and Resources

### Blog Content

The blog features articles on:
- AAPM TG Reports analysis
- ASTRO guidelines updates
- Clinical case discussions
- Research highlights
- Professional development topics

### Accessing Resources

1. Go to "Blog" in the main navigation
2. Browse articles by category or use the search function
3. Save articles to your personal library for later reference
4. Comment and engage with the community

## Podcast

### Podcast Series

- **Clinical Practice Series**: Discussions on clinical applications
- **Technology Frontiers**: Exploring new technologies
- **Career Development**: Professional growth strategies
- **Research Spotlight**: Highlighting important research

### Listening to Episodes

1. Go to "Podcast" in the main navigation
2. Browse episodes by series or topic
3. Click on an episode to listen directly on the platform
4. Download episodes for offline listening (Premium and Enterprise tiers)

## Account Management

### Profile Settings

1. Click on your profile icon in the top right corner
2. Select "Profile Settings"
3. Update your personal information, professional details, and profile picture
4. Set notification preferences

### Membership Management

1. Go to "Membership" in your profile menu
2. View your current plan details
3. Update payment information
4. View billing history
5. Manage subscription settings

### Privacy Settings

1. Go to "Privacy" in your profile settings
2. Control what information is visible to other members
3. Manage data sharing preferences
4. Download your data or request deletion

## Support and Help

### Getting Help

- **FAQ Section**: Common questions and answers
- **Knowledge Base**: Detailed guides and tutorials
- **Contact Support**: Direct assistance from our team
- **Community Forum**: Peer support and discussions

### Contacting Support

1. Click "Support" in the footer
2. Select your issue category
3. Describe your problem in detail
4. Submit your request
5. You'll receive a response within 24 hours

### Feedback and Suggestions

We value your input! To provide feedback:
1. Click "Feedback" in the footer
2. Share your thoughts, suggestions, or report issues
3. Rate your experience

## Conclusion

Thank you for choosing Radiation Oncology Academy. We're committed to providing high-quality educational resources to help you excel in your career. If you have any questions or need assistance, don't hesitate to contact our support team.

Happy learning!
