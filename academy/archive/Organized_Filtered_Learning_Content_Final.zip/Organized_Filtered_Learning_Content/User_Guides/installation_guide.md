# Radiation Oncology Academy - GoDaddy Installation Guide

This comprehensive guide will walk you through the process of deploying the Radiation Oncology Academy website to GoDaddy hosting. The installation is designed to be straightforward, even for those without extensive web development experience.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Domain and Hosting Setup](#domain-and-hosting-setup)
3. [Database Setup](#database-setup)
4. [Backend Deployment](#backend-deployment)
5. [Frontend Deployment](#frontend-deployment)
6. [Environment Configuration](#environment-configuration)
7. [Payment Processing Setup](#payment-processing-setup)
8. [API Integration Setup](#api-integration-setup)
9. [Testing the Deployment](#testing-the-deployment)
10. [Troubleshooting](#troubleshooting)

## Prerequisites

Before beginning the installation process, ensure you have the following:

- GoDaddy account with access to radiationoncologyacademy.com
- GoDaddy hosting plan (Linux-based with Node.js support)
- MongoDB Atlas account (for database hosting)
- Stripe account for payment processing
- OpenAI API key for blog content generation
- ElevenLabs API key for podcast generation
- Google Cloud account for Speech-to-Text API

## Domain and Hosting Setup

1. **Log in to your GoDaddy account**
   - Go to [GoDaddy.com](https://www.godaddy.com/) and sign in

2. **Verify domain ownership**
   - Ensure radiationoncologyacademy.com is properly configured in your account
   - Verify that DNS settings are pointing to your GoDaddy hosting

3. **Set up hosting**
   - Navigate to "My Products" > "Web Hosting"
   - Select your hosting plan for radiationoncologyacademy.com
   - Click "Manage" to access the hosting control panel

4. **Enable Node.js support**
   - In the hosting control panel, go to "Settings" > "Web Options"
   - Ensure Node.js is enabled (version 16.x or higher)
   - Save changes

## Database Setup

1. **Create MongoDB Atlas account**
   - Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and sign up or log in
   - Create a new project named "RadiationOncologyAcademy"

2. **Set up a new cluster**
   - Click "Build a Cluster" and select the free tier option
   - Choose a cloud provider and region closest to your target audience
   - Click "Create Cluster" (this may take a few minutes)

3. **Configure database access**
   - In the left sidebar, go to "Database Access"
   - Click "Add New Database User"
   - Create a username and secure password (save these for later)
   - Set privileges to "Read and Write to Any Database"
   - Click "Add User"

4. **Configure network access**
   - In the left sidebar, go to "Network Access"
   - Click "Add IP Address"
   - For development, you can select "Allow Access from Anywhere" (0.0.0.0/0)
   - For production, add the specific IP address of your GoDaddy hosting
   - Click "Confirm"

5. **Get your connection string**
   - Once your cluster is created, click "Connect"
   - Select "Connect your application"
   - Copy the connection string (it will look like: `mongodb+srv://username:<password>@cluster0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`)
   - Replace `<password>` with your database user's password
   - Replace `myFirstDatabase` with `radiation-oncology-academy`
   - Save this connection string for later use

## Backend Deployment

1. **Access GoDaddy cPanel**
   - From your GoDaddy hosting dashboard, click "cPanel Admin"
   - Log in with your credentials

2. **Set up Node.js application**
   - In cPanel, find and click on "Setup Node.js App"
   - Click "Create Application"
   - Fill in the following details:
     - Node.js version: Select the latest available version (14.x or higher)
     - Application mode: Production
     - Application root: /backend
     - Application URL: api.radiationoncologyacademy.com
     - Application startup file: server.js
   - Click "Create"

3. **Upload backend files**
   - In cPanel, go to "File Manager"
   - Navigate to the root directory
   - Create a new folder named "backend"
   - Upload all backend files to this folder
   - Ensure the directory structure matches the project structure

4. **Install dependencies**
   - In cPanel, go back to "Setup Node.js App"
   - Select your application
   - Click on "Run NPM Install" to install all dependencies

## Frontend Deployment

1. **Build the frontend application**
   - On your local machine, navigate to the frontend directory
   - Run `npm run build` to create a production build
   - This will generate a `build` or `out` directory with static files

2. **Upload frontend files**
   - In cPanel, go to "File Manager"
   - Navigate to the public_html directory
   - Upload all files from the frontend build directory to this location

3. **Configure frontend routing**
   - Create a new file named `.htaccess` in the public_html directory
   - Add the following content:

```
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>
```

## Environment Configuration

1. **Create environment variables for backend**
   - In cPanel, go back to "Setup Node.js App"
   - Select your application
   - Click on "Environment Variables"
   - Add the following variables:
     - `PORT`: 3000
     - `MONGODB_URI`: Your MongoDB Atlas connection string
     - `JWT_SECRET`: A secure random string for JWT token generation
     - `JWT_EXPIRE`: 30d
     - `NODE_ENV`: production
     - `STRIPE_SECRET_KEY`: Your Stripe secret key
     - `STRIPE_WEBHOOK_SECRET`: Your Stripe webhook secret
     - `PAYPAL_CLIENT_ID`: Your PayPal client ID
     - `PAYPAL_CLIENT_SECRET`: Your PayPal client secret
     - `OPENAI_API_KEY`: Your OpenAI API key
     - `ELEVENLABS_API_KEY`: Your ElevenLabs API key
     - `GOOGLE_STT_API_KEY`: Your Google Speech-to-Text API key
   - Click "Save"

2. **Update API endpoint in frontend**
   - In the frontend build, locate the configuration file (usually in a config.js or similar)
   - Update the API endpoint to point to your backend URL (api.radiationoncologyacademy.com)

## Payment Processing Setup

1. **Configure Stripe**
   - Log in to your [Stripe Dashboard](https://dashboard.stripe.com/)
   - Go to "Developers" > "API keys"
   - Copy your publishable key and update it in the frontend code
   - Your secret key should already be added to the backend environment variables

2. **Set up Stripe webhooks**
   - In Stripe Dashboard, go to "Developers" > "Webhooks"
   - Click "Add endpoint"
   - Enter your webhook URL: https://api.radiationoncologyacademy.com/api/payment/webhook
   - Select events to listen for:
     - payment_intent.succeeded
     - payment_intent.payment_failed
     - customer.subscription.created
     - customer.subscription.updated
     - customer.subscription.deleted
   - Click "Add endpoint"
   - Copy the signing secret and add it to your backend environment variables as STRIPE_WEBHOOK_SECRET

3. **Configure PayPal (optional)**
   - Log in to your [PayPal Developer Dashboard](https://developer.paypal.com/developer/applications)
   - Create a new app to get your client ID and secret
   - Add these to your backend environment variables

## API Integration Setup

1. **OpenAI API**
   - Ensure your OpenAI API key is added to the backend environment variables
   - Test the integration by creating a blog post through the admin interface

2. **ElevenLabs API**
   - Ensure your ElevenLabs API key is added to the backend environment variables
   - Test the integration by creating a podcast through the admin interface

3. **Google Speech-to-Text API**
   - Ensure your Google API key is added to the backend environment variables
   - Test the integration by generating a transcript for a podcast episode

## Testing the Deployment

1. **Test frontend**
   - Visit your domain (radiationoncologyacademy.com)
   - Verify that all pages load correctly
   - Check that responsive design works on different devices

2. **Test backend API**
   - Use a tool like Postman to test API endpoints
   - Verify that authentication works
   - Test CRUD operations for courses, blog posts, etc.

3. **Test membership system**
   - Create a test account
   - Subscribe to a membership plan using Stripe's test card numbers
   - Verify that access control works based on membership tier

4. **Test content generation**
   - Log in as an admin
   - Generate a blog post using OpenAI
   - Create a podcast using ElevenLabs
   - Verify that the content is created correctly

## Troubleshooting

### Common Issues and Solutions

1. **Backend not starting**
   - Check Node.js version compatibility
   - Verify that all dependencies are installed
   - Check environment variables
   - Review server logs for errors

2. **Database connection issues**
   - Verify MongoDB Atlas connection string
   - Check network access settings in MongoDB Atlas
   - Ensure database user has correct permissions

3. **Frontend routing issues**
   - Verify .htaccess configuration
   - Check that all static assets are properly loaded
   - Clear browser cache and try again

4. **Payment processing issues**
   - Verify Stripe API keys
   - Check webhook configuration
   - Use Stripe's test mode for testing

5. **API integration issues**
   - Verify API keys for OpenAI, ElevenLabs, and Google
   - Check API request format and parameters
   - Review server logs for specific error messages

### Getting Help

If you encounter issues not covered in this guide, you can:

1. Check the project documentation for additional information
2. Contact GoDaddy support for hosting-related issues
3. Reach out to the developer for application-specific problems

## Conclusion

Congratulations! You have successfully deployed the Radiation Oncology Academy website to GoDaddy hosting. The site is now ready to provide valuable educational resources to medical physics professionals.

Remember to regularly back up your database and files to prevent data loss. Also, keep all software and dependencies updated to ensure security and performance.
