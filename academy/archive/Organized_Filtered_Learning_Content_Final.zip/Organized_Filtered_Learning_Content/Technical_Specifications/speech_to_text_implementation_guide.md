# Google Cloud Speech-to-Text Implementation Guide for Radiation Oncology Academy

This guide provides step-by-step instructions for implementing Google Cloud Speech-to-Text for the Radiation Oncology Academy platform. It's designed specifically for non-technical users to follow easily.

## Table of Contents

1. [Setting Up Google Cloud Speech-to-Text](#setting-up-google-cloud-speech-to-text)
2. [Creating a Speech-to-Text Service Account](#creating-a-speech-to-text-service-account)
3. [Implementing Podcast Transcription](#implementing-podcast-transcription)
4. [Implementing Lecture Transcription](#implementing-lecture-transcription)
5. [Adding Captions to Educational Videos](#adding-captions-to-educational-videos)
6. [Testing and Troubleshooting](#testing-and-troubleshooting)
7. [Best Practices and Maintenance](#best-practices-and-maintenance)

## Setting Up Google Cloud Speech-to-Text

### Step 1: Enable the Speech-to-Text API

1. Log in to your Google Cloud Console at [console.cloud.google.com](https://console.cloud.google.com/)
2. Select your "Radiation Oncology Academy" project
3. In the left sidebar, navigate to "APIs & Services" > "Library"
4. Search for "Speech-to-Text"
5. Click on "Cloud Speech-to-Text API"
6. Click "Enable"

### Step 2: Configure API Settings

1. After enabling the API, go to "APIs & Services" > "Credentials"
2. Click on the "Configure Consent Screen" button if prompted
3. Select "External" and click "Create"
4. Fill in the required information:
   - App name: "Radiation Oncology Academy"
   - User support email: Your email address
   - Developer contact information: Your email address
5. Click "Save and Continue"
6. Skip the "Scopes" section by clicking "Save and Continue"
7. Skip the "Test users" section by clicking "Save and Continue"
8. Review your settings and click "Back to Dashboard"

## Creating a Speech-to-Text Service Account

### Step 1: Create a Service Account

1. In the Google Cloud Console, go to "IAM & Admin" > "Service Accounts"
2. Click "Create Service Account"
3. Name it "roa-speech-to-text"
4. Add a description: "Service account for Speech-to-Text transcription"
5. Click "Create and Continue"

### Step 2: Assign Permissions

1. Click "Select a role"
2. Search for "Speech-to-Text"
3. Select "Cloud Speech-to-Text User"
4. Click "Add Another Role"
5. Search for "Storage"
6. Select "Storage Object Viewer" (to access audio files)
7. Click "Continue"

### Step 3: Create and Download a Key

1. Click "Create Key"
2. Select "JSON" as the key type
3. Click "Create"
4. The key file will download automatically to your computer
5. Rename this file to `speech-to-text-key.json`

### Step 4: Add the Key to Your Website

1. Upload the `speech-to-text-key.json` file to your website's backend server in the `/home/ubuntu/radiation_oncology_academy/backend/config/` directory
2. Make sure this file is not publicly accessible

### Step 5: Update Environment Variables

Add these lines to your `.env` file in the backend directory:

```
GOOGLE_APPLICATION_CREDENTIALS=./config/speech-to-text-key.json
GOOGLE_CLOUD_PROJECT_ID=your-project-id
```

Replace `your-project-id` with your actual Google Cloud project ID.

## Implementing Podcast Transcription

### Step 1: Set Up the Transcription Endpoint

The backend of your Radiation Oncology Academy already has a controller for podcast transcription. You need to update it to use Google Speech-to-Text:

1. Log in to your website's admin panel
2. Go to "Settings" > "API Integrations"
3. Find the "Google Speech-to-Text" section
4. Toggle the "Enable Transcription" switch to "On"
5. Save your changes

### Step 2: Configure Transcription Settings

1. Still in the admin panel, go to "Settings" > "Content Settings"
2. Find the "Podcast Settings" section
3. Configure the following options:
   - Automatic Transcription: Enable
   - Language: English (or your preferred language)
   - Include Speaker Diarization: Enable (to distinguish between speakers)
   - Include Punctuation: Enable
   - Include Word Timestamps: Enable
4. Save your changes

### Step 3: Test Podcast Transcription

1. Go to "Content" > "Podcasts" in the admin panel
2. Click "Add New Episode"
3. Fill in the episode details
4. Upload an audio file
5. Check the "Generate Transcript" option
6. Click "Create Episode"
7. The system will automatically generate a transcript using Google Speech-to-Text

## Implementing Lecture Transcription

### Step 1: Configure Lecture Settings

1. In the admin panel, go to "Settings" > "Content Settings"
2. Find the "Lecture Settings" section
3. Configure the following options:
   - Automatic Transcription: Enable
   - Generate Captions: Enable
   - Language: English (or your preferred language)
4. Save your changes

### Step 2: Upload a Lecture Video

1. Go to "Content" > "Courses" in the admin panel
2. Select a course or create a new one
3. Add a new module or select an existing one
4. Click "Add Lecture"
5. Fill in the lecture details
6. Upload a video file
7. Check the "Generate Transcript" option
8. Click "Create Lecture"
9. The system will automatically generate a transcript using Google Speech-to-Text

### Step 3: Review and Edit the Transcript

1. Once the transcript is generated, you'll receive a notification
2. Go to the lecture page
3. Click on the "Transcript" tab
4. Review the generated transcript
5. Use the built-in editor to make any necessary corrections
6. Click "Save Changes"

## Adding Captions to Educational Videos

### Step 1: Enable Automatic Captioning

1. In the admin panel, go to "Settings" > "Content Settings"
2. Find the "Video Settings" section
3. Enable "Automatic Captioning"
4. Save your changes

### Step 2: Generate Captions for Existing Videos

1. Go to "Content" > "Media Library"
2. Select the videos you want to caption
3. Click "Actions" > "Generate Captions"
4. The system will process the videos and generate captions

### Step 3: Export Captions in Different Formats

1. Go to a video with generated captions
2. Click on the "Captions" tab
3. Click "Export"
4. Select the format you want (SRT, VTT, or TXT)
5. Click "Download"

## Testing and Troubleshooting

### Testing Accuracy

1. Upload a sample audio file with clear speech
2. Generate a transcript
3. Compare the transcript with the actual content
4. Note any words or phrases that were transcribed incorrectly

### Improving Accuracy

1. In the admin panel, go to "Settings" > "Speech-to-Text Settings"
2. Add domain-specific words to the "Custom Dictionary"
3. Include medical and physics terminology that's commonly used
4. Save your changes and test again

### Troubleshooting Common Issues

#### Issue: Transcription is taking too long

Solution:
1. Check the size of your audio file (larger files take longer)
2. Ensure your internet connection is stable
3. Check the Google Cloud Console for any service disruptions

#### Issue: Poor transcription accuracy

Solution:
1. Ensure the audio quality is good with minimal background noise
2. Add specialized terminology to the custom dictionary
3. Try using a different audio format (FLAC or WAV are recommended)

#### Issue: API quota exceeded

Solution:
1. Check your usage in the Google Cloud Console
2. Consider upgrading your plan if you're using the free tier
3. Implement a queue system for large batches of transcriptions

## Best Practices and Maintenance

### Audio Quality Guidelines

For best transcription results:
1. Record in a quiet environment
2. Use a good quality microphone
3. Speak clearly and at a moderate pace
4. Avoid overlapping speech when possible

### Regular Maintenance

1. Review and update your custom dictionary regularly
2. Monitor your API usage in the Google Cloud Console
3. Keep your service account credentials secure
4. Update your integration when Google releases new features

### Cost Management

1. In Google Cloud Console, go to "Billing" > "Cost Management"
2. Set up a budget to monitor and control costs
3. Consider implementing a usage limit in your application

## Conclusion

You've now set up Google Cloud Speech-to-Text for your Radiation Oncology Academy platform. This integration enables:

1. Automatic transcription of podcast episodes
2. Lecture transcripts for educational content
3. Captions for videos to improve accessibility

These features make your educational content more accessible and searchable, enhancing the learning experience for all users.

For any questions or issues, refer to the [Google Cloud Speech-to-Text documentation](https://cloud.google.com/speech-to-text/docs) or contact your website administrator.
