# Radiation Oncology Academy Website Structure

## Overview
The Radiation Oncology Academy website will follow a hybrid approach, combining multi-page structure with SPA-like user experience. This document outlines the overall site architecture, content organization, and feature set based on user requirements.

## Site Architecture

### Main Sections
1. **Home Page**
   - Hero section with value proposition
   - Featured content carousel
   - Quick access to learning tracks
   - Testimonials
   - Call-to-action for registration

2. **Learning Tracks**
   - Landing page with track selection
   - Sub-pages for each user type:
     - `/tracks/oncologist`
     - `/tracks/physicist`
     - `/tracks/residents`
     - `/tracks/graduate-students`
   - Each track contains multiple modules with their own pages

3. **ABR Board Preparation**
   - Organized by exam part:
     - Part 1 (General, Clinical)
     - Part 2 (Therapeutic, Diagnostic, Nuclear)
   - Also organized by topic:
     - Radiobiology
     - Dosimetry
     - Imaging
     - QA
     - etc.

4. **Clinical Modules**
   - Practical clinical applications
   - Case-based learning
   - Procedural guides
   - Best practices

5. **Podcast**
   - Episode listings
   - Audio player
   - Show notes
   - Guest information
   - Subscription options

6. **Blog/News**
   - Latest articles
   - Category filtering
   - Author information
   - Related content suggestions

7. **User Dashboard**
   - Progress tracking
   - Saved content
   - Quiz results
   - Subscription management
   - Personal notes

8. **Admin Dashboard**
   - Content management
   - User management
   - Analytics
   - Subscription data

## Membership Tiers

### Free Trial (30 days)
- Limited access to sample content
- Basic quizzes
- Introductory modules
- Expires after 30 days

### Paid Tier 1 (Pro/Standard)
- Full access to question banks
- Complete modules
- All podcast episodes
- Blog content

### Paid Tier 2 (Premium/Elite)
- Everything in Tier 1
- Specialized case studies
- Private webinars
- 1-on-1 Q&A sessions
- Advanced "premium" modules

## Interactive Features

### Quizzes
- Multiple choice questions
- Fill-in-the-blank
- Point-and-click
- Case-based questions
- Immediate feedback and rationales
- Progress tracking

### Flashcards
- Q&A style for quick review
- Key definitions
- Formulas
- Constants
- Spaced repetition system

### Case Studies
- Clinical scenarios
- Advanced planning cases
- Brachytherapy dose calculations
- QA scenarios
- Interactive problem-solving

### Discussion Forums
- Topic-based discussions
- Q&A board
- Peer support
- Knowledge sharing
- Moderated by experts

## Technical Architecture

### Frontend
- React / Next.js
- Server-side rendering for SEO
- Client-side navigation for SPA experience
- Responsive design for all devices

### Backend
- Node.js with Express or Next.js API routes
- RESTful API design
- JWT authentication
- Role-based access control

### Database
- MongoDB or PostgreSQL
- User profiles
- Content management
- Quiz and interactive content
- Subscription management

### Payment Processing
- Stripe integration for subscription management
- PayPal as alternative payment method
- Handling of subscription upgrades/downgrades
- Free trial conversion to paid plans

## Design System

### Brand Colors
- Primary: Mid-to-dark blue (#3B82F6)
- Accent: Green/teal (#10B981) or orange
- Neutrals: Light gray backgrounds (#F3F4F6)
- Text: Near-black (#111827)

### Typography
- Clean, professional sans-serif fonts
- Clear hierarchy for headings
- Optimized for readability of medical content

### UI Components
- Consistent navigation
- Card-based content display
- Interactive quiz interfaces
- Media players for podcast
- Progress indicators
- Membership badges

## User Flows

### New User Journey
1. Landing page
2. Track selection
3. Free trial registration
4. Onboarding tutorial
5. First module/quiz
6. Subscription prompt before trial expiration

### Returning User Journey
1. Login
2. Dashboard with progress
3. Continue learning
4. Explore new content
5. Track completion

### Content Discovery
1. Browse by track
2. Browse by exam part
3. Browse by topic
4. Search functionality
5. Recommended content based on progress

## Responsive Design
- Desktop-first approach with full responsive support
- Tablet optimization
- Mobile-friendly navigation
- Touch-friendly interactive elements

## SEO Strategy
- Semantic HTML structure
- Server-side rendering for core pages
- Metadata optimization
- Structured data for educational content
- Sitemap generation
