# iOS Production Build Creation

## Overview
This document outlines the process for creating a signed production build of the Radiation Oncology Academy iOS app for App Store submission.

## Prerequisites
- iOS build environment set up
- Apple Developer account configured with:
  - App ID created
  - Distribution certificate generated
  - Distribution provisioning profile created
- Xcode 14.0 or later installed
- Project code finalized for production

## Production Build Process

### 1. Project Preparation
- Update app version and build number:
  - Open `ios/RadiationOncologyAcademy/Info.plist`
  - Set `CFBundleShortVersionString` to "1.0.0"
  - Set `CFBundleVersion` to "1"
- Configure production environment:
  - Verify `.env.production` contains correct API endpoints
  - Ensure analytics keys are set for production
  - Remove any debug code or console logs

### 2. React Native Production Build
- Install all dependencies:
  ```bash
  npm install
  ```
- Update CocoaPods:
  ```bash
  cd ios
  pod install
  cd ..
  ```
- Create release build configuration:
  ```bash
  npx react-native config
  ```

### 3. Xcode Archive Process
- Open project in Xcode:
  ```bash
  open ios/RadiationOncologyAcademy.xcworkspace
  ```
- Select "Generic iOS Device" as the build target
- Select Product > Archive from the menu
- Wait for archive process to complete

### 4. Distribution Certificate and Provisioning Profile
- In Xcode Organizer (Window > Organizer):
  - Select the created archive
  - Click "Distribute App"
  - Select "App Store Connect" distribution method
  - Select "Upload" to upload to App Store Connect
  - Select distribution certificate
  - Select provisioning profile
  - Configure app export options:
    - Include bitcode: No
    - Strip Swift symbols: Yes
    - Upload symbols: Yes

### 5. Build Signing and Upload
- Review distribution options
- Click "Next" to proceed with signing
- Wait for Xcode to process and sign the app
- Review upload information
- Click "Upload" to send to App Store Connect
- Wait for upload and processing to complete

### 6. App Store Connect Verification
- Log in to [App Store Connect](https://appstoreconnect.apple.com/)
- Navigate to the app's page
- Verify build appears in the "TestFlight" tab
- Wait for Apple to complete processing (typically 30 minutes to 1 hour)
- Check for any issues reported by App Store Connect

### 7. TestFlight Internal Testing
- Once processing is complete:
  - Navigate to TestFlight tab
  - Select the build
  - Click "Start Testing"
  - Select internal testing group
  - Add release notes
  - Start internal testing

### 8. Build Verification
- Install build on test devices via TestFlight
- Verify all functionality works as expected:
  - User authentication
  - Content loading and display
  - Navigation and UI elements
  - Offline functionality
  - Any platform-specific features
- Document any issues found

## Troubleshooting

### Archive Failures
- If archive fails with code signing errors:
  - Verify distribution certificate is valid
  - Check provisioning profile matches App ID
  - Ensure team selection is correct in project settings
  - Clean build folder (Product > Clean Build Folder) and try again

### Upload Failures
- If upload to App Store Connect fails:
  - Check internet connection
  - Verify Apple Developer account has correct permissions
  - Ensure app version and build number are unique
  - Check for any App Store Connect maintenance notices

### Processing Issues
- If App Store Connect reports issues:
  - Address any missing information or metadata
  - Fix any reported app crashes or performance issues
  - Verify app meets Apple's guidelines
  - Create new build with fixes if necessary

## Next Steps
After successfully creating and uploading the iOS production build:
1. Complete TestFlight internal testing
2. Address any issues found during testing
3. Prepare app store metadata and screenshots
4. Submit for App Store review

## Documentation
- [Xcode Archive and Upload Guide](https://help.apple.com/xcode/mac/current/#/dev442d7f2ca)
- [TestFlight Beta Testing](https://developer.apple.com/testflight/)
- [App Store Connect Help](https://help.apple.com/app-store-connect/)
- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
