# Android Deployment Guide for Radiation Oncology Academy Mobile App

## Overview

This guide outlines the complete process for deploying the Radiation Oncology Academy mobile application to the Google Play Store. It covers all necessary steps from preparing the development environment to submitting the app for review.

## Prerequisites

- Google Play Developer account ($25 one-time fee)
- Android Studio installed
- React Native development environment
- Java Development Kit (JDK) 11 or later
- Gradle 7.0 or later

## 1. Development Environment Setup

### Install Required Tools

```bash
# Install Android Studio
# Download from https://developer.android.com/studio

# Install JDK if not already installed
sudo apt install openjdk-11-jdk

# Verify installation
java -version
javac -version
```

### Configure Android Studio

1. Open Android Studio
2. Go to SDK Manager (Tools > SDK Manager)
3. Install the following:
   - Android SDK Platform (API level 31 or higher)
   - Android SDK Build-Tools
   - Android SDK Command-line Tools
   - Android Emulator
   - Android SDK Platform-Tools

## 2. App Configuration

### Update App Information

Edit the following files to ensure proper app configuration:

#### `android/app/build.gradle`

```gradle
android {
    defaultConfig {
        applicationId "com.radiationoncologyacademy.mobile"
        minSdkVersion 21
        targetSdkVersion 33
        versionCode 1
        versionName "1.0.0"
    }
}
```

#### `android/app/src/main/AndroidManifest.xml`

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.radiationoncologyacademy.mobile">

    <uses-permission android:name="android.permission.INTERNET" />
    <!-- Add other permissions as needed -->

    <application
        android:name=".MainApplication"
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:allowBackup="false"
        android:theme="@style/AppTheme">
        <!-- ... -->
    </application>
</manifest>
```

#### `android/app/src/main/res/values/strings.xml`

```xml
<resources>
    <string name="app_name">Radiation Oncology Academy</string>
</resources>
```

### Configure App Capabilities

Add required permissions to `AndroidManifest.xml`:

```xml
<!-- For offline functionality -->
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

<!-- For downloading content -->
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

<!-- For push notifications -->
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

<!-- For podcast playback -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
```

## 3. Signing Configuration

### Generate Signing Key

```bash
keytool -genkeypair -v -storetype PKCS12 -keystore radiation_oncology_key.keystore -alias radiation_oncology_alias -keyalg RSA -keysize 2048 -validity 10000
```

When prompted:
- Enter a secure password
- Enter your organization details
- Remember these details for future updates

### Configure Gradle for Signing

Create a `keystore.properties` file in the android directory:

```properties
storePassword=your_keystore_password
keyPassword=your_key_password
keyAlias=radiation_oncology_alias
storeFile=radiation_oncology_key.keystore
```

Update `android/app/build.gradle`:

```gradle
def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
keystoreProperties.load(new FileInputStream(keystorePropertiesFile))

android {
    // ...
    
    signingConfigs {
        release {
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

## 4. Google Play Console Setup

### Create New App

1. Go to [Google Play Console](https://play.google.com/console)
2. Click "Create app"
3. Fill in the required information:
   - App name: Radiation Oncology Academy
   - Default language: English
   - App or game: App
   - Free or paid: Free
   - Declarations: Complete as required

### App Information

Fill in the following details:

1. **Store presence**
   - Short description (80 characters max)
   - Full description (4000 characters max)
   - App category: Medical, Education
   - Tags: radiation oncology, medical education, healthcare

2. **Contact details**
   - Email address
   - Website
   - Phone number (optional)

3. **Privacy policy**
   - URL to privacy policy: https://radiationoncologyacademy.com/privacy

## 5. Prepare App Assets

### App Icon

Generate app icons using the following dimensions:

- mipmap-mdpi: 48x48 px
- mipmap-hdpi: 72x72 px
- mipmap-xhdpi: 96x96 px
- mipmap-xxhdpi: 144x144 px
- mipmap-xxxhdpi: 192x192 px
- Play Store: 512x512 px

Use the following command to generate all required icon sizes:

```bash
npx react-native-asset --icon ./assets/icon.png --platforms android
```

### Feature Graphic

Create a feature graphic (1024x500 px) that showcases the app's main features.

### Screenshots

Create screenshots for the following devices:
- Phone: 16:9 aspect ratio (1920x1080 px)
- 7-inch tablet: 16:10 aspect ratio (2560x1600 px)
- 10-inch tablet: 16:10 aspect ratio (2560x1600 px)

Each screenshot should showcase a key feature:
1. Home screen with personalized dashboard
2. Educational content viewer
3. Podcast player
4. News article reader
5. Interactive quiz

### Promo Video

Create a 30-second to 2-minute promotional video demonstrating the app's key features.

## 6. Build Configuration

### Configure Release Build

Update `android/app/build.gradle`:

```gradle
android {
    // ...
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

### Configure ProGuard

Create or update `android/app/proguard-rules.pro`:

```
# React Native
-keep class com.facebook.react.** { *; }
-keep class com.facebook.hermes.** { *; }
-keep class com.facebook.jni.** { *; }

# Keep native methods
-keepclassmembers class * {
    native <methods>;
}

# Keep JavaScript callbacks
-keepclassmembers class * {
    @com.facebook.react.uimanager.annotations.ReactProp <methods>;
}

# Third-party libraries
# Add specific rules for libraries used in the project
```

### Configure Environment Variables

Create a `.env.production` file:

```
API_BASE_URL=https://api.radiationoncologyacademy.com/v1
ENABLE_ANALYTICS=true
LOG_LEVEL=error
```

## 7. Create Production Build

### Manual Build Process

```bash
# Install dependencies
cd /path/to/RadiationOncologyApp
npm install

# Create release bundle
npx react-native bundle --platform android --dev false --entry-file index.js --bundle-output android/app/src/main/assets/index.android.bundle --assets-dest android/app/src/main/res

# Build APK
cd android
./gradlew assembleRelease

# Build AAB (Android App Bundle) - preferred for Play Store
./gradlew bundleRelease
```

### Using Fastlane (Recommended)

Create a `Fastfile` in the `android/fastlane` directory:

```ruby
default_platform(:android)

platform :android do
  desc "Build and upload to Play Store internal testing track"
  lane :internal do
    gradle(
      task: "clean bundleRelease",
      properties: {
        "android.injected.signing.store.file" => ENV["KEYSTORE_PATH"],
        "android.injected.signing.store.password" => ENV["STORE_PASSWORD"],
        "android.injected.signing.key.alias" => ENV["KEY_ALIAS"],
        "android.injected.signing.key.password" => ENV["KEY_PASSWORD"],
      }
    )
    upload_to_play_store(
      track: 'internal',
      aab: lane_context[SharedValues::GRADLE_AAB_OUTPUT_PATH]
    )
  end

  desc "Build and upload to Play Store production"
  lane :production do
    gradle(
      task: "clean bundleRelease",
      properties: {
        "android.injected.signing.store.file" => ENV["KEYSTORE_PATH"],
        "android.injected.signing.store.password" => ENV["STORE_PASSWORD"],
        "android.injected.signing.key.alias" => ENV["KEY_ALIAS"],
        "android.injected.signing.key.password" => ENV["KEY_PASSWORD"],
      }
    )
    upload_to_play_store(
      track: 'production',
      aab: lane_context[SharedValues::GRADLE_AAB_OUTPUT_PATH]
    )
  end
end
```

Run the fastlane command:

```bash
cd android
fastlane internal  # For internal testing
# or
fastlane production  # For production release
```

## 8. Testing Distribution

### Internal Testing

1. Go to Google Play Console > Your app > Testing > Internal testing
2. Create a new release
3. Upload the AAB file
4. Add release notes
5. Save and review the release
6. Start rollout to internal testing

### Add Testers

1. Go to Google Play Console > Your app > Testing > Internal testing
2. Click "Testers" tab
3. Create a new tester list or use an existing one
4. Add tester email addresses
5. Save changes
6. Share the opt-in URL with testers

## 9. Play Store Submission

### Final Checklist

- App icon and feature graphic are properly configured
- All required screenshots are uploaded
- Promo video is uploaded (if available)
- App metadata is complete
- Privacy policy is in place
- App complies with Google Play policies
- All testing reported issues are resolved

### Content Rating

1. Go to Google Play Console > Your app > Content rating
2. Complete the questionnaire
3. Submit for rating

### App Content

1. Go to Google Play Console > Your app > App content
2. Complete all sections:
   - Privacy policy
   - Ads
   - Content ratings
   - Target audience
   - News apps (if applicable)
   - COVID-19 info (if applicable)

### Data Safety

1. Go to Google Play Console > Your app > Data safety
2. Declare what data your app collects
3. Explain how the data is used
4. Specify security practices
5. Submit the form

### Pricing & Distribution

1. Go to Google Play Console > Your app > Pricing & distribution
2. Select app availability (countries)
3. Choose price (Free)
4. Select content restrictions (if any)

### Submit for Review

1. Go to Google Play Console > Your app > Production
2. Create a new release
3. Upload the AAB file
4. Add release notes
5. Save and review the release
6. Start rollout to production

### Monitor Review Status

1. Check Google Play Console regularly for review status
2. Be prepared to respond to reviewer questions
3. Address any issues raised during review

## 10. Post-Launch Activities

### Monitor Analytics

1. Set up Google Play Console Analytics
2. Monitor crash reports and ANRs (Application Not Responding)
3. Track user engagement metrics
4. Monitor user reviews and ratings

### Plan Updates

1. Collect user feedback
2. Prioritize feature requests
3. Plan regular update schedule

### Support

1. Set up support channels
2. Create FAQ documentation
3. Establish response protocols for user issues

## Troubleshooting

### Common Issues and Solutions

1. **Signing Issues**
   - Verify keystore path and credentials
   - Ensure keystore is properly generated
   - Check build.gradle configuration

2. **Build Errors**
   - Clean project (./gradlew clean)
   - Delete build directories
   - Reinstall dependencies

3. **Submission Rejections**
   - Privacy concerns: Update privacy policy and data safety form
   - Crashes: Fix stability issues
   - Metadata: Correct misleading information

## Resources

- [Google Play Console Help](https://support.google.com/googleplay/android-developer/)
- [Android Developer Documentation](https://developer.android.com/docs)
- [React Native Android Deployment Guide](https://reactnative.dev/docs/signed-apk-android)
- [Fastlane Documentation](https://docs.fastlane.tools/)
