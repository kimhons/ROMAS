# iOS Build Environment Setup

## Overview
This document outlines the setup process for the iOS build environment for the Radiation Oncology Academy app submission.

## Prerequisites
- macOS Monterey or later
- Xcode 14.0 or later
- CocoaPods
- Node.js and npm
- React Native CLI
- Apple Developer account credentials

## Environment Configuration Steps

### 1. Xcode Installation and Configuration
- Install latest version of Xcode from Mac App Store
- Install Xcode Command Line Tools:
  ```bash
  xcode-select --install
  ```
- Configure Xcode preferences:
  - Set default team to Radiation Oncology Academy team
  - Verify iOS deployment target (iOS 14.0+)
  - Configure code signing settings

### 2. React Native Environment Setup
- Install Node.js and npm:
  ```bash
  brew install node
  ```
- Install React Native CLI:
  ```bash
  npm install -g react-native-cli
  ```
- Install CocoaPods:
  ```bash
  sudo gem install cocoapods
  ```

### 3. Project Configuration
- Clone project repository:
  ```bash
  git clone https://github.com/radiation-oncology-academy/mobile-app.git
  cd mobile-app
  ```
- Install JavaScript dependencies:
  ```bash
  npm install
  ```
- Install CocoaPods dependencies:
  ```bash
  cd ios
  pod install
  ```

### 4. Build Configuration
- Update app version to 1.0.0 in Info.plist
- Update build number to 1 in Info.plist
- Configure bundle identifier (com.radiationoncologyacademy.mobile)
- Set up environment variables for production:
  ```bash
  echo "API_URL=https://api.radiationoncologyacademy.com/v1" > .env.production
  echo "ANALYTICS_KEY=production_key_here" >> .env.production
  ```

### 5. Code Signing Setup
- Open project in Xcode:
  ```bash
  open ios/RadiationOncologyAcademy.xcworkspace
  ```
- Navigate to Signing & Capabilities tab
- Select team from Apple Developer account
- Verify automatic signing is enabled
- Note the provisioning profile generated

### 6. Build Verification
- Run development build to verify environment:
  ```bash
  npx react-native run-ios
  ```
- Verify app launches successfully on simulator
- Test basic functionality to ensure environment is correctly configured

## Next Steps
After successfully setting up the iOS build environment:
1. Configure Apple Developer account with necessary certificates and profiles
2. Create and sign production build
3. Verify build on physical devices
4. Prepare for App Store submission

## Troubleshooting
- If CocoaPods installation fails, try:
  ```bash
  sudo gem install cocoapods -n /usr/local/bin
  ```
- If build fails with code signing errors:
  - Verify Apple Developer account is active
  - Check team selection in Xcode
  - Manually refresh provisioning profiles

- If React Native dependencies fail:
  - Clear npm cache:
    ```bash
    npm cache clean --force
    ```
  - Delete node_modules and reinstall:
    ```bash
    rm -rf node_modules
    npm install
    ```

## Documentation
- [React Native Environment Setup](https://reactnative.dev/docs/environment-setup)
- [Xcode Documentation](https://developer.apple.com/documentation/xcode)
- [Apple Developer Program](https://developer.apple.com/programs/)
- [App Store Submission Guidelines](https://developer.apple.com/app-store/review/guidelines/)
