# User Feedback System Implementation for Radiation Oncology Academy

## Overview

This document outlines the implementation of a comprehensive user feedback system for the Radiation Oncology Academy website. Collecting and analyzing user feedback is essential for improving content quality, enhancing user experience, and guiding future development. This system establishes structured processes for gathering, categorizing, analyzing, and responding to user feedback across all aspects of the platform.

## User Feedback Collection Interface

### 1. Feedback Widget Component

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/components/feedback/FeedbackWidget.tsx
import React, { useState } from 'react';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, 
         FormControl, InputLabel, Select, MenuItem, Rating, Snackbar, Alert } from '@mui/material';
import { Send as SendIcon } from '@mui/icons-material';

interface FeedbackWidgetProps {
  contentId?: string;
  contentType?: string;
  location: string;
  userRole?: string;
}

const FeedbackWidget: React.FC<FeedbackWidgetProps> = ({ 
  contentId, 
  contentType, 
  location,
  userRole
}) => {
  const [open, setOpen] = useState(false);
  const [feedbackType, setFeedbackType] = useState('');
  const [rating, setRating] = useState<number | null>(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    // Reset form after a delay
    setTimeout(() => {
      setFeedbackType('');
      setRating(null);
      setFeedbackText('');
      setSubmitted(false);
      setError(null);
    }, 500);
  };

  const handleSubmit = async () => {
    try {
      // Validate form
      if (!feedbackType) {
        setError('Please select a feedback type');
        return;
      }
      
      if (feedbackType === 'rating' && rating === null) {
        setError('Please provide a rating');
        return;
      }
      
      if (!feedbackText.trim()) {
        setError('Please provide feedback details');
        return;
      }
      
      // Prepare feedback data
      const feedbackData = {
        feedbackType,
        rating,
        feedbackText,
        contentId,
        contentType,
        location,
        userRole,
        timestamp: new Date().toISOString(),
        userId: localStorage.getItem('userId') || 'anonymous'
      };
      
      // Submit feedback
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }
      
      setSubmitted(true);
      setTimeout(handleClose, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  return (
    <>
      <Button 
        variant="outlined" 
        size="small" 
        onClick={handleOpen}
        sx={{ position: 'fixed', bottom: '20px', right: '20px', zIndex: 1000 }}
      >
        Provide Feedback
      </Button>
      
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>Share Your Feedback</DialogTitle>
        <DialogContent>
          {submitted ? (
            <Alert severity="success">
              Thank you for your feedback! We appreciate your input.
            </Alert>
          ) : (
            <>
              {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Feedback Type</InputLabel>
                <Select
                  value={feedbackType}
                  onChange={(e) => setFeedbackType(e.target.value)}
                  label="Feedback Type"
                >
                  <MenuItem value="content">Content Quality</MenuItem>
                  <MenuItem value="usability">Usability</MenuItem>
                  <MenuItem value="technical">Technical Issue</MenuItem>
                  <MenuItem value="suggestion">Feature Suggestion</MenuItem>
                  <MenuItem value="rating">Overall Rating</MenuItem>
                </Select>
              </FormControl>
              
              {feedbackType === 'rating' && (
                <FormControl fullWidth margin="normal" sx={{ display: 'flex', alignItems: 'center' }}>
                  <InputLabel sx={{ position: 'relative' }}>Your Rating</InputLabel>
                  <Rating
                    name="feedback-rating"
                    value={rating}
                    onChange={(_, newValue) => {
                      setRating(newValue);
                    }}
                    size="large"
                    sx={{ mt: 3 }}
                  />
                </FormControl>
              )}
              
              <TextField
                label="Feedback Details"
                multiline
                rows={4}
                value={feedbackText}
                onChange={(e) => setFeedbackText(e.target.value)}
                fullWidth
                margin="normal"
                placeholder="Please provide specific details about your feedback..."
              />
            </>
          )}
        </DialogContent>
        
        {!submitted && (
          <DialogActions>
            <Button onClick={handleClose}>Cancel</Button>
            <Button 
              onClick={handleSubmit} 
              variant="contained" 
              endIcon={<SendIcon />}
              disabled={submitted}
            >
              Submit Feedback
            </Button>
          </DialogActions>
        )}
      </Dialog>
    </>
  );
};

export default FeedbackWidget;
```

### 2. Content-Specific Feedback Component

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/components/feedback/ContentFeedback.tsx
import React, { useState } from 'react';
import { Box, Typography, Rating, TextField, Button, Snackbar, Alert } from '@mui/material';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';

interface ContentFeedbackProps {
  contentId: string;
  contentType: string;
  title: string;
}

const ContentFeedback: React.FC<ContentFeedbackProps> = ({ contentId, contentType, title }) => {
  const [helpfulRating, setHelpfulRating] = useState<'helpful' | 'not_helpful' | null>(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [showTextArea, setShowTextArea] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);

  const handleRating = (rating: 'helpful' | 'not_helpful') => {
    setHelpfulRating(rating);
    setShowTextArea(true);
  };

  const handleSubmit = async () => {
    try {
      if (!helpfulRating) {
        setError('Please indicate if the content was helpful');
        return;
      }
      
      // Prepare feedback data
      const feedbackData = {
        feedbackType: 'content_rating',
        helpfulRating,
        feedbackText,
        contentId,
        contentType,
        title,
        timestamp: new Date().toISOString(),
        userId: localStorage.getItem('userId') || 'anonymous'
      };
      
      // Submit feedback
      const response = await fetch('/api/feedback/content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }
      
      setSubmitted(true);
      setSnackbarOpen(true);
      
      // Reset form after submission
      setTimeout(() => {
        setHelpfulRating(null);
        setFeedbackText('');
        setShowTextArea(false);
        setSubmitted(false);
      }, 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  return (
    <Box sx={{ mt: 4, p: 2, border: '1px solid #e0e0e0', borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        Was this content helpful?
      </Typography>
      
      <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
        <Button 
          variant={helpfulRating === 'helpful' ? 'contained' : 'outlined'}
          startIcon={<ThumbUpIcon />}
          onClick={() => handleRating('helpful')}
          color="success"
        >
          Yes
        </Button>
        
        <Button 
          variant={helpfulRating === 'not_helpful' ? 'contained' : 'outlined'}
          startIcon={<ThumbDownIcon />}
          onClick={() => handleRating('not_helpful')}
          color="error"
        >
          No
        </Button>
      </Box>
      
      {showTextArea && (
        <>
          <TextField
            label={helpfulRating === 'helpful' ? "What did you find most valuable?" : "How can we improve this content?"}
            multiline
            rows={3}
            value={feedbackText}
            onChange={(e) => setFeedbackText(e.target.value)}
            fullWidth
            margin="normal"
            disabled={submitted}
          />
          
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            disabled={submitted}
            sx={{ mt: 1 }}
          >
            Submit Feedback
          </Button>
          
          {error && (
            <Typography color="error" sx={{ mt: 1 }}>
              {error}
            </Typography>
          )}
        </>
      )}
      
      <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose}>
        <Alert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
          Thank you for your feedback!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ContentFeedback;
```

### 3. User Experience Survey Component

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/components/feedback/UserSurvey.tsx
import React, { useState, useEffect } from 'react';
import { 
  Box, Typography, Button, Stepper, Step, StepLabel, 
  Radio, RadioGroup, FormControlLabel, FormControl, FormLabel,
  TextField, Rating, Dialog, DialogTitle, DialogContent, DialogActions
} from '@mui/material';

interface SurveyQuestion {
  id: string;
  type: 'multiple_choice' | 'rating' | 'text';
  question: string;
  options?: string[];
  required: boolean;
}

interface UserSurveyProps {
  surveyId: string;
  title: string;
  description: string;
  questions: SurveyQuestion[];
  onComplete?: () => void;
}

const UserSurvey: React.FC<UserSurveyProps> = ({ 
  surveyId, 
  title, 
  description, 
  questions,
  onComplete
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [error, setError] = useState<string | null>(null);
  const [completed, setCompleted] = useState(false);
  const [open, setOpen] = useState(false);

  // Show survey based on user's activity
  useEffect(() => {
    const hasCompletedSurvey = localStorage.getItem(`survey_${surveyId}_completed`);
    if (hasCompletedSurvey) {
      return;
    }
    
    const visitCount = parseInt(localStorage.getItem('visit_count') || '0', 10);
    
    // Show survey after 5 visits
    if (visitCount >= 5) {
      setTimeout(() => {
        setOpen(true);
      }, 30000); // Show after 30 seconds on the site
    }
  }, [surveyId]);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleNext = () => {
    const currentQuestion = questions[activeStep];
    
    // Validate current answer if required
    if (currentQuestion.required && !answers[currentQuestion.id]) {
      setError('This question requires an answer');
      return;
    }
    
    setError(null);
    
    if (activeStep === questions.length - 1) {
      handleSubmit();
    } else {
      setActiveStep((prevStep) => prevStep + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleAnswerChange = (questionId: string, value: any) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: value
    }));
  };

  const handleSubmit = async () => {
    try {
      // Prepare survey data
      const surveyData = {
        surveyId,
        answers,
        timestamp: new Date().toISOString(),
        userId: localStorage.getItem('userId') || 'anonymous'
      };
      
      // Submit survey
      const response = await fetch('/api/feedback/survey', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(surveyData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit survey');
      }
      
      setCompleted(true);
      localStorage.setItem(`survey_${surveyId}_completed`, 'true');
      
      if (onComplete) {
        onComplete();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const renderQuestion = (question: SurveyQuestion) => {
    switch (question.type) {
      case 'multiple_choice':
        return (
          <FormControl component="fieldset" fullWidth margin="normal">
            <FormLabel component="legend">{question.question}</FormLabel>
            <RadioGroup
              value={answers[question.id] || ''}
              onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            >
              {question.options?.map((option) => (
                <FormControlLabel
                  key={option}
                  value={option}
                  control={<Radio />}
                  label={option}
                />
              ))}
            </RadioGroup>
          </FormControl>
        );
        
      case 'rating':
        return (
          <FormControl component="fieldset" fullWidth margin="normal">
            <FormLabel component="legend">{question.question}</FormLabel>
            <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
              <Rating
                name={`question-${question.id}`}
                value={answers[question.id] || null}
                onChange={(_, newValue) => {
                  handleAnswerChange(question.id, newValue);
                }}
                size="large"
              />
            </Box>
          </FormControl>
        );
        
      case 'text':
        return (
          <TextField
            label={question.question}
            multiline
            rows={3}
            value={answers[question.id] || ''}
            onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            fullWidth
            margin="normal"
          />
        );
        
      default:
        return null;
    }
  };

  return (
    <>
      <Button variant="outlined" onClick={handleOpen}>
        Take Our Survey
      </Button>
      
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle>{title}</DialogTitle>
        <DialogContent>
          {completed ? (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography variant="h5" gutterBottom>
                Thank You!
              </Typography>
              <Typography variant="body1">
                Your feedback is valuable and will help us improve the Radiation Oncology Academy.
              </Typography>
            </Box>
          ) : (
            <>
              <Typography variant="body1" paragraph>
                {description}
              </Typography>
              
              <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
                {questions.map((_, index) => (
                  <Step key={index}>
                    <StepLabel></StepLabel>
                  </Step>
                ))}
              </Stepper>
              
              {error && (
                <Typography color="error" sx={{ mb: 2 }}>
                  {error}
                </Typography>
              )}
              
              {renderQuestion(questions[activeStep])}
            </>
          )}
        </DialogContent>
        
        {!completed && (
          <DialogActions>
            <Button onClick={handleClose}>Cancel</Button>
            <Button disabled={activeStep === 0} onClick={handleBack}>
              Back
            </Button>
            <Button variant="contained" onClick={handleNext}>
              {activeStep === questions.length - 1 ? 'Submit' : 'Next'}
            </Button>
          </DialogActions>
        )}
      </Dialog>
    </>
  );
};

export default UserSurvey;
```

### 4. Backend API for Feedback Collection

```javascript
// File: /home/username/public_html/radiation_oncology_academy/backend/controllers/feedback.controller.js
const Feedback = require('../models/Feedback');
const ContentFeedback = require('../models/ContentFeedback');
const Survey = require('../models/Survey');
const SurveyResponse = require('../models/SurveyResponse');
const { sendAlert, SEVERITY } = require('../utils/alert_manager');

// Submit general feedback
exports.submitFeedback = async (req, res) => {
  try {
    const {
      feedbackType,
      rating,
      feedbackText,
      contentId,
      contentType,
      location,
      userRole,
      userId
    } = req.body;
    
    // Create new feedback entry
    const feedback = new Feedback({
      feedbackType,
      rating,
      feedbackText,
      contentId,
      contentType,
      location,
      userRole,
      userId: userId || req.userId || 'anonymous',
      status: 'new',
      createdAt: new Date()
    });
    
    await feedback.save();
    
    // Send alert for critical feedback
    if (feedbackType === 'technical' || feedbackText.toLowerCase().includes('error') || feedbackText.toLowerCase().includes('bug')) {
      sendAlert(
        'Critical user feedback received',
        `A user reported a technical issue: ${feedbackText.substring(0, 100)}...`,
        SEVERITY.WARNING,
        { feedbackId: feedback._id }
      );
    }
    
    res.status(201).json({
      success: true,
      message: 'Feedback submitted successfully',
      feedbackId: feedback._id
    });
  } catch (error) {
    console.error('Error submitting feedback:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit feedback',
      error: error.message
    });
  }
};

// Submit content-specific feedback
exports.submitContentFeedback = async (req, res) => {
  try {
    const {
      helpfulRating,
      feedbackText,
      contentId,
      contentType,
      title,
      userId
    } = req.body;
    
    // Create new content feedback entry
    const contentFeedback = new ContentFeedback({
      helpfulRating,
      feedbackText,
      contentId,
      contentType,
      title,
      userId: userId || req.userId || 'anonymous',
      createdAt: new Date()
    });
    
    await contentFeedback.save();
    
    // If content is consistently rated not helpful, send alert
    if (helpfulRating === 'not_helpful') {
      const recentNegativeFeedback = await ContentFeedback.countDocuments({
        contentId,
        helpfulRating: 'not_helpful',
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } // Last 7 days
      });
      
      if (recentNegativeFeedback >= 3) {
        sendAlert(
          'Content receiving negative feedback',
          `Content "${title}" (${contentType}) has received ${recentNegativeFeedback} negative ratings in the past week`,
          SEVERITY.WARNING,
          { contentId, contentType }
        );
      }
    }
    
    res.status(201).json({
      success: true,
      message: 'Content feedback submitted successfully',
      feedbackId: contentFeedback._id
    });
  } catch (error) {
    console.error('Error submitting content feedback:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit content feedback',
      error: error.message
    });
  }
};

// Submit survey response
exports.submitSurveyResponse = async (req, res) => {
  try {
    const {
      surveyId,
      answers,
      userId
    } = req.body;
    
    // Check if survey exists
    const survey = await Survey.findById(surveyId);
    if (!survey) {
      return res.status(404).json({
        success: false,
        message: 'Survey not found'
      });
    }
    
    // Create new survey response
    const surveyResponse = new SurveyResponse({
      surveyId,
      answers,
      userId: userId || req.userId || 'anonymous',
      completedAt: new Date()
    });
    
    await surveyResponse.save();
    
    res.status(201).json({
      success: true,
      message: 'Survey response submitted successfully',
      responseId: surveyResponse._id
    });
  } catch (error) {
    console.error('Error submitting survey response:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit survey response',
      error: error.message
    });
  }
};

// Get active surveys
exports.getActiveSurveys = async (req, res) => {
  try {
    const activeSurveys = await Survey.find({
      isActive: true,
      startDate: { $lte: new Date() },
      endDate: { $gte: new Date() }
    });
    
    res.status(200).json({
      success: true,
      surveys: activeSurveys
    });
  } catch (error) {
    console.error('Error getting active surveys:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get active surveys',
      error: error.message
    });
  }
};
```

### 5. Database Models for Feedback

```javascript
// File: /home/username/public_html/radiation_oncology_academy/backend/models/Feedback.js
const mongoose = require('mongoose');

const FeedbackSchema = new mongoose.Schema({
  feedbackType: {
    type: String,
    enum: ['content', 'usability', 'technical', 'suggestion', 'rating'],
    required: true
  },
  rating: {
    type: Number,
    min: 1,
    max: 5
  },
  feedbackText: {
    type: String,
    required: true
  },
  contentId: {
    type: String
  },
  contentType: {
    type: String
  },
  location: {
    type: String,
    required: true
  },
  userRole: {
    type: String
  },
  userId: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['new', 'in_progress', 'resolved', 'closed'],
    default: 'new'
  },
  adminResponse: {
    type: String
  },
  respondedBy: {
    type: String
  },
  respondedAt: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Feedback', FeedbackSchema);
```

```javascript
// File: /home/username/public_html/radiation_oncology_academy/backend/models/ContentFeedback.js
const mongoose = require('mongoose');

const ContentFeedbackSchema = new mongoose.Schema({
  helpfulRating: {
    type: String,
    enum: ['helpful', 'not_helpful'],
    required: true
  },
  feedbackText: {
    type: String
  },
  contentId: {
    type: String,
    required: true
  },
  contentType: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('ContentFeedback', ContentFeedbackSchema);
```

```javascript
// File: /home/username/public_html/radiation_oncology_academy/backend/models/Survey.js
const mongoose = require('mongoose');

const SurveySchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  questions: [{
    id: {
      type: String,
      required: true
    },
    type: {
      type: String,
      enum: ['multiple_choice', 'rating', 'text'],
      required: true
    },
    question: {
      type: String,
      required: true
    },
    options: [String],
    required: {
      type: Boolean,
      default: false
    }
  }],
  targetAudience: {
    type: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date
  },
  createdBy: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Survey', SurveySchema);
```

```javascript
// File: /home/username/public_html/radiation_oncology_academy/backend/models/SurveyResponse.js
const mongoose = require('mongoose');

const SurveyResponseSchema = new mongoose.Schema({
  surveyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Survey',
    required: true
  },
  answers: {
    type: Map,
    of: mongoose.Schema.Types.Mixed,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  completedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('SurveyResponse', SurveyResponseSchema);
```

### 6. API Routes for Feedback

```javascript
// File: /home/username/public_html/radiation_oncology_academy/backend/routes/feedback.routes.js
const express = require('express');
const router = express.Router();
const feedbackController = require('../controllers/feedback.controller');
const { authMiddleware, optionalAuth } = require('../middleware/auth');

// Submit general feedback
router.post('/', optionalAuth, feedbackController.submitFeedback);

// Submit content-specific feedback
router.post('/content', optionalAuth, feedbackController.submitContentFeedback);

// Submit survey response
router.post('/survey', optionalAuth, feedbackController.submitSurveyResponse);

// Get active surveys
router.get('/surveys/active', optionalAuth, feedbackController.getActiveSurveys);

module.exports = router;
```

## Feedback Categorization System

### 1. Feedback Analysis Script

```javascript
// File: /home/username/feedback_scripts/analyze_feedback.js
const fs = require('fs');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');
const { Configuration, OpenAIApi } = require('openai');
const { sendAlert, SEVERITY } = require('../monitoring_scripts/alert_manager');

// MongoDB connection
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

// OpenAI configuration
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

// Categorize feedback using AI
async function categorizeFeedback(feedbackText, feedbackType) {
  try {
    const prompt = `
    Analyze the following user feedback for a radiation oncology educational website and categorize it.
    
    Feedback type: ${feedbackType}
    Feedback text: "${feedbackText}"
    
    Provide a JSON response with:
    1. Primary category (choose one): Content Quality, User Interface, Technical Issue, Feature Request, Praise, Complaint
    2. Subcategory (more specific)
    3. Sentiment (positive, neutral, negative)
    4. Priority (low, medium, high, critical)
    5. Key topics mentioned (list of keywords)
    6. Suggested action
    
    Format as JSON:
    {
      "primary_category": "...",
      "subcategory": "...",
      "sentiment": "...",
      "priority": "...",
      "topics": ["...", "..."],
      "suggested_action": "..."
    }
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 500,
      temperature: 0.3,
    });
    
    // Parse the JSON response
    const responseText = response.data.choices[0].text.trim();
    let analysis;
    
    try {
      analysis = JSON.parse(responseText);
    } catch (error) {
      // If JSON parsing fails, try to extract JSON portion
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysis = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('Failed to parse feedback analysis JSON');
      }
    }
    
    return analysis;
  } catch (error) {
    console.error('Error categorizing feedback:', error);
    return {
      primary_category: 'Uncategorized',
      subcategory: 'Error in Analysis',
      sentiment: 'neutral',
      priority: 'medium',
      topics: ['error'],
      suggested_action: 'Review manually'
    };
  }
}

// Update feedback with analysis
async function updateFeedbackWithAnalysis(feedbackId, analysis) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection('feedbacks');
    
    const updateResult = await collection.updateOne(
      { _id: new ObjectId(feedbackId) },
      {
        $set: {
          analysis,
          analyzed: true,
          analyzedAt: new Date()
        }
      }
    );
    
    return {
      feedbackId,
      updated: updateResult.modifiedCount > 0
    };
  } catch (error) {
    console.error(`Error updating feedback ${feedbackId} with analysis:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Process new feedback
async function processNewFeedback() {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection('feedbacks');
    
    // Find unanalyzed feedback
    const unanalyzedFeedback = await collection.find({
      analyzed: { $ne: true },
      status: 'new'
    })
    .limit(20)
    .toArray();
    
    console.log(`Found ${unanalyzedFeedback.length} unanalyzed feedback items`);
    
    const results = {
      processed: [],
      errors: [],
      timestamp: new Date().toISOString()
    };
    
    // Process each feedback item
    for (const feedback of unanalyzedFeedback) {
      try {
        // Categorize feedback
        const analysis = await categorizeFeedback(
          feedback.feedbackText,
          feedback.feedbackType
        );
        
        // Update feedback with analysis
        await updateFeedbackWithAnalysis(
          feedback._id.toString(),
          analysis
        );
        
        results.processed.push({
          feedbackId: feedback._id.toString(),
          analysis
        });
        
        // Alert for high priority feedback
        if (analysis.priority === 'high' || analysis.priority === 'critical') {
          sendAlert(
            `High priority ${analysis.primary_category} feedback received`,
            `A user submitted feedback that requires attention: ${feedback.feedbackText.substring(0, 100)}...`,
            SEVERITY.WARNING,
            { feedbackId: feedback._id.toString(), analysis }
          );
        }
      } catch (error) {
        console.error(`Error processing feedback ${feedback._id}:`, error);
        results.errors.push({
          feedbackId: feedback._id.toString(),
          error: error.message
        });
      }
    }
    
    // Generate report
    const reportDir = path.join(__dirname, '../feedback_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(
      reportDir, 
      `feedback_analysis_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
    
    console.log(`Feedback analysis completed. Report saved to ${reportPath}`);
    return reportPath;
  } catch (error) {
    console.error('Error processing new feedback:', error);
    sendAlert(
      'Error in feedback analysis',
      `Failed to process feedback: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  } finally {
    await client.close();
  }
}

// Generate feedback summary
async function generateFeedbackSummary(timeframe = 'week') {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const feedbackCollection = database.collection('feedbacks');
    const contentFeedbackCollection = database.collection('contentfeedbacks');
    
    // Determine date range
    let startDate;
    const now = new Date();
    
    switch (timeframe) {
      case 'day':
        startDate = new Date(now.setDate(now.getDate() - 1));
        break;
      case 'week':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case 'month':
        startDate = new Date(now.setMonth(now.getMonth() - 1));
        break;
      default:
        startDate = new Date(now.setDate(now.getDate() - 7));
    }
    
    // Get general feedback
    const generalFeedback = await feedbackCollection.find({
      createdAt: { $gte: startDate }
    }).toArray();
    
    // Get content feedback
    const contentFeedback = await contentFeedbackCollection.find({
      createdAt: { $gte: startDate }
    }).toArray();
    
    // Calculate statistics
    const generalStats = {
      total: generalFeedback.length,
      byType: {},
      byCategory: {},
      bySentiment: {
        positive: 0,
        neutral: 0,
        negative: 0
      },
      byPriority: {
        low: 0,
        medium: 0,
        high: 0,
        critical: 0
      }
    };
    
    const contentStats = {
      total: contentFeedback.length,
      helpful: 0,
      notHelpful: 0,
      byContentType: {}
    };
    
    // Process general feedback
    generalFeedback.forEach(feedback => {
      // Count by type
      generalStats.byType[feedback.feedbackType] = (generalStats.byType[feedback.feedbackType] || 0) + 1;
      
      // Count by category if analyzed
      if (feedback.analysis && feedback.analysis.primary_category) {
        generalStats.byCategory[feedback.analysis.primary_category] = 
          (generalStats.byCategory[feedback.analysis.primary_category] || 0) + 1;
        
        // Count by sentiment
        if (feedback.analysis.sentiment) {
          generalStats.bySentiment[feedback.analysis.sentiment] += 1;
        }
        
        // Count by priority
        if (feedback.analysis.priority) {
          generalStats.byPriority[feedback.analysis.priority] += 1;
        }
      }
    });
    
    // Process content feedback
    contentFeedback.forEach(feedback => {
      // Count helpful vs not helpful
      if (feedback.helpfulRating === 'helpful') {
        contentStats.helpful += 1;
      } else {
        contentStats.notHelpful += 1;
      }
      
      // Count by content type
      contentStats.byContentType[feedback.contentType] = 
        (contentStats.byContentType[feedback.contentType] || 0) + 1;
    });
    
    // Calculate helpfulness ratio
    contentStats.helpfulnessRatio = contentStats.total > 0 
      ? (contentStats.helpful / contentStats.total).toFixed(2) 
      : 0;
    
    // Generate summary
    const summary = {
      timeframe,
      period: `${startDate.toISOString()} to ${new Date().toISOString()}`,
      generalFeedback: generalStats,
      contentFeedback: contentStats,
      topIssues: [],
      topPraise: [],
      recommendations: []
    };
    
    // Identify top issues (high/critical priority negative feedback)
    const topIssues = generalFeedback
      .filter(f => f.analysis && f.analysis.sentiment === 'negative' && 
                  (f.analysis.priority === 'high' || f.analysis.priority === 'critical'))
      .slice(0, 5)
      .map(f => ({
        category: f.analysis.primary_category,
        subcategory: f.analysis.subcategory,
        priority: f.analysis.priority,
        text: f.feedbackText.substring(0, 200) + (f.feedbackText.length > 200 ? '...' : '')
      }));
    
    summary.topIssues = topIssues;
    
    // Identify top praise (positive feedback)
    const topPraise = generalFeedback
      .filter(f => f.analysis && f.analysis.sentiment === 'positive')
      .slice(0, 5)
      .map(f => ({
        category: f.analysis.primary_category,
        subcategory: f.analysis.subcategory,
        text: f.feedbackText.substring(0, 200) + (f.feedbackText.length > 200 ? '...' : '')
      }));
    
    summary.topPraise = topPraise;
    
    // Generate AI recommendations based on feedback
    if (generalFeedback.length > 0 || contentFeedback.length > 0) {
      try {
        const recommendationsPrompt = `
        Based on the following feedback summary from users of a radiation oncology educational website, provide 3-5 specific recommendations for improvement.
        
        General Feedback Statistics:
        - Total feedback: ${generalStats.total}
        - Sentiment: ${generalStats.bySentiment.positive} positive, ${generalStats.bySentiment.neutral} neutral, ${generalStats.bySentiment.negative} negative
        - Priority: ${generalStats.byPriority.critical} critical, ${generalStats.byPriority.high} high, ${generalStats.byPriority.medium} medium, ${generalStats.byPriority.low} low
        
        Content Feedback Statistics:
        - Total content ratings: ${contentStats.total}
        - Helpful ratings: ${contentStats.helpful} (${(contentStats.helpfulnessRatio * 100).toFixed(0)}%)
        - Not helpful ratings: ${contentStats.notHelpful}
        
        Top Issues:
        ${topIssues.map(issue => `- ${issue.category} (${issue.subcategory}): "${issue.text}"`).join('\n')}
        
        Provide actionable recommendations in JSON format:
        [
          {
            "area": "...",
            "recommendation": "...",
            "priority": "high/medium/low",
            "implementation_difficulty": "easy/moderate/difficult"
          }
        ]
        `;
        
        const response = await openai.createCompletion({
          model: "text-davinci-003",
          prompt: recommendationsPrompt,
          max_tokens: 1000,
          temperature: 0.5,
        });
        
        // Parse the JSON response
        const responseText = response.data.choices[0].text.trim();
        let recommendations;
        
        try {
          recommendations = JSON.parse(responseText);
        } catch (error) {
          // If JSON parsing fails, try to extract JSON portion
          const jsonMatch = responseText.match(/\[\s*\{.*\}\s*\]/s);
          if (jsonMatch) {
            recommendations = JSON.parse(jsonMatch[0]);
          }
        }
        
        if (recommendations) {
          summary.recommendations = recommendations;
        }
      } catch (error) {
        console.error('Error generating recommendations:', error);
      }
    }
    
    // Generate report
    const reportDir = path.join(__dirname, '../feedback_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(
      reportDir, 
      `feedback_summary_${timeframe}_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify(summary, null, 2));
    
    console.log(`Feedback summary generated. Report saved to ${reportPath}`);
    return { reportPath, summary };
  } catch (error) {
    console.error('Error generating feedback summary:', error);
    sendAlert(
      'Error in feedback summary generation',
      `Failed to generate feedback summary: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  } finally {
    await client.close();
  }
}

// Run feedback analysis
async function runFeedbackAnalysis() {
  try {
    console.log('Processing new feedback...');
    await processNewFeedback();
    
    console.log('Generating weekly feedback summary...');
    const { reportPath, summary } = await generateFeedbackSummary('week');
    
    // Send summary alert
    sendAlert(
      'Weekly feedback summary generated',
      `Received ${summary.generalFeedback.total} general feedback items and ${summary.contentFeedback.total} content ratings this week`,
      SEVERITY.INFO,
      { reportPath }
    );
    
    return reportPath;
  } catch (error) {
    console.error('Error running feedback analysis:', error);
  }
}

// Check if this script is being run directly
if (require.main === module) {
  runFeedbackAnalysis();
}

module.exports = {
  runFeedbackAnalysis,
  processNewFeedback,
  generateFeedbackSummary,
  categorizeFeedback
};
```

### 2. Feedback Response System

```javascript
// File: /home/username/feedback_scripts/feedback_response.js
const fs = require('fs');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');
const { Configuration, OpenAIApi } = require('openai');
const nodemailer = require('nodemailer');
const { sendAlert, SEVERITY } = require('../monitoring_scripts/alert_manager');

// MongoDB connection
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

// OpenAI configuration
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

// Email configuration
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: process.env.EMAIL_SECURE === 'true',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

// Generate response to feedback
async function generateFeedbackResponse(feedback) {
  try {
    const prompt = `
    Generate a personalized response to the following user feedback for a radiation oncology educational website.
    
    Feedback type: ${feedback.feedbackType}
    Feedback: "${feedback.feedbackText}"
    Analysis: ${JSON.stringify(feedback.analysis)}
    
    The response should:
    1. Thank the user for their feedback
    2. Acknowledge their specific points
    3. Explain what actions will be taken (if applicable)
    4. Be professional, empathetic, and helpful
    5. Be concise (100-150 words)
    
    Write the response in a way that can be sent directly to the user.
    `;
    
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      max_tokens: 300,
      temperature: 0.7,
    });
    
    return response.data.choices[0].text.trim();
  } catch (error) {
    console.error('Error generating feedback response:', error);
    return `Thank you for your feedback regarding ${feedback.feedbackType}. We appreciate you taking the time to share your thoughts with us. Your input is valuable and helps us improve the Radiation Oncology Academy. We'll review your comments and take appropriate action. If you have any further questions or concerns, please don't hesitate to contact us.`;
  }
}

// Send response email
async function sendResponseEmail(feedback, responseText) {
  try {
    // Get user email from database
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const usersCollection = database.collection('users');
    
    const user = await usersCollection.findOne({ _id: new ObjectId(feedback.userId) });
    
    if (!user || !user.email) {
      console.log(`No email found for user ${feedback.userId}`);
      return false;
    }
    
    // Send email
    const mailOptions = {
      from: `"Radiation Oncology Academy" <${process.env.EMAIL_USER}>`,
      to: user.email,
      subject: 'Response to Your Feedback',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #4a90e2; padding: 20px; text-align: center;">
            <h1 style="color: white; margin: 0;">Radiation Oncology Academy</h1>
          </div>
          <div style="padding: 20px; border: 1px solid #e0e0e0; border-top: none;">
            <p>Dear ${user.name || 'Valued Member'},</p>
            
            <p>${responseText}</p>
            
            <p style="margin-top: 30px;">Best regards,</p>
            <p>The Radiation Oncology Academy Team</p>
          </div>
          <div style="background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #666;">
            <p>This is an automated response to feedback you submitted on ${new Date(feedback.createdAt).toLocaleDateString()}.</p>
            <p>If you need further assistance, please reply to this email.</p>
          </div>
        </div>
      `
    };
    
    const info = await transporter.sendMail(mailOptions);
    console.log(`Email sent: ${info.messageId}`);
    return true;
  } catch (error) {
    console.error('Error sending response email:', error);
    return false;
  } finally {
    await client.close();
  }
}

// Update feedback with response
async function updateFeedbackWithResponse(feedbackId, responseText, emailSent) {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection('feedbacks');
    
    const updateResult = await collection.updateOne(
      { _id: new ObjectId(feedbackId) },
      {
        $set: {
          adminResponse: responseText,
          respondedBy: 'Automated Response System',
          respondedAt: new Date(),
          emailSent,
          status: 'resolved'
        }
      }
    );
    
    return {
      feedbackId,
      updated: updateResult.modifiedCount > 0
    };
  } catch (error) {
    console.error(`Error updating feedback ${feedbackId} with response:`, error);
    throw error;
  } finally {
    await client.close();
  }
}

// Process feedback that needs response
async function processFeedbackResponses() {
  try {
    await client.connect();
    const database = client.db('radiationOncologyAcademy');
    const collection = database.collection('feedbacks');
    
    // Find analyzed feedback that needs response
    const feedbackNeedingResponse = await collection.find({
      analyzed: true,
      status: { $in: ['new', 'in_progress'] },
      adminResponse: { $exists: false }
    })
    .limit(10)
    .toArray();
    
    console.log(`Found ${feedbackNeedingResponse.length} feedback items needing response`);
    
    const results = {
      processed: [],
      errors: [],
      timestamp: new Date().toISOString()
    };
    
    // Process each feedback item
    for (const feedback of feedbackNeedingResponse) {
      try {
        // Generate response
        const responseText = await generateFeedbackResponse(feedback);
        
        // Send email if possible
        const emailSent = await sendResponseEmail(feedback, responseText);
        
        // Update feedback with response
        await updateFeedbackWithResponse(
          feedback._id.toString(),
          responseText,
          emailSent
        );
        
        results.processed.push({
          feedbackId: feedback._id.toString(),
          responseText,
          emailSent
        });
      } catch (error) {
        console.error(`Error processing response for feedback ${feedback._id}:`, error);
        results.errors.push({
          feedbackId: feedback._id.toString(),
          error: error.message
        });
      }
    }
    
    // Generate report
    const reportDir = path.join(__dirname, '../feedback_reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportPath = path.join(
      reportDir, 
      `feedback_responses_${new Date().toISOString().split('T')[0]}.json`
    );
    
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
    
    console.log(`Feedback responses completed. Report saved to ${reportPath}`);
    return reportPath;
  } catch (error) {
    console.error('Error processing feedback responses:', error);
    sendAlert(
      'Error in feedback response system',
      `Failed to process feedback responses: ${error.message}`,
      SEVERITY.ERROR,
      { stack: error.stack }
    );
    throw error;
  } finally {
    await client.close();
  }
}

// Run feedback response system
async function runFeedbackResponseSystem() {
  try {
    console.log('Processing feedback responses...');
    const reportPath = await processFeedbackResponses();
    
    return reportPath;
  } catch (error) {
    console.error('Error running feedback response system:', error);
  }
}

// Check if this script is being run directly
if (require.main === module) {
  runFeedbackResponseSystem();
}

module.exports = {
  runFeedbackResponseSystem,
  processFeedbackResponses,
  generateFeedbackResponse,
  sendResponseEmail
};
```

## Feedback Analysis Workflow

### 1. Admin Dashboard for Feedback Management

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/app/admin/feedback/page.tsx
import React, { useState, useEffect } from 'react';
import { 
  Container, Typography, Box, Tabs, Tab, Paper, Table, TableBody, 
  TableCell, TableContainer, TableHead, TableRow, Chip, Button,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField,
  FormControl, InputLabel, Select, MenuItem
} from '@mui/material';
import { 
  CheckCircle as ResolvedIcon,
  Error as NewIcon,
  HourglassEmpty as InProgressIcon,
  Block as ClosedIcon,
  ThumbUp as PositiveIcon,
  ThumbDown as NegativeIcon,
  Remove as NeutralIcon
} from '@mui/icons-material';

interface FeedbackItem {
  _id: string;
  feedbackType: string;
  feedbackText: string;
  createdAt: string;
  status: 'new' | 'in_progress' | 'resolved' | 'closed';
  analysis?: {
    primary_category: string;
    subcategory: string;
    sentiment: 'positive' | 'neutral' | 'negative';
    priority: 'low' | 'medium' | 'high' | 'critical';
    topics: string[];
    suggested_action: string;
  };
  adminResponse?: string;
}

const FeedbackDashboard: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);
  const [feedback, setFeedback] = useState<FeedbackItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFeedback, setSelectedFeedback] = useState<FeedbackItem | null>(null);
  const [responseDialogOpen, setResponseDialogOpen] = useState(false);
  const [responseText, setResponseText] = useState('');
  const [newStatus, setNewStatus] = useState('');
  
  useEffect(() => {
    fetchFeedback();
  }, [tabValue]);
  
  const fetchFeedback = async () => {
    setLoading(true);
    try {
      // Map tab value to status
      const statusMap = ['new', 'in_progress', 'resolved', 'closed'];
      const status = statusMap[tabValue];
      
      const response = await fetch(`/api/admin/feedback?status=${status}`);
      const data = await response.json();
      
      if (data.success) {
        setFeedback(data.feedback);
      } else {
        console.error('Failed to fetch feedback:', data.message);
      }
    } catch (error) {
      console.error('Error fetching feedback:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  const handleResponseClick = (item: FeedbackItem) => {
    setSelectedFeedback(item);
    setResponseText(item.adminResponse || '');
    setNewStatus(item.status);
    setResponseDialogOpen(true);
  };
  
  const handleResponseSubmit = async () => {
    if (!selectedFeedback) return;
    
    try {
      const response = await fetch(`/api/admin/feedback/${selectedFeedback._id}/respond`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          response: responseText,
          status: newStatus
        }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Update local state
        setFeedback(prev => prev.map(item => 
          item._id === selectedFeedback._id 
            ? { ...item, adminResponse: responseText, status: newStatus as any } 
            : item
        ));
        
        setResponseDialogOpen(false);
        
        // If status changed, refresh the list
        if (newStatus !== selectedFeedback.status) {
          fetchFeedback();
        }
      } else {
        console.error('Failed to submit response:', data.message);
      }
    } catch (error) {
      console.error('Error submitting response:', error);
    }
  };
  
  const getSentimentIcon = (sentiment?: string) => {
    switch (sentiment) {
      case 'positive':
        return <PositiveIcon color="success" />;
      case 'negative':
        return <NegativeIcon color="error" />;
      default:
        return <NeutralIcon color="action" />;
    }
  };
  
  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      case 'low':
        return 'success';
      default:
        return 'default';
    }
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'new':
        return <NewIcon color="error" />;
      case 'in_progress':
        return <InProgressIcon color="warning" />;
      case 'resolved':
        return <ResolvedIcon color="success" />;
      case 'closed':
        return <ClosedIcon color="action" />;
      default:
        return null;
    }
  };
  
  return (
    <Container maxWidth="xl">
      <Typography variant="h4" component="h1" gutterBottom sx={{ mt: 4 }}>
        Feedback Management
      </Typography>
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="New" icon={<NewIcon />} />
          <Tab label="In Progress" icon={<InProgressIcon />} />
          <Tab label="Resolved" icon={<ResolvedIcon />} />
          <Tab label="Closed" icon={<ClosedIcon />} />
        </Tabs>
      </Box>
      
      {loading ? (
        <Typography>Loading feedback...</Typography>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Type</TableCell>
                <TableCell>Feedback</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Sentiment</TableCell>
                <TableCell>Priority</TableCell>
                <TableCell>Date</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {feedback.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    No feedback found in this category
                  </TableCell>
                </TableRow>
              ) : (
                feedback.map((item) => (
                  <TableRow key={item._id}>
                    <TableCell>
                      <Chip label={item.feedbackType} />
                    </TableCell>
                    <TableCell>
                      {item.feedbackText.length > 100 
                        ? `${item.feedbackText.substring(0, 100)}...` 
                        : item.feedbackText}
                    </TableCell>
                    <TableCell>
                      {item.analysis ? (
                        <Chip 
                          label={item.analysis.primary_category} 
                          size="small"
                        />
                      ) : (
                        'Uncategorized'
                      )}
                    </TableCell>
                    <TableCell>
                      {item.analysis ? getSentimentIcon(item.analysis.sentiment) : '-'}
                    </TableCell>
                    <TableCell>
                      {item.analysis ? (
                        <Chip 
                          label={item.analysis.priority} 
                          color={getPriorityColor(item.analysis.priority) as any}
                          size="small"
                        />
                      ) : (
                        '-'
                      )}
                    </TableCell>
                    <TableCell>
                      {new Date(item.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Button 
                        variant="outlined" 
                        size="small"
                        onClick={() => handleResponseClick(item)}
                      >
                        {item.adminResponse ? 'Edit Response' : 'Respond'}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      
      {/* Response Dialog */}
      <Dialog open={responseDialogOpen} onClose={() => setResponseDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Respond to Feedback</DialogTitle>
        <DialogContent>
          {selectedFeedback && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle1" gutterBottom>
                Feedback Details:
              </Typography>
              <Paper sx={{ p: 2, mb: 3, bgcolor: '#f5f5f5' }}>
                <Typography variant="body1">
                  {selectedFeedback.feedbackText}
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                  <Chip label={selectedFeedback.feedbackType} size="small" />
                  {selectedFeedback.analysis && (
                    <>
                      <Chip label={selectedFeedback.analysis.primary_category} size="small" />
                      <Chip 
                        label={selectedFeedback.analysis.priority} 
                        color={getPriorityColor(selectedFeedback.analysis.priority) as any}
                        size="small"
                      />
                    </>
                  )}
                </Box>
              </Paper>
              
              {selectedFeedback.analysis && (
                <Box sx={{ mb: 3 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    AI Analysis:
                  </Typography>
                  <Paper sx={{ p: 2, bgcolor: '#f0f7ff' }}>
                    <Typography variant="body2" gutterBottom>
                      <strong>Category:</strong> {selectedFeedback.analysis.primary_category} &gt; {selectedFeedback.analysis.subcategory}
                    </Typography>
                    <Typography variant="body2" gutterBottom>
                      <strong>Sentiment:</strong> {selectedFeedback.analysis.sentiment}
                    </Typography>
                    <Typography variant="body2" gutterBottom>
                      <strong>Priority:</strong> {selectedFeedback.analysis.priority}
                    </Typography>
                    <Typography variant="body2" gutterBottom>
                      <strong>Topics:</strong> {selectedFeedback.analysis.topics.join(', ')}
                    </Typography>
                    <Typography variant="body2">
                      <strong>Suggested Action:</strong> {selectedFeedback.analysis.suggested_action}
                    </Typography>
                  </Paper>
                </Box>
              )}
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Status</InputLabel>
                <Select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  label="Status"
                >
                  <MenuItem value="new">New</MenuItem>
                  <MenuItem value="in_progress">In Progress</MenuItem>
                  <MenuItem value="resolved">Resolved</MenuItem>
                  <MenuItem value="closed">Closed</MenuItem>
                </Select>
              </FormControl>
              
              <TextField
                label="Response"
                multiline
                rows={6}
                value={responseText}
                onChange={(e) => setResponseText(e.target.value)}
                fullWidth
                margin="normal"
                placeholder="Enter your response to this feedback..."
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setResponseDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleResponseSubmit} variant="contained" color="primary">
            Submit Response
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default FeedbackDashboard;
```

### 2. Feedback Analytics Dashboard

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/app/admin/feedback/analytics/page.tsx
import React, { useState, useEffect } from 'react';
import { 
  Container, Typography, Box, Paper, Grid, Card, CardContent,
  FormControl, InputLabel, Select, MenuItem, Divider,
  List, ListItem, ListItemText, ListItemIcon
} from '@mui/material';
import {
  PieChart, Pie, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  Cell, ResponsiveContainer, LineChart, Line
} from 'recharts';
import {
  ThumbUp as ThumbUpIcon,
  ThumbDown as ThumbDownIcon,
  PriorityHigh as PriorityIcon,
  Lightbulb as IdeaIcon
} from '@mui/icons-material';

interface FeedbackSummary {
  timeframe: string;
  period: string;
  generalFeedback: {
    total: number;
    byType: Record<string, number>;
    byCategory: Record<string, number>;
    bySentiment: {
      positive: number;
      neutral: number;
      negative: number;
    };
    byPriority: {
      low: number;
      medium: number;
      high: number;
      critical: number;
    };
  };
  contentFeedback: {
    total: number;
    helpful: number;
    notHelpful: number;
    helpfulnessRatio: string;
    byContentType: Record<string, number>;
  };
  topIssues: Array<{
    category: string;
    subcategory: string;
    priority: string;
    text: string;
  }>;
  topPraise: Array<{
    category: string;
    subcategory: string;
    text: string;
  }>;
  recommendations: Array<{
    area: string;
    recommendation: string;
    priority: string;
    implementation_difficulty: string;
  }>;
}

const FeedbackAnalytics: React.FC = () => {
  const [timeframe, setTimeframe] = useState('week');
  const [summary, setSummary] = useState<FeedbackSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [trendData, setTrendData] = useState<any[]>([]);
  
  useEffect(() => {
    fetchSummary();
    fetchTrendData();
  }, [timeframe]);
  
  const fetchSummary = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/admin/feedback/summary?timeframe=${timeframe}`);
      const data = await response.json();
      
      if (data.success) {
        setSummary(data.summary);
      } else {
        console.error('Failed to fetch feedback summary:', data.message);
      }
    } catch (error) {
      console.error('Error fetching feedback summary:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const fetchTrendData = async () => {
    try {
      const response = await fetch('/api/admin/feedback/trends');
      const data = await response.json();
      
      if (data.success) {
        setTrendData(data.trends);
      } else {
        console.error('Failed to fetch trend data:', data.message);
      }
    } catch (error) {
      console.error('Error fetching trend data:', error);
    }
  };
  
  const handleTimeframeChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    setTimeframe(event.target.value as string);
  };
  
  // Prepare chart data
  const prepareSentimentData = () => {
    if (!summary) return [];
    
    const { positive, neutral, negative } = summary.generalFeedback.bySentiment;
    
    return [
      { name: 'Positive', value: positive, color: '#4caf50' },
      { name: 'Neutral', value: neutral, color: '#2196f3' },
      { name: 'Negative', value: negative, color: '#f44336' }
    ];
  };
  
  const preparePriorityData = () => {
    if (!summary) return [];
    
    const { low, medium, high, critical } = summary.generalFeedback.byPriority;
    
    return [
      { name: 'Low', value: low, color: '#4caf50' },
      { name: 'Medium', value: medium, color: '#2196f3' },
      { name: 'High', value: high, color: '#ff9800' },
      { name: 'Critical', value: critical, color: '#f44336' }
    ];
  };
  
  const prepareCategoryData = () => {
    if (!summary) return [];
    
    return Object.entries(summary.generalFeedback.byCategory).map(([category, count]) => ({
      name: category,
      value: count
    }));
  };
  
  const prepareContentTypeData = () => {
    if (!summary) return [];
    
    return Object.entries(summary.contentFeedback.byContentType).map(([type, count]) => ({
      name: type,
      value: count
    }));
  };
  
  const prepareHelpfulnessData = () => {
    if (!summary) return [];
    
    return [
      { name: 'Helpful', value: summary.contentFeedback.helpful, color: '#4caf50' },
      { name: 'Not Helpful', value: summary.contentFeedback.notHelpful, color: '#f44336' }
    ];
  };
  
  return (
    <Container maxWidth="xl">
      <Typography variant="h4" component="h1" gutterBottom sx={{ mt: 4 }}>
        Feedback Analytics
      </Typography>
      
      <Box sx={{ mb: 4 }}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Timeframe</InputLabel>
          <Select
            value={timeframe}
            onChange={handleTimeframeChange as any}
            label="Timeframe"
          >
            <MenuItem value="day">Last 24 Hours</MenuItem>
            <MenuItem value="week">Last 7 Days</MenuItem>
            <MenuItem value="month">Last 30 Days</MenuItem>
          </Select>
        </FormControl>
      </Box>
      
      {loading ? (
        <Typography>Loading analytics...</Typography>
      ) : summary ? (
        <>
          {/* Summary Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary" gutterBottom>
                    Total Feedback
                  </Typography>
                  <Typography variant="h4">
                    {summary.generalFeedback.total}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary" gutterBottom>
                    Content Ratings
                  </Typography>
                  <Typography variant="h4">
                    {summary.contentFeedback.total}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary" gutterBottom>
                    Helpfulness Ratio
                  </Typography>
                  <Typography variant="h4">
                    {Math.round(parseFloat(summary.contentFeedback.helpfulnessRatio) * 100)}%
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary" gutterBottom>
                    Critical Issues
                  </Typography>
                  <Typography variant="h4">
                    {summary.generalFeedback.byPriority.critical}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          
          {/* Charts */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Feedback by Sentiment
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={prepareSentimentData()}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {prepareSentimentData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Feedback by Priority
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={preparePriorityData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Count">
                      {preparePriorityData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Feedback by Category
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={prepareCategoryData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={150} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Content Helpfulness
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={prepareHelpfulnessData()}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {prepareHelpfulnessData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
            
            <Grid item xs={12}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Feedback Trends
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart
                    data={trendData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="total" name="Total Feedback" stroke="#8884d8" />
                    <Line type="monotone" dataKey="positive" name="Positive" stroke="#4caf50" />
                    <Line type="monotone" dataKey="negative" name="Negative" stroke="#f44336" />
                  </LineChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
          </Grid>
          
          {/* Issues and Recommendations */}
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Top Issues
                </Typography>
                <List>
                  {summary.topIssues.map((issue, index) => (
                    <ListItem key={index} alignItems="flex-start">
                      <ListItemIcon>
                        <ThumbDownIcon color="error" />
                      </ListItemIcon>
                      <ListItemText
                        primary={`${issue.category} > ${issue.subcategory}`}
                        secondary={
                          <>
                            <Typography component="span" variant="body2" color="text.primary">
                              Priority: {issue.priority}
                            </Typography>
                            <br />
                            {issue.text}
                          </>
                        }
                      />
                    </ListItem>
                  ))}
                </List>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Recommendations
                </Typography>
                <List>
                  {summary.recommendations.map((rec, index) => (
                    <ListItem key={index} alignItems="flex-start">
                      <ListItemIcon>
                        <IdeaIcon color="primary" />
                      </ListItemIcon>
                      <ListItemText
                        primary={rec.area}
                        secondary={
                          <>
                            <Typography component="span" variant="body2" color="text.primary">
                              Priority: {rec.priority} | Difficulty: {rec.implementation_difficulty}
                            </Typography>
                            <br />
                            {rec.recommendation}
                          </>
                        }
                      />
                    </ListItem>
                  ))}
                </List>
              </Paper>
            </Grid>
          </Grid>
        </>
      ) : (
        <Typography>No feedback data available for the selected timeframe.</Typography>
      )}
    </Container>
  );
};

export default FeedbackAnalytics;
```

## Feedback Schedule

The following schedule establishes a regular cadence for feedback collection and analysis:

### Daily Tasks

1. **Feedback Processing**
   - Schedule: Every day at 2 AM
   - Process:
     - Run `analyze_feedback.js` to categorize new feedback
     - Generate automated responses for appropriate feedback items
     - Update feedback status in database

2. **Critical Issue Alerts**
   - Schedule: Real-time
   - Process:
     - Monitor for high-priority or critical feedback
     - Send immediate alerts to administrators
     - Track response time for critical issues

### Weekly Tasks

1. **Feedback Summary Generation**
   - Schedule: Every Monday at 3 AM
   - Process:
     - Run `generateFeedbackSummary('week')` to create weekly report
     - Send summary to administrators
     - Update analytics dashboard with new data

2. **Content Feedback Analysis**
   - Schedule: Every Wednesday at 3 AM
   - Process:
     - Analyze content-specific feedback
     - Identify content with low helpfulness ratings
     - Flag content for review and improvement

3. **Survey Rotation**
   - Schedule: Every Friday at 12 PM
   - Process:
     - Update active surveys based on schedule
     - Analyze completed survey responses
     - Prepare new surveys for upcoming weeks

### Monthly Tasks

1. **Comprehensive Feedback Analysis**
   - Schedule: First day of each month at 4 AM
   - Process:
     - Generate monthly feedback report
     - Identify trends and patterns
     - Create action items based on feedback

2. **User Experience Review**
   - Schedule: 15th of each month
   - Process:
     - Review all UX-related feedback
     - Prioritize UX improvements
     - Schedule implementation of high-priority changes

3. **Feedback System Optimization**
   - Schedule: Last day of each month
   - Process:
     - Review feedback collection mechanisms
     - Optimize survey questions
     - Update feedback categorization system

### Quarterly Tasks

1. **Feedback-Driven Roadmap Update**
   - Schedule: First week of each quarter
   - Process:
     - Analyze all feedback from previous quarter
     - Identify major themes and priorities
     - Update product roadmap based on user feedback

2. **User Satisfaction Measurement**
   - Schedule: Middle of each quarter
   - Process:
     - Conduct comprehensive satisfaction survey
     - Compare results to previous quarters
     - Identify areas for improvement

## Cron Job Configuration

Add the following to the server's crontab to automate the feedback system:

```
# Daily feedback processing (2 AM)
0 2 * * * /usr/bin/node /home/username/feedback_scripts/analyze_feedback.js >> /home/username/logs/feedback_analysis.log 2>&1

# Daily feedback response processing (4 AM)
0 4 * * * /usr/bin/node /home/username/feedback_scripts/feedback_response.js >> /home/username/logs/feedback_response.log 2>&1

# Weekly feedback summary (Monday at 3 AM)
0 3 * * 1 /usr/bin/node /home/username/feedback_scripts/analyze_feedback.js --summary=week >> /home/username/logs/feedback_summary.log 2>&1

# Monthly feedback analysis (1st of month at 4 AM)
0 4 1 * * /usr/bin/node /home/username/feedback_scripts/analyze_feedback.js --summary=month >> /home/username/logs/monthly_analysis.log 2>&1
```

## GoDaddy-Specific Implementation

Since GoDaddy shared hosting has some limitations, the following adjustments are necessary:

1. Use GoDaddy's cPanel for cron job setup:
   - Access cPanel > Advanced > Cron Jobs
   - Add each cron job as specified in the schedule
   - Ensure proper paths to Node.js executable

2. Configure scripts to work within GoDaddy's environment:
   - Use relative paths compatible with GoDaddy's directory structure
   - Ensure scripts have proper execution permissions
   - Work within GoDaddy's resource limitations

3. For email functionality:
   - Use GoDaddy's SMTP server for sending feedback responses
   - Configure email settings in the .env file

## Implementation Steps

1. Create the feedback components directory structure:
   ```bash
   mkdir -p /home/username/public_html/radiation_oncology_academy/frontend/components/feedback
   mkdir -p /home/username/public_html/radiation_oncology_academy/frontend/app/admin/feedback/analytics
   mkdir -p /home/username/feedback_scripts
   mkdir -p /home/username/feedback_reports
   mkdir -p /home/username/logs
   ```

2. Create the feedback components and pages as outlined above

3. Create the backend models and controllers for feedback

4. Create the feedback analysis and response scripts

5. Make the scripts executable:
   ```bash
   chmod +x /home/username/feedback_scripts/*.js
   ```

6. Install required packages:
   ```bash
   cd /home/username/public_html/radiation_oncology_academy
   npm install nodemailer openai recharts @mui/icons-material --save
   ```

7. Set up cron jobs through GoDaddy cPanel:
   - Access cPanel > Advanced > Cron Jobs
   - Add each cron job as specified in the schedule

8. Test each feedback component and script manually to ensure it works correctly

9. Document the feedback system in the admin guide

## Conclusion

This user feedback system provides a comprehensive approach to collecting, analyzing, and responding to user feedback for the Radiation Oncology Academy website with:
- Multiple feedback collection interfaces for different contexts
- AI-powered feedback categorization and analysis
- Automated response generation for timely communication
- Comprehensive analytics dashboard for data-driven decisions
- Structured workflow for continuous improvement

The system is designed to be compatible with GoDaddy hosting while providing robust feedback management capabilities to enhance user experience and guide future development of the platform.
