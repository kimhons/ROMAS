# Android Build Environment Setup

## Overview
This document outlines the setup process for the Android build environment for the Radiation Oncology Academy app submission.

## Prerequisites
- Linux, macOS, or Windows development machine
- Android Studio (latest version)
- JDK 11 or newer
- Node.js and npm
- React Native CLI
- Google Play Developer account credentials

## Environment Configuration Steps

### 1. Android Studio Installation and Configuration
- Download and install Android Studio from [developer.android.com](https://developer.android.com/studio)
- During installation, ensure the following components are selected:
  - Android SDK
  - Android SDK Platform
  - Android Virtual Device
  - Performance (Intel HAXM)
- Configure Android SDK:
  - Open Android Studio > Preferences > Appearance & Behavior > System Settings > Android SDK
  - Select SDK Platforms tab and install:
    - Android 12 (API Level 31)
    - Android 11 (API Level 30)
    - Android 10 (API Level 29)
  - Select SDK Tools tab and install:
    - Android SDK Build-Tools
    - NDK
    - Android SDK Command-line Tools
    - Android Emulator

### 2. Environment Variables Setup
- Set ANDROID_HOME environment variable:
  - Linux/macOS:
    ```bash
    export ANDROID_HOME=$HOME/Android/Sdk
    export PATH=$PATH:$ANDROID_HOME/tools
    export PATH=$PATH:$ANDROID_HOME/tools/bin
    export PATH=$PATH:$ANDROID_HOME/platform-tools
    ```
  - Windows:
    ```
    setx ANDROID_HOME "%LOCALAPPDATA%\Android\Sdk"
    setx PATH "%PATH%;%ANDROID_HOME%\tools;%ANDROID_HOME%\tools\bin;%ANDROID_HOME%\platform-tools"
    ```
- Verify environment variables:
  ```bash
  echo $ANDROID_HOME
  ```

### 3. React Native Environment Setup
- Install Node.js and npm:
  ```bash
  # Using nvm (recommended)
  nvm install 16
  nvm use 16
  ```
- Install React Native CLI:
  ```bash
  npm install -g react-native-cli
  ```

### 4. Project Configuration
- Clone project repository:
  ```bash
  git clone https://github.com/radiation-oncology-academy/mobile-app.git
  cd mobile-app
  ```
- Install JavaScript dependencies:
  ```bash
  npm install
  ```

### 5. Build Configuration
- Update app version in `android/app/build.gradle`:
  ```gradle
  defaultConfig {
      applicationId "com.radiationoncologyacademy.mobile"
      minSdkVersion rootProject.ext.minSdkVersion
      targetSdkVersion rootProject.ext.targetSdkVersion
      versionCode 1
      versionName "1.0.0"
  }
  ```
- Configure signing config in `android/app/build.gradle`:
  ```gradle
  signingConfigs {
      release {
          storeFile file('radiation-oncology-academy.keystore')
          storePassword 'your-store-password'
          keyAlias 'your-key-alias'
          keyPassword 'your-key-password'
      }
  }
  ```
- Set up environment variables for production:
  ```bash
  echo "API_URL=https://api.radiationoncologyacademy.com/v1" > .env.production
  echo "ANALYTICS_KEY=production_key_here" >> .env.production
  ```

### 6. Keystore Generation
- Generate keystore for app signing:
  ```bash
  keytool -genkeypair -v -storetype PKCS12 -keystore radiation-oncology-academy.keystore -alias radiation-oncology-academy -keyalg RSA -keysize 2048 -validity 10000
  ```
- Move keystore to `android/app/` directory:
  ```bash
  mv radiation-oncology-academy.keystore android/app/
  ```
- Document keystore details securely:
  - Store password
  - Key alias
  - Key password
  - Keystore location

### 7. Build Verification
- Run development build to verify environment:
  ```bash
  npx react-native run-android
  ```
- Verify app launches successfully on emulator
- Test basic functionality to ensure environment is correctly configured

## Next Steps
After successfully setting up the Android build environment:
1. Configure Google Play Developer Console
2. Create and sign Android production build
3. Verify build on physical devices
4. Prepare for Google Play submission

## Troubleshooting
- If Android Studio installation fails:
  - Verify system meets requirements
  - Try downloading installer directly instead of using IDE
  - Check disk space availability

- If environment variables aren't recognized:
  - Restart terminal/command prompt
  - Verify paths are correct for your system
  - On Windows, restart computer after setting environment variables

- If React Native build fails:
  - Check for Java version conflicts:
    ```bash
    java -version
    ```
  - Ensure ANDROID_HOME points to correct location
  - Try clearing build cache:
    ```bash
    cd android
    ./gradlew clean
    ```

## Documentation
- [React Native Environment Setup](https://reactnative.dev/docs/environment-setup)
- [Android Studio Documentation](https://developer.android.com/studio/intro)
- [Google Play Developer Console](https://play.google.com/console/about/)
- [Android App Signing](https://developer.android.com/studio/publish/app-signing)
