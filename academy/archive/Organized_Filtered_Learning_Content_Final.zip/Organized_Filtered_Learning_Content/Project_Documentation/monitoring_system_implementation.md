# Monitoring System Implementation for Radiation Oncology Academy

## Overview

This document outlines the implementation of a comprehensive monitoring system for the Radiation Oncology Academy website hosted on GoDaddy. The monitoring system will track website uptime, performance metrics, user experience, and system health to ensure optimal operation and quick response to any issues.

## Monitoring Components

The monitoring system will cover:
1. Website uptime and availability
2. Performance metrics (load time, response time)
3. Server resource utilization
4. Database performance and health
5. API endpoint functionality
6. User experience metrics
7. Error tracking and logging

## Monitoring Solutions

### Uptime Monitoring with UptimeRobot

UptimeRobot offers a free tier that monitors up to 50 endpoints with 5-minute check intervals, which is suitable for our needs.

#### Implementation Steps:

1. Create an account at [UptimeRobot](https://uptimerobot.com/)
2. Add the following monitors:
   - Main website: `https://radiationoncologyacademy.com`
   - API endpoint: `https://radiationoncologyacademy.com/api/health`
   - Login page: `https://radiationoncologyacademy.com/auth/login`
   - Course pages: `https://radiationoncologyacademy.com/courses`
   - Membership page: `https://radiationoncologyacademy.com/membership`

3. Configure alert settings:
   - Email notifications to: `admin@radiationoncologyacademy.com`
   - SMS alerts for critical downtime (optional paid feature)
   - Set alert threshold to 5 minutes of downtime

4. Create a status page that can be accessed by administrators

### Performance Monitoring with Google Analytics and Lighthouse

#### Google Analytics Implementation:

1. Create a Google Analytics 4 property for the website
2. Add the following tracking code to the website's `<head>` section:

```javascript
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

3. Set up custom events to track:
   - Page load time
   - Time to interactive
   - First contentful paint
   - User interactions with key features

#### Automated Lighthouse Testing:

1. Create a script to run Lighthouse tests daily:

```javascript
// File: /home/username/monitoring_scripts/lighthouse_test.js
const lighthouse = require('lighthouse');
const chromeLauncher = require('chrome-launcher');
const fs = require('fs');
const path = require('path');

const urls = [
  'https://radiationoncologyacademy.com',
  'https://radiationoncologyacademy.com/courses',
  'https://radiationoncologyacademy.com/membership',
  'https://radiationoncologyacademy.com/blog'
];

const runLighthouse = async (url) => {
  const chrome = await chromeLauncher.launch({chromeFlags: ['--headless']});
  const options = {
    logLevel: 'info',
    output: 'json',
    port: chrome.port,
    onlyCategories: ['performance', 'accessibility', 'best-practices', 'seo']
  };
  
  const runnerResult = await lighthouse(url, options);
  await chrome.kill();
  
  const reportDir = path.join(__dirname, '../lighthouse_reports');
  if (!fs.existsSync(reportDir)) {
    fs.mkdirSync(reportDir, { recursive: true });
  }
  
  const date = new Date().toISOString().split('T')[0];
  const urlSlug = url.replace(/https?:\/\//, '').replace(/[^\w]/g, '_');
  const reportPath = path.join(reportDir, `${date}_${urlSlug}.json`);
  
  fs.writeFileSync(reportPath, JSON.stringify(runnerResult.lhr, null, 2));
  
  // Alert if performance score is below threshold
  if (runnerResult.lhr.categories.performance.score < 0.7) {
    console.error(`Performance issue detected on ${url}: Score ${runnerResult.lhr.categories.performance.score * 100}/100`);
    // Send email alert
    // Code for sending email alert would go here
  }
  
  return runnerResult;
};

const runAllTests = async () => {
  for (const url of urls) {
    await runLighthouse(url);
  }
};

runAllTests();
```

2. Set up a cron job to run this script daily:

```
0 1 * * * cd /home/username/monitoring_scripts && node lighthouse_test.js >> /home/username/logs/lighthouse.log 2>&1
```

### Server Monitoring with New Relic

New Relic offers a free tier that provides basic server monitoring capabilities.

#### Implementation Steps:

1. Sign up for a New Relic account
2. Install the New Relic Node.js agent:

```bash
npm install newrelic --save
```

3. Create a newrelic.js configuration file in the project root:

```javascript
// File: /home/username/public_html/radiation_oncology_academy/newrelic.js
'use strict'

exports.config = {
  app_name: ['Radiation Oncology Academy'],
  license_key: 'your_license_key',
  logging: {
    level: 'info'
  },
  allow_all_headers: true,
  attributes: {
    exclude: [
      'request.headers.cookie',
      'request.headers.authorization',
      'request.headers.proxyAuthorization',
      'request.headers.setCookie*',
      'request.headers.x*',
      'response.headers.cookie',
      'response.headers.authorization',
      'response.headers.proxyAuthorization',
      'response.headers.setCookie*',
      'response.headers.x*'
    ]
  }
}
```

4. Require New Relic at the top of the main server file:

```javascript
// File: /home/username/public_html/radiation_oncology_academy/server.js
require('newrelic');
// Rest of server code
```

### Error Tracking with Sentry

Sentry provides error tracking and monitoring with a generous free tier.

#### Implementation Steps:

1. Create an account at [Sentry](https://sentry.io/)
2. Create a new project for Node.js
3. Install the Sentry SDK:

```bash
npm install @sentry/node @sentry/tracing --save
```

4. Initialize Sentry in the main server file:

```javascript
// File: /home/username/public_html/radiation_oncology_academy/server.js
const Sentry = require('@sentry/node');
const Tracing = require('@sentry/tracing');

Sentry.init({
  dsn: "your_sentry_dsn",
  integrations: [
    new Sentry.Integrations.Http({ tracing: true }),
    new Tracing.Integrations.Express({ app }),
  ],
  tracesSampleRate: 1.0,
});

// The rest of your server code
const app = express();

// RequestHandler creates a separate execution context
app.use(Sentry.Handlers.requestHandler());
// TracingHandler creates a trace for every incoming request
app.use(Sentry.Handlers.tracingHandler());

// All your controllers and routes

// The error handler must be before any other error middleware and after all controllers
app.use(Sentry.Handlers.errorHandler());
```

5. Add Sentry to the frontend as well:

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/app/layout.tsx
import * as Sentry from '@sentry/react';

Sentry.init({
  dsn: "your_sentry_dsn",
  integrations: [new Sentry.BrowserTracing()],
  tracesSampleRate: 0.5,
});

// Rest of your layout component
```

## Custom Health Check API Endpoint

Create a health check endpoint to monitor system components:

```javascript
// File: /home/username/public_html/radiation_oncology_academy/routes/health.routes.js
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

router.get('/health', async (req, res) => {
  try {
    // Check database connection
    const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
    
    // Check API services
    const openaiStatus = await checkOpenAIService();
    const elevenlabsStatus = await checkElevenLabsService();
    
    // Check storage
    const storageStatus = await checkGoogleCloudStorage();
    
    // System metrics
    const memoryUsage = process.memoryUsage();
    const uptime = process.uptime();
    
    res.json({
      status: 'ok',
      timestamp: new Date(),
      services: {
        database: dbStatus,
        openai: openaiStatus,
        elevenlabs: elevenlabsStatus,
        storage: storageStatus
      },
      system: {
        memory: {
          rss: Math.round(memoryUsage.rss / 1024 / 1024) + 'MB',
          heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024) + 'MB',
          heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024) + 'MB'
        },
        uptime: uptime + 's'
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

// Helper functions to check services
async function checkOpenAIService() {
  try {
    // Simple check to OpenAI API
    // Implementation depends on how OpenAI is integrated
    return 'ok';
  } catch (error) {
    return 'error: ' + error.message;
  }
}

async function checkElevenLabsService() {
  try {
    // Simple check to ElevenLabs API
    // Implementation depends on how ElevenLabs is integrated
    return 'ok';
  } catch (error) {
    return 'error: ' + error.message;
  }
}

async function checkGoogleCloudStorage() {
  try {
    // Check Google Cloud Storage
    // Implementation depends on how Google Cloud Storage is integrated
    return 'ok';
  } catch (error) {
    return 'error: ' + error.message;
  }
}

module.exports = router;
```

## Monitoring Dashboard

Create a simple admin dashboard to view all monitoring metrics in one place:

```javascript
// File: /home/username/public_html/radiation_oncology_academy/frontend/app/admin/monitoring/page.tsx
import React, { useEffect, useState } from 'react';
import { Card, Container, Grid, Typography } from '@mui/material';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

export default function MonitoringDashboard() {
  const [healthData, setHealthData] = useState(null);
  const [performanceData, setPerformanceData] = useState([]);
  const [uptimeData, setUptimeData] = useState([]);
  
  useEffect(() => {
    // Fetch health check data
    fetch('/api/health')
      .then(res => res.json())
      .then(data => setHealthData(data));
    
    // Fetch performance data
    fetch('/api/admin/monitoring/performance')
      .then(res => res.json())
      .then(data => setPerformanceData(data));
    
    // Fetch uptime data
    fetch('/api/admin/monitoring/uptime')
      .then(res => res.json())
      .then(data => setUptimeData(data));
  }, []);
  
  return (
    <Container maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom>
        System Monitoring Dashboard
      </Typography>
      
      <Grid container spacing={3}>
        {/* System Health Card */}
        <Grid item xs={12} md={6}>
          <Card>
            <Typography variant="h6" padding={2}>System Health</Typography>
            {healthData ? (
              <div>
                <Typography>Database: {healthData.services.database}</Typography>
                <Typography>OpenAI: {healthData.services.openai}</Typography>
                <Typography>ElevenLabs: {healthData.services.elevenlabs}</Typography>
                <Typography>Storage: {healthData.services.storage}</Typography>
                <Typography>Memory Usage: {healthData.system.memory.heapUsed}</Typography>
                <Typography>Uptime: {healthData.system.uptime}</Typography>
              </div>
            ) : (
              <Typography>Loading health data...</Typography>
            )}
          </Card>
        </Grid>
        
        {/* Performance Chart */}
        <Grid item xs={12} md={6}>
          <Card>
            <Typography variant="h6" padding={2}>Page Load Performance</Typography>
            {performanceData.length > 0 ? (
              <LineChart width={500} height={300} data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="homepage" stroke="#8884d8" />
                <Line type="monotone" dataKey="courses" stroke="#82ca9d" />
                <Line type="monotone" dataKey="membership" stroke="#ffc658" />
              </LineChart>
            ) : (
              <Typography>Loading performance data...</Typography>
            )}
          </Card>
        </Grid>
        
        {/* Uptime Chart */}
        <Grid item xs={12}>
          <Card>
            <Typography variant="h6" padding={2}>Website Uptime</Typography>
            {uptimeData.length > 0 ? (
              <LineChart width={1000} height={300} data={uptimeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="uptime" stroke="#8884d8" />
              </LineChart>
            ) : (
              <Typography>Loading uptime data...</Typography>
            )}
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}
```

## Alert System

Configure alerts for critical issues:

1. Set up email notifications for:
   - Website downtime
   - High error rates
   - Performance degradation
   - Database connectivity issues
   - API service failures

2. Create an alert management script:

```javascript
// File: /home/username/monitoring_scripts/alert_manager.js
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

// Configure email transport
const transporter = nodemailer.createTransport({
  host: 'smtp.example.com',
  port: 587,
  secure: false,
  auth: {
    user: 'alerts@radiationoncologyacademy.com',
    pass: 'your_email_password'
  }
});

// Alert recipients
const recipients = [
  'admin@radiationoncologyacademy.com',
  'tech@radiationoncologyacademy.com'
];

// Alert severity levels
const SEVERITY = {
  INFO: 'INFO',
  WARNING: 'WARNING',
  ERROR: 'ERROR',
  CRITICAL: 'CRITICAL'
};

// Send alert
async function sendAlert(title, message, severity = SEVERITY.INFO, data = null) {
  // Log alert
  const logDir = path.join(__dirname, '../logs');
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }
  
  const logFile = path.join(logDir, 'alerts.log');
  const timestamp = new Date().toISOString();
  const logEntry = `${timestamp} [${severity}] ${title}: ${message}\n`;
  
  fs.appendFileSync(logFile, logEntry);
  
  // Only send emails for WARNING and above
  if (severity === SEVERITY.INFO) {
    return;
  }
  
  // Prepare email
  const emailSubject = `[${severity}] Radiation Oncology Academy Alert: ${title}`;
  let emailBody = `
    <h2>${title}</h2>
    <p><strong>Severity:</strong> ${severity}</p>
    <p><strong>Time:</strong> ${timestamp}</p>
    <p><strong>Message:</strong> ${message}</p>
  `;
  
  if (data) {
    emailBody += `<h3>Additional Data:</h3><pre>${JSON.stringify(data, null, 2)}</pre>`;
  }
  
  // Send email to all recipients
  try {
    await transporter.sendMail({
      from: '"ROA Monitoring" <alerts@radiationoncologyacademy.com>',
      to: recipients.join(', '),
      subject: emailSubject,
      html: emailBody
    });
    
    console.log(`Alert email sent: ${emailSubject}`);
  } catch (error) {
    console.error('Error sending alert email:', error);
    // Log to file since email failed
    fs.appendFileSync(logFile, `${timestamp} [ERROR] Failed to send alert email: ${error.message}\n`);
  }
}

module.exports = {
  sendAlert,
  SEVERITY
};
```

## GoDaddy-Specific Implementation

Since GoDaddy shared hosting has some limitations, the following adjustments are necessary:

1. Use external monitoring services (UptimeRobot, New Relic, Sentry) rather than self-hosted solutions
2. Configure scripts to work within GoDaddy's environment:
   - Use relative paths compatible with GoDaddy's directory structure
   - Ensure scripts have proper execution permissions
   - Work within GoDaddy's resource limitations

3. For GoDaddy cPanel, use the built-in resource monitoring:
   - Log in to GoDaddy cPanel
   - Navigate to "Metrics" under the "Metrics" section
   - Review CPU, Memory, and I/O usage

## Implementation Steps

1. Create the monitoring directory structure:
   ```bash
   mkdir -p /home/username/monitoring_scripts
   mkdir -p /home/username/logs
   mkdir -p /home/username/lighthouse_reports
   ```

2. Install required packages:
   ```bash
   cd /home/username/public_html/radiation_oncology_academy
   npm install lighthouse chrome-launcher newrelic @sentry/node @sentry/tracing @sentry/react nodemailer --save
   ```

3. Create the monitoring scripts as outlined above

4. Make the scripts executable:
   ```bash
   chmod +x /home/username/monitoring_scripts/*.js
   ```

5. Set up cron jobs through GoDaddy cPanel:
   - Access cPanel > Advanced > Cron Jobs
   - Add each cron job as specified

6. Set up external monitoring services:
   - Create accounts on UptimeRobot, New Relic, and Sentry
   - Configure each service according to the implementation steps

7. Implement the health check API endpoint and monitoring dashboard

8. Test each monitoring component manually to ensure it works correctly

9. Document the monitoring system in the admin guide

## Conclusion

This monitoring system provides comprehensive oversight of the Radiation Oncology Academy website with:
- Uptime monitoring to detect and alert on website availability issues
- Performance tracking to identify and address slow-loading pages
- Error tracking to catch and fix bugs quickly
- Health checks to monitor all system components
- Alerting system to notify administrators of critical issues
- Dashboard for easy visualization of system health

The system is designed to be compatible with GoDaddy hosting while providing robust monitoring capabilities to ensure the website remains performant and reliable for all users.
