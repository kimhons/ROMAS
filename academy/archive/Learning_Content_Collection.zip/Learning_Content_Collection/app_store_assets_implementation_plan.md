# Radiation Oncology Academy - Implementation Plan for App Store Assets

## Overview

This document outlines the detailed implementation plan for creating all required app store assets for the Radiation Oncology Academy mobile app submission. Based on our project status report and app store submission requirements, we need to create comprehensive visual and textual assets for both the iOS App Store and Google Play Store.

## App Preview Videos

### iOS App Store Preview Video

**Specifications:**
- Duration: 15-30 seconds (target: 30 seconds)
- Resolution: 1080p (1920x1080) for iPhone, 1200p for iPad
- Format: H.264 encoding, .mp4 file
- Audio: Optional but recommended
- Content: Must only show footage of the app in use

**Storyboard:**
1. **0-3s**: App launch and login screen
2. **3-7s**: Home screen showing module overview
3. **7-12s**: Navigation through Radiation Protection Module
4. **12-17s**: Interactive diagram demonstration
5. **17-22s**: Knowledge check interaction
6. **22-27s**: Radiation Biology Module preview
7. **27-30s**: Progress tracking and achievement view

**Implementation Steps:**
1. Set up screen recording environment on iPhone 13 Pro
2. Create test account with full content access
3. Rehearse navigation path through app
4. Record raw footage (multiple takes)
5. Edit footage to 30-second timeline
6. Add subtle background music
7. Add text overlays for key features
8. Export in required format
9. Review for compliance with App Store guidelines

**Timeline:**
- Setup and preparation: 1 hour
- Recording: 2 hours
- Editing: 3 hours
- Review and finalization: 1 hour
- Total: 7 hours (1 work day)

### Google Play Store Promotional Video

**Specifications:**
- Duration: 30-120 seconds (target: 60 seconds)
- Resolution: 1080p (1920x1080)
- Format: H.264 encoding, .mp4 file
- Audio: Required with clear narration
- Content: Can include both app footage and supporting graphics

**Storyboard:**
1. **0-5s**: Brief introduction to Radiation Oncology Academy
2. **5-15s**: Overview of educational content available
3. **15-25s**: Demonstration of interactive learning features
4. **25-35s**: Showcase of Radiation Protection Module
5. **35-45s**: Preview of Radiation Biology Module
6. **45-55s**: Highlight offline access and cross-device synchronization
7. **55-60s**: Call to action and app icon

**Implementation Steps:**
1. Write detailed script with narration
2. Record app footage on Android device
3. Create supporting graphics for introduction and transitions
4. Record voiceover narration
5. Edit video with footage, graphics, and narration
6. Add background music and sound effects
7. Add text overlays and annotations
8. Export in required format
9. Review for compliance with Google Play guidelines

**Timeline:**
- Script writing: 1 hour
- Recording and graphics creation: 3 hours
- Voiceover recording: 1 hour
- Editing: 4 hours
- Review and finalization: 1 hour
- Total: 10 hours (1.5 work days)

## App Screenshots

### iOS App Store Screenshots

**Specifications:**
- 6.5" iPhone (1284 x 2778 pixels)
- 5.5" iPhone (1242 x 2208 pixels)
- 12.9" iPad Pro (2048 x 2732 pixels)
- Format: RGB, .png or .jpg
- Number: 3-10 screenshots (target: 8 screenshots)

**Screenshot Scenes:**
1. Home screen with module overview
2. Radiation Protection Module main screen
3. Interactive diagram from Radiation Protection Module
4. Knowledge check example from Radiation Protection Module
5. Radiation Biology Module main screen
6. Interactive diagram from Radiation Biology Module
7. Offline content access screen
8. Progress tracking and achievements screen

**Implementation Steps:**
1. Prepare app with test content on all required devices
2. Create consistent framing guidelines
3. Add descriptive text overlays for each screenshot
4. Capture raw screenshots on each device size
5. Apply consistent design treatment in Photoshop
6. Add device frames if appropriate
7. Export in required formats
8. Review for compliance with App Store guidelines

**Timeline:**
- Preparation: 1 hour
- Screenshot capture: 2 hours
- Editing and text overlays: 3 hours
- Export and review: 1 hour
- Total: 7 hours (1 work day)

### Google Play Store Screenshots

**Specifications:**
- Phone: 16:9 aspect ratio (1920 x 1080 pixels recommended)
- 7-inch tablet: 16:9 aspect ratio
- 10-inch tablet: 16:9 aspect ratio
- Format: RGB, .png or .jpg
- Number: 2-8 screenshots (target: 8 screenshots)

**Screenshot Scenes:**
- Same 8 scenes as iOS screenshots for consistency

**Implementation Steps:**
- Similar to iOS implementation steps, but captured on Android devices
- Ensure consistent visual treatment between iOS and Android screenshots

**Timeline:**
- Preparation: 1 hour
- Screenshot capture: 2 hours
- Editing and text overlays: 3 hours
- Export and review: 1 hour
- Total: 7 hours (1 work day)

## App Descriptions

### iOS App Store Description

**Specifications:**
- App name: "Radiation Oncology Academy" (30 characters max)
- Subtitle: "Professional Education Platform" (30 characters max)
- Promotional text: 170 characters max
- Description: 4,000 characters max
- Keywords: 100 characters max

**Content Structure:**
1. **Opening paragraph**: Compelling introduction to the platform
2. **Key features**: Bulleted list of main features and benefits
3. **Content overview**: Description of available and upcoming modules
4. **Interactive learning**: Details on interactive elements
5. **Professional benefits**: How the app helps radiation oncology professionals
6. **Subscription information**: Clear explanation of subscription model
7. **Device compatibility**: Information on supported devices
8. **Contact information**: Support email and website

**Implementation Steps:**
1. Draft complete description following structure
2. Optimize keywords for App Store search
3. Create compelling promotional text
4. Review for compliance with App Store guidelines
5. Proofread and finalize

**Timeline:**
- Drafting: 2 hours
- Keyword optimization: 1 hour
- Review and finalization: 1 hour
- Total: 4 hours

### Google Play Store Description

**Specifications:**
- App name: "Radiation Oncology Academy" (50 characters max)
- Short description: 80 characters max
- Full description: 4,000 characters max

**Content Structure:**
- Similar to iOS description for consistency, with formatting adapted for Google Play

**Implementation Steps:**
- Similar to iOS implementation steps
- Ensure HTML formatting is properly applied for Google Play

**Timeline:**
- Adaptation from iOS description: 1 hour
- Formatting for Google Play: 1 hour
- Review and finalization: 1 hour
- Total: 3 hours

## Additional Google Play Assets

### Feature Graphic

**Specifications:**
- Dimensions: 1024 x 500 pixels
- Format: RGB, .png or .jpg
- No text recommended (localization issues)

**Design Concept:**
- Clean, professional design featuring app logo
- Medical imagery related to radiation oncology
- Color scheme consistent with app branding
- Visual representation of educational content

**Implementation Steps:**
1. Create design mockup in Photoshop
2. Review and refine design
3. Export in required format
4. Test visibility at different sizes

**Timeline:**
- Design: 2 hours
- Review and refinement: 1 hour
- Export and testing: 1 hour
- Total: 4 hours

## Implementation Schedule

### Day 1 (April 11, 2025)
- Morning: Begin iOS App Preview Video production
- Afternoon: Begin Google Play Store Promotional Video production

### Day 2 (April 12, 2025)
- Morning: Complete iOS App Preview Video
- Midday: Complete Google Play Store Promotional Video
- Afternoon: Capture and edit iOS screenshots
- Evening: Draft app descriptions for both stores

### Day 3 (April 13, 2025) - If Needed
- Morning: Capture and edit Google Play screenshots
- Midday: Create Google Play feature graphic
- Afternoon: Finalize all descriptions and metadata
- Evening: Final review of all assets

## Quality Assurance Checklist

- [ ] All videos comply with respective store guidelines
- [ ] Videos demonstrate key app functionality clearly
- [ ] Screenshots showcase main features and content
- [ ] Screenshots have consistent visual treatment
- [ ] Text overlays are clear and error-free
- [ ] App descriptions are compelling and error-free
- [ ] Keywords are optimized for discoverability
- [ ] All assets reflect current app version and features
- [ ] All assets maintain consistent branding
- [ ] All assets have been reviewed for compliance with store guidelines

## Resources Required

- iPhone 13 Pro for iOS video and screenshots
- iPad Pro for iPad screenshots
- Samsung Galaxy S21 for Android video and screenshots
- Samsung Galaxy Tab for Android tablet screenshots
- Adobe Premiere Pro for video editing
- Adobe Photoshop for screenshot editing and graphic design
- Screen recording software
- Microphone for voiceover recording
- Test account with full content access

## Conclusion

This implementation plan provides a comprehensive roadmap for creating all required app store assets for the Radiation Oncology Academy mobile app. By following this plan, we will ensure that all assets are high-quality, compliant with store guidelines, and effectively showcase the app's features and content. The estimated timeline allows for completion of all assets by April 13, 2025, well ahead of our planned submission date of April 16, 2025.
