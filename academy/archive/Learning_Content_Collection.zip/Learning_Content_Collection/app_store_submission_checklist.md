# App Store Submission Checklist for Radiation Oncology Academy iOS App

## Pre-Submission Preparation

### Apple Developer Account
- [x] Apple Developer Program membership active
- [ ] Team information verified and up-to-date
- [ ] Agreements, tax, and banking information completed
- [ ] App Store Connect access for team members configured

### App Build Preparation
- [ ] App version number set to 1.0.0
- [ ] Build number set to 1
- [ ] All debug code removed
- [ ] Analytics properly implemented
- [ ] Crash reporting configured
- [ ] Third-party SDKs updated to latest versions
- [ ] All API endpoints pointing to production servers
- [ ] App properly signed with distribution certificate
- [ ] Push notification entitlements configured (if applicable)
- [ ] In-app purchases configured and tested

### App Store Connect Setup
- [ ] App created in App Store Connect
- [ ] Bundle ID registered and configured
- [ ] App SKU defined
- [ ] App information completed
- [ ] Pricing and availability configured
- [ ] In-app purchases created and configured
- [ ] App Review Information provided
- [ ] Contact information updated
- [ ] Age rating questionnaire completed
- [ ] Content rights declaration completed

## Asset Preparation

### App Icons
- [ ] App Store icon (1024x1024px)
- [ ] iPhone icons (all required sizes)
- [ ] iPad icons (all required sizes)
- [ ] All icons follow Apple's guidelines
- [ ] No transparency or alpha channels
- [ ] No rounded corners on App Store icon

### Screenshots
- [ ] iPhone 13 Pro Max screenshots (1284x2778px)
- [ ] iPhone 8 Plus screenshots (1242x2208px)
- [ ] iPad Pro screenshots (2048x2732px)
- [ ] iPad screenshots (1668x2224px)
- [ ] All screenshots show actual app UI
- [ ] Screenshots highlight key features
- [ ] Text overlays are legible and professional
- [ ] Screenshots follow design guidelines

### App Preview Video
- [ ] 30-second preview video created
- [ ] H.264 format, 30fps
- [ ] iPhone and iPad versions (if applicable)
- [ ] Shows actual app functionality
- [ ] No references to pricing or other platforms
- [ ] Professional voiceover and audio
- [ ] Highlights key app features
- [ ] Follows Apple's preview guidelines

### Metadata
- [ ] App name finalized (max 30 characters)
- [ ] App subtitle created (max 30 characters)
- [ ] Keywords optimized (max 100 characters)
- [ ] App description written and formatted
- [ ] What's New text prepared
- [ ] Support URL active and functional
- [ ] Marketing URL active and functional
- [ ] Privacy Policy URL active and compliant

## Submission Process

### TestFlight (Optional but Recommended)
- [ ] Internal testing build uploaded
- [ ] Internal testing completed
- [ ] External testing build uploaded
- [ ] External testing group created
- [ ] Beta app review information provided
- [ ] External testing initiated

### Final Submission
- [ ] Final build archived in Xcode
- [ ] Build validated with no errors
- [ ] Build uploaded to App Store Connect
- [ ] Build selected for submission
- [ ] All required metadata completed
- [ ] All required screenshots uploaded
- [ ] App preview video uploaded (if applicable)
- [ ] In-app purchases submitted for review
- [ ] App submitted for review

## Post-Submission

### Review Process
- [ ] Monitor app status in App Store Connect
- [ ] Be available to respond to reviewer questions
- [ ] Prepare for potential rejection issues
- [ ] Document any reviewer feedback for future submissions

### Approval and Release
- [ ] Set release type (automatic or manual)
- [ ] Verify app appears correctly on App Store
- [ ] Monitor initial downloads and performance
- [ ] Collect user feedback
- [ ] Prepare for potential updates

## Common Rejection Reasons to Avoid
- Incomplete information or metadata
- Broken links or non-functional URLs
- Crashes or bugs
- Misleading descriptions or screenshots
- Poor performance or user experience
- Privacy concerns or missing privacy policy
- In-app purchase issues
- Mentioning other platforms (Android, etc.)
- Using Apple product images in screenshots
- Insufficient content or functionality
- Duplicate apps or copycat functionality
