# App Icons for Radiation Oncology Academy iOS App

## App Icon Specifications

### App Store Icon
- 1024x1024 pixels
- RGB color space
- No alpha channel
- No transparency
- Straight corners (no rounded corners)
- PNG or JPEG format

### iOS App Icons
- 180x180 pixels (iPhone)
- 167x167 pixels (iPad Pro)
- 152x152 pixels (iPad, iPad mini)
- 120x120 pixels (iPhone)
- 87x87 pixels (iPhone Spotlight)
- 80x80 pixels (iPhone Spotlight)
- 76x76 pixels (iPad, iPad mini)
- 60x60 pixels (iPhone)
- 58x58 pixels (iPhone, iPad Settings)
- 40x40 pixels (iPhone Spotlight)
- 29x29 pixels (iPhone, iPad Settings)
- 20x20 pixels (iPhone Notification)

## Design Guidelines

### Primary Design
- Clean, professional medical aesthetic
- Primary color: Deep blue (#0A3D62) representing trust and professionalism
- Secondary accent: Teal (#38BFA0) representing health and innovation
- White background for clarity
- Simple "ROA" monogram in the center
- Subtle radiation symbol integrated into design
- High contrast for visibility at small sizes

### Alternative Design
- White "ROA" text on gradient background
- Gradient from deep blue (#0A3D62) to teal (#38BFA0)
- Minimalist radiation symbol as subtle background element
- Clean, modern typography
- Optimized for visibility at all sizes

## Icon Production Checklist

1. Create master vector file in Adobe Illustrator
2. Export at all required dimensions
3. Verify color accuracy across all sizes
4. Test visibility at smallest sizes (20x20)
5. Ensure no transparency or alpha channels
6. Verify straight edges (no rounded corners for App Store icon)
7. Optimize file sizes
8. Verify against Apple Human Interface Guidelines
9. Test on actual devices for visibility
10. Create backup versions

## File Naming Convention

- AppIcon-AppStore-1024.png
- AppIcon-iPhone-180.png
- AppIcon-iPadPro-167.png
- AppIcon-iPad-152.png
- AppIcon-iPhone-120.png
- AppIcon-iPhoneSpotlight-87.png
- AppIcon-iPhoneSpotlight-80.png
- AppIcon-iPad-76.png
- AppIcon-iPhone-60.png
- AppIcon-Settings-58.png
- AppIcon-iPhoneSpotlight-40.png
- AppIcon-Settings-29.png
- AppIcon-Notification-20.png
