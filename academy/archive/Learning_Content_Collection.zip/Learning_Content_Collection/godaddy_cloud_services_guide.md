# GoDaddy-Specific Implementation Guide for Cloud Services
# Radiation Oncology Academy

This addendum provides specific instructions for implementing Google Cloud services with your Radiation Oncology Academy website hosted on GoDaddy. It addresses the unique considerations and requirements for GoDaddy hosting environments.

## Table of Contents

1. [GoDaddy Hosting Requirements](#godaddy-hosting-requirements)
2. [Node.js Setup on GoDaddy](#nodejs-setup-on-godaddy)
3. [File Structure and Paths](#file-structure-and-paths)
4. [Google Cloud Storage Implementation](#google-cloud-storage-implementation)
5. [Google Speech-to-Text Implementation](#google-speech-to-text-implementation)
6. [Firebase Implementation](#firebase-implementation)
7. [Domain and SSL Configuration](#domain-and-ssl-configuration)
8. [Performance Optimization](#performance-optimization)
9. [Troubleshooting GoDaddy-Specific Issues](#troubleshooting-godaddy-specific-issues)

## GoDaddy Hosting Requirements

### Recommended Hosting Plan

For optimal performance with the cloud integrations, you'll need:

1. **GoDaddy Ultimate Hosting Plan** or higher
   - Supports Node.js applications
   - Provides sufficient processing power and memory
   - Includes SSH access for advanced configuration

2. **If using a lower-tier plan**:
   - Some real-time features may experience delays
   - You may need to process audio files in smaller chunks
   - Consider upgrading if you experience performance issues

### Checking Your Current Plan

1. Log in to your GoDaddy account
2. Go to "My Products"
3. Find your hosting plan for radiationoncologyacademy.com
4. Verify it supports Node.js (most Linux-based plans do)
5. If needed, click "Upgrade" to enhance your hosting capabilities

## Node.js Setup on GoDaddy

GoDaddy's cPanel hosting supports Node.js applications through their Node.js Selector tool.

### Step 1: Access cPanel

1. Log in to your GoDaddy account
2. Go to "My Products"
3. Find your hosting plan and click "Manage"
4. Under "Web Hosting" section, click "cPanel Admin"
5. Enter your cPanel credentials if prompted

### Step 2: Set Up Node.js

1. In cPanel, scroll down to the "SOFTWARE" section
2. Click on "Setup Node.js App"
3. Click "Create Application"
4. Fill in the following details:
   - Node.js version: Select 16.x or higher
   - Application mode: Production
   - Application root: /backend
   - Application URL: api.radiationoncologyacademy.com (or your preferred subdomain)
   - Application startup file: server.js
5. Click "Create"

### Step 3: Install Dependencies

1. In cPanel, go back to "Setup Node.js App"
2. Select your application
3. Click on "Run NPM Install" to install all dependencies

## File Structure and Paths

GoDaddy uses a specific file structure that differs from standard development environments.

### Root Directory

Your website files should be placed in:
```
/home/username/public_html/
```

Where `username` is your GoDaddy account username.

### Backend Directory

Your Node.js backend should be placed in:
```
/home/username/backend/
```

### Configuration Files

Update all file paths in the configuration files to match GoDaddy's structure:

1. Open `/home/username/backend/config/paths.js` (create if it doesn't exist)
2. Add the following content:

```javascript
module.exports = {
  root: '/home/username/',
  public: '/home/username/public_html/',
  backend: '/home/username/backend/',
  uploads: '/home/username/backend/uploads/',
  config: '/home/username/backend/config/'
};
```

Replace `username` with your actual GoDaddy account username.

## Google Cloud Storage Implementation

Follow the main Google Cloud Storage guide with these GoDaddy-specific adjustments:

### Service Account Key Location

1. Upload your `gcs-key.json` file to:
```
/home/username/backend/config/gcs-key.json
```

2. Update your `.env` file with the correct path:
```
GCS_KEY_PATH=/home/username/backend/config/gcs-key.json
```

### CORS Configuration

GoDaddy may have CORS restrictions. To ensure your application can access Google Cloud Storage:

1. In the Google Cloud Console, go to "Cloud Storage" > "Buckets"
2. Select each of your buckets
3. Go to the "Permissions" tab
4. Click "Add Principal"
5. Add your domain (radiationoncologyacademy.com) as a principal
6. Assign the appropriate role

### File Upload Considerations

GoDaddy has file upload limits. For large files:

1. In cPanel, go to "MultiPHP INI Editor"
2. Select your domain
3. Increase the following values:
   - upload_max_filesize = 64M
   - post_max_size = 64M
   - max_execution_time = 300
   - max_input_time = 300
4. Click "Apply"

## Google Speech-to-Text Implementation

Follow the main Google Speech-to-Text guide with these GoDaddy-specific adjustments:

### Service Account Key Location

1. Upload your `speech-to-text-key.json` file to:
```
/home/username/backend/config/speech-to-text-key.json
```

2. Update your `.env` file with the correct path:
```
GOOGLE_APPLICATION_CREDENTIALS=/home/username/backend/config/speech-to-text-key.json
```

### Processing Large Audio Files

GoDaddy shared hosting may time out with large audio files. To address this:

1. Implement a queue system for processing audio files
2. In your backend code, add logic to process audio in chunks
3. Update the transcription controller to handle timeouts gracefully

Example code for `/home/username/backend/controllers/podcast.controller.js`:

```javascript
// Add this function to handle large file processing
exports.processLargeAudioFile = async (req, res) => {
  const { fileId } = req.body;
  
  // Set up a background job
  const job = queue.create('transcription', {
    fileId,
    userId: req.user.id
  }).save();
  
  res.status(200).json({
    success: true,
    message: 'Transcription job started',
    jobId: job.id
  });
};
```

## Firebase Implementation

Follow the main Firebase guide with these GoDaddy-specific adjustments:

### Firebase Configuration

1. In the Firebase console, go to "Authentication" > "Sign-in method"
2. In the "Authorized domains" section, add:
   - radiationoncologyacademy.com
   - www.radiationoncologyacademy.com
   - api.radiationoncologyacademy.com (if using a subdomain for API)

### WebSocket Connections

GoDaddy shared hosting may have limitations with WebSocket connections used by Firebase:

1. In your Firebase configuration, add:

```javascript
// Add this to your firebase-config.js file
const firebaseConfig = {
  // Your existing config...
  
  // Add these connection settings for GoDaddy
  databaseURL: "https://your-project-id.firebaseio.com",
  connectRetryCount: 3,
  connectRetryDelay: 5000
};
```

2. Implement fallback to long-polling if WebSockets fail:

```javascript
// Add this to your Firebase initialization code
firebase.database().goOnline();
firebase.database().ref('.info/connected').on('value', (snap) => {
  if (!snap.val()) {
    console.log('Using long-polling fallback');
    // Your fallback code here
  }
});
```

## Domain and SSL Configuration

Proper domain configuration is essential for cloud services to work correctly.

### Setting Up Subdomains

1. Log in to your GoDaddy account
2. Go to "My Products" > "Domains"
3. Select radiationoncologyacademy.com
4. Click "DNS"
5. Add these records:
   - Type: A, Name: api, Value: (your server IP)
   - Type: CNAME, Name: www, Value: @
   - Type: CNAME, Name: storage, Value: c.storage.googleapis.com

### SSL Certificate

Secure connections are required for many cloud features:

1. In cPanel, go to "SSL/TLS"
2. Click "Manage SSL sites"
3. Select your domain
4. Click "Install Certificate"
5. Follow the prompts to install an SSL certificate
6. Ensure you select coverage for all subdomains

## Performance Optimization

GoDaddy shared hosting may have performance limitations. Here are some optimization tips:

### Caching Strategy

1. In cPanel, go to "Caching"
2. Enable caching for static content
3. In your Node.js application, add:

```javascript
// Add to server.js
const compression = require('compression');
app.use(compression());

// Add cache headers for static content
app.use(express.static('public', {
  maxAge: '1d',
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'public, max-age=0');
    }
  }
}));
```

### Reduce API Calls

1. Implement batching for API requests
2. Add client-side caching for frequently accessed data
3. Use Firebase offline capabilities:

```javascript
// Add to your Firebase initialization
firebase.firestore().enablePersistence()
  .catch((err) => {
    console.log('Offline persistence error:', err);
  });
```

## Troubleshooting GoDaddy-Specific Issues

### Issue: 500 Internal Server Error

Solution:
1. Check the error logs in cPanel > "Logs" > "Error Log"
2. Ensure your Node.js version is compatible
3. Verify file permissions (should be 644 for files, 755 for directories)

### Issue: API Timeouts

Solution:
1. Increase timeout settings in cPanel > "MultiPHP INI Editor"
2. Implement request queuing for long-running operations
3. Consider upgrading your hosting plan

### Issue: WebSocket Connection Failures

Solution:
1. Check if your GoDaddy plan supports WebSockets
2. Implement long-polling fallback as described earlier
3. Contact GoDaddy support to ensure WebSockets are not blocked

### Issue: File Upload Problems

Solution:
1. Check upload limits in cPanel > "MultiPHP INI Editor"
2. Implement chunked uploads for large files
3. Use Google Cloud Storage direct uploads for very large files

## Conclusion

By following these GoDaddy-specific adjustments along with the main implementation guides, you'll be able to successfully integrate Google Cloud services with your Radiation Oncology Academy website hosted on GoDaddy.

Remember to:
1. Choose an appropriate hosting plan
2. Configure Node.js correctly
3. Adjust file paths to match GoDaddy's structure
4. Set up proper domain and SSL configuration
5. Implement performance optimizations

If you encounter any issues during implementation, first check this addendum for GoDaddy-specific solutions, then refer to GoDaddy's support resources if needed.
