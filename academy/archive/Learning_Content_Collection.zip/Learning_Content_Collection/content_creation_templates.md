# Content Creation Templates for Radiation Oncology Academy

## Overview

This document provides standardized templates for creating educational content for the Radiation Oncology Academy platform. These templates ensure consistency across all content types while maintaining high educational quality and engagement.

Each template includes structural guidelines, formatting requirements, and examples to guide content creators. Special attention has been given to equation formatting, animation specifications, and interactive exercise guidelines as requested.

## Table of Contents

1. [Module Template](#module-template)
2. [Lesson Template](#lesson-template)
3. [Assessment Template](#assessment-template)
4. [Reference Material Template](#reference-material-template)
5. [Interactive Element Template](#interactive-element-template)
6. [Equation Guidelines](#equation-guidelines)
7. [Animation Specifications](#animation-specifications)
8. [Interactive Exercise Guidelines](#interactive-exercise-guidelines)

## Module Template

### Purpose
The module template provides the structure for a complete learning unit that contains multiple lessons and an assessment.

### Structure

```
# [Module Title]

## Overview
[Brief description of the module (150-200 words) that explains what the module covers, why it's important, and what learners will be able to do after completing it.]

## Learning Objectives
- [Objective 1: Use action verbs and measurable outcomes]
- [Objective 2: Use action verbs and measurable outcomes]
- [Objective 3: Use action verbs and measurable outcomes]
- [Objective 4: Use action verbs and measurable outcomes]
- [Objective 5: Use action verbs and measurable outcomes]

## Prerequisites
- [Prerequisite 1: Previous module or knowledge required]
- [Prerequisite 2: Previous module or knowledge required]

## Module Structure
1. [Lesson 1 Title]
2. [Lesson 2 Title]
3. [Lesson 3 Title]
4. [Lesson 4 Title]
5. [Lesson 5 Title]
6. Module Assessment

## Estimated Completion Time
[Total time in hours/minutes]

## Key Terms
- **[Term 1]**: [Brief definition]
- **[Term 2]**: [Brief definition]
- **[Term 3]**: [Brief definition]
- **[Term 4]**: [Brief definition]
- **[Term 5]**: [Brief definition]

## Module Resources
- [Resource 1: Book, article, or website with link]
- [Resource 2: Book, article, or website with link]
- [Resource 3: Book, article, or website with link]
```

### Example: Fundamental Physics Module

```
# Fundamental Physics for Radiation Oncology

## Overview
This module covers the essential physics concepts that form the foundation of radiation oncology practice. Understanding these fundamental principles is critical for safe and effective radiation therapy delivery. The module explores atomic and nuclear structure, radioactive decay processes, interactions of radiation with matter, radiation quantities and units, and methods of radiation detection and measurement. After completing this module, learners will have a solid understanding of the physical principles that underpin all aspects of radiation oncology.

## Learning Objectives
- Describe the structure of atoms and nuclei as they relate to radiation oncology
- Explain the processes of radioactive decay and calculate activity using decay equations
- Analyze the different ways radiation interacts with matter at various energy levels
- Convert between different radiation quantities and units used in clinical practice
- Compare and contrast different methods of radiation detection and measurement

## Prerequisites
- Basic understanding of general physics concepts
- Familiarity with mathematical notation and algebra

## Module Structure
1. Atomic and Nuclear Structure
2. Radioactive Decay
3. Interaction of Radiation with Matter
4. Radiation Quantities and Units
5. Radiation Detection and Measurement
6. Module Assessment

## Estimated Completion Time
4 hours

## Key Terms
- **Atom**: The basic unit of matter consisting of a nucleus surrounded by electrons
- **Radioactive Decay**: The process by which an unstable atomic nucleus loses energy by radiation
- **Linear Energy Transfer (LET)**: The amount of energy deposited by ionizing radiation per unit distance
- **Gray (Gy)**: The SI unit of absorbed dose, equal to one joule per kilogram
- **Ionization Chamber**: A device used to detect and measure radiation by collecting ions

## Module Resources
- Khan's The Physics of Radiation Therapy, 6th Edition, Chapters 1-3
- IAEA Radiation Oncology Physics Handbook: https://www.iaea.org/publications/7086/radiation-oncology-physics
- AAPM TG-51 Protocol for Clinical Reference Dosimetry
```

## Lesson Template

### Purpose
The lesson template provides the structure for individual learning units within a module.

### Structure

```
# [Lesson Title]

## Overview
[Brief description of the lesson (100-150 words) that explains what the lesson covers and how it fits into the broader module.]

## Learning Objectives
- [Objective 1: Use action verbs and measurable outcomes]
- [Objective 2: Use action verbs and measurable outcomes]
- [Objective 3: Use action verbs and measurable outcomes]

## Estimated Completion Time
[Time in minutes]

## Content Section 1: [Section Title]

### Subsection 1.1: [Subsection Title]
[Content text with clear explanations, examples, and clinical relevance. Include equations where appropriate using LaTeX format.]

[EQUATION]
$$equation here$$
[/EQUATION]

[IMAGE: Description of image content]

[TABLE: Description of table content]
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Data     | Data     | Data     |
| Data     | Data     | Data     |

### Subsection 1.2: [Subsection Title]
[Content text with clear explanations, examples, and clinical relevance.]

[ANIMATION: Description of animation content and learning purpose]

## Content Section 2: [Section Title]

### Subsection 2.1: [Subsection Title]
[Content text with clear explanations, examples, and clinical relevance.]

[INTERACTIVE EXERCISE: Description of interactive exercise]

### Subsection 2.2: [Subsection Title]
[Content text with clear explanations, examples, and clinical relevance.]

## Clinical Application
[Brief case study or clinical example that illustrates the practical application of the lesson content (150-200 words).]

## Key Points Summary
- [Key point 1]
- [Key point 2]
- [Key point 3]
- [Key point 4]
- [Key point 5]

## Check Your Understanding
[3-5 formative assessment questions with answers and explanations]

## References
1. [Reference 1]
2. [Reference 2]
3. [Reference 3]
```

### Example: Interaction of Radiation with Matter Lesson

```
# Interaction of Radiation with Matter

## Overview
This lesson explores how different types of radiation interact with matter, with a focus on interactions relevant to radiation therapy. Understanding these interaction mechanisms is essential for predicting dose distribution in patients, designing treatment plans, and ensuring radiation protection. The lesson covers photoelectric effect, Compton scattering, pair production, and other interaction processes.

## Learning Objectives
- Describe the major types of photon interactions with matter
- Explain how interaction probability varies with photon energy and material composition
- Calculate attenuation coefficients and transmission using exponential attenuation equations

## Estimated Completion Time
45 minutes

## Content Section 1: Photon Interactions

### Subsection 1.1: Photoelectric Effect
The photoelectric effect occurs when a photon interacts with a tightly bound electron, typically in the K or L shell of an atom. The photon transfers all its energy to the electron, which is then ejected from the atom. This interaction is most probable when the photon energy is slightly greater than the binding energy of the electron.

The probability of photoelectric interaction (τ) is approximately proportional to:

[EQUATION]
$$\tau \propto \frac{Z^3}{E^3}$$
[/EQUATION]

Where:
- Z is the atomic number of the absorber
- E is the energy of the incident photon

This strong Z-dependence explains why high-Z materials like lead are effective for radiation shielding and why bone appears more radiopaque than soft tissue in radiographic images.

[IMAGE: Diagram of photoelectric effect showing incident photon, ejected photoelectron, and resulting atomic ionization]

[TABLE: Photoelectric Effect Probability by Material and Energy]
| Material | 30 keV | 100 keV | 1 MeV |
|----------|--------|---------|-------|
| Water    | 0.95   | 0.25    | 0.02  |
| Bone     | 0.97   | 0.40    | 0.05  |
| Lead     | 0.99   | 0.95    | 0.50  |

### Subsection 1.2: Compton Scattering
Compton scattering involves the interaction between a photon and a loosely bound or "free" electron. The photon transfers part of its energy to the electron and is scattered at an angle.

[ANIMATION: Visualization of Compton scattering showing incident photon, scattered photon at various angles, and recoil electron with energy transfer]

The energy of the scattered photon (E') is related to the incident photon energy (E) and scattering angle (θ) by:

[EQUATION]
$$E' = \frac{E}{1 + \frac{E}{m_0c^2}(1-\cos\theta)}$$
[/EQUATION]

Where:
- E is the incident photon energy
- E' is the scattered photon energy
- m₀c² is the rest energy of an electron (0.511 MeV)
- θ is the scattering angle

## Content Section 2: Attenuation and Transmission

### Subsection 2.1: Exponential Attenuation
When a beam of photons passes through matter, the intensity decreases exponentially due to various interaction processes. This attenuation follows the exponential law:

[EQUATION]
$$I = I_0 e^{-\mu x}$$
[/EQUATION]

Where:
- I is the transmitted intensity
- I₀ is the initial intensity
- μ is the linear attenuation coefficient
- x is the thickness of the material

[INTERACTIVE EXERCISE: Exponential Attenuation Calculator]
This interactive tool allows you to adjust photon energy, material type, and thickness to see how these parameters affect beam transmission. Experiment with different values to understand how shielding requirements change with energy and material.

### Subsection 2.2: Half-Value Layer
The half-value layer (HVL) is the thickness of material required to reduce the intensity of radiation to half its initial value. It is related to the linear attenuation coefficient by:

[EQUATION]
$$\text{HVL} = \frac{\ln(2)}{\mu} \approx \frac{0.693}{\mu}$$
[/EQUATION]

[TABLE: Half-Value Layers for Common Materials]
| Material | 100 keV | 1 MeV | 10 MeV |
|----------|---------|-------|--------|
| Water    | 4.1 cm  | 10 cm | 40 cm  |
| Concrete | 1.1 cm  | 4.4 cm| 20 cm  |
| Lead     | 0.1 cm  | 0.8 cm| 1.2 cm |

## Clinical Application
A 55-year-old patient with lung cancer is receiving radiation therapy with a 6 MV photon beam. The treatment plan shows that the beam passes through 3 cm of lung tissue (density 0.3 g/cm³) before reaching the tumor. The medical physicist needs to account for the attenuation through the lung to ensure accurate dose delivery to the tumor. Using the mass attenuation coefficient for lung at 6 MV (approximately 0.03 cm²/g) and the exponential attenuation equation, the physicist calculates that approximately 97% of the primary beam reaches the tumor. This calculation helps ensure the prescribed dose is accurately delivered to the target volume.

## Key Points Summary
- Photoelectric effect dominates at low energies and is highly dependent on atomic number (Z³)
- Compton scattering is the predominant interaction in the megavoltage range used for radiation therapy
- Pair production only occurs above 1.022 MeV and increases with energy
- Beam attenuation follows an exponential relationship with material thickness
- Understanding interaction mechanisms is essential for treatment planning and radiation protection

## Check Your Understanding
1. Which photon interaction mechanism is most important in the diagnostic energy range (20-150 keV)?
   - A) Pair production
   - B) Photoelectric effect
   - C) Compton scattering
   - D) Nuclear photodisintegration
   
   Answer: B) Photoelectric effect. At diagnostic energies, especially for high-Z materials, the photoelectric effect dominates.

2. Calculate the transmitted intensity of a 100 keV photon beam through 5 cm of water if the linear attenuation coefficient is 0.17 cm⁻¹.
   - A) 42.7%
   - B) 57.3%
   - C) 85.0%
   - D) 15.0%
   
   Answer: A) 42.7%. Using I = I₀e⁻ᵘˣ = I₀e⁻⁰·¹⁷ˣ⁵ = I₀e⁻⁰·⁸⁵ = 0.427 I₀

## References
1. Khan FM, Gibbons JP. Khan's The Physics of Radiation Therapy. 6th ed. Philadelphia: Lippincott Williams & Wilkins; 2020.
2. Attix FH. Introduction to Radiological Physics and Radiation Dosimetry. Wiley-VCH; 2004.
3. ICRP Publication 116. Conversion Coefficients for Radiological Protection Quantities for External Radiation Exposures. Ann ICRP. 2010;40(2-5).
```

## Assessment Template

### Purpose
The assessment template provides the structure for creating comprehensive evaluations of learner understanding.

### Structure

```
# [Module Title] Assessment

## Overview
[Brief description of the assessment (50-100 words) that explains what knowledge and skills are being evaluated.]

## Instructions
- This assessment contains [number] questions of various types
- You have [time limit] to complete the assessment
- A score of [passing percentage]% or higher is required to pass
- [Any other specific instructions]

## Multiple Choice Questions

### Question 1
[Question text]
- A) [Option A]
- B) [Option B]
- C) [Option C]
- D) [Option D]

Correct Answer: [Letter]
Explanation: [Explanation of why this answer is correct and why others are incorrect]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]

### Question 2
[Question text]
- A) [Option A]
- B) [Option B]
- C) [Option C]
- D) [Option D]

Correct Answer: [Letter]
Explanation: [Explanation of why this answer is correct and why others are incorrect]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]

## Calculation Questions

### Question 3
[Problem statement]

[EQUATION]
$$equation for reference$$
[/EQUATION]

Correct Answer: [Numerical answer with units and acceptable range]
Solution: [Step-by-step solution process]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]

## Image-Based Questions

### Question 4
[Question text]

[IMAGE: Description of image]

- A) [Option A]
- B) [Option B]
- C) [Option C]
- D) [Option D]

Correct Answer: [Letter]
Explanation: [Explanation of why this answer is correct and why others are incorrect]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]

## Case-Based Questions

### Case Scenario
[Description of clinical case scenario (100-150 words)]

### Question 5
[Question text related to the case]
- A) [Option A]
- B) [Option B]
- C) [Option C]
- D) [Option D]

Correct Answer: [Letter]
Explanation: [Explanation of why this answer is correct and why others are incorrect]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]

### Question 6
[Question text related to the case]
- A) [Option A]
- B) [Option B]
- C) [Option C]
- D) [Option D]

Correct Answer: [Letter]
Explanation: [Explanation of why this answer is correct and why others are incorrect]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]

## Matching Questions

### Question 7
Match the following [concepts] with their [definitions/characteristics]:

1. [Item 1]
2. [Item 2]
3. [Item 3]
4. [Item 4]

- A) [Definition/Characteristic A]
- B) [Definition/Characteristic B]
- C) [Definition/Characteristic C]
- D) [Definition/Characteristic D]

Correct Answers: 1-[Letter], 2-[Letter], 3-[Letter], 4-[Letter]
Explanation: [Explanation of correct matches]
Reference: [Source of information]
Learning Objective: [Related learning objective]
Difficulty Level: [Easy/Medium/Hard]
```

### Example: Radiation Dosimetry Assessment

```
# Radiation Dosimetry Assessment

## Overview
This assessment evaluates your understanding of fundamental radiation dosimetry concepts, including absorbed dose, kerma, exposure, dose measurement techniques, and calibration protocols. The questions assess both theoretical knowledge and practical application of dosimetry principles.

## Instructions
- This assessment contains 15 questions of various types
- You have 45 minutes to complete the assessment
- A score of 80% or higher is required to pass
- Calculator use is permitted for calculation questions

## Multiple Choice Questions

### Question 1
Which of the following quantities represents the energy imparted by ionizing radiation per unit mass?
- A) Kerma
- B) Exposure
- C) Absorbed dose
- D) Equivalent dose

Correct Answer: C
Explanation: Absorbed dose is defined as the energy imparted by ionizing radiation per unit mass of material. Kerma (Kinetic Energy Released per unit MAss) represents the kinetic energy transferred from photons to charged particles per unit mass. Exposure is a measure of ionization in air, and equivalent dose is absorbed dose weighted by radiation type.
Reference: ICRU Report 85, Section 2.1
Learning Objective: Define and distinguish between fundamental dosimetric quantities
Difficulty Level: Easy

### Question 2
The TG-51 calibration protocol is based on which of the following quantities?
- A) Air kerma
- B) Absorbed dose to water
- C) Exposure
- D) Equivalent dose

Correct Answer: B
Explanation: The AAPM TG-51 protocol is based on absorbed dose to water calibration factors, which directly provide the absorbed dose to water under reference conditions. This represents a change from earlier protocols like TG-21 that were based on exposure or air kerma calibration factors.
Reference: AAPM TG-51 Protocol, Section 2
Learning Objective: Describe the principles of the TG-51 calibration protocol
Difficulty Level: Medium

## Calculation Questions

### Question 3
A cylindrical ionization chamber with an active volume of 0.6 cm³ collects a charge of 2.4 nC when placed in a photon beam. If the calibration factor for the chamber is 4.2 × 10⁷ Gy/C, what is the absorbed dose in Gy?

[EQUATION]
$$D = M \times N_D \times k_Q \times k_{TP} \times k_{ion} \times k_{pol}$$
[/EQUATION]

Correct Answer: 0.101 Gy (acceptable range: 0.100-0.102 Gy)
Solution: 
1. First, calculate the reading M = 2.4 nC = 2.4 × 10⁻⁹ C
2. Assuming all correction factors (kQ, kTP, kion, kpol) = 1.0 for simplicity
3. D = M × ND = 2.4 × 10⁻⁹ C × 4.2 × 10⁷ Gy/C = 0.101 Gy

Reference: Khan's The Physics of Radiation Therapy, Chapter 8
Learning Objective: Calculate absorbed dose from ionization chamber measurements
Difficulty Level: Medium

## Image-Based Questions

### Question 4
The image below shows a depth-dose curve for a photon beam. What phenomenon is primarily responsible for the build-up region labeled "A" in the curve?

[IMAGE: Depth-dose curve showing surface, build-up region (labeled A), maximum dose, and dose fall-off]

- A) Photoelectric effect
- B) Electron contamination
- C) Electronic equilibrium establishment
- D) Pair production

Correct Answer: C
Explanation: The build-up region (A) in a photon depth-dose curve is primarily due to the establishment of electronic equilibrium. As the photon beam enters the medium, it generates secondary electrons that deposit dose at some distance from their point of origin. The maximum dose occurs when electronic equilibrium is reached, where the number of electrons entering a volume equals those leaving it.
Reference: Podgorsak EB. Radiation Oncology Physics: A Handbook for Teachers and Students. IAEA; 2005. Chapter 7.
Learning Objective: Interpret depth-dose curves and explain the physical processes responsible for their characteristics
Difficulty Level: Medium

## Case-Based Questions

### Case Scenario
A medical physicist is commissioning a new 6 MV linear accelerator. During the TG-51 absolute dose calibration, measurements are taken with a Farmer-type ionization chamber in a water phantom at 10 cm depth, with 100 cm SSD. The temperature is 22°C, the pressure is 750 mmHg, and the relative humidity is 40%. The electrometer reading is 19.54 nC for a 200 MU delivery, and the chamber has an ND,w calibration factor of 5.4 × 10⁷ Gy/C with kQ = 0.992.

### Question 5
What is the temperature-pressure correction factor (kTP) for these conditions?
- A) 0.982
- B) 1.018
- C) 1.000
- D) 0.965

Correct Answer: B
Explanation: The temperature-pressure correction factor is calculated using:

kTP = [(273.15 + T)/(273.15 + T0)] × [(P0)/P]

Where T0 = 20°C and P0 = 760 mmHg are the reference conditions.

kTP = [(273.15 + 22)/(273.15 + 20)] × [760/750]
kTP = [295.15/293.15] × [760/750]
kTP = 1.007 × 1.013 = 1.018

Reference: AAPM TG-51 Protocol, Section 3.2
Learning Objective: Calculate correction factors for environmental conditions in dosimetry
Difficulty Level: Medium

### Question 6
Using the information provided in the case, what is the dose per MU at the measurement point?
- A) 0.0106 Gy/MU
- B) 0.0053 Gy/MU
- C) 0.0100 Gy/MU
- D) 0.0098 Gy/MU

Correct Answer: A
Explanation: The dose per MU is calculated using:

Dose/MU = (M × ND,w × kQ × kTP) / MU

Where M is the charge reading.

Dose/MU = (19.54 × 10⁻⁹ C × 5.4 × 10⁷ Gy/C × 0.992 × 1.018) / 200 MU
Dose/MU = (19.54 × 5.4 × 0.992 × 1.018 × 10⁻² Gy) / 200 MU
Dose/MU = 0.0106 Gy/MU

Reference: AAPM TG-51 Protocol, Section 5
Learning Objective: Determine dose per monitor unit from calibration measurements
Difficulty Level: Hard

## Matching Questions

### Question 7
Match the following dosimetry devices with their primary detection mechanism:

1. Ionization chamber
2. Thermoluminescent dosimeter (TLD)
3. Optically stimulated luminescence (OSL) dosimeter
4. Film dosimeter

- A) Radiation-induced changes in optical density
- B) Collection of charge from ionization in a gas
- C) Light emission when electrons are released from traps by heating
- D) Light emission when electrons are released from traps by light stimulation

Correct Answers: 1-B, 2-C, 3-D, 4-A
Explanation: Ionization chambers operate by collecting charge created when radiation ionizes gas molecules. TLDs store energy from radiation in electron traps and release it as light when heated. OSL dosimeters similarly store energy but release it when stimulated by light. Film dosimeters detect radiation through changes in optical density due to chemical reactions in the film emulsion.
Reference: Attix FH. Introduction to Radiological Physics and Radiation Dosimetry. Wiley-VCH; 2004. Chapter 14.
Learning Objective: Compare and contrast different radiation detection and measurement devices
Difficulty Level: Medium
```

## Reference Material Template

### Purpose
The reference material template provides the structure for creating comprehensive reference resources.

### Structure

```
# [Reference Title]

## Purpose
[Brief description of the reference material's purpose and how it should be used (50-100 words).]

## Quick Reference Table
[Summary table of key information for quick access]

| Parameter | Value/Range | Notes |
|-----------|-------------|-------|
| [Item 1]  | [Value]     | [Note]|
| [Item 2]  | [Value]     | [Note]|
| [Item 3]  | [Value]     | [Note]|

## Detailed Information

### Section 1: [Section Title]
[Detailed information with clear explanations and clinical context]

[EQUATION]
$$equation here$$
[/EQUATION]

[TABLE: Detailed data table]
| Parameter | Condition 1 | Condition 2 | Condition 3 |
|-----------|------------|------------|------------|
| [Item 1]  | [Value]    | [Value]    | [Value]    |
| [Item 2]  | [Value]    | [Value]    | [Value]    |
| [Item 3]  | [Value]    | [Value]    | [Value]    |

### Section 2: [Section Title]
[Detailed information with clear explanations and clinical context]

## Clinical Implementation

### Scenario 1: [Clinical Scenario]
[Description of how to apply the reference information in this specific clinical scenario]

### Scenario 2: [Clinical Scenario]
[Description of how to apply the reference information in this specific clinical scenario]

## References
1. [Reference 1]
2. [Reference 2]
3. [Reference 3]

## Version History
- Version 1.0 (Date): Initial release
- Version 1.1 (Date): [Description of updates]
```

### Example: Dose Constraint Guide

```
# Dose Constraint Guide for Radiation Therapy

## Purpose
This reference guide provides recommended dose constraints for organs at risk (OARs) in radiation therapy planning. It compiles constraints from major protocols and publications, organized by anatomical site. Use this guide during treatment planning to evaluate plan quality and ensure patient safety. Note that these constraints should be considered guidelines rather than absolute limits, and clinical judgment should be exercised in individual cases.

## Quick Reference Table: Critical Structures

| Structure | Constraint | Protocol | Priority |
|-----------|------------|----------|----------|
| Spinal Cord | D0.03cc < 50 Gy | QUANTEC | Mandatory |
| Brain Stem | D0.03cc < 54 Gy | QUANTEC | Mandatory |
| Optic Nerves | D0.03cc < 55 Gy | QUANTEC | Mandatory |
| Optic Chiasm | D0.03cc < 55 Gy | QUANTEC | Mandatory |
| Lens | Dmax < 10 Gy | QUANTEC | Recommended |
| Cochlea | Dmean < 45 Gy | QUANTEC | Recommended |
| Parotid (single) | Dmean < 26 Gy | QUANTEC | Recommended |
| Kidneys (combined) | V20Gy < 32% | QUANTEC | Recommended |
| Liver | Dmean < 30 Gy | QUANTEC | Recommended |
| Heart | V25Gy < 10% | QUANTEC | Recommended |
| Lungs (combined) | V20Gy < 30% | QUANTEC | Recommended |

## Detailed Information

### Section 1: Central Nervous System

#### Spinal Cord
- **Conventional Fractionation**:
  - D0.03cc < 50 Gy (QUANTEC)
  - D1cc < 45 Gy (QUANTEC)
- **Hypofractionation**:
  - D0.03cc < 30 Gy in 5 fractions (AAPM TG-101)
  - D0.03cc < 18 Gy in 1 fraction (AAPM TG-101)
- **Clinical Endpoint**: Myelopathy
- **Dose-Response Relationship**:

[EQUATION]
$$NTCP = \frac{1}{1 + \left(\frac{TD_{50}}{D}\right)^{4\gamma_{50}}}$$
[/EQUATION]

Where:
- NTCP is the normal tissue complication probability
- TD50 is the dose at which there is a 50% chance of complication (estimated at 68.6 Gy)
- γ50 is the slope of the dose-response curve at TD50 (estimated at 1.9)
- D is the maximum dose to the spinal cord

[TABLE: Spinal Cord Dose-Response Data]
| Dose (Gy) | Myelopathy Risk (%) | Study |
|-----------|---------------------|-------|
| < 45      | < 0.2               | Kirkpatrick et al. |
| 50        | 0.2-1               | Kirkpatrick et al. |
| 55        | 1-5                 | Kirkpatrick et al. |
| 60        | 6-10                | Kirkpatrick et al. |
| > 65      | > 10                | Kirkpatrick et al. |

#### Brain Stem
- **Conventional Fractionation**:
  - D0.03cc < 54 Gy (QUANTEC)
  - D1cc < 50 Gy (QUANTEC)
- **Hypofractionation**:
  - D0.03cc < 31 Gy in 5 fractions (AAPM TG-101)
  - D0.03cc < 18 Gy in 1 fraction (AAPM TG-101)
- **Clinical Endpoint**: Neuropathy, brain stem necrosis

### Section 2: Thoracic Structures

#### Lungs (combined)
- **Conventional Fractionation**:
  - V20Gy < 30% (QUANTEC)
  - V5Gy < 65% (QUANTEC)
  - Mean lung dose < 20 Gy (QUANTEC)
- **Hypofractionation**:
  - V20Gy < 10% in 5 fractions (RTOG 0813)
  - V12.5Gy < 15% in 5 fractions (RTOG 0813)
- **Clinical Endpoint**: Radiation pneumonitis (grade ≥ 2)
- **Dose-Response Relationship**:

[EQUATION]
$$NTCP = \frac{1}{1 + \left(\frac{TD_{50}}{MLD}\right)^{4\gamma_{50}}}$$
[/EQUATION]

Where:
- NTCP is the normal tissue complication probability
- TD50 is the mean lung dose at which there is a 50% chance of pneumonitis (estimated at 30.8 Gy)
- γ50 is the slope of the dose-response curve at TD50 (estimated at 0.97)
- MLD is the mean lung dose

[TABLE: Lung Dose-Response Data]
| Mean Lung Dose (Gy) | Pneumonitis Risk (%) | Study |
|---------------------|----------------------|-------|
| < 8                 | < 5                  | Marks et al. |
| 13                  | 10                   | Marks et al. |
| 20                  | 20                   | Marks et al. |
| 24                  | 30                   | Marks et al. |
| 27                  | 40                   | Marks et al. |

## Clinical Implementation

### Scenario 1: Head and Neck IMRT Planning
When planning IMRT for a patient with oropharyngeal cancer receiving 70 Gy in 35 fractions:

1. Set spinal cord constraint as PRV D0.03cc < 50 Gy (with 3-5 mm PRV margin)
2. Set brainstem constraint as PRV D0.03cc < 54 Gy (with 3-5 mm PRV margin)
3. Set parotid gland constraint as mean dose < 26 Gy to at least one parotid
4. During optimization, prioritize spinal cord and brainstem constraints as mandatory
5. If parotid sparing compromises target coverage, accept mean doses up to 30 Gy
6. Document any constraints that could not be met and clinical justification

### Scenario 2: Lung SBRT Planning
When planning SBRT for a patient with early-stage lung cancer receiving 50 Gy in 5 fractions:

1. Set spinal cord constraint as D0.03cc < 30 Gy
2. Set heart constraint as D0.03cc < 38 Gy
3. Set lung constraint as V20Gy < 10% (combined lungs minus ITV)
4. During optimization, use a risk-adapted approach based on tumor location
5. For central tumors (within 2 cm of proximal bronchial tree), consider reducing dose to 50 Gy in 5 fractions
6. Document any constraints that could not be met and clinical justification

## References
1. Marks LB, Yorke ED, Jackson A, et al. Use of normal tissue complication probability models in the clinic. Int J Radiat Oncol Biol Phys. 2010;76(3 Suppl):S10-S19.
2. Benedict SH, Yenice KM, Followill D, et al. Stereotactic body radiation therapy: the report of AAPM Task Group 101. Med Phys. 2010;37(8):4078-4101.
3. Emami B, Lyman J, Brown A, et al. Tolerance of normal tissue to therapeutic irradiation. Int J Radiat Oncol Biol Phys. 1991;21(1):109-122.
4. RTOG 0813: Seamless Phase I/II Study of Stereotactic Lung Radiotherapy (SBRT) for Early Stage, Centrally Located, Non-Small Cell Lung Cancer.

## Version History
- Version 1.0 (April 10, 2025): Initial release
- Version 1.1 (May 15, 2025): Updated with RTOG 0915 constraints
```

## Interactive Element Template

### Purpose
The interactive element template provides the structure for creating engaging interactive learning components.

### Structure

```
# [Interactive Element Title]

## Learning Objective
[Specific learning objective that this interactive element addresses]

## Description
[Brief description of the interactive element and how it enhances learning (100-150 words)]

## Technical Requirements
- **Platforms**: [Web/Mobile/Both]
- **Screen Size**: [Minimum recommended screen size]
- **Input Methods**: [Mouse/Touch/Keyboard/etc.]
- **Browser Requirements**: [Any specific browser requirements]
- **Performance Considerations**: [Any performance considerations]

## User Interface Design
[Description of the user interface, including controls, displays, and feedback mechanisms]

[WIREFRAME: Description of wireframe image showing the layout]

## Interaction Flow
1. [Step 1 of the interaction flow]
2. [Step 2 of the interaction flow]
3. [Step 3 of the interaction flow]
4. [Step 4 of the interaction flow]

## Content Requirements
- [Content item 1 needed for the interactive element]
- [Content item 2 needed for the interactive element]
- [Content item 3 needed for the interactive element]

## Feedback Mechanisms
- [Description of how the interactive element provides feedback to the user]
- [Description of how learning is reinforced through feedback]

## Assessment Integration
[Description of how the interactive element can be used for assessment or how it connects to assessments]

## Accessibility Considerations
- [Accessibility requirement 1]
- [Accessibility requirement 2]
- [Accessibility requirement 3]

## Development Notes
[Technical notes for developers implementing this interactive element]
```

### Example: Beam Interaction Simulator

```
# Beam Interaction Simulator

## Learning Objective
Demonstrate how photon beam characteristics (energy, field size, depth) affect dose distribution in tissue.

## Description
This interactive simulator allows users to manipulate key parameters of a radiation beam and observe the resulting dose distribution in real-time. Users can adjust beam energy, field size, and view depth-dose and profile curves that update dynamically. The simulator helps learners visualize abstract concepts like penumbra, build-up region, and beam hardening. By experimenting with different parameters, users develop an intuitive understanding of how beam characteristics influence dose distribution, which is fundamental to treatment planning.

## Technical Requirements
- **Platforms**: Web and Mobile (responsive design)
- **Screen Size**: Minimum 768px width recommended, but will adapt to smaller screens
- **Input Methods**: Mouse/Touch for sliders and buttons, keyboard for numerical inputs
- **Browser Requirements**: Modern browsers with HTML5 and WebGL support (Chrome, Firefox, Safari, Edge)
- **Performance Considerations**: Calculations performed client-side, may be processor-intensive on older devices

## User Interface Design
The interface is divided into three main sections:
1. **Control Panel**: Left side - contains sliders and input fields for beam parameters
2. **Visualization Area**: Center - shows 2D color wash of dose distribution
3. **Graph Display**: Bottom - shows depth-dose curve and profile curves at selected depths

Controls include:
- Energy selector (dropdown): 6MV, 10MV, 15MV, 18MV
- Field size sliders: 1×1 cm to 40×40 cm
- Depth selector slider: 0-30 cm
- Tissue type selector: Water, Lung, Bone
- Display options: Dose colorwash, Isodose lines, Both

[WIREFRAME: Layout showing control panel on left, visualization area in center, and graphs at bottom]

## Interaction Flow
1. User selects beam energy from dropdown menu
2. User adjusts field size using sliders or direct input
3. Dose distribution visualization updates in real-time
4. User can click anywhere in the phantom to see dose at that point
5. User can adjust depth to view profile curves at different depths
6. User can toggle between absolute and relative dose display
7. User can save screenshots of configurations for comparison

## Content Requirements
- **Beam Data**: Accurate beam data for different energies and field sizes
- **Tissue Models**: Density and interaction data for different tissue types
- **Calculation Algorithm**: Simplified convolution/superposition algorithm for dose calculation
- **Educational Overlays**: Labels and explanations for key features (build-up region, penumbra, etc.)
- **Comparison Data**: Reference data from treatment planning systems for validation

## Feedback Mechanisms
- Real-time visual feedback as parameters are changed
- Numerical dose values displayed when hovering over points in the visualization
- Comparison feature that shows difference between user's configuration and optimal setup
- "Challenge mode" that asks users to achieve specific dose distributions by adjusting parameters
- Pop-up explanations that highlight important phenomena as they occur

## Assessment Integration
- Integrated quiz questions that ask users to predict effects of parameter changes
- Challenges that require users to achieve specific dose distributions
- Ability to export configurations for submission as part of assignments
- Tracking of user exploration patterns and time spent with different parameters
- Performance metrics on challenge completion that can be submitted to instructors

## Accessibility Considerations
- Color schemes designed for color-blind users with alternative visualization options
- Keyboard navigation for all controls
- Screen reader compatibility with ARIA labels
- Text alternatives for all visual information
- Ability to increase contrast and text size
- Support for reduced motion preferences

## Development Notes
- Implement using Three.js for 3D visualization
- Use Web Workers for dose calculations to prevent UI freezing
- Cache calculation results to improve performance when revisiting configurations
- Implement progressive enhancement to ensure basic functionality on older browsers
- Consider WebAssembly for computation-intensive portions
- Ensure touch events properly handled for mobile users
- Implement data compression for beam data to reduce initial load time
```

## Equation Guidelines

### Purpose
These guidelines ensure consistent and effective use of equations throughout the educational content.

### When to Use Equations

Equations should be used when:
1. A mathematical relationship needs to be precisely defined
2. The equation is fundamental to understanding the concept
3. The equation will be referenced in subsequent content or exercises
4. The equation summarizes a complex relationship more efficiently than text

Equations should NOT be used when:
1. The mathematical relationship is trivial or obvious
2. A verbal description would be more accessible to the target audience
3. The equation is not directly relevant to the learning objectives

### Equation Formatting

#### Basic Formatting
- Use LaTeX syntax for all equations
- Display important equations as block elements (centered on their own line)
- Use inline equations for simple expressions within text
- Number sequential equations for reference (e.g., Equation 1, Equation 2)
- Include proper spacing between elements

#### Block Equation Example
```
[EQUATION]
$$E = mc^2$$
[/EQUATION]
```

#### Inline Equation Example
```
The energy (E) is calculated as mass (m) multiplied by the speed of light squared ($E = mc^2$).
```

### Variable Definitions

- Always define all variables immediately after the equation
- Use consistent variable names throughout the content
- Format variable names in italics in text (but not in equations)
- Use standard notation conventions for the field

Example:
```
[EQUATION]
$$D = \dot{D} \times t \times \left(\frac{d_0}{d}\right)^2$$
[/EQUATION]

Where:
- D is the dose (Gy)
- $\dot{D}$ is the dose rate (Gy/min)
- t is the time (min)
- d₀ is the reference distance (cm)
- d is the actual distance (cm)
```

### Equation Complexity

- Break complex equations into simpler components when possible
- For multi-step derivations, show intermediate steps
- Use annotations or highlighting to emphasize important parts of equations
- Consider providing both simplified and complete versions of complex equations

Example of breaking down a complex equation:
```
The Linear-Quadratic model for cell survival can be written as:

[EQUATION]
$$S = e^{-(\alpha D + \beta D^2)}$$
[/EQUATION]

This can be understood in two parts:

1. The linear component:
[EQUATION]
$$\text{Linear component} = e^{-\alpha D}$$
[/EQUATION]

2. The quadratic component:
[EQUATION]
$$\text{Quadratic component} = e^{-\beta D^2}$$
[/EQUATION]

Together, these components form the complete model.
```

### Units and Dimensions

- Include units in variable definitions
- Use standard SI units when possible
- For equations where dimensional consistency is important, include dimensional analysis
- Use proper formatting for units (e.g., Gy, not gy or GY)

Example with dimensional analysis:
```
[EQUATION]
$$\mu_{en}/\rho = \frac{\mu_{tr}}{\rho} \times (1 - g)$$
[/EQUATION]

Where:
- $\mu_{en}/\rho$ is the mass energy absorption coefficient (m²/kg)
- $\mu_{tr}/\rho$ is the mass energy transfer coefficient (m²/kg)
- g is the fraction of energy lost to radiative processes (dimensionless)

Dimensional analysis: [m²/kg] = [m²/kg] × [dimensionless]
```

### Equation Integration with Text

- Introduce equations with clear context
- Explain the physical or clinical significance after presenting the equation
- Reference equations by number when discussing them later in the text
- Connect equations to real-world applications or examples

Example:
```
The inverse square law is fundamental to understanding how radiation dose changes with distance from the source. This relationship is expressed mathematically as:

[EQUATION]
$$I_2 = I_1 \times \left(\frac{d_1}{d_2}\right)^2$$
[/EQUATION]

Where:
- I₂ is the intensity at distance d₂
- I₁ is the intensity at distance d₁
- d₁ is the reference distance
- d₂ is the new distance

This equation tells us that if we double the distance from a radiation source, the intensity decreases to one-fourth of its original value. This principle is critical for radiation protection and for calculating treatment times in brachytherapy.

For example, if the dose rate is 4 Gy/min at 5 cm from a source, at 10 cm the dose rate would be:

[EQUATION]
$$\dot{D}_{10cm} = 4 \text{ Gy/min} \times \left(\frac{5 \text{ cm}}{10 \text{ cm}}\right)^2 = 4 \text{ Gy/min} \times 0.25 = 1 \text{ Gy/min}$$
[/EQUATION]
```

### Common Equation Types

#### Differential Equations
For differential equations, clearly indicate derivatives and partial derivatives:

```
[EQUATION]
$$\frac{dN}{dt} = -\lambda N$$
[/EQUATION]
```

#### Integrals
For integrals, clearly specify integration limits:

```
[EQUATION]
$$D = \int_{t_1}^{t_2} \dot{D}(t) \, dt$$
[/EQUATION]
```

#### Matrices and Vectors
For matrices and vectors, use appropriate notation:

```
[EQUATION]
$$\mathbf{M} = 
\begin{pmatrix}
m_{11} & m_{12} & m_{13} \\
m_{21} & m_{22} & m_{23} \\
m_{31} & m_{32} & m_{33}
\end{pmatrix}
$$
[/EQUATION]
```

#### Statistical Equations
For statistical equations, clearly define all parameters:

```
[EQUATION]
$$\chi^2 = \sum_{i=1}^{n} \frac{(O_i - E_i)^2}{E_i}$$
[/EQUATION]
```

### Interactive Equations

When possible, create interactive versions of key equations that allow users to:
- Adjust parameters and see results in real-time
- Visualize the effect of changing variables
- Explore edge cases and limits
- Connect equations to graphical representations

Example interactive equation specification:
```
[INTERACTIVE EQUATION]
Title: Bragg Peak Explorer
Equation: $$D(x) = D_0 \times e^{-\mu x} \times \left(1 + \frac{a}{(x-R)^2 + b}\right)$$
Interactive Elements:
- Slider for beam energy (50-250 MeV)
- Slider for medium density (0.5-2.0 g/cm³)
- Graph showing resulting depth-dose curve
- Numerical output of peak position and width
[/INTERACTIVE EQUATION]
```

## Animation Specifications

### Purpose
These specifications ensure that animations effectively enhance learning by visualizing complex concepts.

### When to Use Animations

Animations should be used when:
1. Demonstrating dynamic processes that change over time
2. Illustrating complex 3D spatial relationships
3. Showing cause-and-effect relationships
4. Visualizing concepts that are difficult to understand from static images
5. Demonstrating proper techniques or procedures

Animations should NOT be used when:
1. A static image would communicate the concept equally well
2. The animation would distract from the core learning objective
3. The concept is simple enough to understand without visual aids
4. The animation would take too long to convey a simple point

### Animation Types and Use Cases

#### 1. Process Animations
**Purpose**: Show step-by-step processes or mechanisms
**Use Cases**:
- Radioactive decay processes
- Interaction of radiation with matter
- Cell damage and repair mechanisms
- Treatment planning workflow

**Example Specification**:
```
[ANIMATION: Photoelectric Effect]
Duration: 15-20 seconds
Description: Animation showing a photon approaching an atom, interacting with a K-shell electron, and ejecting the electron. The animation should then show the cascade of electrons filling the vacancy and the emission of characteristic x-rays.
Key Elements to Include:
- Labeled incident photon with energy indicator
- Atom with electron shells labeled (K, L, M)
- Ejected photoelectron with momentum vector
- Electron transitions between shells
- Characteristic x-ray emission
- Energy conservation indicators
Learning Points to Emphasize:
- Energy transfer from photon to electron
- Relationship between photon energy and electron binding energy
- Origin of characteristic x-rays
Narration Notes: Explain that the photoelectric effect dominates at lower energies and in high-Z materials.
```

#### 2. Comparative Animations
**Purpose**: Compare different techniques, approaches, or phenomena
**Use Cases**:
- Comparing treatment modalities (3D-CRT vs. IMRT vs. VMAT)
- Comparing dose distributions for different beam arrangements
- Comparing imaging modalities (CT vs. MRI vs. PET)

**Example Specification**:
```
[ANIMATION: Treatment Technique Comparison]
Duration: 30-45 seconds
Description: Side-by-side animation comparing dose distributions for 3D-CRT, IMRT, and VMAT for a head and neck case. The animation should rotate around the patient to show 3D dose distribution and highlight differences in conformality and dose to organs at risk.
Key Elements to Include:
- Patient anatomy with target volumes and OARs clearly labeled
- Color-wash dose distributions for each technique
- DVH curves that build as the animation progresses
- Text callouts highlighting key differences
- Timeline showing treatment delivery time for each technique
Learning Points to Emphasize:
- Trade-offs between conformality and complexity
- Dose to organs at risk for each technique
- Efficiency of delivery for each technique
Narration Notes: Emphasize that technique selection depends on clinical goals and patient-specific factors.
```

#### 3. Spatial Relationship Animations
**Purpose**: Illustrate 3D relationships and structures
**Use Cases**:
- Anatomical relationships in complex regions
- Beam arrangement and isocenter placement
- Dose distribution in 3D
- Patient positioning and setup

**Example Specification**:
```
[ANIMATION: Head and Neck Anatomy for Target Delineation]
Duration: 60-90 seconds
Description: 3D animation of head and neck anatomy focusing on lymph node levels and their relationship to critical structures. The animation should allow for layer-by-layer viewing and highlighting of specific structures.
Key Elements to Include:
- Detailed anatomical structures with proper medical terminology
- Lymph node levels (I-VII) with color coding
- Critical structures (spinal cord, parotids, larynx, etc.)
- Common tumor locations with typical spread patterns
- Transition between axial, sagittal, and coronal views
Learning Points to Emphasize:
- Boundaries of lymph node levels
- Proximity of targets to critical structures
- Common areas of recurrence
Narration Notes: Reference RTOG contouring atlases and emphasize consistent naming conventions.
```

#### 4. Conceptual Animations
**Purpose**: Visualize abstract concepts or invisible phenomena
**Use Cases**:
- Radiation interactions at atomic level
- Radiobiology concepts (4 Rs, LET, RBE)
- Statistical concepts in treatment planning
- Quality assurance principles

**Example Specification**:
```
[ANIMATION: Linear Energy Transfer (LET) Comparison]
Duration: 30-40 seconds
Description: Animation comparing the track structures and energy deposition patterns of low-LET radiation (photons) versus high-LET radiation (carbon ions) as they pass through tissue.
Key Elements to Include:
- Microscopic view of cellular structures
- Particle tracks with ionization events
- Energy deposition visualization along tracks
- Comparison of direct and indirect damage
- DNA damage patterns for each radiation type
Learning Points to Emphasize:
- Relationship between LET and biological effectiveness
- Oxygen enhancement ratio differences
- Repair capacity differences
Narration Notes: Explain how LET affects the complexity of DNA damage and repair probability.
```

### Technical Specifications

#### File Formats and Compatibility
- Primary format: HTML5/WebGL for web-based animations
- Alternative formats: MP4 (H.264) for video fallback
- Resolution: 1920x1080 (16:9) with responsive scaling
- Frame rate: 30 fps for most animations, 60 fps for rapid movements
- File size: Optimize for <5MB for standard animations, <15MB for complex 3D

#### User Controls
- Play/pause button
- Playback speed control (0.5x, 1x, 1.5x, 2x)
- Progress bar with scrubbing capability
- Full-screen option
- Closed captioning/subtitles
- Audio mute/unmute (if narration is included)

#### Accessibility Requirements
- Text alternatives for all visual information
- Audio descriptions for important visual elements
- Keyboard-accessible controls
- No reliance on color alone to convey information
- Support for screen readers
- Option to disable animations for users with vestibular disorders

### Design Guidelines

#### Visual Style
- Consistent color scheme with platform design system
- Clear visual hierarchy with emphasis on key elements
- Appropriate use of color to highlight important features
- Clean, uncluttered design with sufficient white space
- Professional medical illustration style for anatomical elements
- Consistent lighting and shading for 3D elements

#### Text and Labels
- Concise, readable labels (16px minimum font size)
- Consistent terminology with other course materials
- Limited text on screen (focus on visual learning)
- Clear association between labels and visual elements
- Proper medical terminology with pronunciation guides when appropriate

#### Timing and Pacing
- Appropriate pacing for complexity of concept (slower for complex ideas)
- Pauses at key points to allow processing
- Logical sequence that builds understanding
- Repetition of key sequences when beneficial for learning
- Total duration appropriate for attention span and concept complexity

### Integration with Learning Content

#### Contextual Placement
- Place animations immediately after introducing the concept
- Provide context before the animation begins
- Follow animation with reinforcement or application of the concept
- Link animations to related static images or diagrams
- Consider placement within the overall learning sequence

#### Supporting Elements
- Brief introduction text explaining what to look for
- Follow-up questions to reinforce learning
- Related static images for reference
- Downloadable version for offline review
- Links to related animations or concepts

#### Assessment Integration
- Questions that reference specific moments in the animation
- Tasks that require applying concepts from the animation
- Opportunities to predict what happens next in a process
- Comparison tasks between different animations
- Application exercises that build on animated concepts

## Interactive Exercise Guidelines

### Purpose
These guidelines ensure that interactive exercises effectively engage learners and reinforce key concepts.

### When to Use Interactive Exercises

Interactive exercises should be used when:
1. Practicing application of theoretical knowledge
2. Reinforcing key concepts through active learning
3. Developing procedural or decision-making skills
4. Providing immediate feedback on understanding
5. Breaking up passive learning with active engagement

Interactive exercises should NOT be used when:
1. The interaction doesn't add educational value
2. The technical complexity outweighs the learning benefit
3. The exercise would take too long relative to its learning value
4. A simpler assessment method would be equally effective

### Interactive Exercise Types and Use Cases

#### 1. Simulation Exercises
**Purpose**: Allow learners to manipulate variables and observe outcomes
**Use Cases**:
- Treatment planning parameter adjustments
- Beam arrangement optimization
- Dose calculation with varying parameters
- Quality assurance procedure simulation

**Example Specification**:
```
[INTERACTIVE EXERCISE: Treatment Planning Simulator]
Learning Objective: Demonstrate how beam arrangement affects dose distribution and organ sparing
Description: Interactive treatment planning simulator that allows users to add, remove, and adjust beam angles, weights, and energies for a prostate cancer case. Users can see real-time updates to the dose distribution and DVH curves.

User Interactions:
- Add/remove beams (up to 9 beams)
- Adjust beam angles (0-360°)
- Set beam weights (0-100%)
- Select beam energies (6, 10, 15, 18 MV)
- Toggle between 3D view and axial/sagittal/coronal views
- View DVH updates in real-time

Feedback Mechanisms:
- Color-wash dose distribution updates
- DVH curve updates
- Numerical dose statistics (D95, V95, etc.)
- Warning indicators when constraints are violated
- Comparison with "expert" plan

Challenge Mode:
- Achieve target coverage of D95 > 95% while keeping rectum V70 < 15%
- Minimize bladder dose while maintaining target coverage
- Achieve plan with minimum number of beams

Assessment Integration:
- Score based on target coverage and OAR sparing
- Time to achieve acceptable plan
- Number of iterations required
- Comparison with class average
```

#### 2. Decision-Making Exercises
**Purpose**: Develop clinical decision-making skills
**Use Cases**:
- Treatment technique selection
- Management of treatment complications
- Image interpretation and target delineation
- Quality assurance failure analysis

**Example Specification**:
```
[INTERACTIVE EXERCISE: Clinical Decision Pathway]
Learning Objective: Apply appropriate management strategies for radiation-induced toxicities
Description: Branching scenario exercise where users manage a patient experiencing side effects during radiation therapy for head and neck cancer. Users make decisions at key points that affect patient outcomes.

Scenario Setup:
- 62-year-old male with stage III oropharyngeal cancer
- Receiving definitive chemoradiation (70 Gy in 35 fractions with weekly cisplatin)
- Currently at fraction 25 with grade 2 mucositis and weight loss

User Interactions:
- Multiple-choice decision points (4-5 options per decision)
- Review of patient data (labs, imaging, physical exam)
- Consultation with other specialists
- Prescription of supportive medications
- Treatment modification decisions

Branching Pathways:
- Each decision leads to different consequences
- Multiple acceptable pathways with varying outcomes
- Suboptimal decisions lead to teaching moments
- Critical errors trigger immediate feedback

Feedback Mechanisms:
- Patient outcome updates after each decision
- Expert commentary on decision quality
- Comparison with evidence-based guidelines
- Explanation of clinical reasoning
- References to relevant literature

Assessment Integration:
- Score based on patient outcome and adherence to guidelines
- Tracking of decision pattern and time spent
- Identification of knowledge gaps
- Personalized recommendations for further study
```

#### 3. Interactive Calculations
**Purpose**: Practice applying formulas and calculations
**Use Cases**:
- Dose calculations
- Monitor unit calculations
- Decay corrections
- Biological effective dose calculations
- Shielding calculations

**Example Specification**:
```
[INTERACTIVE EXERCISE: Monitor Unit Calculator]
Learning Objective: Calculate monitor units for external beam treatments using the standard formulation
Description: Interactive calculator that guides users through the process of calculating monitor units for a linac-based treatment, with step-by-step input and immediate feedback.

User Interactions:
- Input prescription dose and fractionation
- Select calibration conditions (SSD or SAD setup)
- Input depth, field size, and measurement point
- Select beam energy and beam modifiers
- Apply correction factors step by step

Calculation Steps:
1. Determine tissue-phantom ratio or percentage depth dose
2. Apply field size correction factors
3. Apply off-axis corrections if applicable
4. Apply tray and wedge factors if applicable
5. Apply inverse square corrections
6. Calculate final MU value

Feedback Mechanisms:
- Step-by-step validation of inputs
- Highlighting of incorrect values
- Explanation of each factor's purpose
- Comparison with correct calculation
- Visualization of setup geometry

Challenge Mode:
- Timed calculations with increasing complexity
- Random generation of calculation scenarios
- Introduction of unusual setups or equipment
- Identification of errors in pre-worked examples

Assessment Integration:
- Score based on accuracy and completion time
- Tracking of common error patterns
- Progressive difficulty based on performance
- Integration with formal assessments
```

#### 4. Interactive Diagrams
**Purpose**: Explore relationships between components
**Use Cases**:
- Anatomical relationships
- Equipment components
- Workflow processes
- Conceptual frameworks
- Data relationships

**Example Specification**:
```
[INTERACTIVE EXERCISE: Linear Accelerator Components]
Learning Objective: Identify the major components of a medical linear accelerator and explain their functions
Description: Interactive diagram of a linear accelerator that allows users to explore each component, understand its function, and see how components work together.

User Interactions:
- Click/tap on components to view details
- Zoom and rotate the 3D model
- Toggle between external view and internal components
- Play animations of electron generation and acceleration
- Follow the beam path from electron gun to patient

Component Details:
- Electron gun: Electron generation through thermionic emission
- Waveguide: Acceleration of electrons using RF energy
- Bending magnet: Redirecting electron beam toward target
- Target: X-ray production through bremsstrahlung
- Primary collimator: Initial beam shaping
- Flattening filter: Creating uniform beam profile
- Monitor chambers: Dose monitoring
- Secondary collimators: Field size definition
- MLC: Complex field shaping

Feedback Mechanisms:
- Pop-up explanations with text and diagrams
- Animations showing component operation
- Cross-references to related components
- Technical specifications and parameters
- Historical development context

Challenge Mode:
- Component identification quiz
- Troubleshooting scenarios
- Beam parameter prediction based on component settings
- Assembly sequence challenges

Assessment Integration:
- Component identification assessment
- Functional relationship questions
- Troubleshooting scenario evaluation
- Integration with equipment QA assessments
```

#### 5. Interactive Case Studies
**Purpose**: Apply knowledge to realistic clinical scenarios
**Use Cases**:
- Treatment planning case studies
- Patient management scenarios
- Quality assurance investigations
- Image interpretation challenges
- Multidisciplinary team discussions

**Example Specification**:
```
[INTERACTIVE EXERCISE: Breast Cancer Treatment Planning Case]
Learning Objective: Apply appropriate treatment planning techniques for a left-sided breast cancer case with cardiac dose concerns
Description: Comprehensive case study where users progress through the entire treatment planning process for a patient with left-sided breast cancer, making decisions at each step.

Case Information:
- 48-year-old female with left-sided breast cancer
- Status post lumpectomy with negative margins
- Prescription: 50 Gy in 25 fractions to whole breast + 10 Gy boost
- Cardiac dose is a concern due to pre-existing cardiac risk factors

User Interactions:
- Review patient history, imaging, and surgical reports
- Select appropriate imaging position and immobilization
- Perform target volume and OAR contouring
- Choose treatment technique (3D-CRT, IMRT, VMAT, DIBH)
- Evaluate and compare different planning approaches
- Review and approve final plan

Decision Points:
- Conventional vs. hypofractionated regimen
- Free breathing vs. deep inspiration breath hold
- Field arrangement and beam energy selection
- Boost technique selection
- Plan evaluation and approval

Feedback Mechanisms:
- Expert contours for comparison
- Sample plans for different techniques
- DVH analysis tools
- Plan quality metrics
- Expert commentary on decisions

Challenge Variations:
- Add regional nodal irradiation
- Patient unable to tolerate DIBH
- Implant reconstruction case
- Bilateral breast treatment

Assessment Integration:
- Contour comparison metrics
- Plan quality evaluation
- Decision point scoring
- Justification of approach
- Peer comparison statistics
```

### Technical Specifications

#### Interactivity Requirements
- Immediate response to user input (<200ms)
- Clear visual feedback for all interactions
- Consistent UI elements across exercises
- Appropriate input methods (click, drag, type, select)
- Save and resume functionality for complex exercises
- Progress tracking and completion status

#### Platform Compatibility
- Responsive design for desktop and tablet use
- Touch-optimized for tablet interactions
- Keyboard accessibility for all functions
- Cross-browser compatibility (Chrome, Firefox, Safari, Edge)
- Graceful degradation for older browsers
- Offline capability where appropriate

#### Performance Considerations
- Optimize for low-end devices
- Progressive loading for complex exercises
- Efficient data handling for real-time calculations
- Caching of static assets and previous states
- Bandwidth-conscious design for remote users
- Battery usage optimization for mobile devices

### Design Guidelines

#### User Interface Design
- Clear, intuitive controls with consistent placement
- Visual hierarchy that guides users through the exercise
- Sufficient contrast for all interactive elements
- Appropriate use of color to indicate state and feedback
- Clear differentiation between interactive and static elements
- Consistent with platform design language

#### Instructions and Guidance
- Clear, concise instructions at the beginning
- Progressive disclosure of complex instructions
- Context-sensitive help available throughout
- Examples for complex interactions
- Tooltips for unfamiliar controls or concepts
- Clear indication of expected actions

#### Feedback Design
- Immediate feedback for user actions
- Constructive guidance for incorrect actions
- Positive reinforcement for correct actions
- Explanatory feedback that enhances learning
- Multiple feedback modalities (visual, textual, auditory)
- Graduated hints for struggling users

### Learning Integration

#### Scaffolding and Progression
- Start with simpler interactions and build complexity
- Provide guided examples before independent practice
- Offer optional hints that decrease with proficiency
- Include both practice and assessment modes
- Allow repeated attempts with varying scenarios
- Adapt difficulty based on user performance

#### Knowledge Application
- Connect exercises directly to learning objectives
- Require application of multiple concepts
- Include both routine and non-routine scenarios
- Incorporate realistic constraints and limitations
- Encourage critical thinking and problem-solving
- Provide opportunities for creative solutions

#### Reflection and Metacognition
- Prompt users to explain their reasoning
- Provide opportunities to compare approaches
- Include self-assessment components
- Offer expert reasoning for comparison
- Encourage identification of knowledge gaps
- Support development of mental models

### Assessment Integration

#### Performance Metrics
- Accuracy of responses or solutions
- Time to completion
- Efficiency of approach
- Quality of outcomes
- Adherence to best practices
- Comparison to expert performance

#### Data Collection
- Track all meaningful user interactions
- Record decision pathways and changes
- Measure time spent on different components
- Identify patterns of errors or misconceptions
- Collect user explanations and justifications
- Generate detailed performance reports

#### Feedback to Learners
- Immediate performance feedback
- Detailed explanation of correct approaches
- Identification of specific knowledge gaps
- Personalized recommendations for improvement
- Comparison with peers (anonymized)
- Progress tracking over multiple attempts
