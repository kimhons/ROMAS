# App Preview Videos Implementation

## Overview

This document outlines the implementation plan for creating the required app preview videos for the Radiation Oncology Academy mobile app submission to both the Apple App Store and Google Play Store. Following our app store assets implementation plan, this document provides detailed specifications and step-by-step procedures for capturing and producing high-quality preview videos that effectively demonstrate the app's key features and value proposition.

## Video Requirements

### iOS App Store Requirements

#### iPhone App Preview
- **Resolution**: 1080p (1920 x 1080) or 1280 x 720 pixels
- **Format**: H.264 encoding, .mp4 file format
- **Frame Rate**: 30 fps (frames per second)
- **Duration**: 15-30 seconds (must not exceed 30 seconds)
- **File Size**: Maximum 500 MB
- **Audio**: Optional, AAC encoding, stereo or mono

#### iPad App Preview
- **Resolution**: 1080p (1920 x 1080) or 1280 x 720 pixels
- **Format**: H.264 encoding, .mp4 file format
- **Frame Rate**: 30 fps (frames per second)
- **Duration**: 15-30 seconds (must not exceed 30 seconds)
- **File Size**: Maximum 500 MB
- **Audio**: Optional, AAC encoding, stereo or mono

### Google Play Store Requirements

#### Promotional Video
- **Resolution**: 1080p (1920 x 1080) minimum
- **Format**: H.264 encoding, .mp4 file format recommended
- **Frame Rate**: 30 fps recommended
- **Duration**: 30-120 seconds (60 seconds optimal)
- **Hosting**: YouTube URL required (not direct upload)
- **Audio**: Required, clear narration recommended

## Video Storyboards

### iOS App Preview Video (30 seconds)

#### Scene 1: App Introduction (0-5 seconds)
- **Content**: App opening animation and welcome screen
- **Key Elements**:
  - Radiation Oncology Academy logo animation
  - "Professional Education Platform" tagline
  - Clean transition to home screen
- **Audio**: Subtle professional background music
- **On-Screen Text**: "Radiation Oncology Academy"

#### Scene 2: Module Library (5-10 seconds)
- **Content**: Home screen showing available modules
- **Key Elements**:
  - Radiation Protection Module card
  - Radiation Biology Module card with "Partially Available" indicator
  - Coming Soon modules with clear indicators
  - Smooth scrolling through module library
- **Audio**: Continue background music
- **On-Screen Text**: "Comprehensive Educational Content"

#### Scene 3: Radiation Protection Module (10-15 seconds)
- **Content**: Navigating through Radiation Protection Module
- **Key Elements**:
  - Module overview screen
  - Section list with completion indicators
  - Tapping to enter a section
  - Scrolling through educational content
- **Audio**: Continue background music
- **On-Screen Text**: "Complete Radiation Protection Module"

#### Scene 4: Interactive Diagram (15-20 seconds)
- **Content**: Interacting with Cell Death Pathways diagram
- **Key Elements**:
  - Full diagram view
  - Tapping on interactive elements
  - Information panels appearing
  - Zoom and pan functionality
- **Audio**: Continue background music
- **On-Screen Text**: "Interactive Learning Experience"

#### Scene 5: Knowledge Check (20-25 seconds)
- **Content**: Completing a knowledge check question
- **Key Elements**:
  - Question presentation
  - Selecting an answer
  - Feedback animation
  - Explanation panel
- **Audio**: Continue background music
- **On-Screen Text**: "Test Your Understanding"

#### Scene 6: Content Roadmap (25-30 seconds)
- **Content**: Viewing the content roadmap
- **Key Elements**:
  - Timeline visualization
  - Available and upcoming content indicators
  - Notification preference toggle
  - Final app logo and call to action
- **Audio**: Music fade out
- **On-Screen Text**: "Growing Content Library"

### Google Play Promotional Video (60 seconds)

#### Scene 1: Introduction (0-5 seconds)
- **Content**: App logo and introduction
- **Key Elements**:
  - Radiation Oncology Academy logo animation
  - Professional branding elements
  - Brief mission statement
- **Audio**: Professional narration: "Introducing Radiation Oncology Academy, the premier educational platform for radiation oncology professionals."
- **On-Screen Text**: "Radiation Oncology Academy"

#### Scene 2: Platform Overview (5-15 seconds)
- **Content**: Overview of the platform and its purpose
- **Key Elements**:
  - Quick tour of app interface
  - Highlight of key sections
  - Professional design elements
- **Audio**: "Designed by leading experts in the field, our comprehensive platform provides high-quality educational content for radiation oncologists, medical physicists, dosimetrists, and radiation therapists."
- **On-Screen Text**: "Designed by Experts for Professionals"

#### Scene 3: Available Content (15-25 seconds)
- **Content**: Showcase of available modules
- **Key Elements**:
  - Radiation Protection Module details
  - Radiation Biology foundations
  - Section structure and organization
- **Audio**: "Available now, our Radiation Protection Module offers complete coverage of safety protocols and regulatory requirements, while our Radiation Biology foundations provide essential knowledge about cellular response to radiation."
- **On-Screen Text**: "Available Now"

#### Scene 4: Interactive Features (25-35 seconds)
- **Content**: Demonstration of interactive learning features
- **Key Elements**:
  - Interactive diagrams in action
  - Knowledge checks with feedback
  - Note-taking capabilities
- **Audio**: "Our interactive learning features bring complex concepts to life through dynamic visualizations, knowledge checks, and personalized note-taking, enhancing understanding and retention."
- **On-Screen Text**: "Interactive Learning"

#### Scene 5: User Experience (35-45 seconds)
- **Content**: Showcase of user experience features
- **Key Elements**:
  - Offline access functionality
  - Progress tracking dashboard
  - Personalized recommendations
- **Audio**: "Learn anywhere with offline access, track your progress with detailed statistics, and receive personalized content recommendations based on your role and interests."
- **On-Screen Text**: "Personalized Experience"

#### Scene 6: Content Roadmap (45-55 seconds)
- **Content**: Preview of upcoming content
- **Key Elements**:
  - Content roadmap timeline
  - Upcoming module previews
  - Notification preferences
- **Audio**: "Our platform is constantly evolving, with new educational content added regularly. View our content roadmap to see what's coming next and set notifications for new releases."
- **On-Screen Text**: "Growing Content Library"

#### Scene 7: Call to Action (55-60 seconds)
- **Content**: Final branding and download prompt
- **Key Elements**:
  - App logo
  - App store badges
  - Website URL
- **Audio**: "Download Radiation Oncology Academy today and elevate your professional education."
- **On-Screen Text**: "Download Now"

## Implementation Process

### Step 1: Environment Preparation
1. Set up recording devices with screen capture software:
   - iPhone 13 Pro (iOS 15.5) with QuickTime screen recording
   - iPad Pro 12.9" (iOS 15.5) with QuickTime screen recording
   - Samsung Galaxy S21 (Android 12) with AZ Screen Recorder
2. Ensure test accounts have appropriate content access
3. Configure devices for optimal video capture:
   - Set to English language
   - Set time to 9:41 AM (Apple standard)
   - Ensure full battery icon
   - Clear all notifications
   - Connect to Wi-Fi with full signal
   - Disable all notification sounds
   - Set volume to appropriate level

### Step 2: Content Preparation
1. Prepare test accounts with appropriate data:
   - Complete Radiation Protection Module progress
   - Partial Radiation Biology Module progress
   - Knowledge check history
   - Downloaded content for offline access
2. Ensure all interactive diagrams are fully functional
3. Verify content roadmap data is accurate
4. Prepare script and timing cues for each scene
5. Select appropriate background music (for iOS preview)
6. Record professional narration (for Google Play video)

### Step 3: Recording Process
1. For each scene in the storyboard:
   - Practice the interaction sequence multiple times
   - Ensure smooth, deliberate movements
   - Maintain consistent pace
   - Record multiple takes of each scene
   - Review recordings for quality and timing
2. For iOS App Preview:
   - Record iPhone version first
   - Record iPad version with same interactions but optimized for larger screen
3. For Google Play Promotional Video:
   - Record all scenes with slightly slower pace for narration
   - Ensure each scene allows sufficient time for narration

### Step 4: Post-Production
1. Import raw footage into video editing software (Final Cut Pro X or Adobe Premiere Pro)
2. Select best takes for each scene
3. Trim clips to exact timing requirements
4. Add transitions between scenes (subtle fade or dissolve)
5. Add on-screen text overlays
6. For iOS App Preview:
   - Add background music
   - Adjust audio levels
   - Ensure 30-second total duration
7. For Google Play Promotional Video:
   - Sync narration with video clips
   - Add background music at lower volume
   - Ensure 60-second total duration
8. Apply color correction if needed
9. Add device frames if desired

### Step 5: Export and Optimization
1. Export videos according to platform specifications:
   - iOS: H.264 encoding, 30fps, 1080p resolution
   - Google Play: H.264 encoding, 30fps, 1080p resolution
2. Verify audio quality and levels
3. Check file sizes and optimize if needed
4. Verify frame rate consistency
5. Review final videos for any issues or artifacts

### Step 6: Quality Assurance
1. Review all videos for:
   - Visual quality and clarity
   - Timing and pacing
   - Audio quality
   - Text legibility
   - Accurate representation of app functionality
   - Compliance with store requirements
2. Conduct frame-by-frame review of critical moments
3. Test playback on multiple devices
4. Verify file formats and specifications

### Step 7: Delivery and Upload
1. For iOS App Preview:
   - Prepare for direct upload to App Store Connect
   - Create preview poster frames
2. For Google Play Promotional Video:
   - Upload to YouTube channel
   - Set appropriate visibility (unlisted until launch)
   - Create compelling thumbnail
   - Prepare YouTube URL for Play Console

## Implementation Timeline

### Day 1 (April 12, 2025)
- Complete environment and content preparation
- Record all raw footage for iOS App Preview (iPhone)
- Record all raw footage for iOS App Preview (iPad)
- Begin post-production for iOS App Preview

### Day 2 (April 13, 2025)
- Complete post-production for iOS App Preview
- Record all raw footage for Google Play Promotional Video
- Record narration for Google Play Promotional Video
- Begin post-production for Google Play Promotional Video

### Day 3 (April 14, 2025)
- Complete post-production for Google Play Promotional Video
- Conduct quality assurance review for all videos
- Make any necessary adjustments or re-recordings
- Finalize all video assets
- Upload Google Play video to YouTube
- Prepare all assets for submission

## Quality Checklist

### Technical Requirements
- [ ] All videos meet required resolution specifications
- [ ] All videos use correct format and encoding
- [ ] Frame rate is consistent at 30fps
- [ ] Duration meets platform requirements (30s for iOS, 60s for Google Play)
- [ ] File sizes are within limits
- [ ] Audio quality is clear and consistent

### Content Requirements
- [ ] All key app features are demonstrated
- [ ] Interactions are smooth and deliberate
- [ ] Text overlays are legible and timed appropriately
- [ ] No placeholder or test content visible
- [ ] No confidential information visible
- [ ] Consistent presentation of app functionality

### Platform Compliance
- [ ] iOS App Preview shows only footage captured on iOS devices
- [ ] Google Play video complies with content policies
- [ ] No references to competing platforms
- [ ] No pricing information in videos
- [ ] No misleading content or functionality
- [ ] Appropriate content for medical/educational app

## Conclusion

This implementation plan provides a comprehensive approach to creating high-quality app preview videos for the Radiation Oncology Academy mobile app submission. By following this structured process, we will ensure that our videos effectively demonstrate the app's key features and value proposition while meeting all technical requirements for both the Apple App Store and Google Play Store.

The timeline allows for completion of all video assets by April 14, 2025, ahead of our April 19 submission target. Upon completion, these videos will be integrated with our screenshots and other submission assets to create a compelling presentation of the Radiation Oncology Academy mobile app in both app stores.
