# Radiation Oncology Academy - GoDaddy Deployment Guide
## For Non-Technical Users

This step-by-step guide will help you deploy the Radiation Oncology Academy website on GoDaddy hosting without requiring any coding knowledge. Each step includes detailed instructions with screenshots to make the process as simple as possible.

## Table of Contents
1. [Preparation Steps](#preparation-steps)
2. [GoDaddy Account Setup](#godaddy-account-setup)
3. [Domain Configuration](#domain-configuration)
4. [Hosting Setup](#hosting-setup)
5. [Website Files Upload](#website-files-upload)
6. [Database Setup](#database-setup)
7. [API Keys Configuration](#api-keys-configuration)
8. [Google Cloud Setup](#google-cloud-setup)
9. [Testing Your Website](#testing-your-website)
10. [Troubleshooting](#troubleshooting)

## Preparation Steps

### What You'll Need
- Your GoDaddy account credentials
- The Radiation Oncology Academy website files (provided in the zip file)
- API keys for OpenAI and ElevenLabs (provided separately)
- A computer with internet access
- Approximately 1-2 hours of time

### Before You Begin
1. Extract the `radiation_oncology_academy_final_v2.zip` file to a folder on your computer
2. Keep your API keys handy
3. Make sure you have access to your GoDaddy account email for verification

## GoDaddy Account Setup

### Step 1: Log in to Your GoDaddy Account
1. Open your web browser and go to [godaddy.com](https://www.godaddy.com)
2. Click the "Sign In" button in the top-right corner
3. Enter your username and password
4. Click "Sign In"

### Step 2: Navigate to Your Products
1. After logging in, click on "My Products" in the top navigation menu
2. You should see a list of all your GoDaddy products, including domains and hosting plans

## Domain Configuration

### Step 1: Select Your Domain
1. In the My Products page, find "radiationoncologyacademy.com" in your domains list
2. Click on "Manage" next to the domain name

### Step 2: Configure DNS Settings
1. In the domain management page, click on "DNS" or "DNS Management"
2. You'll need to set up the following records:
   - Type: A
   - Name: @
   - Value: This will be your hosting IP address (provided by GoDaddy)
   - TTL: 1 Hour
3. Click "Save" to apply these settings

### Step 3: Set Up Subdomains (Optional)
1. If you want to use subdomains like "api.radiationoncologyacademy.com", click "Add" to create a new record
2. Set up the following:
   - Type: CNAME
   - Name: api
   - Value: @
   - TTL: 1 Hour
3. Click "Save" to apply these settings

## Hosting Setup

### Step 1: Purchase or Access Your Hosting Plan
1. If you don't already have a hosting plan, go to the GoDaddy homepage
2. Click on "Web Hosting" in the top menu
3. Select "Business Hosting" or "Ultimate Hosting" (recommended for this website)
4. Follow the checkout process to purchase the hosting plan
5. Once purchased, go back to "My Products" and click "Manage" next to your hosting plan

### Step 2: Access cPanel
1. In your hosting management page, click on "cPanel" or "Manage"
2. This will take you to the cPanel dashboard, which is where you'll manage your hosting

### Step 3: Set Up Node.js Hosting
1. In cPanel, scroll down to the "Software" section
2. Click on "Setup Node.js App"
3. Click "Create Application"
4. Fill in the following details:
   - Application mode: Production
   - Node.js version: 16.x (or the latest available)
   - Application root: /radiation_oncology_academy
   - Application URL: radiationoncologyacademy.com
   - Application startup file: server.js
5. Click "Create" to set up the Node.js environment

## Website Files Upload

### Step 1: Access File Manager
1. In cPanel, scroll to the "Files" section
2. Click on "File Manager"
3. This will open the file manager where you can upload and manage your website files

### Step 2: Create Directory Structure
1. Navigate to the public_html folder
2. Click "New Folder" and create a folder named "radiation_oncology_academy"
3. Open this new folder

### Step 3: Upload Website Files
1. Click the "Upload" button in the top menu
2. In the upload page, click "Select File" or drag and drop the files from the extracted website folder
3. Upload all files and folders from the "backend" directory first
4. Once the backend files are uploaded, upload all files and folders from the "frontend" directory
5. This process may take some time depending on your internet connection

## Database Setup

### Step 1: Create a MongoDB Database
1. GoDaddy doesn't provide MongoDB directly, so we'll use MongoDB Atlas (a cloud database service)
2. Open a new browser tab and go to [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
3. Click "Try Free" to create an account
4. After signing up, click "Create a New Cluster"
5. Select the "Shared" (free) option
6. Choose your preferred cloud provider and region (select the one closest to your location)
7. Click "Create Cluster" (this may take a few minutes to provision)

### Step 2: Set Up Database Access
1. While your cluster is being created, click on "Database Access" in the left menu
2. Click "Add New Database User"
3. Create a username and password (make sure to save these credentials)
4. Set privileges to "Read and Write to Any Database"
5. Click "Add User"

### Step 3: Configure Network Access
1. Click on "Network Access" in the left menu
2. Click "Add IP Address"
3. For simplicity during setup, click "Allow Access from Anywhere" (you can restrict this later)
4. Click "Confirm"

### Step 4: Get Your Connection String
1. Once your cluster is created, click "Connect"
2. Select "Connect your application"
3. Copy the connection string (it will look something like: `mongodb+srv://username:password@cluster0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`)
4. Replace `<password>` in the string with your actual password
5. Save this connection string for the next section

## API Keys Configuration

### Step 1: Create Environment Variables File
1. In cPanel File Manager, navigate to your radiation_oncology_academy folder
2. Click "New File" and name it ".env"
3. Edit this file and add the following lines:

```
MONGODB_URI=your_mongodb_connection_string_from_previous_step
JWT_SECRET=choose_a_random_secure_string
OPENAI_API_KEY=your_openai_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
NODE_ENV=production
PORT=8080
```

4. Replace each value with your actual API keys and connection string
5. Click "Save Changes"

### Step 2: Update Frontend Configuration
1. Navigate to the frontend folder
2. Find and edit the file "next.config.js"
3. Update the API_URL value to match your domain (e.g., "https://radiationoncologyacademy.com/api")
4. Click "Save Changes"

## Google Cloud Setup

### Step 1: Create a Google Cloud Account
1. Open a new browser tab and go to [cloud.google.com](https://cloud.google.com)
2. Click "Get Started for Free"
3. Sign in with your Google account or create a new one
4. Follow the steps to set up your account and enter payment information (you won't be charged during the free trial)

### Step 2: Create a New Project
1. In the Google Cloud Console, click on the project dropdown at the top of the page
2. Click "New Project"
3. Name it "Radiation Oncology Academy"
4. Click "Create"

### Step 3: Set Up Google Cloud Storage
1. In the left menu, go to "Storage" > "Browser"
2. Click "Create Bucket"
3. Name your bucket "roa-private-source-materials"
4. Choose a region close to your location
5. Leave other settings as default
6. Click "Create"
7. Repeat this process to create two more buckets:
   - "roa-member-content"
   - "roa-public-content"

### Step 4: Set Up Service Account
1. In the left menu, go to "IAM & Admin" > "Service Accounts"
2. Click "Create Service Account"
3. Name it "roa-storage-account"
4. Click "Create and Continue"
5. For the role, select "Storage Admin"
6. Click "Continue" and then "Done"
7. Click on the service account you just created
8. Go to the "Keys" tab
9. Click "Add Key" > "Create new key"
10. Select JSON format
11. Click "Create" to download the key file

### Step 5: Upload Service Account Key
1. Go back to cPanel File Manager
2. Navigate to your radiation_oncology_academy folder
3. Create a new folder called "config"
4. Upload the JSON key file you downloaded to this folder

### Step 6: Update Environment Variables
1. Edit your .env file again
2. Add the following line:
```
GOOGLE_APPLICATION_CREDENTIALS=/path/to/your/radiation_oncology_academy/config/your-key-file.json
```
3. Replace the path with the actual path to your key file
4. Click "Save Changes"

## Testing Your Website

### Step 1: Start Your Application
1. In cPanel, go back to the Node.js App setup
2. Click on your application
3. Click "Run NPM Install" to install all dependencies
4. Once that completes, click "Run JS Script" to start your application

### Step 2: Check Your Website
1. Open a new browser tab
2. Go to your domain (radiationoncologyacademy.com)
3. You should see the Radiation Oncology Academy homepage
4. Test the following features:
   - User registration and login
   - Browsing content categories
   - Membership tier selection
   - Applying discount codes

### Step 3: Verify API Connections
1. Log in as an administrator
2. Go to the admin dashboard
3. Try generating a sample blog post using the AI content generator
4. Create a test podcast to verify ElevenLabs integration
5. Upload a test file to Google Cloud Storage

## Troubleshooting

### Common Issues and Solutions

#### Website Not Loading
1. Check if your Node.js application is running in cPanel
2. Verify your domain DNS settings are correct
3. Make sure all files were uploaded correctly

#### Database Connection Errors
1. Verify your MongoDB connection string in the .env file
2. Check if your IP address is allowed in MongoDB Atlas
3. Ensure your database user has the correct permissions

#### API Integration Issues
1. Verify all API keys in the .env file
2. Check if the APIs are active and have sufficient credits
3. Look for error messages in the application logs

#### Google Cloud Storage Problems
1. Verify the service account key file is uploaded correctly
2. Check if the environment variable path is correct
3. Ensure the service account has the proper permissions

### Getting Help
If you encounter issues not covered in this guide:
1. Check the detailed documentation in the "documentation" folder of your website files
2. Contact GoDaddy support for hosting-related issues
3. Reach out to a web developer for assistance with specific technical problems

## Conclusion
Congratulations! You've successfully deployed the Radiation Oncology Academy website on GoDaddy hosting. Your educational platform is now live and ready to serve medical physics professionals with tailored content, AI-powered features, and a flexible membership system.

Remember to regularly back up your website files and database to prevent data loss. You can do this through cPanel's backup tools or by setting up automated backups in MongoDB Atlas.

For ongoing maintenance and updates, refer to the admin guide included in your website files.
