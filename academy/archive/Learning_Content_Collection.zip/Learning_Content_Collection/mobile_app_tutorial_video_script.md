# Radiation Oncology Academy - Mobile App Tutorial Video Script

## Introduction

**[SCENE: Opening with Radiation Oncology Academy logo animation on mobile device]**

**NARRATOR:** Welcome to the Radiation Oncology Academy mobile app tutorial. This video will guide you through the powerful features of our mobile application, designed to provide seamless educational access for radiation oncology professionals on the go.

**[SCENE: Overview of mobile app home screen with callouts to main sections]**

**NARRATOR:** The Radiation Oncology Academy mobile app brings the full power of our educational platform to your smartphone or tablet, with optimized interfaces and offline capabilities designed specifically for mobile learning.

## Getting Started

**[SCENE: Show app download and installation]**

**NARRATOR:** The app is available for both iOS and Android devices. After installation, log in with the same credentials you use on the web platform.

**[SCENE: Demonstrate login screen and process]**

**NARRATOR:** If you're new to Radiation Oncology Academy, you can also create an account directly from the app. Your profile, preferences, and progress will automatically sync across all your devices.

## Home Screen Navigation

**[SCENE: Demonstrate home screen with finger taps highlighting features]**

**NARRATOR:** The home screen provides quick access to all key features:

**[SCENE: Highlight each section as mentioned]**

1. Your personalized content recommendations at the top
2. Continue learning section for recently accessed content
3. Downloaded content for offline access
4. New content alerts and notifications
5. Quick access to podcasts, news, and community features

**NARRATOR:** The bottom navigation bar remains consistent throughout the app for easy access to main sections.

## Content Library

**[SCENE: Navigate to Content Library, showing category structure]**

**NARRATOR:** The Content Library organizes all educational materials into intuitive categories.

**[SCENE: Demonstrate mobile search and filtering]**

**NARRATOR:** The search function is optimized for mobile, with voice search capability and predictive text. Filters help you quickly narrow down content by type, topic, or difficulty level.

**[SCENE: Show content viewing on mobile]**

**NARRATOR:** The reading experience is optimized for mobile screens with:

**[SCENE: Demonstrate each feature]**

1. Adjustable text size and night mode for comfortable reading
2. Landscape/portrait orientation switching
3. Distraction-free reading mode
4. Easy highlighting and note-taking with touch gestures
5. Offline access to downloaded content

## Learning Paths

**[SCENE: Navigate to Learning Paths section]**

**NARRATOR:** Learning Paths provide structured educational journeys through related content, all optimized for mobile learning.

**[SCENE: Show a learning path structure with progress indicators]**

**NARRATOR:** Your progress is tracked and synchronized with the web platform. Resume exactly where you left off, regardless of which device you last used.

**[SCENE: Demonstrate mobile-optimized assessments]**

**NARRATOR:** Assessments and interactive elements are designed for touch interaction, making it easy to test your knowledge wherever you are.

## Podcast Player

**[SCENE: Navigate to Podcast section]**

**NARRATOR:** The mobile podcast player is designed for on-the-go listening.

**[SCENE: Demonstrate podcast player features]**

**NARRATOR:** Key features include:
- Background playback while using other apps
- Lock screen controls
- Offline listening for downloaded episodes
- Sleep timer for bedtime listening
- Playback speed adjustment
- Audio bookmarking

**[SCENE: Show podcast download for offline listening]**

**NARRATOR:** Download episodes with a single tap to listen without using mobile data. Downloaded episodes are automatically managed to optimize storage space.

## News Reader

**[SCENE: Navigate to News section]**

**NARRATOR:** Stay updated with the latest developments in radiation oncology through our mobile-optimized news reader.

**[SCENE: Demonstrate news browsing and reading]**

**NARRATOR:** The news reader features:
- Swipe navigation between articles
- Offline reading for saved articles
- Easy sharing via email or messaging apps
- Text-to-speech functionality for hands-free consumption
- Bookmarking for later reference

## Interactive Learning

**[SCENE: Navigate to Interactive section]**

**NARRATOR:** Interactive learning tools are specially designed for touch interfaces.

**[SCENE: Demonstrate case study on mobile]**

**NARRATOR:** Case studies use intuitive touch interactions for decision-making and navigation through clinical scenarios.

**[SCENE: Show mobile quiz interface]**

**NARRATOR:** Quizzes and assessments use mobile-friendly input methods, making it easy to test your knowledge during short breaks in your day.

## Community Access

**[SCENE: Navigate to Community section]**

**NARRATOR:** Stay connected to the radiation oncology community wherever you are.

**[SCENE: Show discussion forum on mobile]**

**NARRATOR:** Participate in discussions with intuitive touch-based commenting and navigation. Receive notifications for responses to your contributions.

**[SCENE: Demonstrate live event participation]**

**NARRATOR:** Join live webinars and Q&A sessions directly from your mobile device with optimized video streaming and interactive participation.

## Offline Capabilities

**[SCENE: Demonstrate offline mode activation]**

**NARRATOR:** One of the most powerful features of the mobile app is comprehensive offline access.

**[SCENE: Show downloading content for offline use]**

**NARRATOR:** Download any content with a single tap. The app intelligently manages your storage, suggesting content to remove when space is limited.

**[SCENE: Demonstrate offline usage]**

**NARRATOR:** While offline, you can:
- Access all downloaded content
- Take notes and highlight text
- Complete downloaded assessments
- Listen to downloaded podcasts
- Track your progress

**NARRATOR:** All activity automatically synchronizes when you reconnect to the internet.

## Cross-Device Synchronization

**[SCENE: Split screen showing mobile app and web platform]**

**NARRATOR:** Seamless synchronization between mobile and web ensures a consistent experience across all your devices.

**[SCENE: Show starting content on web, continuing on mobile]**

**NARRATOR:** Begin reading an article on your desktop, then continue exactly where you left off on your mobile device. Notes, bookmarks, and progress synchronize instantly.

## Notifications and Reminders

**[SCENE: Navigate to Notifications section]**

**NARRATOR:** Stay informed with customizable notifications:

**[SCENE: Show notification settings]**

**NARRATOR:** Configure alerts for:
- New content matching your interests
- Responses to your community contributions
- Learning reminders based on your goals
- Live event notifications
- Updates to saved content

**[SCENE: Demonstrate notification management]**

**NARRATOR:** Easily manage notification frequency and types to avoid information overload.

## Profile and Settings

**[SCENE: Navigate to Profile section]**

**NARRATOR:** Manage your profile and app settings with intuitive mobile controls.

**[SCENE: Show profile customization]**

**NARRATOR:** Update your specialty, interests, and learning goals directly from the app.

**[SCENE: Demonstrate app settings]**

**NARRATOR:** Customize your experience with settings for:
- Display preferences (dark mode, text size)
- Download behavior and storage management
- Notification preferences
- Privacy controls
- Accessibility features

## Help and Support

**[SCENE: Navigate to Help section]**

**NARRATOR:** Get assistance whenever you need it:

**[SCENE: Show mobile help options]**

**NARRATOR:** Access support through:
- In-app help articles
- Tutorial videos
- Live chat support
- Email support
- Feedback submission

**[SCENE: Demonstrate in-app tutorial access]**

**NARRATOR:** Quick tutorials for each feature are available directly within the app, providing contextual guidance when you need it.

## Conclusion

**[SCENE: Return to home screen with visual summary of key features]**

**NARRATOR:** The Radiation Oncology Academy mobile app puts comprehensive radiation oncology education in your pocket, with powerful features optimized for learning on the go.

**[SCENE: Show synchronization between web and mobile]**

**NARRATOR:** Combined with our web platform, you'll enjoy a seamless educational experience across all your devices, adapting to your schedule and learning preferences.

**[SCENE: Call to action with app store badges]**

**NARRATOR:** Download the Radiation Oncology Academy app today from the Apple App Store or Google Play Store and transform your professional development.

**[SCENE: Closing with Radiation Oncology Academy logo and contact information]**

---

# Production Notes

## Visual Style
- Clean, modern mobile interface with blue and white color scheme
- Finger tap and swipe animations to demonstrate interactions
- Device frames should be minimal and modern
- Use both smartphone and tablet demonstrations
- Show both iOS and Android interfaces where they differ

## Device Requirements
- Feature both iPhone and Android phone demonstrations
- Include tablet views for iPad and Android tablets
- Show both portrait and landscape orientations
- Demonstrate responsive design elements

## Audio Requirements
- Professional narrator with clear medical terminology pronunciation
- Minimal background music appropriate for mobile context
- Sound effects for taps, swipes, and notifications should be subtle

## Technical Specifications
- Resolution: 1080p minimum
- Duration: 6-8 minutes (slightly shorter than web tutorial)
- Format: MP4 with H.264 encoding
- Captions: Include closed captions in English
- Intro and outro: 5 seconds each with logo animation

## Additional Requirements
- Include text overlays for key features and gestures
- Highlight finger movements and touch interactions
- Use zoom effects for small UI elements
- Include progress bar at bottom of screen
- Add chapter markers for easy navigation
- Show battery usage and performance metrics where relevant
