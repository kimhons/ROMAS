# CI/CD Pipeline Setup for Radiation Oncology Academy

This document outlines the configuration and setup of the Continuous Integration and Continuous Deployment (CI/CD) pipeline for the Radiation Oncology Academy platform, covering both the website and mobile applications.

## Overview

The CI/CD pipeline automates the build, test, and deployment processes, ensuring consistent and reliable releases across all platforms. This setup uses GitHub Actions for the primary workflow, with integrations to the appropriate deployment targets.

## Pipeline Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Code Changes   │────▶│  Build & Test   │────▶│    Deploy to    │
│                 │     │                 │     │    Staging      │
└─────────────────┘     └─────────────────┘     └────────┬────────┘
                                                         │
                                                         ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │                 │     │                 │
                        │  Manual Review  │◀────│   Integration   │
                        │  & Approval     │     │     Tests       │
                        └────────┬────────┘     └─────────────────┘
                                 │
                                 ▼
                        ┌─────────────────┐
                        │                 │
                        │    Deploy to    │
                        │   Production    │
                        └─────────────────┘
```

## Repository Structure

```
radiation-oncology-academy/
├── website/                # Website codebase
│   ├── frontend/           # React frontend
│   ├── backend/            # Node.js backend
│   └── ...
├── mobile/                 # Mobile app codebase
│   ├── ios/                # iOS-specific code
│   ├── android/            # Android-specific code
│   └── ...
├── .github/
│   └── workflows/          # GitHub Actions workflow files
│       ├── website.yml     # Website CI/CD workflow
│       ├── ios.yml         # iOS app CI/CD workflow
│       └── android.yml     # Android app CI/CD workflow
└── ...
```

## Website CI/CD Workflow

### File: `.github/workflows/website.yml`

```yaml
name: Website CI/CD

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'website/**'
      - '.github/workflows/website.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'website/**'
  workflow_dispatch:

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: website/package-lock.json
      
      - name: Install dependencies
        run: |
          cd website
          npm ci
      
      - name: Lint
        run: |
          cd website
          npm run lint
      
      - name: Run tests
        run: |
          cd website
          npm test
      
      - name: Build
        run: |
          cd website
          npm run build
      
      - name: Upload build artifacts
        uses: actions/upload-artifact@v3
        with:
          name: website-build
          path: website/build/
  
  deploy-staging:
    needs: build-and-test
    if: github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Download build artifacts
        uses: actions/download-artifact@v3
        with:
          name: website-build
          path: website/build
      
      - name: Deploy to staging
        uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT_STAGING }}'
          projectId: radiation-oncology-academy-staging
          channelId: live
  
  deploy-production:
    needs: build-and-test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Download build artifacts
        uses: actions/download-artifact@v3
        with:
          name: website-build
          path: website/build
      
      - name: Deploy to production
        uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT_PRODUCTION }}'
          projectId: radiation-oncology-academy
          channelId: live
```

## iOS CI/CD Workflow

### File: `.github/workflows/ios.yml`

```yaml
name: iOS CI/CD

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'mobile/ios/**'
      - 'mobile/src/**'
      - '.github/workflows/ios.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'mobile/ios/**'
      - 'mobile/src/**'
  workflow_dispatch:

jobs:
  build-and-test:
    runs-on: macos-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: mobile/package-lock.json
      
      - name: Install dependencies
        run: |
          cd mobile
          npm ci
          cd ios
          pod install
      
      - name: Run tests
        run: |
          cd mobile
          npm run test
      
      - name: Build iOS app
        run: |
          cd mobile/ios
          xcodebuild -workspace RadiationOncologyApp.xcworkspace -scheme RadiationOncologyApp -configuration Debug -sdk iphonesimulator -destination 'platform=iOS Simulator,name=iPhone 14,OS=16.2' build test
  
  build-testflight:
    needs: build-and-test
    if: github.ref == 'refs/heads/develop' || github.ref == 'refs/heads/main'
    runs-on: macos-latest
    environment: ios-deployment
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: mobile/package-lock.json
      
      - name: Install dependencies
        run: |
          cd mobile
          npm ci
          cd ios
          pod install
      
      - name: Setup Ruby
        uses: ruby/setup-ruby@v1
        with:
          ruby-version: '3.0'
          bundler-cache: true
      
      - name: Install fastlane
        run: |
          cd mobile/ios
          gem install fastlane
      
      - name: Setup code signing
        run: |
          cd mobile/ios
          echo "${{ secrets.IOS_PROVISIONING_PROFILE }}" | base64 --decode > profile.mobileprovision
          mkdir -p ~/Library/MobileDevice/Provisioning\ Profiles
          cp profile.mobileprovision ~/Library/MobileDevice/Provisioning\ Profiles/
          echo "${{ secrets.IOS_CERTIFICATE }}" | base64 --decode > certificate.p12
          security create-keychain -p "" build.keychain
          security default-keychain -s build.keychain
          security unlock-keychain -p "" build.keychain
          security import certificate.p12 -k build.keychain -P "${{ secrets.IOS_CERTIFICATE_PASSWORD }}" -A
          security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k "" build.keychain
      
      - name: Build and upload to TestFlight
        env:
          APP_STORE_CONNECT_API_KEY_ID: ${{ secrets.APP_STORE_CONNECT_API_KEY_ID }}
          APP_STORE_CONNECT_API_KEY_ISSUER_ID: ${{ secrets.APP_STORE_CONNECT_API_KEY_ISSUER_ID }}
          APP_STORE_CONNECT_API_KEY_CONTENT: ${{ secrets.APP_STORE_CONNECT_API_KEY_CONTENT }}
        run: |
          cd mobile/ios
          fastlane beta
```

## Android CI/CD Workflow

### File: `.github/workflows/android.yml`

```yaml
name: Android CI/CD

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'mobile/android/**'
      - 'mobile/src/**'
      - '.github/workflows/android.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'mobile/android/**'
      - 'mobile/src/**'
  workflow_dispatch:

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: mobile/package-lock.json
      
      - name: Install dependencies
        run: |
          cd mobile
          npm ci
      
      - name: Run tests
        run: |
          cd mobile
          npm run test
      
      - name: Set up JDK
        uses: actions/setup-java@v3
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'
      
      - name: Build Android app
        run: |
          cd mobile/android
          ./gradlew assembleDebug
      
      - name: Run Android tests
        run: |
          cd mobile/android
          ./gradlew testDebugUnitTest
  
  build-internal:
    needs: build-and-test
    if: github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    environment: android-deployment
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: mobile/package-lock.json
      
      - name: Install dependencies
        run: |
          cd mobile
          npm ci
      
      - name: Set up JDK
        uses: actions/setup-java@v3
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'
      
      - name: Setup signing
        run: |
          cd mobile/android
          echo "${{ secrets.ANDROID_KEYSTORE }}" | base64 --decode > app/upload-keystore.jks
          echo "storeFile=upload-keystore.jks" > keystore.properties
          echo "storePassword=${{ secrets.ANDROID_KEYSTORE_PASSWORD }}" >> keystore.properties
          echo "keyAlias=${{ secrets.ANDROID_KEY_ALIAS }}" >> keystore.properties
          echo "keyPassword=${{ secrets.ANDROID_KEY_PASSWORD }}" >> keystore.properties
      
      - name: Build release bundle
        run: |
          cd mobile/android
          ./gradlew bundleRelease
      
      - name: Upload to Play Store (Internal Testing)
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJsonPlainText: ${{ secrets.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON }}
          packageName: org.radiationoncologyacademy.mobile
          releaseFiles: mobile/android/app/build/outputs/bundle/release/app-release.aab
          track: internal
          status: completed
  
  build-production:
    needs: build-and-test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: android-production
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
          cache-dependency-path: mobile/package-lock.json
      
      - name: Install dependencies
        run: |
          cd mobile
          npm ci
      
      - name: Set up JDK
        uses: actions/setup-java@v3
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'
      
      - name: Setup signing
        run: |
          cd mobile/android
          echo "${{ secrets.ANDROID_KEYSTORE }}" | base64 --decode > app/upload-keystore.jks
          echo "storeFile=upload-keystore.jks" > keystore.properties
          echo "storePassword=${{ secrets.ANDROID_KEYSTORE_PASSWORD }}" >> keystore.properties
          echo "keyAlias=${{ secrets.ANDROID_KEY_ALIAS }}" >> keystore.properties
          echo "keyPassword=${{ secrets.ANDROID_KEY_PASSWORD }}" >> keystore.properties
      
      - name: Build release bundle
        run: |
          cd mobile/android
          ./gradlew bundleRelease
      
      - name: Upload to Play Store (Production)
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJsonPlainText: ${{ secrets.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON }}
          packageName: org.radiationoncologyacademy.mobile
          releaseFiles: mobile/android/app/build/outputs/bundle/release/app-release.aab
          track: production
          status: completed
```

## Fastlane Configuration for iOS

### File: `mobile/ios/fastlane/Fastfile`

```ruby
default_platform(:ios)

platform :ios do
  desc "Push a new beta build to TestFlight"
  lane :beta do
    app_store_connect_api_key(
      key_id: ENV["APP_STORE_CONNECT_API_KEY_ID"],
      issuer_id: ENV["APP_STORE_CONNECT_API_KEY_ISSUER_ID"],
      key_content: ENV["APP_STORE_CONNECT_API_KEY_CONTENT"],
      duration: 1200,
      in_house: false
    )
    
    increment_build_number(
      xcodeproj: "RadiationOncologyApp.xcodeproj"
    )
    
    build_app(
      scheme: "RadiationOncologyApp",
      workspace: "RadiationOncologyApp.xcworkspace",
      export_method: "app-store"
    )
    
    upload_to_testflight(
      skip_waiting_for_build_processing: true
    )
  end
end
```

## Required Secrets

### GitHub Repository Secrets

#### Website Deployment
- `FIREBASE_SERVICE_ACCOUNT_STAGING`: Firebase service account for staging
- `FIREBASE_SERVICE_ACCOUNT_PRODUCTION`: Firebase service account for production

#### iOS Deployment
- `IOS_CERTIFICATE`: Base64-encoded distribution certificate
- `IOS_CERTIFICATE_PASSWORD`: Certificate password
- `IOS_PROVISIONING_PROFILE`: Base64-encoded provisioning profile
- `APP_STORE_CONNECT_API_KEY_ID`: App Store Connect API key ID
- `APP_STORE_CONNECT_API_KEY_ISSUER_ID`: App Store Connect API key issuer ID
- `APP_STORE_CONNECT_API_KEY_CONTENT`: App Store Connect API key content

#### Android Deployment
- `ANDROID_KEYSTORE`: Base64-encoded keystore file
- `ANDROID_KEYSTORE_PASSWORD`: Keystore password
- `ANDROID_KEY_ALIAS`: Key alias
- `ANDROID_KEY_PASSWORD`: Key password
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`: Google Play service account JSON

## Deployment Environments

### Staging Environment
- Website: https://staging.radiationoncologyacademy.org
- iOS: TestFlight Internal Testing
- Android: Google Play Internal Testing

### Production Environment
- Website: https://radiationoncologyacademy.org
- iOS: App Store
- Android: Google Play Store

## Workflow Triggers

1. **Automatic Triggers**:
   - Push to `develop` branch: Deploys to staging environments
   - Push to `main` branch: Deploys to production environments (requires approval)
   - Pull requests: Runs build and tests only

2. **Manual Triggers**:
   - Workflow dispatch: Allows manual triggering of workflows from GitHub UI

## Monitoring and Notifications

- GitHub Actions status notifications via email
- Slack integration for build and deployment notifications
- Error reporting via Firebase Crashlytics

## Setup Instructions

1. **Repository Setup**:
   - Create the repository structure as outlined above
   - Add the workflow files to `.github/workflows/`

2. **Secrets Configuration**:
   - Add all required secrets to the GitHub repository
   - Configure environment-specific secrets for production deployments

3. **Environment Setup**:
   - Create staging and production environments in GitHub
   - Configure protection rules for production environment (require approvals)

4. **Service Accounts**:
   - Create Firebase service accounts for website deployment
   - Create Google Play service account for Android deployment
   - Configure App Store Connect API key for iOS deployment

5. **Initial Deployment**:
   - Push to the `develop` branch to trigger the first staging deployment
   - Review the staging deployment
   - Create a pull request to merge to `main` for production deployment

## Maintenance and Troubleshooting

### Common Issues

1. **Build Failures**:
   - Check the build logs for specific errors
   - Verify that all dependencies are correctly installed
   - Ensure that the code passes all tests locally before pushing

2. **Deployment Failures**:
   - Verify that all secrets are correctly configured
   - Check service account permissions
   - Ensure that the build artifacts are correctly generated

3. **Certificate Issues (iOS)**:
   - Verify that the certificate and provisioning profile are valid
   - Check that the certificate password is correct
   - Ensure that the certificate is not expired

### Regular Maintenance

1. **Certificate Renewal**:
   - iOS certificates expire after one year
   - Update the certificate in GitHub secrets when renewed

2. **Dependency Updates**:
   - Regularly update dependencies to maintain security
   - Test thoroughly after dependency updates

3. **Workflow Updates**:
   - Keep GitHub Actions workflows updated with the latest versions
   - Review and update deployment configurations as needed

## Conclusion

This CI/CD pipeline setup provides automated build, test, and deployment workflows for the Radiation Oncology Academy platform across web and mobile platforms. The configuration ensures consistent and reliable releases, with appropriate safeguards for production deployments.

By following this setup, the development team can focus on building features while the CI/CD pipeline handles the repetitive tasks of building, testing, and deploying the applications.
