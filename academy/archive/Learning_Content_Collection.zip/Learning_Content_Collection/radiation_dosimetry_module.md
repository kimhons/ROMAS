# Radiation Dosimetry Module

## Overview
This module covers the essential concepts and principles of radiation dosimetry that form the foundation of clinical radiation oncology practice. Understanding dosimetry is critical for accurate treatment planning, quality assurance, and radiation safety. The module explores fundamental dosimetric quantities, measurement techniques, calibration protocols, and practical applications in radiation therapy. After completing this module, learners will have a comprehensive understanding of how radiation dose is defined, measured, and applied in clinical settings.

## Learning Objectives
- Define and distinguish between fundamental dosimetric quantities including absorbed dose, kerma, and exposure
- Explain the principles of cavity theory and its application to radiation dosimetry
- Describe the operation of common dosimetry systems used in radiation oncology
- Apply calibration protocols to determine absorbed dose to water from ionization chamber measurements
- Analyze sources of uncertainty in radiation dosimetry and implement appropriate quality assurance procedures

## Prerequisites
- Fundamental Physics Module
- Basic understanding of radiation interactions with matter
- Familiarity with mathematical concepts including calculus and exponential functions

## Module Structure
1. Fundamental Dosimetric Quantities
2. Cavity Theory and Dosimetry Principles
3. Dosimetry Systems and Instrumentation
4. Calibration Protocols and Standards
5. Clinical Applications and Quality Assurance
6. Module Assessment

## Estimated Completion Time
4 hours

## Key Terms
- **Absorbed Dose**: The energy imparted by ionizing radiation per unit mass of material
- **Kerma**: Kinetic Energy Released per unit MAss, representing energy transferred from photons to charged particles
- **Bragg-Gray Cavity Theory**: Theoretical foundation relating ionization in a gas-filled cavity to absorbed dose in the surrounding medium
- **TG-51 Protocol**: AAPM Task Group 51 protocol for clinical reference dosimetry of high-energy photon and electron beams
- **Dosimetry System**: Collection of instruments and procedures used to determine radiation dose

## Module Resources
- Khan's The Physics of Radiation Therapy, 6th Edition, Chapters 8-10
- IAEA Technical Reports Series No. 398: Absorbed Dose Determination in External Beam Radiotherapy
- AAPM TG-51 Protocol for Clinical Reference Dosimetry of High-Energy Photon and Electron Beams
- ICRU Report 90: Key Data for Ionizing-Radiation Dosimetry

# Lesson 1: Fundamental Dosimetric Quantities

## Overview
This lesson introduces the fundamental quantities used in radiation dosimetry, including absorbed dose, kerma, exposure, and their interrelationships. Understanding these quantities is essential for accurate dose measurement and calculation in radiation therapy. The lesson explores the definitions, units, and practical applications of these dosimetric quantities in clinical settings.

## Learning Objectives
- Define absorbed dose, kerma, and exposure in precise terms
- Convert between different dosimetric quantities and their units
- Explain the relationship between kerma and absorbed dose under different equilibrium conditions

## Estimated Completion Time
45 minutes

## Content Section 1: Absorbed Dose

### Subsection 1.1: Definition and Units
Absorbed dose is the fundamental dosimetric quantity in radiation therapy. It is defined as the energy imparted (ε) by ionizing radiation per unit mass (m) of material:

$$D = \frac{d\varepsilon}{dm}$$

The SI unit of absorbed dose is the gray (Gy), which equals one joule per kilogram:

$$1 \text{ Gy} = 1 \text{ J/kg}$$

The older unit of absorbed dose was the rad (radiation absorbed dose):

$$1 \text{ rad} = 0.01 \text{ Gy} = 0.01 \text{ J/kg}$$

Absorbed dose is a point quantity, meaning it can vary from point to point within a medium. It is the most relevant quantity for determining biological effects and clinical outcomes in radiation therapy.

[IMAGE: Visual representation of energy deposition in tissue with color gradient showing dose distribution]

### Subsection 1.2: Energy Imparted
The energy imparted (ε) to matter in a volume is defined as:

$$\varepsilon = R_{in} - R_{out} + \sum Q$$

Where:
- R<sub>in</sub> is the radiant energy entering the volume
- R<sub>out</sub> is the radiant energy leaving the volume
- ∑Q is the sum of all changes in rest mass energy of nuclei and elementary particles in the volume

Energy imparted accounts for all energy depositions and losses within the volume, including those from primary and secondary radiations.

[ANIMATION: Visualization of energy transfer and deposition processes in a defined volume, showing incoming and outgoing radiation, as well as energy conversion events]

## Content Section 2: Kerma

### Subsection 2.1: Definition and Units
Kerma (Kinetic Energy Released per unit MAss) represents the first step in the energy deposition process for indirectly ionizing radiations like photons. It is defined as the sum of the initial kinetic energies of all charged particles liberated by uncharged particles in a material per unit mass:

$$K = \frac{dE_{tr}}{dm}$$

Where:
- dE<sub>tr</sub> is the sum of the initial kinetic energies of all charged particles liberated by uncharged particles
- dm is the mass of the material

Kerma is also measured in gray (Gy), the same unit as absorbed dose.

### Subsection 2.2: Collision and Radiative Kerma
Kerma can be divided into two components:

$$K = K_{col} + K_{rad}$$

Where:
- K<sub>col</sub> is collision kerma, representing energy spent in ionization and excitation near the interaction site
- K<sub>rad</sub> is radiative kerma, representing energy carried away by bremsstrahlung photons

The relationship between these components is often expressed using the radiative fraction g:

$$g = \frac{K_{rad}}{K}$$

For low-Z materials like tissue and for photon energies used in radiation therapy, g is typically small (< 0.1), meaning most of the energy transferred to charged particles is deposited locally.

[INTERACTIVE EXERCISE: Kerma Components Calculator]
This interactive tool allows you to adjust photon energy and material composition to see how the collision and radiative components of kerma change. Observe how the radiative fraction increases with both photon energy and atomic number.

## Content Section 3: Exposure

### Subsection 3.1: Definition and Units
Exposure is a measure of ionization in air produced by photons. It is defined as the total charge of ions of one sign produced in air when all electrons liberated by photons in a volume of air are completely stopped, divided by the mass of air in that volume:

$$X = \frac{dQ}{dm}$$

Where:
- dQ is the absolute value of the total charge of ions of one sign
- dm is the mass of air

The SI unit of exposure is coulomb per kilogram (C/kg). The traditional unit is the roentgen (R):

$$1 \text{ R} = 2.58 \times 10^{-4} \text{ C/kg}$$

Exposure is defined only for photon interactions in air and is not used for describing dose in tissue or for other types of radiation.

### Subsection 3.2: Relationship to Absorbed Dose
The exposure can be related to absorbed dose in air through the mean energy required to produce an ion pair in air (W/e):

$$D_{air} = X \times \frac{W}{e}$$

Where:
- D<sub>air</sub> is the absorbed dose in air
- X is the exposure
- W/e is the mean energy required to produce an ion pair in air (approximately 33.97 J/C)

This relationship allows conversion between exposure measurements and absorbed dose in air, which is useful in calibration procedures.

[TABLE: Conversion Factors Between Dosimetric Quantities]
| From | To | Conversion Factor |
|------|----|--------------------|
| Exposure (R) | Absorbed dose in air (Gy) | 0.00877 Gy/R |
| Kerma in air (Gy) | Exposure (R) | 114.1 R/Gy |
| Absorbed dose in air (Gy) | Absorbed dose in water (Gy) | ~1.11 (depends on energy) |

## Content Section 4: Equilibrium Conditions

### Subsection 4.1: Charged Particle Equilibrium
Charged Particle Equilibrium (CPE) is a condition where, for every charged particle leaving a volume, a charged particle of the same type and energy enters the volume. Under CPE conditions, absorbed dose and collision kerma are equal:

$$D = K_{col} \text{ (under CPE)}$$

True CPE is rarely achieved in clinical situations due to beam attenuation and boundaries between different materials. However, the concept is important for understanding dose measurements and calculations.

### Subsection 4.2: Transient Charged Particle Equilibrium
In most practical situations, Transient Charged Particle Equilibrium (TCPE) exists, where absorbed dose and collision kerma are related by:

$$D = K_{col} \times \beta \text{ (under TCPE)}$$

Where β is a proportionality factor slightly greater than 1.0 (typically 1.005-1.02 for megavoltage photon beams in tissue).

[ANIMATION: Visualization of charged particle equilibrium conditions, showing particle tracks entering and leaving a volume under different equilibrium states]

## Clinical Application
A medical physicist is performing absolute dose calibration of a new linear accelerator using an ionization chamber and following the TG-51 protocol. The chamber reading is 19.54 nC for a 200 MU exposure at reference conditions (10×10 cm² field, 10 cm depth in water, 100 cm SSD). The chamber has an N<sub>D,w</sub> calibration factor of 5.4 × 10⁷ Gy/C with k<sub>Q</sub> = 0.992. The temperature is 22°C and the pressure is 750 mmHg.

The physicist first calculates the temperature-pressure correction factor:

$$k_{TP} = \frac{(273.15 + T)}{(273.15 + T_0)} \times \frac{P_0}{P} = \frac{(273.15 + 22)}{(273.15 + 20)} \times \frac{760}{750} = 1.018$$

Then, the absorbed dose to water is calculated:

$$D_w = M \times N_{D,w} \times k_Q \times k_{TP} = 19.54 \times 10^{-9} \times 5.4 \times 10^7 \times 0.992 \times 1.018 = 1.06 \text{ Gy}$$

Finally, the dose per monitor unit is determined:

$$\text{Dose/MU} = \frac{D_w}{MU} = \frac{1.06 \text{ Gy}}{200 \text{ MU}} = 0.0053 \text{ Gy/MU}$$

This calibration ensures that when the linear accelerator delivers 1 MU under reference conditions, it delivers 0.0053 Gy (5.3 mGy) to water at the reference point.

## Key Points Summary
- Absorbed dose is the fundamental quantity for radiation therapy, representing energy imparted per unit mass
- Kerma represents the first step in energy transfer from uncharged to charged particles
- Exposure is a measure of ionization in air and is useful for calibration purposes
- Under charged particle equilibrium, absorbed dose equals collision kerma
- Understanding these quantities and their relationships is essential for accurate dosimetry in radiation therapy

## Check Your Understanding
1. Which of the following is the SI unit for absorbed dose?
   - A) Roentgen (R)
   - B) Gray (Gy)
   - C) Sievert (Sv)
   - D) Coulomb per kilogram (C/kg)
   
   Answer: B) Gray (Gy). The gray is defined as one joule per kilogram and is the SI unit for absorbed dose.

2. What is the relationship between absorbed dose (D) and collision kerma (K<sub>col</sub>) under conditions of charged particle equilibrium?
   - A) D = K<sub>col</sub>
   - B) D < K<sub>col</sub>
   - C) D > K<sub>col</sub>
   - D) D = K<sub>col</sub> × g
   
   Answer: A) D = K<sub>col</sub>. Under charged particle equilibrium, the absorbed dose equals the collision kerma.

3. Calculate the absorbed dose in air from an exposure of 10 R, given that W/e = 33.97 J/C.
   - A) 0.0877 Gy
   - B) 0.877 Gy
   - C) 8.77 Gy
   - D) 87.7 Gy
   
   Answer: A) 0.0877 Gy. Using D<sub>air</sub> = X × W/e = 10 R × 2.58 × 10⁻⁴ C/kg/R × 33.97 J/C = 0.0877 Gy.

4. Which of the following best describes kerma?
   - A) Energy imparted per unit mass
   - B) Kinetic energy released per unit mass
   - C) Charge liberated per unit mass
   - D) Equivalent dose per unit mass
   
   Answer: B) Kinetic energy released per unit mass. Kerma represents the sum of the initial kinetic energies of all charged particles liberated by uncharged particles in a material per unit mass.

5. In a 6 MV photon beam, why is the absorbed dose at the surface of a phantom less than the maximum dose at depth?
   - A) Due to inverse square law
   - B) Due to lack of charged particle equilibrium
   - C) Due to beam hardening
   - D) Due to radiative losses
   
   Answer: B) Due to lack of charged particle equilibrium. At the surface, there is an insufficient buildup of secondary electrons, resulting in a lack of charged particle equilibrium and a lower dose compared to the maximum at depth.

## References
1. Podgorsak EB. Radiation Oncology Physics: A Handbook for Teachers and Students. Vienna: International Atomic Energy Agency; 2005.
2. Almond PR, Biggs PJ, Coursey BM, et al. AAPM's TG-51 protocol for clinical reference dosimetry of high-energy photon and electron beams. Med Phys. 1999;26(9):1847-1870.
3. International Commission on Radiation Units and Measurements. ICRU Report 90: Key Data for Ionizing-Radiation Dosimetry. Journal of the ICRU. 2016;14(1).
4. Khan FM, Gibbons JP. Khan's The Physics of Radiation Therapy. 6th ed. Philadelphia: Lippincott Williams & Wilkins; 2020.
