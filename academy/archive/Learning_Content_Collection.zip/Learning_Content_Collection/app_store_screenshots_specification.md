# App Store Screenshots Design Specification

## Overview
This document outlines the detailed design specifications for creating screenshots for both the iOS App Store and Google Play Store. These screenshots will showcase the key features and content of the Radiation Oncology Academy mobile app in a visually consistent and compelling manner.

## General Design Guidelines

### Visual Style
- **Clean, Professional Aesthetic**: Maintain a clinical, professional look aligned with medical education
- **Color Scheme**: Use the app's primary color palette (deep blue, teal, white) consistently
- **Typography**: Sans-serif fonts for all text overlays (Helvetica Neue or Roboto)
- **Text Overlay Style**: Semi-transparent background bars with white text for maximum readability
- **Device Frames**: Include minimal device frames to provide context

### Text Overlay Guidelines
- **Headline Format**: Short, benefit-focused phrases (3-5 words)
- **Font Size**: Large enough to be readable at thumbnail size
- **Positioning**: Consistent placement (top or bottom) across all screenshots
- **Language**: Professional but accessible terminology
- **Character Count**: Maximum 30 characters per headline

## iOS App Store Screenshots

### Required Sizes
1. **6.5" iPhone (iPhone 13 Pro Max)**
   - 1284 x 2778 pixels portrait
   - Primary showcase screenshots

2. **5.5" iPhone (iPhone 8 Plus)**
   - 1242 x 2208 pixels portrait
   - Required for compatibility with older devices

3. **12.9" iPad Pro**
   - 2048 x 2732 pixels portrait
   - Showcase tablet-optimized interface

### Screenshot Scenes (8 total)

1. **Home Screen with Module Overview**
   - **Content**: Home screen showing module cards for Radiation Protection and Radiation Biology
   - **Action**: None (static screen)
   - **Text Overlay**: "Comprehensive Educational Modules"
   - **Highlight**: Module cards with progress indicators

2. **Radiation Protection Module Main Screen**
   - **Content**: Module main screen showing section list
   - **Action**: None (static screen)
   - **Text Overlay**: "Complete Radiation Protection Content"
   - **Highlight**: Section list with completion indicators

3. **Interactive Diagram - MRI Safety**
   - **Content**: MRI Safety Zones interactive diagram
   - **Action**: Show interaction with zone elements
   - **Text Overlay**: "Interactive Learning Tools"
   - **Highlight**: Active zone with information popup

4. **Knowledge Check Example**
   - **Content**: Multiple-choice question from Radiation Protection Module
   - **Action**: Show selected answer with feedback
   - **Text Overlay**: "Test Your Knowledge"
   - **Highlight**: Correct answer feedback

5. **Radiation Biology Module Main Screen**
   - **Content**: Module main screen showing section list
   - **Action**: None (static screen)
   - **Text Overlay**: "Expanding Content Library"
   - **Highlight**: Available and coming soon sections

6. **Interactive Diagram - Cell Survival Curves**
   - **Content**: Cell Survival Curves interactive diagram
   - **Action**: Show interaction with curve elements
   - **Text Overlay**: "Visualize Complex Concepts"
   - **Highlight**: Active element with information popup

7. **Offline Content Access**
   - **Content**: Downloaded content library screen
   - **Action**: Show downloaded modules
   - **Text Overlay**: "Learn Anywhere, Anytime"
   - **Highlight**: Download status indicators

8. **Progress Tracking and Achievements**
   - **Content**: User profile with progress statistics
   - **Action**: None (static screen)
   - **Text Overlay**: "Track Your Professional Growth"
   - **Highlight**: Completion percentages and earned badges

## Google Play Store Screenshots

### Required Sizes
1. **Phone Screenshots**
   - 1080 x 1920 pixels (16:9 aspect ratio)
   - Minimum 2 screenshots, maximum 8 (we'll use 8)

2. **7-inch Tablet**
   - 1080 x 1920 pixels (16:9 aspect ratio)
   - Optional but recommended

3. **10-inch Tablet**
   - 1080 x 1920 pixels (16:9 aspect ratio)
   - Optional but recommended

### Screenshot Scenes
- Use the same 8 scenes as iOS screenshots for consistency
- Adapt layouts to account for Android UI differences
- Maintain consistent text overlays and highlighting approach

## Design Production Process

### Preparation
1. Set up test environment with complete content
2. Ensure all UI elements are final and error-free
3. Prepare text overlay templates for consistency
4. Create device frame templates for each required size

### Capture Process
1. Capture raw screenshots on actual devices
2. Ensure proper lighting and screen brightness
3. Capture multiple versions of each scene
4. Verify all captured content is appropriate and error-free

### Post-Processing
1. Import raw screenshots into Photoshop
2. Apply consistent color correction if needed
3. Add device frames
4. Add text overlay bars with headlines
5. Add subtle highlight effects to key UI elements
6. Export in required formats for each store
7. Verify pixel dimensions and file formats

## Text Overlay Content (Final Copy)

| Screenshot | Text Overlay |
|------------|--------------|
| Home Screen | "Comprehensive Educational Modules" |
| Radiation Protection Module | "Complete Radiation Protection Content" |
| Interactive Diagram - MRI | "Interactive Learning Tools" |
| Knowledge Check | "Test Your Knowledge" |
| Radiation Biology Module | "Expanding Content Library" |
| Interactive Diagram - Cell Survival | "Visualize Complex Concepts" |
| Offline Content | "Learn Anywhere, Anytime" |
| Progress Tracking | "Track Your Professional Growth" |

## Production Timeline
- Setup and preparation: 1 hour
- Screenshot capture (all devices): 3 hours
- Post-processing and design: 4 hours
- Review and refinement: 1 hour
- Final export and verification: 1 hour
- Total: 10 hours (1.5 work days)

## Quality Assurance Checklist
- [ ] All screenshots show final, error-free UI
- [ ] Text overlays are consistent in style and positioning
- [ ] All required device sizes are included
- [ ] Images meet technical specifications for each store
- [ ] Content accurately represents app functionality
- [ ] No placeholder or test content visible
- [ ] Device frames are consistent and appropriate
- [ ] Text is readable at both full size and thumbnail size
- [ ] Highlighting effectively draws attention to key features
- [ ] Overall visual style is consistent with app branding

## Final Deliverables
- 8 screenshots for iPhone 6.5" (1284 x 2778 pixels)
- 8 screenshots for iPhone 5.5" (1242 x 2208 pixels)
- 8 screenshots for iPad Pro 12.9" (2048 x 2732 pixels)
- 8 screenshots for Android Phone (1080 x 1920 pixels)
- 8 screenshots for Android 7" Tablet (1080 x 1920 pixels)
- 8 screenshots for Android 10" Tablet (1080 x 1920 pixels)
- All in PNG format with RGB color space
