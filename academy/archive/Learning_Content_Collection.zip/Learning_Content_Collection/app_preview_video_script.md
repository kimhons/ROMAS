# App Preview Video Script for Radiation Oncology Academy iOS App

## Overview
- Duration: 30 seconds
- Resolution: 1242x2208px (iPhone 8 Plus)
- Format: H.264, 30fps
- Audio: Professional voiceover with subtle background music

## Scene-by-Scene Breakdown

### Scene 1: Introduction (0-5 seconds)
- **Visual**: App logo animation fades in, followed by a professional opening the app on iPhone
- **Voiceover**: "Introducing Radiation Oncology Academy - the premier educational platform for radiation oncology professionals."
- **Action**: Show login screen transitioning to personalized dashboard

### Scene 2: Dashboard & Personalization (5-10 seconds)
- **Visual**: Dashboard with personalized content recommendations and progress tracking
- **Voiceover**: "Your personalized dashboard delivers tailored educational content and tracks your progress."
- **Action**: Show AI recommendations highlighting and progress statistics

### Scene 3: Educational Content (10-15 seconds)
- **Visual**: User browsing educational content library and opening an article with interactive elements
- **Voiceover**: "Access comprehensive educational resources including articles, videos, and interactive modules."
- **Action**: Demonstrate interactive anatomy diagram with touch interaction

### Scene 4: Podcast Feature (15-20 seconds)
- **Visual**: Podcast player interface with episode list and playback controls
- **Voiceover**: "Stay updated with expert podcasts featuring leading radiation oncology specialists."
- **Action**: Show downloading podcast for offline listening and adjusting playback speed

### Scene 5: News & Research (20-25 seconds)
- **Visual**: Latest news feed with research highlights and saving functionality
- **Voiceover**: "Browse the latest research and developments in radiation oncology."
- **Action**: Demonstrate saving article for later and sharing functionality

### Scene 6: Cross-Platform & Closing (25-30 seconds)
- **Visual**: Cross-platform synchronization between iPhone and iPad
- **Voiceover**: "Seamlessly continue your learning across all your devices. Download Radiation Oncology Academy today."
- **Action**: Show progress syncing between devices and close with app icon and call-to-action

## Production Notes

### Visual Style
- Clean, professional medical aesthetic
- Blue and teal color scheme matching app design
- Clear, legible text overlays for feature highlights
- Smooth transitions between scenes
- Professional hand model demonstrating features

### Audio Requirements
- Professional male or female voiceover with medical terminology expertise
- Subtle, professional background music (non-distracting)
- Clear audio levels with voiceover prominence

### Technical Requirements
- Capture at 60fps, export at 30fps for smooth motion
- Record on iPhone 13 Pro or newer for highest quality
- Use screen recording with clean hands demonstration
- Ensure all text is legible on mobile screens
- Follow Apple's preview video guidelines precisely
- No references to pricing or purchasing
- No references to other platforms (Android, etc.)

### Post-Production
- Color correction to match app's color scheme
- Subtle zoom and focus effects to highlight key elements
- Text overlays for feature names (minimal, elegant)
- Smooth transitions between scenes (dissolves or subtle wipes)
- Final export in H.264 format at 30fps
