# Staging Environment Deployment Guide

This document outlines the process for deploying the Radiation Oncology Academy website to a staging environment on GoDaddy hosting with Google Cloud integration.

## Prerequisites

- GoDaddy hosting account credentials
- Google Cloud account credentials
- OpenAI API key
- Access to the project repository

## Deployment Steps

### 1. Create Staging Subdomain

1. Log in to GoDaddy account
2. Navigate to Domain Management
3. Select radiationoncologyacademy.com
4. Create a staging subdomain (staging.radiationoncologyacademy.com)
5. Configure DNS settings for the subdomain

### 2. Set Up Staging Environment on GoDaddy

1. Create a new hosting environment for the staging subdomain
2. Configure server settings to match production requirements
3. Set up SSL certificate for the staging subdomain
4. Configure environment variables for staging

### 3. Deploy Backend to Staging

1. Create a staging database
2. Deploy backend code to staging environment
3. Configure environment variables:
   - Database connection strings
   - API keys (OpenAI, Google Cloud)
   - Service endpoints
   - Feature flags for staging
4. Run database migrations
5. Seed database with sample data

### 4. Deploy Frontend to Staging

1. Build frontend with staging configuration
2. Deploy frontend code to staging environment
3. Configure frontend to use staging API endpoints
4. Set up caching and performance optimizations

### 5. Configure Google Cloud Services for Staging

1. Create staging buckets in Google Cloud Storage
2. Configure IAM permissions for staging environment
3. Set up staging service accounts
4. Configure API access for staging environment

### 6. Verify Deployment

1. Test all website functionality in staging environment
2. Verify AI integration features
3. Test podcast, news, and advanced courses features
4. Validate user authentication and authorization
5. Check responsive design and performance

### 7. Set Up Monitoring for Staging

1. Configure error logging
2. Set up performance monitoring
3. Implement uptime checks
4. Configure alert notifications

## Staging Environment URLs

- Website: https://staging.radiationoncologyacademy.com
- API: https://staging.radiationoncologyacademy.com/api
- Admin: https://staging.radiationoncologyacademy.com/admin

## Access Control

- Staging environment will be password-protected
- Access credentials will be provided separately
- IP restrictions may be implemented for additional security

## Rollback Procedure

In case of deployment issues:
1. Identify the problem
2. Restore from the most recent backup
3. Fix the issue in the development environment
4. Redeploy to staging after verification

## Notes

- Staging environment is for testing purposes only
- Data in staging may be reset periodically
- Performance in staging may not match production
