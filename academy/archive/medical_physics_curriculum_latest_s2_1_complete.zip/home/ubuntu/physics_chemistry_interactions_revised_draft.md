# Section 2.1: Physics and Chemistry of Radiation Interactions with Matter

## Introduction

Understanding how radiation interacts with biological matter at the physical and chemical level is fundamental to radiation biology and its application in radiotherapy. When ionizing radiation passes through tissue, it deposits energy, initiating a cascade of events that ultimately lead to biological effects. This section explores the initial physical interactions, the subsequent chemical changes (particularly the radiolysis of water), and key concepts like Linear Energy Transfer (LET), Relative Biological Effectiveness (RBE), and the Oxygen Enhancement Ratio (OER), which link these initial events to the observed biological outcomes.

## Learning Objectives

Upon completing this section, the student should be able to:

*   Differentiate between direct and indirect actions of radiation.
*   Describe the process of water radiolysis and identify the major reactive species produced.
*   Explain the significance of free radicals in causing biological damage.
*   Define Linear Energy Transfer (LET) and explain its dependence on radiation type and energy.
*   Define Relative Biological Effectiveness (RBE) and discuss the factors that influence it.
*   Explain the relationship between LET and RBE.
*   Define the Oxygen Enhancement Ratio (OER) and explain the oxygen fixation hypothesis.
*   Discuss the dependence of OER on LET and its clinical implications for radiotherapy.

## Direct vs. Indirect Action of Radiation

Ionizing radiation can damage critical cellular macromolecules, primarily DNA, through two main mechanisms:

1.  **Direct Action:** The radiation particle (photon, electron, proton, alpha particle, etc.) interacts directly with the atoms of the target molecule (e.g., DNA), causing ionization or excitation within the molecule itself. This leads to bond breaks or chemical changes directly within the target. Direct action is the dominant mechanism for high-LET radiations like alpha particles and neutrons, where ionizations are densely clustered along the particle track.
    *   **Example:** An alpha particle passes directly through a DNA strand, causing multiple ionizations within the sugar-phosphate backbone or bases, leading to a double-strand break.

2.  **Indirect Action:** The radiation particle interacts with other abundant molecules in the cell, primarily water (which constitutes ~70-80% of the cell mass). This interaction, known as radiolysis, produces highly reactive free radicals. These free radicals can then diffuse a short distance (nanometers) and react with the target molecule (DNA), causing damage. Indirect action is the dominant mechanism for low-LET radiations like X-rays and gamma rays, which produce sparsely distributed ionizations.
    *   **Example:** A high-energy photon interacts with a water molecule, creating a hydroxyl radical (•OH). This highly reactive radical diffuses to a nearby DNA molecule and oxidizes a base, causing damage.

It is estimated that for sparsely ionizing radiation (like X-rays used in therapy), approximately two-thirds of the DNA damage is caused by indirect action via free radicals, while one-third is due to direct action.

[Image: Diagram illustrating direct action (radiation hitting DNA) and indirect action (radiation hitting water, creating free radicals that hit DNA) - /home/ubuntu/curriculum/images/section_2_1/radiation_damage_pathways.jpeg]

## Radiolysis of Water

The interaction of ionizing radiation with water molecules is a critical process in radiobiology due to the prevalence of water in cells and the high reactivity of the products. The sequence of events occurs very rapidly (within picoseconds to microseconds):

1.  **Initial Physical Interaction (femtoseconds):** Radiation ionizes or excites water molecules:
    *   Ionization: H₂O + radiation → H₂O⁺ + e⁻
    *   Excitation: H₂O + radiation → H₂O*
2.  **Ion Molecule Reactions (picoseconds):** The initial products react further with other water molecules:
    *   H₂O⁺ + H₂O → H₃O⁺ + •OH (Hydroxyl radical - highly oxidizing)
    *   The ejected electron (e⁻) gets thermalized and hydrated:
        *   e⁻ + H₂O → e⁻aq (Hydrated electron - highly reducing)
3.  **Dissociation of Excited Water (picoseconds):**
    *   H₂O* → H• (Hydrogen atom - reducing) + •OH

**Major Reactive Species:** The primary chemically reactive species produced by water radiolysis are:

*   **Hydroxyl Radical (•OH):** Considered the most damaging species due to its high reactivity and ability to cause oxidative damage. Accounts for about two-thirds of indirect DNA damage.
*   **Hydrated Electron (e⁻aq):** A potent reducing agent.
*   **Hydrogen Atom (H•):** A reducing agent.

Other less reactive species like hydrogen peroxide (H₂O₂) and hydrogen gas (H₂) can also be formed through radical-radical reactions, especially at high dose rates or with high-LET radiation.

[Image: Schematic diagram showing the stages and products of water radiolysis - /home/ubuntu/curriculum/images/section_2_1/water_radiolysis_process.jpeg]

**Significance:** These free radicals are highly unstable molecules with unpaired electrons, making them extremely reactive. They seek to stabilize themselves by reacting with nearby molecules, including DNA, proteins, and lipids. Damage to DNA, particularly double-strand breaks, is considered the most critical lesion leading to cell killing, mutation, and carcinogenesis.

## Linear Energy Transfer (LET)

**Definition:** Linear Energy Transfer (LET) is the average energy deposited by an ionizing particle per unit length of track. It is typically expressed in units of kiloelectron volts per micrometer (keV/µm).

**Concept:** LET describes the density of ionization along the path of a charged particle. High-LET radiation deposits its energy densely over a short track, while low-LET radiation deposits energy sparsely over a longer track.

*   **Low-LET Radiation:** Examples include X-rays, gamma rays, and high-energy electrons. They produce sparse ionizations and are characterized by LET values typically less than 10 keV/µm (e.g., Cobalt-60 gamma rays ~0.3 keV/µm, 250 kVp X-rays ~2 keV/µm).
*   **High-LET Radiation:** Examples include alpha particles, protons (especially near the end of their range - Bragg peak), neutrons (via recoil protons), and heavy ions. They produce dense ionizations. LET values can range from 10 keV/µm to over 1000 keV/µm (e.g., 5 MeV alpha particles ~100 keV/µm, fission neutrons ~40-70 keV/µm).

**Calculation:** For charged particles, LET (often denoted L<0xE2><0x88><0x9E> or LET<0xE2><0x88><0x9E>) is closely related to the stopping power (dE/dx), which is the total energy loss per unit path length. LET specifically considers energy deposited locally (usually excluding energy carried away by high-energy secondary electrons, delta rays, above a certain cutoff energy, though often LET is used interchangeably with unrestricted stopping power in radiobiology).

**Dependence on Radiation Type and Energy:**
*   Heavier charged particles (alpha particles, heavy ions) generally have higher LET than lighter particles (electrons) of the same energy.
*   For a given particle type, LET generally increases as the particle slows down, reaching a maximum (the Bragg peak for protons and heavier ions) near the end of its range.
*   Neutrons, being uncharged, deposit energy indirectly via interactions with nuclei, primarily producing recoil protons. Their LET is characterized by the LET spectrum of these secondary charged particles, generally falling into the high-LET category.

[Image: Bragg curve showing the increase in LET (Stopping Power) for an alpha particle as it slows down near the end of its range - /home/ubuntu/curriculum/images/section_2_1/bragg_curve_alpha_let.png]

**Significance:** LET is a crucial determinant of the biological effectiveness of radiation. Densely ionizing (high-LET) radiation is generally more effective at causing complex, difficult-to-repair DNA damage (like multiple lesions within a short segment, including double-strand breaks) compared to sparsely ionizing (low-LET) radiation for the same absorbed dose.

## Relative Biological Effectiveness (RBE)

**Definition:** Relative Biological Effectiveness (RBE) is the ratio of the dose of a reference radiation (usually 250 kVp X-rays or Cobalt-60 gamma rays) required to produce a specific biological effect, to the dose of a test radiation required to produce the same level of that effect.

**Formula:**
RBE = (Dose of reference radiation) / (Dose of test radiation) for the same biological effect

**Concept:** RBE quantifies the biological impact of different types of radiation relative to a standard. An RBE greater than 1 indicates that the test radiation is more effective per unit dose than the reference radiation.

[Image: Graph showing survival fraction vs dose for low-LET (X-rays) and high-LET (alpha particles) radiation, illustrating the concept of RBE - derived from /home/ubuntu/curriculum/images/section_2_1/let_rbe_oer_infographic.jpeg]

**Factors Influencing RBE:** RBE is not a fixed value for a given radiation type; it depends on several factors:

1.  **Radiation Quality (LET):** This is the most significant factor. RBE generally increases with LET up to a maximum around 100-200 keV/µm, after which it may decrease (the "overkill" effect, where energy is wasted on already inactivated targets).
    *   **Low-LET (X-rays, gamma rays):** RBE is typically 1 (by definition for the reference) or slightly less.
    *   **High-LET (alpha particles, neutrons):** RBE values can be significantly higher (e.g., 2-20 or more, depending on the endpoint).
    *   **Protons:** RBE varies along the beam path, being slightly higher than 1 (often assumed clinically as 1.1) in the entrance region and potentially higher in the Bragg peak region.
2.  **Biological Endpoint:** RBE values differ depending on the biological effect being measured (e.g., cell killing, mutation induction, chromosome aberrations, tissue damage). RBE tends to be higher for endpoints resulting from complex, non-repairable damage.
3.  **Dose:** RBE is generally higher at lower doses (or lower levels of effect). This is because the dose-response curve for high-LET radiation is often steeper and has less of a shoulder (indicating less capacity for sublethal damage repair) compared to low-LET radiation.
4.  **Dose Rate:** Lowering the dose rate typically reduces the effectiveness of low-LET radiation (allowing more time for repair), but has less impact on high-LET radiation. This can lead to higher RBE values at lower dose rates.
5.  **Tissue Type/Cell Line:** Different cells and tissues exhibit varying sensitivities and repair capacities, which can influence RBE.

**Significance:** RBE is critical for radiation protection (where radiation weighting factors, wR, are derived from RBE concepts) and for radiotherapy, especially when using radiations other than photons or electrons (e.g., proton therapy, neutron therapy). Accurate RBE values are needed to ensure equivalent biological doses are delivered when comparing or switching between different radiation modalities.

## Oxygen Enhancement Ratio (OER)

**Definition:** The Oxygen Enhancement Ratio (OER) is the ratio of the dose required to produce a given biological effect under hypoxic (low oxygen) conditions to the dose required to produce the same effect under aerated (normal oxygen) conditions.

**Formula:**
OER = (Dose under hypoxic conditions) / (Dose under aerated conditions) for the same biological effect

**Concept:** OER quantifies the extent to which the presence of oxygen increases the sensitivity of cells to radiation. An OER greater than 1 indicates that cells are more sensitive when irradiated in the presence of oxygen.

[Image: Graph showing survival fraction vs dose under aerated and hypoxic conditions, illustrating the concept of OER - derived from /home/ubuntu/curriculum/images/section_2_1/let_rbe_oer_infographic.jpeg]

**Mechanism (Oxygen Fixation Hypothesis):** Oxygen is thought to enhance radiation damage primarily by reacting with the initial radiation-induced free radicals on target molecules (like DNA). This reaction "fixes" the damage, making it permanent and less repairable. In the absence of oxygen, these initial lesions might be chemically restored or repaired more easily.

*   Radiation creates a radical site (R•) on DNA.
*   **In the presence of O₂:** R• + O₂ → RO₂• (peroxy radical - a fixed, non-restorable lesion)
*   **In the absence of O₂:** R• + SH (e.g., glutathione) → RH + S• (chemical restoration)

**Dependence on LET:** The magnitude of the OER depends strongly on the LET of the radiation.

*   **Low-LET Radiation (X-rays, gamma rays):** OER is maximal, typically around 2.5 to 3.5 at high doses. This means 2.5 to 3.5 times more dose is needed to kill hypoxic cells compared to aerated cells.
*   **High-LET Radiation (alpha particles, low-energy neutrons):** OER decreases as LET increases. For LET values above ~150-200 keV/µm, the OER approaches 1. This means oxygen has little or no protective effect against high-LET radiation. High-LET radiation is thought to produce more complex, clustered damage (often direct action) that is less dependent on oxygen-mediated fixation for its lethality.

**Clinical Significance:** Many solid tumors contain regions of hypoxia due to inadequate blood supply. These hypoxic cells are significantly more resistant to conventional radiotherapy (low-LET X-rays) because of the high OER. This radioresistance is a major cause of treatment failure. Strategies to overcome hypoxia include:

*   **Fractionation:** Allows reoxygenation of hypoxic cells between fractions.
*   **Hypoxic Cell Sensitizers:** Drugs that mimic oxygen (e.g., nimorazole).
*   **Hypoxia-Activated Prodrugs:** Drugs activated under low oxygen conditions to kill hypoxic cells.
*   **High-LET Radiation Therapy:** Using particles like neutrons or heavy ions, which have a lower OER and are thus more effective against hypoxic cells.
*   **Increasing Oxygen Delivery:** Hyperbaric oxygen (limited success), carbogen breathing.

Understanding OER and its dependence on LET is crucial for optimizing radiotherapy strategies, particularly for tumors known to contain significant hypoxic fractions.

## Summary

The initial interaction of radiation with biological matter involves direct damage to critical molecules or, more commonly for low-LET radiation, indirect damage mediated by free radicals produced via water radiolysis. The density of energy deposition (LET) influences the type and complexity of damage, which in turn affects the biological effectiveness (RBE) and the dependence on oxygen (OER). High-LET radiation generally has a higher RBE and a lower OER compared to low-LET radiation. These fundamental concepts underpin our understanding of how radiation affects cells and tissues and are essential for the safe and effective application of radiation in medicine.

[Image: Infographic summarizing LET, RBE, and OER concepts - /home/ubuntu/curriculum/images/section_2_1/let_rbe_oer_infographic.jpeg]

## Assessment Questions

**1. Which statement best describes the indirect action of radiation?**
    a) Radiation directly ionizes a DNA molecule.
    b) Radiation interacts with water to produce free radicals, which then damage DNA.
    c) Radiation causes thermal heating of the cell.
    d) Radiation is absorbed by the cell nucleus without causing ionization.

**2. What is the most chemically reactive and biologically significant species produced during the radiolysis of water?**
    a) Hydrated electron (e⁻aq)
    b) Hydrogen atom (H•)
    c) Hydrogen peroxide (H₂O₂)
    d) Hydroxyl radical (•OH)

**3. Linear Energy Transfer (LET) is defined as:**
    a) The total energy deposited by radiation in a tissue volume.
    b) The average energy deposited per unit mass.
    c) The average energy deposited per unit length of the radiation track.
    d) The rate at which radiation dose is delivered.

**4. Which type of radiation typically has the highest LET?**
    a) Cobalt-60 gamma rays
    b) 6 MV X-rays
    c) High-energy electrons
    d) Alpha particles

**5. Relative Biological Effectiveness (RBE) compares:**
    a) The dose of two different radiations needed for the same biological effect.
    b) The LET of two different radiations.
    c) The penetration depth of two different radiations.
    d) The dose rate of two different radiations.

**6. How does RBE generally change with increasing LET?**
    a) RBE decreases continuously with increasing LET.
    b) RBE increases continuously with increasing LET.
    c) RBE increases with LET up to a maximum (~100-200 keV/µm) and then decreases.
    d) RBE is independent of LET.

**7. The Oxygen Enhancement Ratio (OER) is typically highest for:**
    a) Alpha particles
    b) Neutrons
    c) Low-LET radiation (e.g., X-rays)
    d) High-energy protons

**8. According to the oxygen fixation hypothesis, oxygen enhances radiation damage by:**
    a) Directly breaking DNA strands.
    b) Increasing the production of free radicals.
    c) Reacting with radiation-induced radicals on target molecules, making the damage permanent.
    d) Inhibiting DNA repair enzymes.

**9. A tumor has hypoxic regions. Compared to well-oxygenated regions, these hypoxic cells will likely be:**
    a) More sensitive to low-LET radiation.
    b) More resistant to low-LET radiation.
    c) Equally sensitive to low-LET radiation.
    d) More resistant to high-LET radiation.

**10. If the dose required to achieve a certain level of cell killing is 3 Gy under aerated conditions and 9 Gy under hypoxic conditions, what is the OER?**
    a) 0.33
    b) 1
    c) 3
    d) 9

## Answers and Explanations

1.  **b) Radiation interacts with water to produce free radicals, which then damage DNA.** Indirect action involves damage mediated by reactive species, primarily from water radiolysis, whereas direct action involves the radiation interacting directly with the target molecule.
2.  **d) Hydroxyl radical (•OH).** The hydroxyl radical is a highly oxidizing species and is considered the primary mediator of indirect DNA damage by low-LET radiation.
3.  **c) The average energy deposited per unit length of the radiation track.** LET quantifies the density of energy deposition along the particle's path.
4.  **d) Alpha particles.** Alpha particles are heavy, charged particles that deposit energy densely along their tracks, resulting in high LET values.
5.  **a) The dose of two different radiations needed for the same biological effect.** RBE is defined as the ratio of the dose of a reference radiation to the dose of a test radiation that produces the same level of a specific biological endpoint.
6.  **c) RBE increases with LET up to a maximum (~100-200 keV/µm) and then decreases.** This relationship reflects the increasing efficiency of damage production with LET up to an optimal density, beyond which energy may be wasted (overkill effect).
7.  **c) Low-LET radiation (e.g., X-rays).** The oxygen effect is most pronounced for sparsely ionizing radiation where indirect action via free radicals is dominant. The OER for typical low-LET radiation is around 2.5-3.5.
8.  **c) Reacting with radiation-induced radicals on target molecules, making the damage permanent.** Oxygen reacts with initial radical lesions on DNA, preventing their chemical restoration and 
