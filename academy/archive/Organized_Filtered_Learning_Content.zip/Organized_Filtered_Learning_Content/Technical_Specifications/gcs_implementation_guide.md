# Google Cloud Storage Implementation Guide for Radiation Oncology Academy

This guide provides step-by-step instructions for implementing Google Cloud Storage with proper access controls for the Radiation Oncology Academy platform. It's designed specifically for non-technical users to follow easily.

## Table of Contents

1. [Setting Up Google Cloud Account](#setting-up-google-cloud-account)
2. [Creating Storage Buckets](#creating-storage-buckets)
3. [Configuring Access Controls](#configuring-access-controls)
4. [Uploading and Managing Content](#uploading-and-managing-content)
5. [Integrating with the Website](#integrating-with-the-website)
6. [Testing Access Controls](#testing-access-controls)
7. [Maintenance and Best Practices](#maintenance-and-best-practices)

## Setting Up Google Cloud Account

### Step 1: Create a Google Cloud Account

1. Go to [cloud.google.com](https://cloud.google.com/)
2. Click "Get Started for Free" or "Sign In" if you already have a Google account
3. Follow the prompts to create a new Google Cloud account
4. You'll need to provide billing information, but Google offers a free tier and initial credits

### Step 2: Create a New Project

1. Once logged in, go to the Google Cloud Console dashboard
2. Click on the project dropdown at the top of the page
3. Click "New Project"
4. Name your project "Radiation Oncology Academy"
5. Click "Create"

### Step 3: Enable Cloud Storage API

1. In the left sidebar, navigate to "APIs & Services" > "Library"
2. Search for "Cloud Storage"
3. Click on "Google Cloud Storage JSON API"
4. Click "Enable"

## Creating Storage Buckets

Google Cloud Storage organizes content in "buckets." We'll create three separate buckets with different access levels:

### Step 1: Create Private Source Materials Bucket

1. In the left sidebar, navigate to "Cloud Storage" > "Buckets"
2. Click "Create Bucket"
3. Name the bucket `roa-private-source-materials` (must be globally unique, adjust if needed)
4. For Location type, select "Region" and choose a region close to your primary audience
5. For Storage class, select "Standard"
6. For Access control, select "Fine-grained"
7. For Protection tools, leave at default settings
8. Click "Create"

### Step 2: Create Restricted Member Content Bucket

1. Click "Create Bucket" again
2. Name the bucket `roa-member-content`
3. Use the same region as your first bucket
4. For Storage class, select "Standard"
5. For Access control, select "Fine-grained"
6. For Protection tools, leave at default settings
7. Click "Create"

### Step 3: Create Public Content Bucket

1. Click "Create Bucket" again
2. Name the bucket `roa-public-content`
3. Use the same region as your other buckets
4. For Storage class, select "Standard"
5. For Access control, select "Fine-grained"
6. For Protection tools, leave at default settings
7. Click "Create"

## Configuring Access Controls

### Step 1: Configure Private Source Materials Bucket

1. In the buckets list, click on `roa-private-source-materials`
2. Go to the "Permissions" tab
3. Click "Add Principal"
4. In the "New principals" field, enter your email address
5. For "Role", select "Storage Object Admin"
6. Click "Save"
7. This bucket will be accessible only to you and any administrators you add

### Step 2: Configure Member Content Bucket

1. Go back to the buckets list and click on `roa-member-content`
2. Go to the "Permissions" tab
3. Click "Add Principal"
4. In the "New principals" field, enter your email address
5. For "Role", select "Storage Object Admin"
6. Click "Save"
7. We'll set up more granular access through signed URLs later

### Step 3: Configure Public Content Bucket

1. Go back to the buckets list and click on `roa-public-content`
2. Go to the "Permissions" tab
3. Click "Add Principal"
4. In the "New principals" field, enter `allUsers`
5. For "Role", select "Storage Object Viewer"
6. Click "Save"
7. You'll see a warning that this makes the bucket public - click "Allow Public Access"

## Uploading and Managing Content

### Step 1: Create Folder Structure

For each bucket, we'll create a consistent folder structure:

1. Click on the `roa-private-source-materials` bucket
2. Click "Create Folder"
3. Name it "aapm-tg-reports"
4. Click "Create"
5. Repeat to create folders for:
   - "research-papers"
   - "clinical-notes"
   - "source-presentations"

Repeat this process for the other two buckets, creating appropriate folders:

For `roa-member-content`:
- "courses"
- "presentations"
- "assessments"
- "resources"

For `roa-public-content`:
- "blog"
- "podcast"
- "previews"
- "marketing"

### Step 2: Upload Files

To upload files to any folder:

1. Navigate to the desired folder
2. Click "Upload Files" or "Upload Folder"
3. Select the files from your computer
4. Click "Open" to begin uploading

### Step 3: Manage Files

To manage existing files:

1. Navigate to the file
2. Click the three dots menu next to the file
3. Options include:
   - "Download"
   - "Rename"
   - "Move"
   - "Copy"
   - "Delete"
   - "Edit metadata"

## Integrating with the Website

To connect your Google Cloud Storage to the Radiation Oncology Academy website, you'll need to:

### Step 1: Create a Service Account

1. In the Google Cloud Console, go to "IAM & Admin" > "Service Accounts"
2. Click "Create Service Account"
3. Name it "roa-storage-access"
4. Click "Create and Continue"
5. Assign these roles:
   - "Storage Object Admin" for full management
   - "Storage Object Creator" for uploading
   - "Storage Object Viewer" for viewing
6. Click "Continue" and then "Done"

### Step 2: Create and Download a Key

1. Click on the service account you just created
2. Go to the "Keys" tab
3. Click "Add Key" > "Create new key"
4. Select "JSON" format
5. Click "Create"
6. The key file will download automatically - keep this secure!

### Step 3: Add the Key to Your Website

1. Rename the downloaded JSON file to `gcs-key.json`
2. Upload this file to your website's backend server in the `/home/ubuntu/radiation_oncology_academy/backend/config/` directory
3. Make sure this file is not publicly accessible

### Step 4: Update Environment Variables

Add these lines to your `.env` file in the backend directory:

```
GCS_PROJECT_ID=your-project-id
GCS_PRIVATE_BUCKET=roa-private-source-materials
GCS_MEMBER_BUCKET=roa-member-content
GCS_PUBLIC_BUCKET=roa-public-content
GCS_KEY_PATH=./config/gcs-key.json
```

Replace `your-project-id` with your actual Google Cloud project ID.

## Testing Access Controls

### Test Private Bucket Access

1. Log out of your Google account
2. Try to access a file in the private bucket directly via its URL
3. You should receive an "Access Denied" error

### Test Member Content Access

To test member-restricted content:

1. In your website admin panel, go to "Content" > "Member Resources"
2. Upload a test file to the member content area
3. Log in as a member with appropriate access level
4. Verify you can access the file
5. Log out and verify the file is no longer accessible

### Test Public Content Access

1. Upload a file to the public bucket
2. Access the file directly via its URL in an incognito browser window
3. The file should be accessible without logging in

## Maintenance and Best Practices

### Regular Backups

1. Set up regular backups of your important content
2. In Google Cloud Console, go to "Cloud Storage" > "Transfer"
3. Create a transfer job to copy data to another bucket or location

### Monitoring Storage Usage

1. In Google Cloud Console, go to "Monitoring" > "Dashboards"
2. Create a custom dashboard to monitor storage usage
3. Set up alerts for when storage exceeds certain thresholds

### Cost Management

1. In Google Cloud Console, go to "Billing" > "Cost Management"
2. Set up a budget to monitor and control costs
3. Consider lifecycle rules to automatically archive or delete old content

### Security Best Practices

1. Regularly review bucket permissions
2. Use the principle of least privilege - only grant necessary access
3. Consider enabling Object Versioning for important files
4. Set up audit logging to track access and changes

## Conclusion

You've now set up Google Cloud Storage for your Radiation Oncology Academy platform with three different access levels:

1. Private storage for source materials
2. Restricted access for member content
3. Public access for freely available content

This structure ensures that your source materials remain private while allowing you to selectively share content based on membership levels.

For any questions or issues, refer to the [Google Cloud Storage documentation](https://cloud.google.com/storage/docs) or contact your website administrator.
