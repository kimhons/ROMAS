# Content Migration Strategy for Radiation Oncology Academy

## Overview

This document outlines the comprehensive strategy for migrating existing educational content to the new Radiation Oncology Academy platform. The migration process will ensure all content is properly transferred, optimized, and structured for both the website and mobile applications.

## Content Inventory and Assessment

### Current Content Sources

1. **Existing Website Content**
   - Educational articles and guides
   - Clinical case studies
   - Reference materials
   - Lecture slides and notes
   - Assessment questions and quizzes

2. **External Content Repositories**
   - Academic publications
   - Conference presentations
   - Collaborative research documents
   - Partner institution materials

3. **Multimedia Content**
   - Video lectures and demonstrations
   - Podcast episodes
   - Webinar recordings
   - Interactive simulations
   - Infographics and illustrations

### Content Audit Process

1. **Inventory Creation**
   - Catalog all existing content items
   - Document metadata (title, author, creation date, etc.)
   - Identify content types and formats
   - Map content to topic categories
   - Assess content volume (word count, duration, file size)

2. **Quality Assessment**
   - Evaluate accuracy and currency of information
   - Assess educational value and relevance
   - Review for completeness and clarity
   - Check for copyright compliance
   - Identify content requiring updates

3. **Technical Assessment**
   - Evaluate file formats and compatibility
   - Assess media quality (resolution, bitrate, etc.)
   - Identify accessibility issues
   - Check for browser/device compatibility
   - Evaluate load times and performance impact

4. **Gap Analysis**
   - Identify missing content areas
   - Determine content update requirements
   - Assess need for new content creation
   - Evaluate content distribution across topics
   - Identify opportunities for content enhancement

## Content Classification and Structure

### Content Taxonomy

1. **Primary Categories**
   - Radiation Physics
   - Clinical Oncology
   - Treatment Planning
   - Radiation Biology
   - Patient Care
   - Professional Development
   - Research Methodologies
   - Technology and Innovation

2. **Content Types**
   - Articles
   - Case Studies
   - Video Lectures
   - Podcasts
   - Interactive Modules
   - Assessments
   - Reference Materials
   - News Updates

3. **Difficulty Levels**
   - Beginner
   - Intermediate
   - Advanced
   - Expert

4. **Target Audiences**
   - Radiation Oncologists
   - Medical Physicists
   - Radiation Therapists
   - Dosimetrists
   - Oncology Nurses
   - Residents/Fellows
   - Medical Students
   - Researchers

### Metadata Schema

| Metadata Field | Description | Example |
|----------------|-------------|---------|
| Content ID | Unique identifier | ROA-ART-2025-0042 |
| Title | Content title | "SBRT for Early-Stage Lung Cancer" |
| Description | Brief summary | "Overview of stereotactic body radiation therapy techniques for early-stage lung cancer treatment." |
| Author(s) | Content creator(s) | "Dr. Jane Smith, Dr. Robert Johnson" |
| Creation Date | Original creation date | 2023-06-15 |
| Last Updated | Last modification date | 2025-03-22 |
| Primary Category | Main topic area | Radiation Physics |
| Secondary Categories | Additional topic areas | Clinical Oncology, Treatment Planning |
| Content Type | Format of content | Video Lecture |
| Difficulty Level | Complexity level | Intermediate |
| Target Audience | Intended users | Radiation Oncologists, Residents/Fellows |
| Duration/Length | Time or word count | 45 minutes, 3,200 words |
| Keywords | Search terms | SBRT, lung cancer, stereotactic, early-stage |
| Prerequisites | Required prior knowledge | "Basic understanding of radiation therapy principles" |
| Learning Objectives | Educational goals | "Describe SBRT techniques, Identify suitable candidates, Explain dose constraints" |
| Related Content | Associated materials | ROA-ART-2025-0036, ROA-ART-2025-0043 |
| File Format | Technical format | MP4, PDF, HTML |
| File Size | Storage requirements | 450MB |
| Accessibility Features | Accessibility support | Closed captions, transcript, alt text |
| License Information | Usage rights | Creative Commons Attribution 4.0 |

## Migration Approach

### Phase 1: Preparation and Planning (Weeks 1-2)

1. **Content Inventory Completion**
   - Finalize comprehensive content catalog
   - Prioritize content for migration
   - Identify high-value content for initial focus
   - Establish content ownership and responsibilities

2. **Migration Tools Setup**
   - Configure content migration scripts
   - Set up automated metadata extraction tools
   - Prepare media conversion utilities
   - Establish quality assurance tools
   - Create content validation frameworks

3. **Database Schema Preparation**
   - Finalize content database structure
   - Create migration staging environment
   - Set up content versioning system
   - Establish content relationships
   - Configure search indexing

4. **Team Training**
   - Train content migration team
   - Document migration procedures
   - Establish quality standards
   - Define escalation procedures
   - Assign team responsibilities

### Phase 2: Content Preparation (Weeks 3-4)

1. **Content Cleanup**
   - Remove outdated or irrelevant content
   - Update inaccurate information
   - Fix broken links and references
   - Standardize formatting
   - Resolve copyright issues

2. **Content Enhancement**
   - Add missing metadata
   - Improve content descriptions
   - Enhance keywords for searchability
   - Create consistent naming conventions
   - Standardize author information

3. **Media Optimization**
   - Convert videos to adaptive streaming formats
   - Optimize images for web and mobile
   - Create multiple resolution versions
   - Compress files for efficient delivery
   - Generate thumbnails and previews

4. **Accessibility Improvements**
   - Add alt text to images
   - Create transcripts for audio content
   - Add closed captions to videos
   - Ensure proper heading structure
   - Improve color contrast in visual materials

### Phase 3: Test Migration (Week 5)

1. **Sample Content Migration**
   - Select representative content samples
   - Migrate to staging environment
   - Test content display and functionality
   - Verify metadata accuracy
   - Validate search functionality

2. **Technical Validation**
   - Test content loading performance
   - Verify cross-platform compatibility
   - Check responsive design adaptation
   - Test offline content functionality
   - Validate content synchronization

3. **User Experience Testing**
   - Conduct internal review of migrated content
   - Test navigation and discoverability
   - Verify content relationships
   - Test learning path functionality
   - Validate content bookmarking and notes

4. **Issue Resolution**
   - Document migration issues
   - Develop solutions for common problems
   - Update migration scripts and processes
   - Retest problematic content types
   - Refine migration approach

### Phase 4: Full Migration (Weeks 6-8)

1. **Prioritized Content Migration**
   - Migrate high-priority content first
   - Process content by category
   - Implement in manageable batches
   - Track migration progress
   - Validate each batch after migration

2. **Continuous Quality Assurance**
   - Automated validation checks
   - Manual spot-checking
   - Cross-platform verification
   - Performance monitoring
   - User experience validation

3. **Content Relationship Establishment**
   - Create content relationships
   - Build learning paths
   - Establish prerequisites
   - Link related content
   - Create content collections

4. **Search Optimization**
   - Index all migrated content
   - Test search functionality
   - Optimize search relevance
   - Implement faceted search
   - Test search performance

### Phase 5: Verification and Optimization (Weeks 9-10)

1. **Comprehensive Validation**
   - Verify all content is migrated
   - Check for missing assets or metadata
   - Validate content relationships
   - Test user journeys through content
   - Verify content accessibility

2. **Performance Optimization**
   - Identify performance bottlenecks
   - Optimize large media files
   - Implement lazy loading
   - Configure caching strategies
   - Test on various network conditions

3. **User Acceptance Testing**
   - Invite select users to review content
   - Gather feedback on organization and access
   - Test content consumption experience
   - Validate offline functionality
   - Test cross-platform experience

4. **Final Adjustments**
   - Address user feedback
   - Make final content optimizations
   - Fix any remaining issues
   - Document known limitations
   - Prepare for public release

## Technical Implementation

### Content Migration Scripts

1. **Content Extraction Script**
```python
# Example Python script for content extraction
import os
import json
import pandas as pd
from bs4 import BeautifulSoup
import requests

def extract_content(source_url, content_type):
    """Extract content from source URL based on content type"""
    if content_type == "article":
        return extract_article(source_url)
    elif content_type == "video":
        return extract_video_metadata(source_url)
    # Additional content types...

def extract_article(url):
    """Extract article content and metadata"""
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Extract metadata and content
    title = soup.find('h1').text.strip()
    author = soup.find('meta', {'name': 'author'})['content']
    date = soup.find('meta', {'name': 'date'})['content']
    content = soup.find('div', {'class': 'article-content'}).prettify()
    
    # Extract images and other assets
    images = [img['src'] for img in soup.find_all('img')]
    
    return {
        'title': title,
        'author': author,
        'date': date,
        'content': content,
        'images': images,
        'source_url': url
    }

# Main execution
content_inventory = pd.read_csv('content_inventory.csv')
extracted_content = []

for index, row in content_inventory.iterrows():
    content_data = extract_content(row['source_url'], row['content_type'])
    content_data['content_id'] = row['content_id']
    extracted_content.append(content_data)

# Save extracted content
with open('extracted_content.json', 'w') as f:
    json.dump(extracted_content, f, indent=2)
```

2. **Metadata Enhancement Script**
```python
# Example Python script for metadata enhancement
import json
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer

# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

def enhance_metadata(content_item):
    """Enhance content metadata with additional information"""
    # Generate keywords using TF-IDF
    if 'content' in content_item:
        content_item['keywords'] = extract_keywords(content_item['content'])
    
    # Determine difficulty level based on content analysis
    content_item['difficulty_level'] = determine_difficulty(content_item)
    
    # Suggest related content based on similarity
    content_item['suggested_related'] = find_related_content(content_item)
    
    return content_item

def extract_keywords(text, num_keywords=10):
    """Extract keywords from text using TF-IDF"""
    # Tokenize and remove stopwords
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(text.lower())
    filtered_text = [w for w in word_tokens if w.isalnum() and w not in stop_words]
    
    # Use TF-IDF to find important terms
    vectorizer = TfidfVectorizer(max_features=num_keywords)
    tfidf_matrix = vectorizer.fit_transform([' '.join(filtered_text)])
    feature_names = vectorizer.get_feature_names_out()
    
    # Get top terms
    dense = tfidf_matrix.todense()
    phrase_scores = [(feature_names[i], dense[0, i]) for i in range(len(feature_names))]
    sorted_phrase_scores = sorted(phrase_scores, key=lambda x: x[1], reverse=True)
    
    return [phrase[0] for phrase in sorted_phrase_scores]

# Main execution
with open('extracted_content.json', 'r') as f:
    content_data = json.load(f)

enhanced_content = [enhance_metadata(item) for item in content_data]

# Save enhanced content
with open('enhanced_content.json', 'w') as f:
    json.dump(enhanced_content, f, indent=2)
```

3. **Media Optimization Script**
```python
# Example Python script for media optimization
import os
import json
import subprocess
from PIL import Image
import concurrent.futures

def optimize_media(content_item):
    """Optimize media files for web and mobile delivery"""
    if 'images' in content_item and content_item['images']:
        content_item['optimized_images'] = optimize_images(content_item['images'])
    
    if content_item['content_type'] == 'video':
        content_item['optimized_video'] = optimize_video(content_item['video_url'])
    
    return content_item

def optimize_images(image_urls, sizes=[(800, 600), (400, 300), (200, 150)]):
    """Optimize images for multiple screen sizes"""
    optimized_images = {}
    
    for url in image_urls:
        filename = os.path.basename(url)
        base_name, ext = os.path.splitext(filename)
        
        # Download original image
        download_path = f"temp/{filename}"
        subprocess.run(['wget', '-O', download_path, url])
        
        # Create optimized versions
        optimized_versions = {}
        for width, height in sizes:
            size_key = f"{width}x{height}"
            output_path = f"optimized/{base_name}_{size_key}{ext}"
            
            # Resize and optimize
            img = Image.open(download_path)
            img = img.resize((width, height), Image.LANCZOS)
            img.save(output_path, optimize=True, quality=85)
            
            # Add to optimized versions
            optimized_versions[size_key] = output_path
        
        optimized_images[url] = optimized_versions
    
    return optimized_images

def optimize_video(video_url):
    """Optimize video for adaptive streaming"""
    filename = os.path.basename(video_url)
    base_name, ext = os.path.splitext(filename)
    
    # Download original video
    download_path = f"temp/{filename}"
    subprocess.run(['wget', '-O', download_path, video_url])
    
    # Create HLS adaptive streaming versions
    output_dir = f"optimized/{base_name}_hls"
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate multiple bitrate versions
    subprocess.run([
        'ffmpeg', '-i', download_path,
        '-profile:v', 'main', '-level', '3.1',
        '-start_number', '0', '-hls_time', '10', '-hls_list_size', '0',
        '-f', 'hls', f"{output_dir}/master.m3u8"
    ])
    
    # Generate thumbnail
    thumbnail_path = f"optimized/{base_name}_thumbnail.jpg"
    subprocess.run([
        'ffmpeg', '-i', download_path, '-ss', '00:00:05', '-vframes', '1',
        thumbnail_path
    ])
    
    return {
        'hls_url': f"{output_dir}/master.m3u8",
        'thumbnail': thumbnail_path,
        'original': download_path
    }

# Main execution with parallel processing
with open('enhanced_content.json', 'r') as f:
    content_data = json.load(f)

# Process media optimization in parallel
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
    optimized_content = list(executor.map(optimize_media, content_data))

# Save optimized content
with open('optimized_content.json', 'w') as f:
    json.dump(optimized_content, f, indent=2)
```

4. **Database Import Script**
```python
# Example Python script for database import
import json
import pymongo
import firebase_admin
from firebase_admin import credentials, firestore

# Initialize Firebase (for web/mobile data)
cred = credentials.Certificate('firebase-credentials.json')
firebase_admin.initialize_app(cred)
db = firestore.client()

# Initialize MongoDB (for content management system)
mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
mongo_db = mongo_client["radiation_oncology_academy"]
content_collection = mongo_db["content"]

def import_to_databases(content_item):
    """Import content to both Firebase and MongoDB"""
    # Prepare content document
    content_doc = {
        'content_id': content_item['content_id'],
        'title': content_item['title'],
        'description': content_item.get('description', ''),
        'author': content_item['author'],
        'creation_date': content_item['date'],
        'last_updated': content_item.get('last_updated', content_item['date']),
        'primary_category': content_item.get('primary_category', ''),
        'secondary_categories': content_item.get('secondary_categories', []),
        'content_type': content_item['content_type'],
        'difficulty_level': content_item.get('difficulty_level', 'Intermediate'),
        'target_audience': content_item.get('target_audience', []),
        'keywords': content_item.get('keywords', []),
        'learning_objectives': content_item.get('learning_objectives', []),
        'related_content': content_item.get('suggested_related', []),
        'metadata': {
            'file_format': content_item.get('file_format', ''),
            'file_size': content_item.get('file_size', 0),
            'duration': content_item.get('duration', 0),
            'accessibility_features': content_item.get('accessibility_features', []),
            'license': content_item.get('license', 'All Rights Reserved')
        }
    }
    
    # Add content-specific fields
    if content_item['content_type'] == 'article':
        content_doc['content_html'] = content_item['content']
        content_doc['images'] = content_item.get('optimized_images', {})
    elif content_item['content_type'] == 'video':
        content_doc['video_sources'] = content_item.get('optimized_video', {})
        content_doc['transcript'] = content_item.get('transcript', '')
    
    # Import to MongoDB (CMS)
    content_collection.insert_one(content_doc)
    
    # Import to Firebase (web/mobile)
    db.collection('content').document(content_item['content_id']).set(content_doc)
    
    return content_item['content_id']

# Main execution
with open('optimized_content.json', 'r') as f:
    content_data = json.load(f)

imported_ids = []
for item in content_data:
    imported_id = import_to_databases(item)
    imported_ids.append(imported_id)

print(f"Successfully imported {len(imported_ids)} content items")
```

### Database Schema

1. **Content Collection Schema**
```json
{
  "content_id": "ROA-ART-2025-0042",
  "title": "SBRT for Early-Stage Lung Cancer",
  "description": "Overview of stereotactic body radiation therapy techniques for early-stage lung cancer treatment.",
  "author": ["Dr. Jane Smith", "Dr. Robert Johnson"],
  "creation_date": "2023-06-15",
  "last_updated": "2025-03-22",
  "primary_category": "Clinical Oncology",
  "secondary_categories": ["Treatment Planning", "Technology and Innovation"],
  "content_type": "article",
  "difficulty_level": "Intermediate",
  "target_audience": ["Radiation Oncologists", "Residents/Fellows"],
  "keywords": ["SBRT", "lung cancer", "stereotactic", "early-stage", "treatment planning"],
  "learning_objectives": [
    "Describe SBRT techniques for lung cancer",
    "Identify suitable candidates for SBRT",
    "Explain dose constraints and normal tissue considerations"
  ],
  "related_content": ["ROA-ART-2025-0036", "ROA-ART-2025-0043"],
  "content_html": "<div class='article'>...</div>",
  "images": {
    "figure1.jpg": {
      "800x600": "/images/figure1_800x600.jpg",
      "400x300": "/images/figure1_400x300.jpg",
      "200x150": "/images/figure1_200x150.jpg"
    },
    "figure2.jpg": {
      "800x600": "/images/figure2_800x600.jpg",
      "400x300": "/images/figure2_400x300.jpg",
      "200x150": "/images/figure2_200x150.jpg"
    }
  },
  "metadata": {
    "file_format": "HTML",
    "file_size": 45000,
    "word_count": 3200,
    "accessibility_features": ["alt text", "semantic HTML"],
    "license": "Creative Commons Attribution 4.0"
  },
  "offline_availability": true,
  "view_count": 0,
  "average_rating": 0,
  "review_count": 0
}
```

2. **Video Content Schema**
```json
{
  "content_id": "ROA-VID-2025-0018",
  "title": "Contouring Techniques for Head and Neck Cancer",
  "description": "Step-by-step demonstration of contouring techniques for head and neck cancer treatment planning.",
  "author": ["Dr. Michael Chen"],
  "creation_date": "2024-02-10",
  "last_updated": "2025-03-15",
  "primary_category": "Treatment Planning",
  "secondary_categories": ["Clinical Oncology"],
  "content_type": "video",
  "difficulty_level": "Advanced",
  "target_audience": ["Radiation Oncologists", "Dosimetrists"],
  "keywords": ["contouring", "head and neck cancer", "treatment planning", "organs at risk"],
  "learning_objectives": [
    "Demonstrate proper contouring techniques for head and neck tumors",
    "Identify critical organs at risk",
    "Apply RTOG contouring guidelines"
  ],
  "related_content": ["ROA-VID-2025-0012", "ROA-ART-2025-0078"],
  "video_sources": {
    "hls_url": "/videos/contouring_hn/master.m3u8",
    "thumbnail": "/videos/contouring_hn_thumbnail.jpg",
    "duration": 1845
  },
  "transcript": "In this video, we'll demonstrate the proper contouring techniques for head and neck cancer...",
  "chapters": [
    {"time": 0, "title": "Introduction"},
    {"time": 120, "title": "Patient Positioning"},
    {"time": 300, "title": "Target Volume Delineation"},
    {"time": 720, "title": "Organs at Risk"},
    {"time": 1200, "title": "Plan Evaluation"},
    {"time": 1620, "title": "Summary"}
  ],
  "metadata": {
    "file_format": "MP4",
    "file_size": 450000000,
    "accessibility_features": ["closed captions", "transcript"],
    "license": "All Rights Reserved"
  },
  "offline_availability": true,
  "view_count": 0,
  "average_rating": 0,
  "review_count": 0
}
```

3. **Podcast Content Schema**
```json
{
  "content_id": "ROA-POD-2025-0007",
  "title": "Advances in Proton Therapy: Interview with Dr. Sarah Johnson",
  "description": "Discussion of recent advances in proton therapy technology and clinical applications.",
  "author": ["Dr. Mark Williams", "Dr. Sarah Johnson"],
  "creation_date": "2025-01-22",
  "last_updated": "2025-01-22",
  "primary_category": "Technology and Innovation",
  "secondary_categories": ["Clinical Oncology", "Radiation Physics"],
  "content_type": "podcast",
  "difficulty_level": "Intermediate",
  "target_audience": ["Radiation Oncologists", "Medical Physicists", "Residents/Fellows"],
  "keywords": ["proton therapy", "particle therapy", "technology", "clinical applications"],
  "learning_objectives": [
    "Describe recent advances in proton therapy technology",
    "Discuss clinical applications and evidence",
    "Explain advantages and limitations of proton therapy"
  ],
  "related_content": ["ROA-POD-2025-0003", "ROA-ART-2025-0056"],
  "audio_sources": {
    "high_quality": "/podcasts/proton_therapy_hq.mp3",
    "medium_quality": "/podcasts/proton_therapy_mq.mp3",
    "low_quality": "/podcasts/proton_therapy_lq.mp3",
    "duration": 2520
  },
  "transcript": "Host: Welcome to the Radiation Oncology Academy podcast. Today we're discussing advances in proton therapy...",
  "show_notes": "In this episode, we interview Dr. Sarah Johnson, Director of Proton Therapy at University Medical Center...",
  "episode_number": 7,
  "season_number": 2,
  "metadata": {
    "file_format": "MP3",
    "file_size": 60000000,
    "accessibility_features": ["transcript"],
    "license": "All Rights Reserved"
  },
  "offline_availability": true,
  "listen_count": 0,
  "average_rating": 0,
  "review_count": 0
}
```

### API Endpoints for Content Access

1. **Content Listing API**
```javascript
// GET /api/content
// Query parameters:
// - category: Filter by primary category
// - type: Filter by content type
// - difficulty: Filter by difficulty level
// - audience: Filter by target audience
// - page: Page number for pagination
// - limit: Number of items per page
// - sort: Sort field (date, title, popularity)
// - order: Sort order (asc, desc)

app.get('/api/content', async (req, res) => {
  try {
    const {
      category,
      type,
      difficulty,
      audience,
      page = 1,
      limit = 20,
      sort = 'date',
      order = 'desc'
    } = req.query;
    
    // Build query
    const query = {};
    if (category) query.primary_category = category;
    if (type) query.content_type = type;
    if (difficulty) query.difficulty_level = difficulty;
    if (audience) query.target_audience = audience;
    
    // Determine sort field
    let sortField = 'creation_date';
    if (sort === 'title') sortField = 'title';
    if (sort === 'popularity') sortField = 'view_count';
    
    // Execute query with pagination
    const skip = (page - 1) * limit;
    const sortOrder = order === 'asc' ? 1 : -1;
    const sortOptions = {};
    sortOptions[sortField] = sortOrder;
    
    const contentItems = await db.collection('content')
      .find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit))
      .toArray();
    
    const totalItems = await db.collection('content')
      .countDocuments(query);
    
    // Return results with pagination metadata
    res.json({
      items: contentItems,
      pagination: {
        total: totalItems,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(totalItems / limit)
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

2. **Content Detail API**
```javascript
// GET /api/content/:contentId

app.get('/api/content/:contentId', async (req, res) => {
  try {
    const { contentId } = req.params;
    
    // Get content item
    const contentItem = await db.collection('content')
      .findOne({ content_id: contentId });
    
    if (!contentItem) {
      return res.status(404).json({ error: 'Content not found' });
    }
    
    // Increment view count
    await db.collection('content')
      .updateOne(
        { content_id: contentId },
        { $inc: { view_count: 1 } }
      );
    
    // Get related content
    let relatedContent = [];
    if (contentItem.related_content && contentItem.related_content.length > 0) {
      relatedContent = await db.collection('content')
        .find({ content_id: { $in: contentItem.related_content } })
        .project({
          content_id: 1,
          title: 1,
          description: 1,
          content_type: 1,
          primary_category: 1,
          difficulty_level: 1
        })
        .toArray();
    }
    
    // Return content with related items
    res.json({
      ...contentItem,
      related_content: relatedContent
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

3. **Search API**
```javascript
// GET /api/search
// Query parameters:
// - q: Search query
// - filters: JSON object with filters
// - page: Page number
// - limit: Results per page

app.get('/api/search', async (req, res) => {
  try {
    const {
      q,
      filters = '{}',
      page = 1,
      limit = 20
    } = req.query;
    
    // Parse filters
    const parsedFilters = JSON.parse(filters);
    
    // Build search query
    const searchQuery = {
      $text: { $search: q }
    };
    
    // Add filters
    if (parsedFilters.categories) {
      searchQuery.$or = [
        { primary_category: { $in: parsedFilters.categories } },
        { secondary_categories: { $in: parsedFilters.categories } }
      ];
    }
    
    if (parsedFilters.types) {
      searchQuery.content_type = { $in: parsedFilters.types };
    }
    
    if (parsedFilters.difficulty) {
      searchQuery.difficulty_level = { $in: parsedFilters.difficulty };
    }
    
    if (parsedFilters.audience) {
      searchQuery.target_audience = { $in: parsedFilters.audience };
    }
    
    // Execute search with pagination
    const skip = (page - 1) * limit;
    
    const searchResults = await db.collection('content')
      .find(searchQuery)
      .project({
        content_id: 1,
        title: 1,
        description: 1,
        author: 1,
        creation_date: 1,
        content_type: 1,
        primary_category: 1,
        difficulty_level: 1,
        keywords: 1,
        score: { $meta: "textScore" }
      })
      .sort({ score: { $meta: "textScore" } })
      .skip(skip)
      .limit(parseInt(limit))
      .toArray();
    
    const totalResults = await db.collection('content')
      .countDocuments(searchQuery);
    
    // Return search results with pagination metadata
    res.json({
      query: q,
      results: searchResults,
      pagination: {
        total: totalResults,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(totalResults / limit)
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

## Mobile Optimization Strategy

### Offline Content Access

1. **Content Selection for Offline Access**
   - Allow users to select specific content for offline access
   - Automatically download prerequisites for selected content
   - Implement content package bundles for related materials
   - Prioritize text content over media for storage efficiency
   - Provide storage usage information to users

2. **Storage Management**
   - Implement configurable storage limits (100MB, 500MB, 1GB)
   - Provide content size information before download
   - Allow batch deletion of offline content
   - Implement least-recently-used eviction policy
   - Track content access patterns for smart caching

3. **Synchronization**
   - Implement background synchronization for content updates
   - Sync user progress and notes when online
   - Provide visual indicators for sync status
   - Allow manual sync triggering
   - Implement conflict resolution for simultaneous edits

### Media Optimization

1. **Video Content**
   - Implement adaptive bitrate streaming (HLS/DASH)
   - Provide multiple quality options (high, medium, low)
   - Generate optimized thumbnails
   - Implement efficient seeking with keyframe indexes
   - Support background audio-only mode

2. **Audio Content**
   - Provide multiple bitrate options (64kbps, 128kbps, 192kbps)
   - Implement progressive download
   - Support background playback
   - Optimize metadata for minimal storage
   - Implement playback speed controls

3. **Image Content**
   - Generate responsive image sets (small, medium, large)
   - Implement lazy loading for images
   - Use WebP format with PNG/JPEG fallbacks
   - Optimize image quality for screen density
   - Implement efficient caching strategies

## Content Update Strategy

### Regular Content Updates

1. **Update Schedule**
   - Weekly news updates
   - Monthly podcast episodes
   - Quarterly educational content updates
   - Annual comprehensive content review

2. **Update Process**
   - Identify content requiring updates
   - Prepare updated content in staging environment
   - Review and approve updates
   - Deploy updates to production
   - Notify users of new/updated content

3. **Version Control**
   - Maintain content version history
   - Allow access to previous versions
   - Track changes between versions
   - Document update rationale
   - Implement content deprecation process

### User-Generated Content

1. **Notes and Annotations**
   - Allow users to add personal notes to content
   - Support highlighting and bookmarking
   - Implement note synchronization across devices
   - Provide note search functionality
   - Allow note export and sharing

2. **Discussion and Comments**
   - Implement moderated discussion forums
   - Allow content-specific comments
   - Support threaded discussions
   - Implement upvoting/liking of comments
   - Provide notification system for replies

## Quality Assurance

### Content Validation Checklist

1. **Accuracy and Completeness**
   - Content reflects current medical knowledge
   - All required sections are present
   - References are accurate and up-to-date
   - No missing images or media
   - Learning objectives are addressed

2. **Technical Quality**
   - All links function correctly
   - Media plays properly on all platforms
   - Content displays correctly on all devices
   - Offline functionality works as expected
   - Search returns appropriate results

3. **Metadata Validation**
   - All required metadata fields are present
   - Keywords are relevant and comprehensive
   - Categories are appropriate
   - Related content links are valid
   - Difficulty level is appropriate

4. **Accessibility Compliance**
   - Alt text for all images
   - Proper heading structure
   - Sufficient color contrast
   - Keyboard navigation support
   - Screen reader compatibility

### Automated Testing

1. **Content Integrity Tests**
```javascript
// Example Jest test for content integrity
describe('Content Integrity Tests', () => {
  test('All content items have required fields', async () => {
    const contentItems = await db.collection('content').find({}).toArray();
    
    for (const item of contentItems) {
      expect(item).toHaveProperty('content_id');
      expect(item).toHaveProperty('title');
      expect(item).toHaveProperty('description');
      expect(item).toHaveProperty('author');
      expect(item).toHaveProperty('creation_date');
      expect(item).toHaveProperty('content_type');
      expect(item).toHaveProperty('primary_category');
    }
  });
  
  test('All content links are valid', async () => {
    const contentItems = await db.collection('content')
      .find({ content_type: 'article' })
      .toArray();
    
    for (const item of contentItems) {
      const $ = cheerio.load(item.content_html);
      const links = $('a');
      
      for (let i = 0; i < links.length; i++) {
        const href = $(links[i]).attr('href');
        if (href && !href.startsWith('#')) {
          const response = await fetch(href);
          expect(response.status).toBeLessThan(400);
        }
      }
    }
  });
  
  test('All images have alt text', async () => {
    const contentItems = await db.collection('content')
      .find({ content_type: 'article' })
      .toArray();
    
    for (const item of contentItems) {
      const $ = cheerio.load(item.content_html);
      const images = $('img');
      
      for (let i = 0; i < images.length; i++) {
        const alt = $(images[i]).attr('alt');
        expect(alt).toBeDefined();
        expect(alt.length).toBeGreaterThan(0);
      }
    }
  });
});
```

2. **API Tests**
```javascript
// Example Jest test for API endpoints
describe('Content API Tests', () => {
  test('Content listing API returns correct data', async () => {
    const response = await request(app).get('/api/content');
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('pagination');
    expect(Array.isArray(response.body.items)).toBe(true);
  });
  
  test('Content detail API returns correct data', async () => {
    const contentId = 'ROA-ART-2025-0042';
    const response = await request(app).get(`/api/content/${contentId}`);
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('content_id', contentId);
    expect(response.body).toHaveProperty('title');
    expect(response.body).toHaveProperty('content_type');
  });
  
  test('Search API returns relevant results', async () => {
    const query = 'SBRT lung cancer';
    const response = await request(app).get(`/api/search?q=${encodeURIComponent(query)}`);
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('results');
    expect(Array.isArray(response.body.results)).toBe(true);
    
    // Check if results are relevant
    if (response.body.results.length > 0) {
      const firstResult = response.body.results[0];
      expect(
        firstResult.title.includes('SBRT') ||
        firstResult.title.includes('lung') ||
        firstResult.title.includes('cancer') ||
        firstResult.keywords.some(k => ['sbrt', 'lung', 'cancer'].includes(k.toLowerCase()))
      ).toBe(true);
    }
  });
});
```

## Monitoring and Reporting

### Migration Metrics

1. **Progress Metrics**
   - Total content items migrated
   - Percentage of content migrated
   - Migration rate (items per day)
   - Content types distribution
   - Migration failures and retries

2. **Quality Metrics**
   - Content validation pass rate
   - Metadata completeness
   - Media optimization success rate
   - Accessibility compliance rate
   - Search relevance score

3. **Performance Metrics**
   - Content load time
   - Media playback performance
   - Search response time
   - API response time
   - Database query performance

### Reporting Dashboard

1. **Migration Progress Dashboard**
```html
<!-- Example dashboard HTML structure -->
<div class="dashboard-container">
  <div class="dashboard-header">
    <h1>Content Migration Dashboard</h1>
    <div class="date-range">
      <label>Date Range:</label>
      <select id="date-range">
        <option value="today">Today</option>
        <option value="week" selected>This Week</option>
        <option value="month">This Month</option>
        <option value="all">All Time</option>
      </select>
    </div>
  </div>
  
  <div class="metrics-overview">
    <div class="metric-card">
      <h3>Total Content</h3>
      <div class="metric-value">1,245</div>
      <div class="metric-progress">
        <div class="progress-bar" style="width: 78%"></div>
        <div class="progress-text">78% Complete</div>
      </div>
    </div>
    
    <div class="metric-card">
      <h3>Migration Rate</h3>
      <div class="metric-value">42</div>
      <div class="metric-label">items/day</div>
    </div>
    
    <div class="metric-card">
      <h3>Success Rate</h3>
      <div class="metric-value">96.8%</div>
      <div class="metric-trend positive">+2.3%</div>
    </div>
    
    <div class="metric-card">
      <h3>Validation Score</h3>
      <div class="metric-value">92.5%</div>
      <div class="metric-trend positive">+1.7%</div>
    </div>
  </div>
  
  <div class="dashboard-row">
    <div class="dashboard-column">
      <div class="chart-container">
        <h3>Content Type Distribution</h3>
        <canvas id="content-type-chart"></canvas>
      </div>
    </div>
    
    <div class="dashboard-column">
      <div class="chart-container">
        <h3>Migration Progress by Category</h3>
        <canvas id="category-progress-chart"></canvas>
      </div>
    </div>
  </div>
  
  <div class="dashboard-row">
    <div class="dashboard-column">
      <div class="chart-container">
        <h3>Daily Migration Volume</h3>
        <canvas id="daily-volume-chart"></canvas>
      </div>
    </div>
    
    <div class="dashboard-column">
      <div class="chart-container">
        <h3>Error Distribution</h3>
        <canvas id="error-distribution-chart"></canvas>
      </div>
    </div>
  </div>
  
  <div class="recent-activity">
    <h3>Recent Migration Activity</h3>
    <table class="activity-table">
      <thead>
        <tr>
          <th>Content ID</th>
          <th>Title</th>
          <th>Type</th>
          <th>Status</th>
          <th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>ROA-ART-2025-0042</td>
          <td>SBRT for Early-Stage Lung Cancer</td>
          <td>Article</td>
          <td class="status success">Success</td>
          <td>2025-04-10 15:42:18</td>
        </tr>
        <tr>
          <td>ROA-VID-2025-0018</td>
          <td>Contouring Techniques for Head and Neck Cancer</td>
          <td>Video</td>
          <td class="status success">Success</td>
          <td>2025-04-10 15:38:45</td>
        </tr>
        <tr>
          <td>ROA-POD-2025-0007</td>
          <td>Advances in Proton Therapy: Interview with Dr. Sarah Johnson</td>
          <td>Podcast</td>
          <td class="status warning">Partial</td>
          <td>2025-04-10 15:35:22</td>
        </tr>
        <tr>
          <td>ROA-ART-2025-0043</td>
          <td>Radiation Therapy for Pediatric Malignancies</td>
          <td>Article</td>
          <td class="status success">Success</td>
          <td>2025-04-10 15:30:56</td>
        </tr>
        <tr>
          <td>ROA-VID-2025-0019</td>
          <td>VMAT Planning Tutorial</td>
          <td>Video</td>
          <td class="status error">Failed</td>
          <td>2025-04-10 15:28:03</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
```

## Risk Management

| Risk | Impact | Probability | Mitigation Strategy |
|------|--------|------------|---------------------|
| Content format incompatibility | High | Medium | Develop format conversion tools, test with sample content before full migration |
| Missing or incomplete metadata | Medium | High | Implement metadata enhancement scripts, manual review of high-priority content |
| Media quality issues | Medium | Medium | Implement quality checks, regenerate media from source when possible |
| Storage capacity constraints | High | Low | Implement content prioritization, optimize media files, use cloud storage with auto-scaling |
| Database performance degradation | High | Medium | Implement database indexing, sharding for large collections, performance monitoring |
| Content access disruption | High | Low | Implement phased migration, maintain old system until migration is complete, create rollback plan |
| Copyright/licensing issues | High | Medium | Conduct thorough rights review, obtain necessary permissions, document content sources |
| User experience inconsistency | Medium | Medium | Implement comprehensive testing, gather user feedback, maintain design consistency |
| Data loss during migration | High | Low | Implement comprehensive backup strategy, verify data integrity after migration |
| Timeline delays | Medium | High | Build buffer time into schedule, prioritize critical content, implement parallel processing |

## Post-Migration Activities

### Content Verification

1. **Automated Verification**
   - Run content integrity tests
   - Verify metadata completeness
   - Check media playback
   - Test search functionality
   - Validate cross-references

2. **Manual Verification**
   - Sample-based content review
   - User experience evaluation
   - Cross-platform testing
   - Accessibility verification
   - Performance assessment

### User Communication

1. **Pre-Migration Communication**
   - Announce migration timeline
   - Explain benefits of new platform
   - Provide preview access to select users
   - Set expectations for transition
   - Address potential concerns

2. **During Migration Communication**
   - Provide progress updates
   - Highlight newly available content
   - Explain any temporary limitations
   - Offer support channels
   - Gather initial feedback

3. **Post-Migration Communication**
   - Announce completion of migration
   - Highlight new features and improvements
   - Provide user guides and tutorials
   - Request feedback on new platform
   - Address any reported issues

### Ongoing Maintenance

1. **Content Freshness**
   - Implement regular content review schedule
   - Flag outdated content for updates
   - Track content age and usage metrics
   - Solicit user feedback on content relevance
   - Prioritize updates based on usage and importance

2. **Performance Monitoring**
   - Track content load times
   - Monitor media playback performance
   - Analyze search performance
   - Track offline sync efficiency
   - Identify and address bottlenecks

3. **User Engagement Tracking**
   - Monitor content usage patterns
   - Track completion rates
   - Analyze search queries
   - Measure cross-platform usage
   - Identify popular and underutilized content

## Conclusion

This content migration strategy provides a comprehensive framework for transferring existing educational content to the new Radiation Oncology Academy platform. By following this structured approach, we can ensure that all content is properly migrated, optimized, and organized for both the website and mobile applications.

The strategy emphasizes quality, performance, and user experience while providing technical solutions for content extraction, enhancement, optimization, and import. The phased approach allows for thorough testing and validation at each stage, minimizing risks and ensuring a smooth transition.

Upon completion of this migration, the Radiation Oncology Academy platform will offer a rich, well-organized educational resource that provides a seamless experience across web and mobile platforms, with robust offline capabilities and optimized performance.
