# Radiation Oncology Academy - UAT Tester Recruitment Email Templates

## Email Template for Practicing Radiation Oncologists

**Subject:** Invitation to Shape the Future of Radiation Oncology Education

Dear [Recipient Name],

I hope this email finds you well. As a respected radiation oncologist, you are invited to participate in the beta testing of the **Radiation Oncology Academy** platform - a comprehensive educational resource designed specifically for radiation oncology professionals.

**Why You?**  
Your clinical expertise and experience make you an ideal candidate to evaluate our platform. Your insights will directly influence the final product that will serve the radiation oncology community.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Testing of educational content, podcasts, news, and AI features
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to cutting-edge educational content
- 10 CME credits upon completion of testing
- $200 honorarium or donation to a radiation oncology charity of your choice
- Recognition as a founding contributor
- Direct influence on platform development

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to advance radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Residents/Fellows

**Subject:** Help Shape a Revolutionary Learning Platform for Radiation Oncology

Dear Dr. [Recipient Name],

As a resident/fellow in radiation oncology, you represent the future of our field. We invite you to participate in beta testing the **Radiation Oncology Academy** platform - an innovative educational resource designed to support radiation oncology training and continuing education.

**Why Residents/Fellows?**  
Your perspective as someone actively engaged in the learning process is invaluable. You understand firsthand the challenges of mastering radiation oncology concepts and the tools that would be most helpful.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Testing of educational content, podcasts, news, and AI features
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to study resources and board preparation materials
- Certificate of participation for your CV
- $150 honorarium
- Opportunity to network with leaders in radiation oncology education
- Influence the development of a tool you can use throughout your career

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to help advance radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Medical Physicists

**Subject:** Invitation to Evaluate the Physics Content of Radiation Oncology Academy

Dear [Recipient Name],

Your expertise as a medical physicist is crucial to the development of comprehensive radiation oncology education. We invite you to participate in beta testing the **Radiation Oncology Academy** platform, with a particular focus on evaluating our physics content and technical accuracy.

**Why Medical Physicists?**  
The interdisciplinary nature of radiation oncology requires strong physics foundations. Your specialized knowledge will ensure our platform effectively addresses the physics aspects of radiation oncology practice.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Focus on physics content, dosimetry modules, and technical accuracy
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to advanced physics educational content
- CAMPEP continuing education credits (10 credits)
- $175 honorarium
- Recognition as a content advisor
- Opportunity to influence physics education in radiation oncology

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to advance radiation oncology physics education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Radiation Therapists

**Subject:** Help Evaluate the Radiation Oncology Academy Platform

Dear [Recipient Name],

As a radiation therapist, your practical expertise is essential to comprehensive radiation oncology education. We invite you to participate in beta testing the **Radiation Oncology Academy** platform, with a focus on evaluating content relevant to radiation therapy practice.

**Why Radiation Therapists?**  
Your hands-on experience with treatment delivery provides a crucial perspective. Your insights will help ensure our platform addresses the practical aspects of radiation oncology that are essential for quality patient care.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Focus on treatment delivery content, patient positioning, and practical applications
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to continuing education resources
- 10 CE credits recognized by ARRT
- $150 honorarium
- Recognition as a platform contributor
- Opportunity to influence educational content for radiation therapists

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to advance radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Academic Faculty

**Subject:** Invitation to Evaluate the Educational Quality of Radiation Oncology Academy

Dear Professor [Recipient Name],

As an educator in radiation oncology, your perspective on effective teaching methodologies is invaluable. We invite you to participate in beta testing the **Radiation Oncology Academy** platform, with a focus on evaluating the educational design and pedagogical approach.

**Why Academic Faculty?**  
Your experience in radiation oncology education positions you perfectly to assess our platform's effectiveness as a teaching tool. Your insights will help ensure our platform meets the highest standards of educational quality.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Focus on educational structure, content quality, and teaching effectiveness
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to teaching resources and curriculum materials
- Opportunity to incorporate platform resources into your teaching
- $200 honorarium
- Recognition as an educational advisor
- Potential for academic collaboration and publication

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to advance radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Medical Students

**Subject:** Help Shape the Future of Radiation Oncology Education

Dear [Recipient Name],

As a medical student interested in radiation oncology, your fresh perspective is incredibly valuable. We invite you to participate in beta testing the **Radiation Oncology Academy** platform, with a focus on evaluating its effectiveness for those new to the field.

**Why Medical Students?**  
Your perspective as someone approaching radiation oncology with fresh eyes will help ensure our platform is accessible and valuable to learners at all levels.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Focus on introductory content and user-friendliness
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to radiation oncology educational resources
- Certificate of participation for your CV
- $100 honorarium
- Networking opportunity with radiation oncology professionals
- Valuable experience in medical education development

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to help advance radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Oncology Nurses

**Subject:** Invitation to Evaluate the Radiation Oncology Academy Platform

Dear [Recipient Name],

As an oncology nurse working with radiation oncology patients, your clinical perspective is extremely valuable. We invite you to participate in beta testing the **Radiation Oncology Academy** platform, with a focus on evaluating content related to patient care and side effect management.

**Why Oncology Nurses?**  
Your experience in patient care provides crucial insights into the practical application of radiation oncology knowledge. Your feedback will help ensure our platform addresses the collaborative aspects of radiation oncology practice.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Focus on patient care content, side effect management, and interdisciplinary resources
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early access to continuing education resources
- 10 nursing CE credits
- $150 honorarium
- Recognition as a platform contributor
- Opportunity to influence educational content for the nursing perspective

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to advance radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Email Template for Hospital Administrators

**Subject:** Evaluate the Educational Value of the Radiation Oncology Academy Platform

Dear [Recipient Name],

As a healthcare administrator involved in educational resource decisions, your perspective on the Radiation Oncology Academy platform would be invaluable. We invite you to participate in our beta testing program, with a focus on evaluating the platform's institutional value and implementation potential.

**Why Hospital Administrators?**  
Your understanding of institutional needs and resource allocation provides a crucial perspective. Your insights will help ensure our platform delivers value to healthcare organizations and supports departmental educational goals.

**What's Involved:**
- 3-week testing period (April 18-May 9, 2025)
- Access to both web and mobile applications
- Focus on institutional features, team management, and educational ROI
- Approximately 3-5 hours of total participation time (flexible scheduling)

**Benefits to You:**
- Early insight into emerging educational technologies
- Preview of institutional subscription features
- $200 honorarium
- Early access to institutional pricing
- Opportunity to influence platform features for organizational use

**Next Steps:**  
If you're interested in participating, please complete our brief [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) by April 15, 2025.

We will host a virtual orientation session on April 17 at 7:00 PM EST to provide an overview of the testing process and answer any questions.

Thank you for considering this opportunity to help shape the future of radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Follow-up Email Template (For Non-Responders)

**Subject:** Final Opportunity: Radiation Oncology Academy Beta Testing

Dear [Recipient Name],

I wanted to follow up on our invitation for you to participate in beta testing the Radiation Oncology Academy platform. As a [role], your perspective would be extremely valuable to our development process.

The registration deadline is approaching on April 15, and we wanted to ensure you didn't miss this opportunity. Your participation would involve approximately 3-5 hours over a 3-week period, with flexible scheduling to accommodate your professional commitments.

If you're interested in participating, please complete our [Tester Registration Form](https://forms.radiationoncologyacademy.org/beta-tester) at your earliest convenience.

If you have any questions about the testing process or time commitment, please don't hesitate to reach out.

Thank you for your consideration.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team

---

## Confirmation Email Template (After Registration)

**Subject:** Welcome to the Radiation Oncology Academy Beta Testing Program

Dear [Recipient Name],

Thank you for registering to participate in the beta testing of the Radiation Oncology Academy platform. We're excited to have you on board and value the expertise you'll bring to this process.

**Next Steps:**

1. **Orientation Session:**  
   Please join our virtual orientation on April 17 at 7:00 PM EST.  
   Zoom Link: [insert link]  
   Meeting ID: [insert ID]  
   Password: [insert password]

2. **Access Information:**  
   You will receive your personal login credentials on April 18 to access both the web platform and mobile applications.

3. **Testing Schedule:**  
   The testing period runs from April 18 to May 9, 2025.  
   We recommend allocating 1-2 hours per week for the best experience.

4. **Support Contact:**  
   For any questions during the testing period, please contact:  
   Email: betatest@radiationoncologyacademy.org  
   Phone: (555) 123-4567

**What to Expect:**  
During the orientation, we will provide an overview of the platform, explain the testing process, and answer any questions you may have. We will also demonstrate how to provide feedback and report any issues you encounter.

We look forward to your valuable insights that will help shape the future of radiation oncology education.

Sincerely,

[Your Name]  
Radiation Oncology Academy Team
