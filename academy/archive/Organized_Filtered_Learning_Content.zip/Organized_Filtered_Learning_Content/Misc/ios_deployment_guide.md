# iOS Deployment Guide for Radiation Oncology Academy Mobile App

## Overview

This guide outlines the complete process for deploying the Radiation Oncology Academy mobile application to the Apple App Store. It covers all necessary steps from preparing the development environment to submitting the app for review.

## Prerequisites

- Apple Developer Program membership ($99/year)
- Mac computer running macOS Monterey or later
- Xcode 14 or later
- React Native development environment
- App Store Connect access

## 1. Development Environment Setup

### Install Required Tools

```bash
# Install Xcode Command Line Tools
xcode-select --install

# Install CocoaPods
sudo gem install cocoapods

# Install fastlane for automated deployment
brew install fastlane
```

### Configure Xcode

1. Open Xcode
2. Go to Preferences > Accounts
3. Add your Apple Developer account
4. Download manual profiles (if needed)

## 2. App Configuration

### Update App Information

Edit the following files to ensure proper app configuration:

#### `ios/RadiationOncologyApp/Info.plist`

```xml
<key>CFBundleDisplayName</key>
<string>Radiation Oncology Academy</string>
<key>CFBundleIdentifier</key>
<string>com.radiationoncologyacademy.mobile</string>
<key>CFBundleShortVersionString</key>
<string>1.0.0</string>
<key>CFBundleVersion</key>
<string>1</string>
```

#### `app.json`

```json
{
  "name": "RadiationOncologyApp",
  "displayName": "Radiation Oncology Academy"
}
```

### Configure App Capabilities

In Xcode:
1. Open the project file
2. Select the target
3. Go to "Signing & Capabilities"
4. Add the following capabilities:
   - Push Notifications
   - Background Modes (Audio, Background fetch)
   - Associated Domains (if using universal links)

## 3. Code Signing Setup

### Create App ID

1. Go to [Apple Developer Portal](https://developer.apple.com/account/resources/identifiers/list)
2. Click "+" to register a new identifier
3. Select "App IDs" > "App"
4. Enter description: "Radiation Oncology Academy"
5. Bundle ID: com.radiationoncologyacademy.mobile
6. Select required capabilities
7. Click "Continue" and "Register"

### Create Provisioning Profiles

#### Development Profile

1. Go to [Profiles section](https://developer.apple.com/account/resources/profiles/list)
2. Click "+" to create a new profile
3. Select "iOS App Development"
4. Select the App ID created earlier
5. Select development certificates
6. Select devices for testing
7. Name the profile "Radiation Oncology Academy Development"
8. Download and install the profile

#### Distribution Profile

1. Go to [Profiles section](https://developer.apple.com/account/resources/profiles/list)
2. Click "+" to create a new profile
3. Select "App Store"
4. Select the App ID created earlier
5. Select distribution certificate
6. Name the profile "Radiation Oncology Academy Distribution"
7. Download and install the profile

### Configure Automatic Signing in Xcode

1. Open the project in Xcode
2. Select the target
3. Go to "Signing & Capabilities"
4. Check "Automatically manage signing"
5. Select your team

## 4. App Store Connect Setup

### Create New App

1. Go to [App Store Connect](https://appstoreconnect.apple.com/)
2. Click "My Apps"
3. Click "+" > "New App"
4. Fill in the required information:
   - Platforms: iOS
   - Name: Radiation Oncology Academy
   - Primary language: English
   - Bundle ID: com.radiationoncologyacademy.mobile
   - SKU: RADONCAPP2025
   - User Access: Full Access

### App Information

Fill in the following details:

1. **App Information**
   - Privacy Policy URL: https://radiationoncologyacademy.com/privacy
   - Subtitle: Advanced Learning for Radiation Oncology
   - Category: Medical, Education

2. **Pricing and Availability**
   - Price: Free
   - Availability: All territories

3. **App Review Information**
   - Contact information
   - Demo account credentials (if needed)
   - Notes for the review team

## 5. Prepare App Assets

### App Icon

Generate app icons using the following dimensions:

- iPhone: 60pt (@1x, @2x, @3x)
- iPad: 76pt (@1x, @2x), 83.5pt (@2x)
- App Store: 1024px x 1024px

Use the following command to generate all required icon sizes:

```bash
npx react-native-asset --icon ./assets/icon.png --platforms ios
```

### Screenshots

Create screenshots for the following devices:
- iPhone 14 Pro Max (6.7-inch)
- iPhone 14 (6.1-inch)
- iPhone SE (4.7-inch)
- iPad Pro (12.9-inch)
- iPad Pro (11-inch)

Each screenshot should showcase a key feature:
1. Home screen with personalized dashboard
2. Educational content viewer
3. Podcast player
4. News article reader
5. Interactive quiz

### App Preview Videos

Create 30-second preview videos demonstrating:
1. Navigating the app
2. Viewing educational content
3. Using the podcast player
4. Taking quizzes

## 6. Build Configuration

### Configure Release Scheme

1. In Xcode, go to Product > Scheme > Edit Scheme
2. Select "Run" from the left sidebar
3. Change the Build Configuration to "Release"

### Update Build Settings

1. Select the project in Xcode
2. Go to Build Settings
3. Set the following:
   - Enable Bitcode: No
   - Dead Code Stripping: Yes
   - Optimization Level: Fastest, Smallest [-Os]

### Configure Environment Variables

Create a `.env.production` file:

```
API_BASE_URL=https://api.radiationoncologyacademy.com/v1
ENABLE_ANALYTICS=true
LOG_LEVEL=error
```

## 7. Create Production Build

### Manual Build Process

```bash
# Install dependencies
cd /path/to/RadiationOncologyApp
npm install

# Install CocoaPods dependencies
cd ios
pod install
cd ..

# Build the app for production
npx react-native run-ios --configuration Release
```

### Using Fastlane (Recommended)

Create a `Fastfile` in the `ios/fastlane` directory:

```ruby
default_platform(:ios)

platform :ios do
  desc "Build and upload to TestFlight"
  lane :beta do
    increment_build_number(xcodeproj: "RadiationOncologyApp.xcodeproj")
    build_app(
      workspace: "RadiationOncologyApp.xcworkspace",
      scheme: "RadiationOncologyApp",
      configuration: "Release",
      export_method: "app-store",
      output_directory: "./build",
      output_name: "RadiationOncologyApp.ipa"
    )
    upload_to_testflight
  end

  desc "Build and upload to App Store"
  lane :release do
    increment_build_number(xcodeproj: "RadiationOncologyApp.xcodeproj")
    build_app(
      workspace: "RadiationOncologyApp.xcworkspace",
      scheme: "RadiationOncologyApp",
      configuration: "Release",
      export_method: "app-store",
      output_directory: "./build",
      output_name: "RadiationOncologyApp.ipa"
    )
    upload_to_app_store(
      skip_metadata: false,
      skip_screenshots: false,
      submit_for_review: true,
      force: true,
      automatic_release: true
    )
  end
end
```

Run the fastlane command:

```bash
cd ios
fastlane beta  # For TestFlight
# or
fastlane release  # For App Store
```

## 8. TestFlight Distribution

### Upload to TestFlight

1. Build the app using Xcode or fastlane
2. In Xcode, go to Product > Archive
3. Click "Distribute App"
4. Select "App Store Connect"
5. Select "Upload"
6. Follow the prompts to complete the upload

### Configure TestFlight

1. Go to App Store Connect > TestFlight
2. Add internal testers (up to 25 users)
3. Create external testing groups
4. Add external testers (up to 10,000 users)
5. Set testing information:
   - What to test
   - Known issues
   - Beta app description

## 9. App Store Submission

### Final Checklist

- App icon and launch screen are properly configured
- All required screenshots are uploaded
- App preview videos are uploaded
- App metadata is complete
- Privacy policy is in place
- App complies with Apple's App Review Guidelines
- All TestFlight reported issues are resolved

### Submit for Review

1. Go to App Store Connect > App Store tab
2. Verify all information is complete
3. Click "Submit for Review"
4. Answer the export compliance questions
5. Confirm submission

### Monitor Review Status

1. Check App Store Connect regularly for review status
2. Be prepared to respond to reviewer questions
3. Address any issues raised during review

## 10. Post-Launch Activities

### Monitor Analytics

1. Set up App Store Connect Analytics
2. Monitor crash reports
3. Track user engagement metrics

### Plan Updates

1. Collect user feedback
2. Prioritize feature requests
3. Plan regular update schedule

### Support

1. Set up support channels
2. Create FAQ documentation
3. Establish response protocols for user issues

## Troubleshooting

### Common Issues and Solutions

1. **Code Signing Issues**
   - Verify team selection in project settings
   - Check provisioning profile validity
   - Ensure certificates are properly installed

2. **Build Errors**
   - Clean build folder (Shift+Cmd+K)
   - Delete derived data
   - Reinstall dependencies

3. **Submission Rejections**
   - Privacy concerns: Update privacy policy
   - Crashes: Fix stability issues
   - Metadata: Correct misleading information

## Resources

- [Apple App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [App Store Connect Help](https://help.apple.com/app-store-connect/)
- [React Native iOS Deployment Guide](https://reactnative.dev/docs/publishing-to-app-store)
- [Fastlane Documentation](https://docs.fastlane.tools/)
