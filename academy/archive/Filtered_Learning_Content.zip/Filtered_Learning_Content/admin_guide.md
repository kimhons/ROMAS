# Radiation Oncology Academy - Admin Guide

This guide provides detailed instructions for administrators of the Radiation Oncology Academy platform. It covers all aspects of managing the website, including content management, user administration, and system configuration.

## Table of Contents

1. [Admin Dashboard Overview](#admin-dashboard-overview)
2. [User Management](#user-management)
3. [Content Management](#content-management)
4. [Membership Management](#membership-management)
5. [Payment Processing](#payment-processing)
6. [Automated Content Generation](#automated-content-generation)
7. [System Configuration](#system-configuration)
8. [Analytics and Reporting](#analytics-and-reporting)
9. [Maintenance and Updates](#maintenance-and-updates)

## Admin Dashboard Overview

### Accessing the Admin Dashboard

1. Log in to your admin account at [radiationoncologyacademy.com/auth/login](https://radiationoncologyacademy.com/auth/login)
2. You will be automatically redirected to the admin dashboard
3. Alternatively, click on your profile icon and select "Admin Dashboard"

### Dashboard Sections

The admin dashboard is divided into several sections:

- **Overview**: Key metrics and recent activity
- **Users**: User management and permissions
- **Content**: Courses, modules, blog posts, and podcasts
- **Membership**: Tier management and subscriptions
- **Payments**: Transaction history and financial reports
- **Settings**: System configuration and site settings
- **Analytics**: Detailed usage statistics and reports

## User Management

### User Roles

The platform has four user roles:

1. **User**: Regular members with access based on their subscription tier
2. **Instructor**: Can create and manage educational content
3. **Admin**: Full access to all platform features and settings
4. **Super Admin**: System-level access with ability to manage other admins

### Managing Users

#### Viewing Users

1. Go to "Users" in the admin sidebar
2. Use filters to sort by role, membership tier, or activity status
3. Click on a user to view their detailed profile

#### Creating Users

1. Click "Add New User" in the Users section
2. Fill in the required information (name, email, password)
3. Assign a role and membership tier
4. Click "Create User"

#### Editing Users

1. Find the user in the user list
2. Click "Edit" or click on their name
3. Update their information as needed
4. Click "Save Changes"

#### Managing Permissions

1. Go to the user's profile
2. Click on the "Permissions" tab
3. Adjust role-specific permissions
4. Click "Save Permissions"

## Content Management

### Course Management

#### Creating a Course

1. Go to "Content" > "Courses" in the admin sidebar
2. Click "Add New Course"
3. Fill in the course details:
   - Title and description
   - Category and difficulty level
   - Featured image
   - Required membership tier
4. Click "Create Course"

#### Managing Modules

1. Navigate to the course you want to add modules to
2. Click on the "Modules" tab
3. Click "Add Module"
4. Fill in the module details:
   - Title and description
   - Content (text, images, videos)
   - Order within the course
   - Duration
5. Click "Save Module"

#### Creating Quizzes

1. Navigate to the module you want to add a quiz to
2. Click on the "Quiz" tab
3. Click "Create Quiz"
4. Add questions and answers
5. Set passing score and time limit
6. Click "Save Quiz"

### Blog Management

#### Creating Blog Posts

1. Go to "Content" > "Blog" in the admin sidebar
2. Click "Add New Post"
3. Fill in the post details:
   - Title and excerpt
   - Content
   - Category and tags
   - Featured image
4. Set publication status (draft or published)
5. Click "Create Post"

#### Managing Comments

1. Go to "Content" > "Blog" > "Comments"
2. Review pending comments
3. Approve, edit, or delete comments as needed

### Podcast Management

#### Adding Podcast Episodes

1. Go to "Content" > "Podcast" in the admin sidebar
2. Click "Add New Episode"
3. Fill in the episode details:
   - Title and description
   - Series and episode number
   - Upload audio file
   - Add transcript (optional)
   - Set required membership tier
4. Click "Create Episode"

## Membership Management

### Managing Membership Tiers

#### Viewing Tiers

1. Go to "Membership" > "Tiers" in the admin sidebar
2. View all current membership tiers and their details

#### Editing Tiers

1. Click "Edit" next to the tier you want to modify
2. Update pricing, features, or description
3. Click "Save Changes"

#### Creating New Tiers

1. Click "Add New Tier"
2. Fill in the tier details:
   - Name and description
   - Monthly and yearly pricing
   - Features list
   - Access level
3. Click "Create Tier"

### Managing Subscriptions

#### Viewing Subscriptions

1. Go to "Membership" > "Subscriptions"
2. View all active subscriptions
3. Filter by tier, status, or date range

#### Modifying Subscriptions

1. Click on a subscription to view details
2. Click "Edit Subscription"
3. Change tier, billing cycle, or status
4. Click "Save Changes"

#### Handling Cancellations

1. Go to "Membership" > "Cancellations"
2. Review cancellation requests
3. Process or deny requests
4. Add notes for internal reference

## Payment Processing

### Transaction Management

#### Viewing Transactions

1. Go to "Payments" > "Transactions"
2. View all payment transactions
3. Filter by status, payment method, or date range

#### Processing Refunds

1. Find the transaction in the list
2. Click "Refund"
3. Enter refund amount and reason
4. Click "Process Refund"

### Payment Settings

#### Configuring Payment Methods

1. Go to "Payments" > "Settings"
2. Enable or disable payment methods (Stripe, PayPal)
3. Update API keys and credentials
4. Configure webhook endpoints

#### Managing Tax Settings

1. Go to "Payments" > "Tax Settings"
2. Configure tax rates by region
3. Set up tax exemptions if applicable
4. Save changes

## Automated Content Generation

### Blog Content Generation

#### Generating Blog Posts

1. Go to "Content" > "Blog" > "Generate Content"
2. Enter a topic related to radiation oncology
3. Select category and tags
4. Click "Generate Post"
5. Review and edit the generated content
6. Publish or save as draft

#### Managing Generated Content

1. Go to "Content" > "Blog" > "Generated Content"
2. View all automatically generated posts
3. Edit, publish, or delete as needed

### Podcast Generation

#### Generating Podcast Scripts

1. Go to "Content" > "Podcast" > "Generate Script"
2. Enter a topic and select series
3. Click "Generate Script"
4. Review and edit the generated script
5. Save for later use or proceed to audio generation

#### Generating Audio

1. From the generated script page, click "Generate Audio"
2. Select voice options
3. Click "Create Audio"
4. Preview the generated audio
5. Edit metadata and publish when ready

### Transcript Generation

1. Go to "Content" > "Podcast" > select an episode
2. Click "Generate Transcript"
3. Wait for the transcript to be generated
4. Review and edit the transcript
5. Click "Save Transcript"

## System Configuration

### General Settings

1. Go to "Settings" > "General"
2. Configure site title, description, and logo
3. Set up email templates and notification settings
4. Adjust date, time, and regional settings

### API Integrations

#### OpenAI Configuration

1. Go to "Settings" > "Integrations" > "OpenAI"
2. Enter your API key
3. Configure model settings and parameters
4. Test the integration
5. Save changes

#### ElevenLabs Configuration

1. Go to "Settings" > "Integrations" > "ElevenLabs"
2. Enter your API key
3. Configure voice settings and parameters
4. Test the integration
5. Save changes

#### Google STT Configuration

1. Go to "Settings" > "Integrations" > "Google STT"
2. Enter your API key
3. Configure language and transcription settings
4. Test the integration
5. Save changes

### Security Settings

1. Go to "Settings" > "Security"
2. Configure password policies
3. Set up two-factor authentication requirements
4. Manage session timeout settings
5. Configure IP restrictions if needed

## Analytics and Reporting

### User Analytics

1. Go to "Analytics" > "Users"
2. View user registration trends
3. Analyze user engagement metrics
4. Export reports as needed

### Content Analytics

1. Go to "Analytics" > "Content"
2. View most popular courses, blog posts, and podcasts
3. Analyze completion rates and engagement
4. Identify content improvement opportunities

### Revenue Reports

1. Go to "Analytics" > "Revenue"
2. View revenue by membership tier
3. Analyze subscription trends
4. Generate financial reports for specific periods

### Custom Reports

1. Go to "Analytics" > "Custom Reports"
2. Select metrics and dimensions
3. Set date range
4. Generate and export custom reports

## Maintenance and Updates

### Database Backup

1. Go to "Settings" > "Maintenance" > "Backup"
2. Click "Create Backup" to manually backup the database
3. Configure automatic backup schedule
4. Download backup files for safekeeping

### System Updates

1. Go to "Settings" > "Maintenance" > "Updates"
2. Check for available updates
3. Review update notes
4. Create a backup before updating
5. Click "Update System"

### Error Logs

1. Go to "Settings" > "Maintenance" > "Logs"
2. View system error logs
3. Filter by severity or date
4. Address critical errors promptly

### Performance Optimization

1. Go to "Settings" > "Maintenance" > "Performance"
2. View current performance metrics
3. Clear cache if needed
4. Adjust optimization settings

## Conclusion

This admin guide covers the essential functions for managing the Radiation Oncology Academy platform. For technical issues or advanced configuration needs, please refer to the technical documentation or contact the development team.

Remember to regularly backup your data and keep the system updated to ensure optimal performance and security.
