# Reference Materials Management Guide
# Radiation Oncology Academy

This guide provides detailed instructions for managing reference materials in the Radiation Oncology Academy platform. It explains how to upload, organize, and utilize various educational resources such as AAPM TG reports, research papers, textbooks, and clinical notes.

## Table of Contents

1. [Overview of Reference Materials Management](#overview-of-reference-materials-management)
2. [Setting Up Google Cloud Storage for Reference Materials](#setting-up-google-cloud-storage-for-reference-materials)
3. [Organizing Your Reference Materials](#organizing-your-reference-materials)
4. [Uploading Reference Materials](#uploading-reference-materials)
5. [Managing Access Controls](#managing-access-controls)
6. [Using Reference Materials for Content Generation](#using-reference-materials-for-content-generation)
7. [Best Practices and Maintenance](#best-practices-and-maintenance)

## Overview of Reference Materials Management

The Radiation Oncology Academy platform uses a three-tier storage system:

1. **Private Source Materials**: Original reference materials (AAPM TG reports, research papers, textbooks) that are only accessible to administrators
2. **Member Content**: Educational content derived from source materials, accessible based on membership tier
3. **Public Content**: Freely available content for marketing and preview purposes

This guide focuses on managing the private source materials that form the foundation of your educational content.

## Setting Up Google Cloud Storage for Reference Materials

### Step 1: Create the Private Source Materials Bucket

Follow these steps to create a secure storage location for your reference materials:

1. Log in to the Google Cloud Console at [console.cloud.google.com](https://console.cloud.google.com/)
2. Select your "Radiation Oncology Academy" project
3. In the left sidebar, navigate to "Cloud Storage" > "Buckets"
4. Click "Create Bucket"
5. Name the bucket `roa-private-source-materials` (adjust if needed)
6. For Location type, select "Region" and choose a region close to your primary audience
7. For Storage class, select "Standard"
8. For Access control, select "Fine-grained"
9. For Protection tools, leave at default settings
10. Click "Create"

### Step 2: Configure Access Controls

Ensure your reference materials remain private:

1. In the buckets list, click on `roa-private-source-materials`
2. Go to the "Permissions" tab
3. Click "Add Principal"
4. In the "New principals" field, enter your email address
5. For "Role", select "Storage Object Admin"
6. Click "Save"
7. This bucket will be accessible only to you and any administrators you add

### Step 3: Connect to GoDaddy Hosting

If you're using GoDaddy hosting:

1. Follow the GoDaddy-specific guide to set up the service account
2. Upload your `gcs-key.json` file to:
```
/home/username/backend/config/gcs-key.json
```
3. Update your `.env` file with the correct path:
```
GCS_KEY_PATH=/home/username/backend/config/gcs-key.json
GCS_PRIVATE_BUCKET=roa-private-source-materials
```

## Organizing Your Reference Materials

### Recommended Folder Structure

Create the following folder structure in your private bucket:

1. **AAPM TG Reports**
   - Path: `/aapm-tg-reports/`
   - Purpose: Store all AAPM Task Group reports
   - Subfolders:
     - `/aapm-tg-reports/radiation-therapy/`
     - `/aapm-tg-reports/quality-assurance/`
     - `/aapm-tg-reports/imaging/`
     - `/aapm-tg-reports/radiation-protection/`

2. **Research Papers**
   - Path: `/research-papers/`
   - Purpose: Store scientific papers and research
   - Subfolders:
     - `/research-papers/clinical-studies/`
     - `/research-papers/physics/`
     - `/research-papers/biology/`
     - `/research-papers/technology/`

3. **Textbooks**
   - Path: `/textbooks/`
   - Purpose: Store reference books and textbooks
   - Subfolders:
     - `/textbooks/radiation-physics/`
     - `/textbooks/clinical-oncology/`
     - `/textbooks/dosimetry/`
     - `/textbooks/imaging/`

4. **Clinical Notes**
   - Path: `/clinical-notes/`
   - Purpose: Store clinical practice notes
   - Subfolders:
     - `/clinical-notes/treatment-planning/`
     - `/clinical-notes/quality-assurance/`
     - `/clinical-notes/patient-setup/`
     - `/clinical-notes/case-studies/`

### Creating the Folder Structure

1. In the Google Cloud Console, navigate to your `roa-private-source-materials` bucket
2. Click "Create Folder"
3. Enter the folder name (e.g., "aapm-tg-reports")
4. Click "Create"
5. Navigate into the new folder
6. Create subfolders following the same process
7. Repeat for all recommended folders and subfolders

## Uploading Reference Materials

### Method 1: Direct Upload via Google Cloud Console

1. Navigate to the appropriate folder in your bucket
2. Click "Upload Files" or "Upload Folder"
3. Select the files from your computer
4. Click "Open" to begin uploading

### Method 2: Upload via Admin Dashboard

1. Log in to your Radiation Oncology Academy admin panel
2. Go to "Content" > "Reference Materials"
3. Click "Upload New Material"
4. Fill in the metadata form:
   - Title: Document title
   - Type: Select from dropdown (AAPM TG Report, Research Paper, etc.)
   - Category: Select appropriate category
   - Description: Brief description of the material
   - Tags: Add relevant keywords for searchability
5. Click "Choose File" and select your document
6. Click "Upload"

### Method 3: Batch Upload for Multiple Files

For uploading many files at once:

1. In the admin panel, go to "Content" > "Reference Materials"
2. Click "Batch Upload"
3. Prepare your files with a consistent naming convention
4. Create a CSV file with metadata for each document (template provided)
5. Upload the CSV file and the folder containing all documents
6. Click "Process Batch"

### File Naming Conventions

For optimal organization, follow these naming conventions:

1. **AAPM TG Reports**: `AAPM-TG-[number]-[short-title].pdf`
   - Example: `AAPM-TG-142-QA-Linear-Accelerators.pdf`

2. **Research Papers**: `[Author]-[Year]-[Short-Title].pdf`
   - Example: `Smith-2023-Dosimetry-Comparison.pdf`

3. **Textbooks**: `[Author]-[Title]-[Edition].pdf`
   - Example: `Khan-Physics-of-Radiation-Therapy-5th.pdf`

4. **Clinical Notes**: `[Topic]-[Subtopic]-[Date].pdf`
   - Example: `Treatment-Planning-Lung-SBRT-2023-03.pdf`

## Managing Access Controls

### Setting Up Administrator Access

To grant access to additional administrators:

1. In the Google Cloud Console, navigate to your `roa-private-source-materials` bucket
2. Go to the "Permissions" tab
3. Click "Add Principal"
4. Enter the email address of the administrator
5. Assign the "Storage Object Admin" role
6. Click "Save"

### Revoking Access

To remove access for a user:

1. In the "Permissions" tab, find the user
2. Click the trash icon next to their name
3. Confirm the removal

### Audit Access

To review who has access to your materials:

1. In the Google Cloud Console, go to "IAM & Admin" > "IAM"
2. Review the list of principals and their roles
3. For detailed access logs, go to "Cloud Logging" > "Logs Explorer"
4. Filter for storage access events

## Using Reference Materials for Content Generation

### Manual Content Creation

1. In the admin panel, go to "Content" > "Create New"
2. Select content type (Course, Blog Post, Quiz, etc.)
3. Click "Reference Materials" to browse available documents
4. Select relevant materials to reference
5. Use the content editor to create your educational content
6. Include proper citations to the reference materials

### Automated Content Generation

The platform can automatically generate content based on your reference materials:

1. In the admin panel, go to "Content" > "AI Generation"
2. Click "New Generation Task"
3. Select the reference materials to use as sources
4. Choose the type of content to generate:
   - Blog post
   - Course module
   - Quiz questions
   - Podcast script
5. Configure generation parameters:
   - Complexity level
   - Target audience
   - Content length
   - Key points to include
6. Click "Generate Content"
7. Review and edit the generated content
8. Publish or save as draft

## Best Practices and Maintenance

### Regular Backups

1. Set up automatic backups of your reference materials
2. In Google Cloud Console, go to "Cloud Storage" > "Transfer"
3. Create a transfer job to copy data to another bucket weekly

### Content Auditing

1. Quarterly, review your reference materials for:
   - Outdated content that needs updating
   - Missing materials in important topic areas
   - Opportunities for new content creation
2. Document your content audit findings
3. Create an action plan for addressing gaps

### Version Control

For documents that update regularly:

1. Use version numbers in filenames
   - Example: `AAPM-TG-142-QA-Linear-Accelerators-v2.pdf`
2. Maintain a version log in the admin panel
3. Consider using Google Cloud Storage's object versioning:
   - In bucket details, go to "Configuration"
   - Enable "Object Versioning"

### Storage Optimization

To manage storage costs:

1. Regularly archive rarely accessed materials
   - In bucket details, go to "Lifecycle"
   - Create a rule to transition objects to Nearline storage after 90 days
2. Compress large files before uploading
3. Consider converting text-heavy PDFs to more efficient formats

## Conclusion

By following this guide, you'll have a well-organized system for managing reference materials in your Radiation Oncology Academy platform. This foundation will enable you to create high-quality educational content, either manually or through AI-assisted generation.

Remember that the reference materials you upload are the foundation of your platform's value. Taking time to properly organize and manage these resources will significantly enhance the quality and effectiveness of your educational content.

For any questions or issues, refer to the Google Cloud Storage documentation or contact your website administrator.
