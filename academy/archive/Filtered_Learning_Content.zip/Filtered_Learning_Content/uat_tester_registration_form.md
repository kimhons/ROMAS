# Radiation Oncology Academy - Beta Tester Registration Form

## Form Introduction

Thank you for your interest in participating in the beta testing of the Radiation Oncology Academy platform. This form will help us understand your background and ensure we have a diverse group of testers representing different roles and experience levels within radiation oncology.

## Personal Information

**Full Name:** [Text Field]

**Email Address:** [Email Field]

**Phone Number:** [Phone Field]

**City/State/Country:** [Text Field]

**Preferred Contact Method:**
- [ ] Email
- [ ] Phone
- [ ] Text Message

## Professional Background

**Primary Professional Role:**
- [ ] Radiation Oncologist
- [ ] Resident/Fellow
- [ ] Medical Physicist
- [ ] Radiation Therapist
- [ ] Academic Faculty
- [ ] Medical Student
- [ ] Oncology Nurse
- [ ] Hospital Administrator
- [ ] Other: [Text Field]

**Years of Experience in Radiation Oncology:**
- [ ] Less than 2 years
- [ ] 2-5 years
- [ ] 6-10 years
- [ ] 11-20 years
- [ ] More than 20 years

**Practice Setting:**
- [ ] Academic Medical Center
- [ ] Community Hospital
- [ ] Private Practice
- [ ] Government/VA
- [ ] Cancer Center
- [ ] Other: [Text Field]

**Subspecialty Interest/Focus (select all that apply):**
- [ ] CNS
- [ ] Head and Neck
- [ ] Breast
- [ ] Thoracic
- [ ] GI
- [ ] GU
- [ ] Gynecologic
- [ ] Pediatric
- [ ] Lymphoma
- [ ] Sarcoma
- [ ] Palliative Care
- [ ] Physics/Dosimetry
- [ ] Brachytherapy
- [ ] Proton Therapy
- [ ] Other: [Text Field]

## Technical Information

**Devices You Will Use for Testing (select all that apply):**
- [ ] iPhone (Model: [Text Field])
- [ ] iPad (Model: [Text Field])
- [ ] Android Phone (Model: [Text Field])
- [ ] Android Tablet (Model: [Text Field])
- [ ] Windows PC/Laptop
- [ ] Mac PC/Laptop
- [ ] Other: [Text Field]

**Primary Web Browser:**
- [ ] Chrome
- [ ] Safari
- [ ] Firefox
- [ ] Edge
- [ ] Other: [Text Field]

**Internet Connection Type:**
- [ ] High-speed broadband
- [ ] Moderate speed
- [ ] Mobile data
- [ ] Variable/Multiple

**How would you rate your technical proficiency?**
- [ ] Beginner - I use basic features of technology
- [ ] Intermediate - I'm comfortable with most technology
- [ ] Advanced - I quickly adapt to new technology
- [ ] Expert - I often help others with technology

## Availability and Participation

**Can you commit to approximately 3-5 hours of testing over a 3-week period (April 18-May 9, 2025)?**
- [ ] Yes
- [ ] No
- [ ] Unsure, would need more information

**Are you available to attend a virtual orientation session on April 17 at 7:00 PM EST?**
- [ ] Yes
- [ ] No, but I can watch a recording
- [ ] No, I would need an alternative time

**Preferred testing schedule:**
- [ ] Weekdays during business hours
- [ ] Weekday evenings
- [ ] Weekends
- [ ] Flexible/No preference

**Would you be interested in participating in:**
- [ ] One-on-one interview/feedback session (30 minutes)
- [ ] Focus group discussion (60 minutes)
- [ ] Screen recording of your usage (with your permission)
- [ ] All of the above
- [ ] None of the above

## Experience and Motivation

**Have you participated in beta testing for software or educational platforms before?**
- [ ] Yes (Please describe: [Text Field])
- [ ] No

**What interests you most about testing the Radiation Oncology Academy platform? (select all that apply)**
- [ ] Early access to educational content
- [ ] Influencing the development of the platform
- [ ] Professional development opportunity
- [ ] Incentives (CME credits, honorarium)
- [ ] Interest in educational technology
- [ ] Other: [Text Field]

**Which aspects of the platform are you most interested in testing? (select all that apply)**
- [ ] Educational content quality and accuracy
- [ ] User interface and experience
- [ ] Mobile app functionality
- [ ] Podcast features
- [ ] News and updates section
- [ ] AI-powered features
- [ ] Cross-platform synchronization
- [ ] Offline capabilities
- [ ] Other: [Text Field]

**What educational resources do you currently use for radiation oncology information? (select all that apply)**
- [ ] Textbooks
- [ ] Journal articles
- [ ] Online courses
- [ ] Conferences
- [ ] Podcasts
- [ ] Social media
- [ ] Other platforms (Please specify: [Text Field])

## Incentives and Recognition

**Preferred form of honorarium:**
- [ ] Direct payment
- [ ] Gift card
- [ ] Donation to radiation oncology charity
- [ ] CME/CE credits only

**If you selected donation, please specify preferred charity:** [Text Field]

**Would you like to be recognized as a beta tester in our platform credits?**
- [ ] Yes, using my full name and credentials
- [ ] Yes, using my name only
- [ ] No, I prefer to remain anonymous

## Additional Information

**Do you have any specific accessibility needs we should be aware of?**
[Text Area]

**Is there anything else you would like us to know about your interest in testing the Radiation Oncology Academy platform?**
[Text Area]

## Agreement

[ ] I understand that as a beta tester, I will be accessing pre-release software that may contain bugs or incomplete features.

[ ] I agree to provide constructive feedback throughout the testing period.

[ ] I understand that I will be asked to keep certain aspects of the platform confidential until public release.

[ ] I have read and agree to the [Terms and Conditions] and [Privacy Policy].

## Submission

[Submit Button]

Thank you for your interest in the Radiation Oncology Academy beta testing program. We will review your application and contact you by April 16, 2025, regarding your participation.

If you have any questions, please contact betatest@radiationoncologyacademy.org.
