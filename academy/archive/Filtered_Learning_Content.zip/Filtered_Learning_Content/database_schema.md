# Radiation Oncology Academy Database Schema

## Overview
This document outlines the database schema for the Radiation Oncology Academy website. The schema is designed to support user authentication, content management, interactive features, and subscription management. We'll use MongoDB as our database system due to its flexibility with document-based structures and scalability.

## User Management

### Users Collection
```json
{
  "_id": "ObjectId",
  "email": "String (unique, required)",
  "password": "String (hashed, required)",
  "firstName": "String (required)",
  "lastName": "String (required)",
  "role": "String (enum: 'user', 'admin', 'editor', 'instructor')",
  "profileImage": "String (URL)",
  "specialty": "String (enum: 'oncologist', 'physicist', 'resident', 'graduate-student', 'other')",
  "institution": "String",
  "bio": "String",
  "createdAt": "Date",
  "updatedAt": "Date",
  "lastLogin": "Date"
}
```

### Subscriptions Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "plan": "String (enum: 'trial', 'pro', 'premium')",
  "status": "String (enum: 'active', 'canceled', 'expired', 'past_due')",
  "startDate": "Date",
  "endDate": "Date",
  "trialEndsAt": "Date",
  "stripeCustomerId": "String",
  "stripeSubscriptionId": "String",
  "paymentMethod": "String (enum: 'stripe', 'paypal')",
  "cancelReason": "String",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Payment History Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "subscriptionId": "ObjectId (ref: Subscriptions)",
  "amount": "Number",
  "currency": "String",
  "status": "String (enum: 'succeeded', 'failed', 'pending')",
  "paymentMethod": "String",
  "paymentIntentId": "String",
  "invoiceId": "String",
  "createdAt": "Date"
}
```

## Content Management

### Tracks Collection
```json
{
  "_id": "ObjectId",
  "name": "String (required)",
  "slug": "String (unique, required)",
  "description": "String",
  "targetAudience": "String (enum: 'oncologist', 'physicist', 'resident', 'graduate-student')",
  "featuredImage": "String (URL)",
  "modules": ["ObjectId (ref: Modules)"],
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Modules Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "slug": "String (unique, required)",
  "description": "String",
  "trackId": "ObjectId (ref: Tracks)",
  "examPart": "String (enum: 'part1-general', 'part1-clinical', 'part2-therapeutic', 'part2-diagnostic', 'part2-nuclear')",
  "topics": ["String"],
  "order": "Number",
  "duration": "Number (minutes)",
  "lessons": ["ObjectId (ref: Lessons)"],
  "quizzes": ["ObjectId (ref: Quizzes)"],
  "resources": ["ObjectId (ref: Resources)"],
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Lessons Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "slug": "String (unique, required)",
  "moduleId": "ObjectId (ref: Modules)",
  "content": "String (HTML/Markdown)",
  "videoUrl": "String",
  "slidesUrl": "String",
  "order": "Number",
  "duration": "Number (minutes)",
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Resources Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "description": "String",
  "type": "String (enum: 'pdf', 'video', 'link', 'image', 'presentation')",
  "url": "String",
  "fileSize": "Number",
  "moduleId": "ObjectId (ref: Modules)",
  "lessonId": "ObjectId (ref: Lessons)",
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

## Interactive Features

### Quizzes Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "description": "String",
  "moduleId": "ObjectId (ref: Modules)",
  "lessonId": "ObjectId (ref: Lessons)",
  "type": "String (enum: 'practice', 'assessment', 'flashcard')",
  "questions": ["ObjectId (ref: Questions)"],
  "timeLimit": "Number (minutes)",
  "passingScore": "Number (percentage)",
  "randomizeQuestions": "Boolean",
  "showAnswers": "Boolean",
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Questions Collection
```json
{
  "_id": "ObjectId",
  "quizId": "ObjectId (ref: Quizzes)",
  "type": "String (enum: 'multiple-choice', 'fill-in-blank', 'point-and-click', 'case-based')",
  "question": "String (required)",
  "explanation": "String",
  "imageUrl": "String",
  "options": [
    {
      "text": "String",
      "isCorrect": "Boolean",
      "explanation": "String"
    }
  ],
  "correctAnswer": "String or Array (for fill-in-blank or point-and-click)",
  "points": "Number",
  "difficulty": "String (enum: 'easy', 'medium', 'hard')",
  "topics": ["String"],
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### UserProgress Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "trackId": "ObjectId (ref: Tracks)",
  "moduleId": "ObjectId (ref: Modules)",
  "lessonId": "ObjectId (ref: Lessons)",
  "status": "String (enum: 'not-started', 'in-progress', 'completed')",
  "progress": "Number (percentage)",
  "lastAccessedAt": "Date",
  "completedAt": "Date",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### QuizAttempts Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "quizId": "ObjectId (ref: Quizzes)",
  "score": "Number",
  "totalQuestions": "Number",
  "correctAnswers": "Number",
  "timeSpent": "Number (seconds)",
  "completed": "Boolean",
  "answers": [
    {
      "questionId": "ObjectId (ref: Questions)",
      "userAnswer": "String or Array",
      "isCorrect": "Boolean",
      "timeSpent": "Number (seconds)"
    }
  ],
  "startedAt": "Date",
  "completedAt": "Date",
  "createdAt": "Date"
}
```

### Flashcards Collection
```json
{
  "_id": "ObjectId",
  "front": "String (required)",
  "back": "String (required)",
  "moduleId": "ObjectId (ref: Modules)",
  "topics": ["String"],
  "difficulty": "String (enum: 'easy', 'medium', 'hard')",
  "imageUrl": "String",
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### CaseStudies Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "description": "String",
  "content": "String (HTML/Markdown)",
  "patientInfo": "Object",
  "images": ["String (URL)"],
  "questions": ["ObjectId (ref: Questions)"],
  "moduleId": "ObjectId (ref: Modules)",
  "topics": ["String"],
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

## Community Features

### Forums Collection
```json
{
  "_id": "ObjectId",
  "name": "String (required)",
  "slug": "String (unique, required)",
  "description": "String",
  "topics": ["ObjectId (ref: ForumTopics)"],
  "moderators": ["ObjectId (ref: Users)"],
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isActive": "Boolean",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### ForumTopics Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "slug": "String (unique, required)",
  "forumId": "ObjectId (ref: Forums)",
  "content": "String (HTML/Markdown)",
  "author": "ObjectId (ref: Users)",
  "isPinned": "Boolean",
  "isLocked": "Boolean",
  "views": "Number",
  "replies": ["ObjectId (ref: ForumReplies)"],
  "tags": ["String"],
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### ForumReplies Collection
```json
{
  "_id": "ObjectId",
  "topicId": "ObjectId (ref: ForumTopics)",
  "content": "String (HTML/Markdown)",
  "author": "ObjectId (ref: Users)",
  "isAnswer": "Boolean",
  "upvotes": "Number",
  "downvotes": "Number",
  "parentReplyId": "ObjectId (ref: ForumReplies)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

## Content Publishing

### Podcasts Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "slug": "String (unique, required)",
  "description": "String",
  "audioUrl": "String (required)",
  "duration": "Number (seconds)",
  "imageUrl": "String",
  "guests": ["String"],
  "topics": ["String"],
  "transcript": "String",
  "showNotes": "String (HTML/Markdown)",
  "episodeNumber": "Number",
  "publishDate": "Date",
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "createdBy": "ObjectId (ref: Users)",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### BlogPosts Collection
```json
{
  "_id": "ObjectId",
  "title": "String (required)",
  "slug": "String (unique, required)",
  "content": "String (HTML/Markdown)",
  "excerpt": "String",
  "featuredImage": "String (URL)",
  "author": "ObjectId (ref: Users)",
  "categories": ["String"],
  "tags": ["String"],
  "publishDate": "Date",
  "accessLevel": "String (enum: 'trial', 'pro', 'premium')",
  "isPublished": "Boolean",
  "views": "Number",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

## System Management

### Settings Collection
```json
{
  "_id": "ObjectId",
  "key": "String (unique, required)",
  "value": "Mixed",
  "description": "String",
  "updatedBy": "ObjectId (ref: Users)",
  "updatedAt": "Date"
}
```

### Notifications Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "type": "String (enum: 'system', 'subscription', 'content', 'forum')",
  "title": "String",
  "message": "String",
  "link": "String",
  "isRead": "Boolean",
  "createdAt": "Date"
}
```

### ActivityLogs Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "action": "String",
  "entity": "String",
  "entityId": "ObjectId",
  "details": "Object",
  "ipAddress": "String",
  "userAgent": "String",
  "createdAt": "Date"
}
```

## Relationships and Indexes

### Key Relationships
1. Users -> Subscriptions (one-to-one)
2. Tracks -> Modules (one-to-many)
3. Modules -> Lessons (one-to-many)
4. Modules -> Quizzes (one-to-many)
5. Quizzes -> Questions (one-to-many)
6. Users -> UserProgress (one-to-many)
7. Users -> QuizAttempts (one-to-many)
8. Forums -> ForumTopics (one-to-many)
9. ForumTopics -> ForumReplies (one-to-many)

### Recommended Indexes
1. Users: email (unique)
2. Tracks: slug (unique)
3. Modules: slug (unique), trackId
4. Lessons: moduleId, order
5. Quizzes: moduleId
6. UserProgress: userId, moduleId, lessonId
7. QuizAttempts: userId, quizId
8. BlogPosts: slug (unique), publishDate
9. Podcasts: slug (unique), publishDate
10. ForumTopics: forumId, createdAt

## Data Access Patterns

### Common Queries
1. Get user subscription status
2. Get modules by track
3. Get lessons by module
4. Get user progress across modules
5. Get quiz results for a user
6. Get content based on access level
7. Get latest blog posts and podcasts
8. Get forum topics with most recent activity

### Access Control
- Content access will be controlled by the accessLevel field
- User roles will determine administrative capabilities
- Subscription status will be checked for premium content access

## Migration Strategy
1. Start with Users, Subscriptions, and basic content collections
2. Add interactive features (Quizzes, Questions) in phase 2
3. Add community features (Forums) in phase 3
4. Add analytics and reporting in phase 4

## Backup and Recovery
- Daily automated backups
- Point-in-time recovery capability
- Separate backup strategy for user data and content data

## Scaling Considerations
- Sharding strategy for large collections (Users, QuizAttempts)
- Read replicas for content-heavy queries
- Caching layer for frequently accessed content
