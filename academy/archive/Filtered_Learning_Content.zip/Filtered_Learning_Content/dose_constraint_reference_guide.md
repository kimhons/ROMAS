# Dose Constraint Guide for Radiation Therapy

## Purpose
This reference guide provides recommended dose constraints for organs at risk (OARs) in radiation therapy planning. It compiles constraints from major protocols and publications, organized by anatomical site. Use this guide during treatment planning to evaluate plan quality and ensure patient safety. Note that these constraints should be considered guidelines rather than absolute limits, and clinical judgment should be exercised in individual cases.

## Quick Reference Table: Critical Structures

| Structure | Constraint | Protocol | Priority |
|-----------|------------|----------|----------|
| Spinal Cord | D0.03cc < 50 Gy | QUANTEC | Mandatory |
| Brain Stem | D0.03cc < 54 Gy | QUANTEC | Mandatory |
| Optic Nerves | D0.03cc < 55 Gy | QUANTEC | Mandatory |
| Optic Chiasm | D0.03cc < 55 Gy | QUANTEC | Mandatory |
| Lens | Dmax < 10 Gy | QUANTEC | Recommended |
| Cochlea | Dmean < 45 Gy | QUANTEC | Recommended |
| Parotid (single) | Dmean < 26 Gy | QUANTEC | Recommended |
| Kidneys (combined) | V20Gy < 32% | QUANTEC | Recommended |
| Liver | Dmean < 30 Gy | QUANTEC | Recommended |
| Heart | V25Gy < 10% | QUANTEC | Recommended |
| Lungs (combined) | V20Gy < 30% | QUANTEC | Recommended |

## Detailed Information

### Section 1: Central Nervous System

#### Spinal Cord
- **Conventional Fractionation**:
  - D0.03cc < 50 Gy (QUANTEC)
  - D1cc < 45 Gy (QUANTEC)
- **Hypofractionation**:
  - D0.03cc < 30 Gy in 5 fractions (AAPM TG-101)
  - D0.03cc < 18 Gy in 1 fraction (AAPM TG-101)
- **Clinical Endpoint**: Myelopathy
- **Dose-Response Relationship**:

$$NTCP = \frac{1}{1 + \left(\frac{TD_{50}}{D}\right)^{4\gamma_{50}}}$$

Where:
- NTCP is the normal tissue complication probability
- TD50 is the dose at which there is a 50% chance of complication (estimated at 68.6 Gy)
- γ50 is the slope of the dose-response curve at TD50 (estimated at 1.9)
- D is the maximum dose to the spinal cord

| Dose (Gy) | Myelopathy Risk (%) | Study |
|-----------|---------------------|-------|
| < 45      | < 0.2               | Kirkpatrick et al. |
| 50        | 0.2-1               | Kirkpatrick et al. |
| 55        | 1-5                 | Kirkpatrick et al. |
| 60        | 6-10                | Kirkpatrick et al. |
| > 65      | > 10                | Kirkpatrick et al. |

#### Brain Stem
- **Conventional Fractionation**:
  - D0.03cc < 54 Gy (QUANTEC)
  - D1cc < 50 Gy (QUANTEC)
- **Hypofractionation**:
  - D0.03cc < 31 Gy in 5 fractions (AAPM TG-101)
  - D0.03cc < 18 Gy in 1 fraction (AAPM TG-101)
- **Clinical Endpoint**: Neuropathy, brain stem necrosis

#### Optic Pathway (Chiasm, Nerves)
- **Conventional Fractionation**:
  - D0.03cc < 55 Gy (QUANTEC)
  - D0.2cc < 50 Gy (QUANTEC)
- **Hypofractionation**:
  - D0.03cc < 25 Gy in 5 fractions (AAPM TG-101)
  - D0.03cc < 12 Gy in 1 fraction (AAPM TG-101)
- **Clinical Endpoint**: Optic neuropathy, vision loss

#### Lens
- **Conventional Fractionation**:
  - Dmax < 10 Gy (QUANTEC)
- **Clinical Endpoint**: Cataract formation

#### Cochlea
- **Conventional Fractionation**:
  - Dmean < 45 Gy (QUANTEC)
  - Dmax < 55 Gy (QUANTEC)
- **Clinical Endpoint**: Hearing loss

### Section 2: Thoracic Structures

#### Lungs (combined)
- **Conventional Fractionation**:
  - V20Gy < 30% (QUANTEC)
  - V5Gy < 65% (QUANTEC)
  - Mean lung dose < 20 Gy (QUANTEC)
- **Hypofractionation**:
  - V20Gy < 10% in 5 fractions (RTOG 0813)
  - V12.5Gy < 15% in 5 fractions (RTOG 0813)
- **Clinical Endpoint**: Radiation pneumonitis (grade ≥ 2)
- **Dose-Response Relationship**:

$$NTCP = \frac{1}{1 + \left(\frac{TD_{50}}{MLD}\right)^{4\gamma_{50}}}$$

Where:
- NTCP is the normal tissue complication probability
- TD50 is the mean lung dose at which there is a 50% chance of pneumonitis (estimated at 30.8 Gy)
- γ50 is the slope of the dose-response curve at TD50 (estimated at 0.97)
- MLD is the mean lung dose

| Mean Lung Dose (Gy) | Pneumonitis Risk (%) | Study |
|---------------------|----------------------|-------|
| < 8                 | < 5                  | Marks et al. |
| 13                  | 10                   | Marks et al. |
| 20                  | 20                   | Marks et al. |
| 24                  | 30                   | Marks et al. |
| 27                  | 40                   | Marks et al. |

#### Heart
- **Conventional Fractionation**:
  - V25Gy < 10% (QUANTEC)
  - Mean heart dose < 26 Gy (QUANTEC)
- **Hypofractionation**:
  - V32Gy < 15 cc in 4 fractions (SABR)
  - Maximum dose < 38 Gy in 4 fractions (SABR)
- **Clinical Endpoint**: Pericarditis, long-term cardiac mortality

#### Esophagus
- **Conventional Fractionation**:
  - Mean dose < 34 Gy (QUANTEC)
  - V50Gy < 40% (QUANTEC)
  - V70Gy < 20% (QUANTEC)
- **Hypofractionation**:
  - Maximum dose < 30 Gy in 5 fractions (RTOG 0813)
- **Clinical Endpoint**: Acute esophagitis, stricture, perforation

### Section 3: Abdominal Structures

#### Liver
- **Conventional Fractionation**:
  - Mean dose to normal liver < 30 Gy (QUANTEC)
  - V30Gy < 40% of normal liver (QUANTEC)
- **Hypofractionation**:
  - ≥ 700 cc of normal liver receiving < 15 Gy in 3-5 fractions (RTOG 1112)
- **Clinical Endpoint**: Radiation-induced liver disease (RILD)

#### Kidneys (combined)
- **Conventional Fractionation**:
  - Mean dose < 18 Gy (QUANTEC)
  - V20Gy < 32% (QUANTEC)
  - At least 2/3 of one kidney < 20 Gy (QUANTEC)
- **Clinical Endpoint**: Renal dysfunction

#### Small Bowel
- **Conventional Fractionation**:
  - V45Gy < 195 cc (QUANTEC)
  - V15Gy < 120 cc (QUANTEC)
- **Hypofractionation**:
  - D5cc < 35 Gy in 5 fractions (AAPM TG-101)
  - Maximum point dose < 38 Gy in 5 fractions (AAPM TG-101)
- **Clinical Endpoint**: Grade 3+ enteritis, obstruction, perforation

### Section 4: Pelvic Structures

#### Rectum
- **Conventional Fractionation**:
  - V50Gy < 50% (QUANTEC)
  - V70Gy < 20% (QUANTEC)
  - V75Gy < 15% (QUANTEC)
- **Hypofractionation (Prostate SBRT)**:
  - V36Gy < 1 cc in 5 fractions (RTOG 0938)
  - V38Gy < 0.1 cc in 5 fractions (RTOG 0938)
- **Clinical Endpoint**: Grade 2+ rectal bleeding, proctitis

#### Bladder
- **Conventional Fractionation**:
  - V65Gy < 50% (QUANTEC)
  - V70Gy < 35% (QUANTEC)
  - V75Gy < 25% (QUANTEC)
- **Hypofractionation (Prostate SBRT)**:
  - V37Gy < 5 cc in 5 fractions (RTOG 0938)
  - V38Gy < 0.1 cc in 5 fractions (RTOG 0938)
- **Clinical Endpoint**: Grade 2+ cystitis, hematuria

#### Femoral Heads
- **Conventional Fractionation**:
  - V50Gy < 5% (QUANTEC)
  - Maximum dose < 55 Gy (QUANTEC)
- **Hypofractionation**:
  - Maximum dose < 30 Gy in 5 fractions (RTOG 0938)
- **Clinical Endpoint**: Necrosis, fracture

### Section 5: Stereotactic Radiosurgery (Single Fraction)

| Structure | Maximum Point Dose | Volume Constraint | Clinical Endpoint |
|-----------|-------------------|-------------------|-------------------|
| Brainstem | 15 Gy | V10Gy < 0.5 cc | Brainstem necrosis |
| Optic Pathway | 10 Gy | V8Gy < 0.2 cc | Vision loss |
| Cochlea | 12 Gy | Mean < 9 Gy | Hearing loss |
| Spinal Cord | 14 Gy | V10Gy < 0.35 cc | Myelopathy |
| Cauda Equina | 16 Gy | V12Gy < 1.5 cc | Neuropathy |
| Lens | 6 Gy | - | Cataract |
| Trigeminal Nerve | 12 Gy | - | Neuropathy |

### Section 6: Stereotactic Body Radiation Therapy (SBRT)

#### Lung SBRT (4-5 Fractions)

| Structure | Constraint | Protocol |
|-----------|------------|----------|
| Spinal Cord | D0.03cc < 30 Gy | RTOG 0813 |
| Brachial Plexus | D0.03cc < 32 Gy | RTOG 0813 |
| Heart | D0.03cc < 38 Gy | RTOG 0813 |
| Esophagus | D0.03cc < 35 Gy | RTOG 0813 |
| Trachea | D0.03cc < 38 Gy | RTOG 0813 |
| Great Vessels | D0.03cc < 45 Gy | RTOG 0813 |
| Lungs (combined) | V20Gy < 10% | RTOG 0813 |
| Lungs (combined) | V12.5Gy < 15% | RTOG 0813 |

#### Liver SBRT (3-5 Fractions)

| Structure | Constraint | Protocol |
|-----------|------------|----------|
| Normal Liver | ≥ 700 cc < 15 Gy | RTOG 1112 |
| Spinal Cord | D0.03cc < 18 Gy | RTOG 1112 |
| Kidneys (combined) | V12Gy < 25% | RTOG 1112 |
| Stomach | D0.03cc < 30 Gy | RTOG 1112 |
| Duodenum | D0.03cc < 24 Gy | RTOG 1112 |
| Small Bowel | D0.03cc < 24 Gy | RTOG 1112 |
| Esophagus | D0.03cc < 27 Gy | RTOG 1112 |
| Heart | D0.03cc < 30 Gy | RTOG 1112 |

## Clinical Implementation

### Scenario 1: Head and Neck IMRT Planning
When planning IMRT for a patient with oropharyngeal cancer receiving 70 Gy in 35 fractions:

1. Set spinal cord constraint as PRV D0.03cc < 50 Gy (with 3-5 mm PRV margin)
2. Set brainstem constraint as PRV D0.03cc < 54 Gy (with 3-5 mm PRV margin)
3. Set parotid gland constraint as mean dose < 26 Gy to at least one parotid
4. During optimization, prioritize spinal cord and brainstem constraints as mandatory
5. If parotid sparing compromises target coverage, accept mean doses up to 30 Gy
6. Document any constraints that could not be met and clinical justification

### Scenario 2: Lung SBRT Planning
When planning SBRT for a patient with early-stage lung cancer receiving 50 Gy in 5 fractions:

1. Set spinal cord constraint as D0.03cc < 30 Gy
2. Set heart constraint as D0.03cc < 38 Gy
3. Set lung constraint as V20Gy < 10% (combined lungs minus ITV)
4. During optimization, use a risk-adapted approach based on tumor location
5. For central tumors (within 2 cm of proximal bronchial tree), consider reducing dose to 50 Gy in 5 fractions
6. Document any constraints that could not be met and clinical justification

### Scenario 3: Prostate IMRT Planning
When planning IMRT for a patient with localized prostate cancer receiving 78 Gy in 39 fractions:

1. Set rectum constraints as V50Gy < 50%, V70Gy < 20%, and V75Gy < 15%
2. Set bladder constraints as V65Gy < 50%, V70Gy < 35%, and V75Gy < 25%
3. Set femoral head constraints as V50Gy < 5% and maximum dose < 55 Gy
4. Prioritize rectal constraints over bladder constraints when optimization trade-offs are necessary
5. For patients with large prostate volumes or unfavorable anatomy, consider accepting slightly higher rectal doses while maintaining V75Gy < 15%
6. Document any constraints that could not be met and clinical justification

## Biological Equivalent Dose Conversion

For hypofractionated regimens, the following formula can be used to estimate biological equivalent dose:

$$BED = nd \times \left(1 + \frac{d}{\alpha/\beta}\right)$$

Where:
- BED is the biologically equivalent dose
- n is the number of fractions
- d is the dose per fraction
- α/β is the tissue-specific parameter (typically 3 Gy for late-responding normal tissues and 10 Gy for tumors and early-responding tissues)

| Structure | α/β Ratio (Gy) | Reference |
|-----------|----------------|-----------|
| Spinal Cord | 2 | Kirkpatrick et al. |
| Brain | 2.9 | Lawrence et al. |
| Optic Pathway | 1.6 | Mayo et al. |
| Lung | 3-4 | Marks et al. |
| Heart | 2-3 | Gagliardi et al. |
| Rectum | 3.9 | Michalski et al. |
| Bladder | 5-10 | Viswanathan et al. |

### Example Calculation
To convert a conventional constraint (e.g., spinal cord D0.03cc < 50 Gy in 25 fractions) to a hypofractionated regimen (e.g., 5 fractions):

1. Calculate BED for conventional constraint:
   - BED = 25 × 2 × (1 + 2/2) = 50 × 2 = 100 Gy₂

2. Determine equivalent dose in 5 fractions:
   - 100 = 5 × d × (1 + d/2)
   - Solving for d: d ≈ 6 Gy per fraction
   - Total dose: 5 × 6 = 30 Gy in 5 fractions

## References
1. Marks LB, Yorke ED, Jackson A, et al. Use of normal tissue complication probability models in the clinic. Int J Radiat Oncol Biol Phys. 2010;76(3 Suppl):S10-S19.
2. Benedict SH, Yenice KM, Followill D, et al. Stereotactic body radiation therapy: the report of AAPM Task Group 101. Med Phys. 2010;37(8):4078-4101.
3. Emami B, Lyman J, Brown A, et al. Tolerance of normal tissue to therapeutic irradiation. Int J Radiat Oncol Biol Phys. 1991;21(1):109-122.
4. RTOG 0813: Seamless Phase I/II Study of Stereotactic Lung Radiotherapy (SBRT) for Early Stage, Centrally Located, Non-Small Cell Lung Cancer.
5. RTOG 1112: Randomized Phase III Study of Sorafenib versus Stereotactic Body Radiation Therapy followed by Sorafenib in Hepatocellular Carcinoma.
6. RTOG 0938: A Randomized Phase II Trial of Hypofractionated Radiotherapy for Favorable Risk Prostate Cancer.

## Version History
- Version 1.0 (April 10, 2025): Initial release
- Version 1.1 (May 15, 2025): Updated with RTOG 0915 constraints
