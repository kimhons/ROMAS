# Radiation Oncology Academy - Project Setup

This document outlines the steps to set up the development environment for the Radiation Oncology Academy website.

## Technology Stack

- **Frontend**: Next.js with React
- **Styling**: Tailwind CSS
- **Backend**: Node.js with Express
- **Database**: MongoDB
- **Authentication**: JWT-based auth
- **Payment Processing**: Stripe and PayPal
- **API Integrations**: OpenAI, ElevenLabs, Google STT

## Development Environment Setup

### Prerequisites

- Node.js (v18+)
- npm or yarn
- Git
- MongoDB (local or Atlas)

### Project Initialization

1. Create a new Next.js project with the app router:

```bash
npx create-next-app@latest radiation-oncology-academy
```

Options to select:
- Would you like to use TypeScript? Yes
- Would you like to use ESLint? Yes
- Would you like to use Tailwind CSS? Yes
- Would you like to use `src/` directory? Yes
- Would you like to use App Router? Yes
- Would you like to customize the default import alias? No

2. Navigate to the project directory:

```bash
cd radiation-oncology-academy
```

3. Install additional dependencies:

```bash
npm install axios mongoose jsonwebtoken bcryptjs stripe @stripe/stripe-js @paypal/react-paypal-js
npm install openai @elevenlabs/api @google-cloud/speech
npm install react-icons react-markdown next-auth
npm install -D prettier prettier-plugin-tailwindcss
```

4. Set up environment variables by creating a `.env.local` file:

```
# Base URLs
NEXT_PUBLIC_BASE_URL=http://localhost:3000
API_BASE_URL=http://localhost:3000/api

# MongoDB
MONGODB_URI=mongodb://localhost:27017/radiation-oncology-academy
# or for MongoDB Atlas
# MONGODB_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/radiation-oncology-academy

# Authentication
JWT_SECRET=your_jwt_secret_key
NEXTAUTH_SECRET=your_nextauth_secret
NEXTAUTH_URL=http://localhost:3000

# Payment Processing
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret

# API Integrations
OPENAI_API_KEY=your_openai_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
GOOGLE_APPLICATION_CREDENTIALS=path_to_google_credentials_json
```

5. Create a basic folder structure:

```bash
mkdir -p src/app/api
mkdir -p src/components
mkdir -p src/lib
mkdir -p src/models
mkdir -p src/hooks
mkdir -p src/utils
mkdir -p public/images
```

## Project Structure

```
radiation-oncology-academy/
├── public/
│   ├── images/
│   └── ...
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   ├── blog/
│   │   │   ├── courses/
│   │   │   ├── membership/
│   │   │   └── ...
│   │   ├── (auth)/
│   │   │   ├── login/
│   │   │   ├── register/
│   │   │   └── ...
│   │   ├── dashboard/
│   │   ├── courses/
│   │   ├── blog/
│   │   ├── podcast/
│   │   ├── membership/
│   │   ├── about/
│   │   ├── contact/
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/
│   │   ├── common/
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Navbar.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── ...
│   │   ├── dashboard/
│   │   ├── courses/
│   │   ├── blog/
│   │   ├── podcast/
│   │   └── ...
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useCourses.ts
│   │   └── ...
│   ├── lib/
│   │   ├── db.ts
│   │   ├── api.ts
│   │   └── ...
│   ├── models/
│   │   ├── User.ts
│   │   ├── Course.ts
│   │   ├── Lesson.ts
│   │   ├── Quiz.ts
│   │   ├── Subscription.ts
│   │   └── ...
│   └── utils/
│       ├── auth.ts
│       ├── formatting.ts
│       └── ...
├── .env.local
├── .gitignore
├── next.config.js
├── package.json
├── tailwind.config.js
└── tsconfig.json
```

## Database Schema Setup

Create MongoDB schema models based on the database_schema.md document. The main models will include:

- User
- Subscription
- Track
- Module
- Lesson
- Quiz
- Question
- BlogPost
- Podcast
- UserProgress

## Configuration Files

### Tailwind Configuration

Update `tailwind.config.js` to include custom colors and extend the theme:

```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          200: '#bae6fd',
          300: '#7dd3fc',
          400: '#38bdf8',
          500: '#0ea5e9',
          600: '#0284c7',
          700: '#0369a1',
          800: '#075985',
          900: '#0c4a6e',
          950: '#082f49',
        },
        secondary: {
          50: '#f0fdfa',
          100: '#ccfbf1',
          200: '#99f6e4',
          300: '#5eead4',
          400: '#2dd4bf',
          500: '#14b8a6',
          600: '#0d9488',
          700: '#0f766e',
          800: '#115e59',
          900: '#134e4a',
          950: '#042f2e',
        },
        accent: {
          50: '#fff7ed',
          100: '#ffedd5',
          200: '#fed7aa',
          300: '#fdba74',
          400: '#fb923c',
          500: '#f97316',
          600: '#ea580c',
          700: '#c2410c',
          800: '#9a3412',
          900: '#7c2d12',
          950: '#431407',
        },
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'sans-serif'],
        heading: ['var(--font-montserrat)', 'sans-serif'],
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
      },
      boxShadow: {
        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'card': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
      },
    },
  },
  plugins: [],
}
```

### Next.js Configuration

Update `next.config.js` to include any necessary configurations:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['res.cloudinary.com', 'images.unsplash.com'],
  },
  async redirects() {
    return [
      {
        source: '/dashboard',
        destination: '/login',
        permanent: false,
        missing: [
          {
            type: 'cookie',
            key: 'auth_token',
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
```

## API Routes Structure

The API routes will be organized as follows:

```
/api/auth - Authentication endpoints
/api/users - User management
/api/tracks - Learning tracks
/api/modules - Educational modules
/api/lessons - Individual lessons
/api/quizzes - Quiz and assessment
/api/blog - Blog content
/api/podcast - Podcast content
/api/subscriptions - Membership management
/api/progress - User progress tracking
/api/content-generator - AI content generation
```

## Next Steps

After setting up the project structure:

1. Implement the core components (Navbar, Footer, Layout)
2. Create the homepage and main public pages
3. Set up authentication system
4. Implement the dashboard interface
5. Develop the course viewing experience
6. Create the membership system
7. Integrate the payment processing
8. Implement the content generation APIs
