# Assessment Report: Section 4.9 - Modality Comparison, Image Features and Artifacts (SPECT vs. PET)

**Date:** 2025-04-29

**Assessed Section:** Medical Physics Part 1, Section 4, Subsection 9: Modality Comparison, Image Features and Artifacts (SPECT vs. PET) (`/home/ubuntu/nm_modality_comparison_draft.md`)

**Evaluation Rubric Used:** `/home/ubuntu/curriculum/lesson_evaluation_rubric.md`

**Quality Threshold:** 58.6 / 60 (97.7%)

**Assessment Summary:**

The draft provides an excellent and comprehensive comparison between SPECT and PET imaging. It clearly articulates the fundamental differences in principles, instrumentation, performance, image quality, artifacts, clinical roles, and quantitative capabilities. The content is accurate, well-organized, and presented at an appropriate graduate level, directly addressing the comparative nature of the topic.

**Scores per Criterion:**

| Criteria                             | Score (out of 5) | Comments |
| :----------------------------------- | :--------------- | :------- |
| 1. Learning Objectives               | 5                | Objectives are exceptionally clear, measurable, and directly focused on comparing and contrasting SPECT and PET across various aspects, aligning perfectly with CAMPEP/ABR expectations for this topic. |
| 2. Key Points for Understanding      | 5                | Key points effectively summarize the critical distinctions between the two modalities in terms of principles, sensitivity, resolution, quantification, and clinical use. |
| 3. Accuracy & Completeness           | 5                | Information is accurate, current, and provides a thorough comparison covering all essential aspects, including principles, instrumentation, performance, image quality, artifacts, applications, and quantification. |
| 4. Theoretical Depth                 | 5                | Explains the underlying physics driving the differences (e.g., physical vs. electronic collimation, detector physics, photon energies) at a solid graduate level. |
| 5. Equations & Mathematical Content | 5                | While not equation-heavy, relevant concepts like sensitivity units (cps/MBq) and resolution metrics (FWHM) are used appropriately. The focus is on conceptual comparison, which is well-executed. |
| 6. Clinical Relevance & Application | 5                | Excellent discussion of the clinical strengths, weaknesses, and typical applications of each modality, providing practical context for the technical differences. |
| 7. Practical Examples & Case Studies | 5                | Effectively uses comparative examples throughout (e.g., comparing sensitivity values, resolution limits, specific artifacts, typical clinical scenarios) to illustrate practical differences. |
| 8. Illustrations & Visual Elements   | 4                | Placeholder included. The suggested illustrations comparing collimation, sensitivity, resolution, and specific artifacts are highly relevant and will significantly enhance understanding. |
| 9. Assessment Questions              | 5                | Diverse ABR-style questions effectively test understanding of the key comparative points regarding principles, performance, artifacts, and quantification. Solutions are clear. |
| 10. Clarity & Organization          | 5                | Content is very clearly organized, using tables and parallel structure to effectively compare SPECT and PET across different categories. Language is precise. |
| 11. Self-Contained Nature           | 5                | Provides a comprehensive, self-contained comparison, serving as an excellent primary resource for understanding the differences between SPECT and PET. |
| 12. Alignment with CAMPEP/ABR       | 5                | Thoroughly covers CAMPEP/ABR requirements related to comparing and contrasting SPECT and PET systems, performance, and applications. |

**Overall Score:** **59 / 60 (98.3%)**

**Conclusion:**

The section score **exceeds** the quality threshold of 58.6/60.

**Recommendation:**

No revisions are required. The section is ready for integration into the main curriculum document.
